import * as THREE from 'three';
import { StoryCompanion } from '../../types/prologue';
import { getTerrainHeight } from '../Terrain';
import { soundEngine } from '../../utils/audio';
import { UnifiedPhysicsManager } from '../physics/UnifiedPhysicsManager';
import { ApartmentBuilding } from './ApartmentBuilding';

export class StoryCompanionManager {
  public scene: THREE.Scene;
  public group: THREE.Group;
  public companions: Map<'marcus' | 'chloe' | 'maya', StoryCompanion> = new Map();
  public companionMeshes: Map<'marcus' | 'chloe' | 'maya', THREE.Group> = new Map();
  private walkTime: number = 0;
  private gestureTimers = new Map<string, number>();

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.group = new THREE.Group();
    this.group.name = 'story_companions';
    this.scene.add(this.group);

    this.initCompanions();
  }

  private initCompanions() {
    const friendDefs: StoryCompanion[] = [
      {
        id: 'marcus',
        name: 'Marcus Cole',
        title: 'The Leader',
        role: 'Leader',
        color: 0x1f3b60,
        jacketColor: 0x223a5e,
        pantColor: 0x1c2128,
        hairColor: 0x1a1a1a,
        position: [-10, 0, 16],
        rotationY: Math.PI / 4,
        health: 150,
        maxHealth: 150,
        dialogueState: 0,
        isFollowing: false,
        station: 'town',
        relationshipScore: 80,
      },
      {
        id: 'chloe',
        name: 'Chloe Miller',
        title: 'The Technician',
        role: 'Technician',
        color: 0xd9822b,
        jacketColor: 0xd47a22,
        pantColor: 0x3d434a,
        hairColor: 0x5c2c16,
        position: [-11.5, 0, 17.5],
        rotationY: 0,
        health: 100,
        maxHealth: 100,
        dialogueState: 0,
        isFollowing: false,
        station: 'town',
        relationshipScore: 85,
      },
      {
        id: 'maya',
        name: 'Dr. Maya Lin',
        title: 'The Medic',
        role: 'Medic',
        color: 0x2e8b57,
        jacketColor: 0x2b7a4c,
        pantColor: 0xe6e6e6,
        hairColor: 0x111111,
        position: [-9, 0, 18],
        rotationY: -Math.PI / 3,
        health: 120,
        maxHealth: 120,
        dialogueState: 0,
        isFollowing: false,
        station: 'town',
        relationshipScore: 90,
      },
    ];

    friendDefs.forEach((c) => {
      c.isFriend = c.isFriend ?? true;
      this.companions.set(c.id, c);
      const mesh = this.createCompanionMesh(c);
      mesh.name = `companion_${c.id}`;
      mesh.position.set(c.position[0], getTerrainHeight(c.position[0], c.position[2]), c.position[2]);
      mesh.rotation.y = c.rotationY;
      this.group.add(mesh);
      this.companionMeshes.set(c.id, mesh);
    });
  }

  private createCompanionMesh(c: StoryCompanion): THREE.Group {
    // Match the playable survivor's exact block-proportion anatomy, PBR materials, and pivot points.
    const g = new THREE.Group();
    const skinMat = new THREE.MeshStandardMaterial({ color: 0xdeb887, roughness: 0.7 });
    const jacketMat = new THREE.MeshStandardMaterial({ color: c.jacketColor, roughness: 0.85 });
    const pantsMat = new THREE.MeshStandardMaterial({ color: c.pantColor, roughness: 0.9 });
    const bootsMat = new THREE.MeshStandardMaterial({ color: 0x1b1b1b, roughness: 0.6 });
    const bandanaMat = new THREE.MeshStandardMaterial({ color: c.color, roughness: 0.8 });
    const packMat = new THREE.MeshStandardMaterial({ color: 0x2b3126, roughness: 0.9 });

    // 1. Torso & Tactical Outerwear
    const torso = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.75, 0.32), jacketMat);
    torso.position.y = 1.15;
    torso.castShadow = true;
    torso.receiveShadow = true;
    torso.name = 'torso';

    // Tactical Backpack on back (+Z)
    const pack = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.5, 0.22), packMat);
    pack.position.set(0, 1.2, 0.22);
    pack.castShadow = true;
    pack.name = 'backpack';

    // 2. Head & Hair
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.35, 0.35), skinMat);
    head.position.y = 1.7;
    head.castShadow = true;
    head.name = 'head';

    const hairMat = new THREE.MeshStandardMaterial({ color: c.hairColor, roughness: 0.88 });
    const hair = new THREE.Mesh(new THREE.BoxGeometry(0.37, 0.1, 0.37), hairMat);
    hair.position.set(0, 1.88, 0.015);
    hair.castShadow = true;

    const bandana = new THREE.Mesh(new THREE.BoxGeometry(0.37, 0.1, 0.37), bandanaMat);
    bandana.position.y = 1.8;

    // Face / Eyes
    const eyeMat = new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.5 });
    for (const x of [-0.085, 0.085]) {
      const eye = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.04, 0.02), eyeMat);
      eye.position.set(x, 1.72, -0.181);
      g.add(eye);
    }

    // 3. Left Arm (both 'leftArm' and 'lArm' alias support)
    const armGeo = new THREE.BoxGeometry(0.15, 0.65, 0.15);
    armGeo.translate(0, -0.28, 0);

    const lArm = new THREE.Mesh(armGeo, jacketMat);
    lArm.name = 'leftArm';
    lArm.position.set(-0.35, 1.45, 0);
    lArm.castShadow = true;

    // 4. Right Arm (both 'rightArm' and 'rArm' alias support)
    const rArm = new THREE.Mesh(armGeo.clone(), jacketMat);
    rArm.name = 'rightArm';
    rArm.position.set(0.35, 1.45, 0);
    rArm.rotation.x = -Math.PI / 4;
    rArm.castShadow = true;

    // 5. Left Leg & Boot
    const legGeo = new THREE.BoxGeometry(0.18, 0.75, 0.18);
    legGeo.translate(0, -0.37, 0);

    const lLeg = new THREE.Mesh(legGeo, pantsMat);
    lLeg.name = 'leftLeg';
    lLeg.position.set(-0.15, 0.75, 0);
    lLeg.castShadow = true;

    const bootL = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.18, 0.26), bootsMat);
    bootL.position.set(0, -0.68, -0.04);
    bootL.castShadow = true;
    lLeg.add(bootL);

    // 6. Right Leg & Boot
    const rLeg = new THREE.Mesh(legGeo.clone(), pantsMat);
    rLeg.name = 'rightLeg';
    rLeg.position.set(0.15, 0.75, 0);
    rLeg.castShadow = true;

    const bootR = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.18, 0.26), bootsMat);
    bootR.position.set(0, -0.68, -0.04);
    bootR.castShadow = true;
    rLeg.add(bootR);

    // Role-specific high-fidelity equipment
    if (c.id === 'chloe') {
      // Communications headset and radio harness
      const headset = new THREE.Mesh(
        new THREE.TorusGeometry(0.19, 0.025, 6, 12, Math.PI),
        new THREE.MeshStandardMaterial({ color: 0x1f2428, metalness: 0.8, roughness: 0.2 })
      );
      headset.position.set(0, 1.72, 0);
      headset.rotation.x = Math.PI / 2;
      g.add(headset);

      const radio = new THREE.Mesh(
        new THREE.BoxGeometry(0.1, 0.18, 0.08),
        new THREE.MeshStandardMaterial({ color: 0x222222, metalness: 0.7 })
      );
      radio.position.set(0.22, 1.25, -0.17);
      g.add(radio);
    } else if (c.id === 'maya') {
      // Medic arm badge and medical utility cross
      const badge = new THREE.Mesh(
        new THREE.PlaneGeometry(0.14, 0.14),
        new THREE.MeshBasicMaterial({ color: 0xee2222, side: THREE.DoubleSide })
      );
      badge.position.set(-0.28, 1.15, 0.05);
      badge.rotation.y = -Math.PI / 2;
      g.add(badge);

      const crossH = new THREE.Mesh(new THREE.PlaneGeometry(0.1, 0.03), new THREE.MeshBasicMaterial({ color: 0xffffff }));
      crossH.position.set(-0.281, 1.15, 0.05); crossH.rotation.y = -Math.PI / 2;
      const crossV = new THREE.Mesh(new THREE.PlaneGeometry(0.03, 0.1), new THREE.MeshBasicMaterial({ color: 0xffffff }));
      crossV.position.set(-0.281, 1.15, 0.05); crossV.rotation.y = -Math.PI / 2;
      g.add(crossH, crossV);
    } else {
      // Marcus: tactical utility belt and holster
      const belt = new THREE.Mesh(
        new THREE.CylinderGeometry(0.28, 0.28, 0.08, 12),
        new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.6, roughness: 0.4 })
      );
      belt.position.y = 0.78;
      const buckle = new THREE.Mesh(
        new THREE.BoxGeometry(0.08, 0.09, 0.02),
        new THREE.MeshStandardMaterial({ color: 0xc0c0c0, metalness: 0.9, roughness: 0.2 })
      );
      buckle.position.set(0, 0.78, -0.285);
      g.add(belt, buckle);
    }

    g.add(torso, pack, head, hair, bandana, lArm, rArm, lLeg, rLeg);
    return g;
  }

  private getLimb(mesh: THREE.Group, name: 'leftArm' | 'rightArm' | 'leftLeg' | 'rightLeg'): THREE.Object3D | null {
    const aliasMap = {
      leftArm: ['leftArm', 'lArm'],
      rightArm: ['rightArm', 'rArm'],
      leftLeg: ['leftLeg', 'lLeg'],
      rightLeg: ['rightLeg', 'rLeg'],
    };
    for (const id of aliasMap[name]) {
      const obj = mesh.getObjectByName(id);
      if (obj) return obj;
    }
    return null;
  }

  public update(delta: number, playerPos: THREE.Vector3, isEscapeOrShelter: boolean, apartment?: ApartmentBuilding) {
    this.walkTime += delta;

    // Formation offsets when following player
    const formationOffsets: Record<'marcus' | 'chloe' | 'maya', THREE.Vector3> = {
      marcus: new THREE.Vector3(1.6, 0, 1.8),
      chloe: new THREE.Vector3(-1.6, 0, 1.8),
      maya: new THREE.Vector3(0, 0, 3.2),
    };

    this.companions.forEach((c, id) => {
      const mesh = this.companionMeshes.get(id);
      if (!mesh) return;

      const gestureLeft = this.gestureTimers.get(id);
      const gestureActive = gestureLeft !== undefined && gestureLeft > 0;

      if (gestureActive) {
        const next = gestureLeft - delta;
        if (next <= 0) {
          this.gestureTimers.delete(id);
          const lA = this.getLimb(mesh, 'leftArm');
          const rA = this.getLimb(mesh, 'rightArm');
          const lL = this.getLimb(mesh, 'leftLeg');
          const rL = this.getLimb(mesh, 'rightLeg');
          if (lA) lA.rotation.set(0, 0, 0);
          if (rA) rA.rotation.set(-Math.PI / 4, 0, 0);
          if (lL) lL.rotation.set(0, 0, 0);
          if (rL) rL.rotation.set(0, 0, 0);
        } else {
          this.gestureTimers.set(id, next);

          // Active continuous gesture animation
          const lA = this.getLimb(mesh, 'leftArm');
          const rA = this.getLimb(mesh, 'rightArm');
          const lL = this.getLimb(mesh, 'leftLeg');
          const rL = this.getLimb(mesh, 'rightLeg');

          const gestureType = (mesh.userData.activeGesture as string) || 'handshake';
          if (gestureType === 'handshake') {
            const pump = Math.sin(this.walkTime * 12) * 0.15;
            if (rA) {
              rA.rotation.x = -1.15 + pump;
              rA.rotation.z = -0.32;
            }
            if (lA) lA.rotation.x = 0.12;
          } else if (gestureType === 'clap') {
            const clapCycle = Math.sin(this.walkTime * 14);
            if (lA) {
              lA.rotation.x = -1.2;
              lA.rotation.z = -0.35 + clapCycle * 0.22;
            }
            if (rA) {
              rA.rotation.x = -1.2;
              rA.rotation.z = 0.35 - clapCycle * 0.22;
            }
          } else if (gestureType === 'dance') {
            const danceWave = Math.sin(this.walkTime * 8);
            const danceBeat = Math.sin(this.walkTime * 16);
            if (lA) {
              lA.rotation.x = danceBeat * 0.3;
              lA.rotation.z = 0.75 + danceWave * 0.35;
            }
            if (rA) {
              rA.rotation.x = -danceBeat * 0.3;
              rA.rotation.z = -0.75 - danceWave * 0.35;
            }
            if (lL) lL.rotation.x = danceWave * 0.38;
            if (rL) rL.rotation.x = -danceWave * 0.38;
          }
        }
      }

      if (c.isFollowing && !gestureActive) {
        const offset = formationOffsets[id];
        const targetX = playerPos.x + offset.x;
        const targetZ = playerPos.z + offset.z;
        const formationTarget = new THREE.Vector3(targetX, playerPos.y, targetZ);
        const legalWaypoint = apartment?.getCompanionNavigationWaypoint(mesh.position, formationTarget) ?? null;
        const navigationTarget = legalWaypoint ?? formationTarget;

        const dx = navigationTarget.x - mesh.position.x;
        const dz = navigationTarget.z - mesh.position.z;
        const dist = Math.hypot(dx, dz);

        const lLeg = this.getLimb(mesh, 'leftLeg');
        const rLeg = this.getLimb(mesh, 'rightLeg');
        const lArm = this.getLimb(mesh, 'leftArm');
        const rArm = this.getLimb(mesh, 'rightArm');

        if (dist > 0.45) {
          const moveSpeed = isEscapeOrShelter ? 6.2 : 4.0;
          const step = Math.min(dist, delta * moveSpeed);
          const angle = Math.atan2(dx, dz);

          const desiredPos = new THREE.Vector3(
            mesh.position.x + Math.sin(angle) * step,
            mesh.position.y,
            mesh.position.z + Math.cos(angle) * step
          );

          const phys = UnifiedPhysicsManager.getInstance();
          if (phys) {
            const resolved = phys.resolveMovement(mesh.position, desiredPos, 0.35, 1.8, `companion_${id}`);
            mesh.position.x = resolved.resolvedPos.x;
            mesh.position.z = resolved.resolvedPos.z;
          } else {
            mesh.position.x = desiredPos.x;
            mesh.position.z = desiredPos.z;
          }
          mesh.rotation.y = angle;

          // Leg & arm walk swing
          const cycle = Math.sin(this.walkTime * 12 * (moveSpeed / 4));
          if (lLeg && rLeg) {
            lLeg.rotation.x = cycle * 0.6;
            rLeg.rotation.x = -cycle * 0.6;
          }
          if (lArm && rArm) {
            lArm.rotation.x = -cycle * 0.5;
            rArm.rotation.x = cycle * 0.5;
          }
        } else {
          // Idle posture
          if (lLeg && rLeg) {
            lLeg.rotation.x = THREE.MathUtils.damp(lLeg.rotation.x, 0, 10, delta);
            rLeg.rotation.x = THREE.MathUtils.damp(rLeg.rotation.x, 0, 10, delta);
          }
          if (lArm && rArm) {
            lArm.rotation.x = THREE.MathUtils.damp(lArm.rotation.x, 0, 10, delta);
            rArm.rotation.x = THREE.MathUtils.damp(rArm.rotation.x, 0, 10, delta);
          }
        }
      }

      mesh.position.y =
        apartment?.getCompanionSurfaceHeight(mesh.position, mesh.position.y, playerPos.y) ??
        getTerrainHeight(mesh.position.x, mesh.position.z);
      c.position = [mesh.position.x, mesh.position.y, mesh.position.z];
      c.rotationY = mesh.rotation.y;

      const physMgr = UnifiedPhysicsManager.getInstance();
      if (physMgr) {
        physMgr.updateColliderPosition(`companion_${id}`, mesh.position, mesh.rotation.y);
      }
    });
  }

  public registerColliders(physMgr: UnifiedPhysicsManager) {
    this.companions.forEach((c) => {
      physMgr.registerCylinderCollider(`companion_${c.id}`, 'companion', c.position, 0.45, 1.85);
    });
  }

  public setAllFollowing(following: boolean) {
    this.companions.forEach((c) => {
      c.isFollowing = following;
    });
  }

  public teleportTo(id: 'marcus' | 'chloe' | 'maya', pos: [number, number, number], rotY: number) {
    const c = this.companions.get(id);
    const mesh = this.companionMeshes.get(id);
    if (c && mesh) {
      c.position = [...pos];
      c.rotationY = rotY;
      mesh.position.set(pos[0], pos[1], pos[2]);
      mesh.rotation.y = rotY;
    }
  }

  public playFriendGesture(id: 'marcus' | 'chloe' | 'maya', gesture: 'handshake' | 'clap' | 'dance') {
    const mesh = this.companionMeshes.get(id);
    if (!mesh) return false;
    mesh.userData.activeGesture = gesture;
    this.gestureTimers.set(id, gesture === 'dance' ? 60 : 3.0);
    soundEngine.playUIClick();
    return true;
  }

  public stopFriendGesture(id: 'marcus' | 'chloe' | 'maya') {
    this.gestureTimers.delete(id);
    const mesh = this.companionMeshes.get(id);
    if (!mesh) return false;
    mesh.userData.activeGesture = undefined;
    const lA = this.getLimb(mesh, 'leftArm');
    const rA = this.getLimb(mesh, 'rightArm');
    const lL = this.getLimb(mesh, 'leftLeg');
    const rL = this.getLimb(mesh, 'rightLeg');
    if (lA) lA.rotation.set(0, 0, 0);
    if (rA) rA.rotation.set(-Math.PI / 4, 0, 0);
    if (lL) lL.rotation.set(0, 0, 0);
    if (rL) rL.rotation.set(0, 0, 0);
    return true;
  }

  public setFriendFollowing(id: 'marcus' | 'chloe' | 'maya', following: boolean) {
    const c = this.companions.get(id);
    if (!c) return false;
    c.isFollowing = following;
    return true;
  }

  public toggleCompanionFollowing(id: 'marcus' | 'chloe' | 'maya'): boolean {
    const c = this.companions.get(id);
    if (!c) return false;
    c.isFollowing = !c.isFollowing;
    soundEngine.playUIClick();
    return c.isFollowing;
  }

  public regroupAll(playerPos: THREE.Vector3) {
    this.companions.forEach((c) => {
      c.isFollowing = true;
    });
    soundEngine.playBuildSnap();
  }

  public getNearestCompanion(pos: THREE.Vector3, maxDist = 3.5): StoryCompanion | null {
    let nearest: StoryCompanion | null = null;
    let minDist = maxDist;
    this.companions.forEach((c) => {
      const d = Math.hypot(c.position[0] - pos.x, c.position[2] - pos.z);
      if (d < minDist) {
        minDist = d;
        nearest = c;
      }
    });
    return nearest;
  }

  public dispose() {
    this.scene.remove(this.group);
    this.group.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        child.geometry.dispose();
        if (Array.isArray(child.material)) child.material.forEach((m) => m.dispose());
        else child.material.dispose();
      }
    });
    this.companions.clear();
    this.companionMeshes.clear();
  }
}
