import React, { useState, useEffect } from 'react';
import { soundEngine } from '../utils/audio';
import { stationAnnouncementSystem, StationAnnouncement } from '../engine/world/MultilingualAnnouncementSystem';

interface RailwayStationHUDProps {
  isVisible: boolean;
  activeTrainInfo?: {
    trainNumber: string;
    trainName: string;
    route: string;
    status: string;
    platform: number;
    countdownSeconds?: number;
  } | null;
  currentFloor: number; // 0, 1, 2, 3, 4
  onSelectFloor: (floor: 0 | 1 | 2 | 3 | 4) => void;
  onNavigateToFacility: (facilityType: 'restaurant' | 'shops' | 'medical' | 'police' | 'toilets' | 'lifts' | 'escalators') => void;
  onOpenTickets: () => void;
  onOpenOperations: () => void;
  onOpenMap: () => void;
  onOpenJourney: () => void;
  onOpenPause?: () => void;
  activeFacilityWaypoint?: { label: string; distanceMeters: number } | null;
}

export const RailwayStationHUD: React.FC<RailwayStationHUDProps> = ({
  isVisible,
  activeTrainInfo,
  currentFloor,
  onSelectFloor,
  onNavigateToFacility,
  onOpenTickets,
  onOpenOperations,
  onOpenMap,
  onOpenJourney,
  onOpenPause,
  activeFacilityWaypoint,
}) => {
  const [announcement, setAnnouncement] = useState<StationAnnouncement | null>(null);
  const [isLanguageHindi, setIsLanguageHindi] = useState(false);

  useEffect(() => {
    const unsubscribe = stationAnnouncementSystem.subscribe((anno) => {
      setAnnouncement(anno);
    });
    return unsubscribe;
  }, []);

  // Alternate announcement language between Hindi and English every 4 seconds
  useEffect(() => {
    if (!announcement) return;
    const timer = setInterval(() => {
      setIsLanguageHindi((prev) => !prev);
    }, 4000);
    return () => clearInterval(timer);
  }, [announcement]);

  if (!isVisible) return null;

  const floorCards = [
    {
      level: 4,
      title: 'Level 4',
      sub: 'Helipad & Solar',
      elevation: '14.50m',
      icon: (
        <svg className="w-6 h-6 text-violet-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M12 3v3m0 12v3m9-9h-3M6 12H3m15.364 6.364l-2.121-2.121M8.757 8.757L6.636 6.636m12.728 0l-2.121 2.121M8.757 15.243l-2.121 2.121M12 8a4 4 0 100 8 4 4 0 000-8z" />
        </svg>
      ),
      bgGradient: 'from-violet-950/70 to-slate-900/80',
    },
    {
      level: 3,
      title: 'Level 3',
      sub: 'Skywalks & Bridge',
      elevation: '9.80m',
      icon: (
        <svg className="w-6 h-6 text-sky-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M3 10h18M3 14h18m-9-4v8m-6-4h12" />
        </svg>
      ),
      bgGradient: 'from-sky-950/70 to-slate-900/80',
    },
    {
      level: 2,
      title: 'Level 2',
      sub: 'Lounge Area',
      elevation: '4.70m',
      icon: (
        <svg className="w-6 h-6 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
        </svg>
      ),
      bgGradient: 'from-amber-950/70 to-slate-900/80',
    },
    {
      level: 1,
      title: 'Level 1',
      sub: 'Waiting Hall',
      elevation: '4.70m',
      icon: (
        <svg className="w-6 h-6 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
        </svg>
      ),
      bgGradient: 'from-emerald-950/70 to-slate-900/80',
    },
    {
      level: 0,
      title: 'Level 0',
      sub: 'Main Entrance',
      elevation: '0.27m',
      icon: (
        <svg className="w-6 h-6 text-rose-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z" />
        </svg>
      ),
      bgGradient: 'from-rose-950/70 to-slate-900/80',
    },
  ] as const;

  return (
    <div className="pointer-events-none fixed inset-0 z-30 flex flex-col justify-between p-3 select-none">
      
      {/* ========================================================================= */}
      {/* 1. TOP HEADER: Station Badge & Live Game Top-Bar */}
      {/* ========================================================================= */}
      <div className="flex items-start justify-between">
        
        {/* Left Side: Game Title & Station Overview Badge */}
        <div className="pointer-events-auto flex flex-col gap-2">
          <div className="bg-slate-950/85 backdrop-blur-md border border-amber-500/40 rounded-xl p-3 shadow-2xl max-w-xs">
            <div className="flex items-center gap-2">
              <span className="flex h-3 w-3 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
              <div>
                <div className="text-[11px] font-black uppercase tracking-wider text-red-500 font-mono">
                  LAST SANCTUARY <span className="text-white">REBIRTH</span>
                </div>
                <h1 className="text-white text-xs font-bold tracking-wider uppercase font-mono">
                  Mega Railway Station
                </h1>
              </div>
            </div>

            <div className="mt-2 grid grid-cols-1 gap-1 text-[11px] text-slate-300">
              <div className="flex items-center gap-1.5">
                <span className="text-emerald-400 font-bold">✓</span>
                <span>4 Levels • 4 Elevators</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-emerald-400 font-bold">✓</span>
                <span>8 Island Platforms</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-emerald-400 font-bold">✓</span>
                <span>World Railway Network</span>
              </div>
            </div>
          </div>
        </div>

        {/* Center: Multilingual Station Announcement Ticker */}
        {announcement && (
          <div className="pointer-events-auto max-w-xl mx-4 bg-gradient-to-r from-red-950/90 via-slate-950/95 to-red-950/90 border border-amber-500/50 rounded-xl p-2.5 shadow-2xl backdrop-blur-md flex items-center gap-3 animate-fade-in">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-red-600/30 border border-red-500/40 text-amber-400">
              <svg className="w-5 h-5 animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
              </svg>
            </div>
            <div className="flex-1 overflow-hidden">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  {isLanguageHindi ? 'सार्वजनिक घोषणा' : 'Public Announcement'}
                </span>
                {announcement.platformNumber && (
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30">
                    Platform {announcement.platformNumber}
                  </span>
                )}
              </div>
              <p className="text-xs font-medium text-white tracking-wide mt-0.5 truncate">
                {isLanguageHindi ? announcement.hindiText : announcement.englishText}
              </p>
            </div>
          </div>
        )}

        {/* Right Side: Game Currency & Status matching reference (Coins, Diamonds, Level, Pause) */}
        <div className="pointer-events-auto flex items-center gap-2 bg-slate-950/85 backdrop-blur-md border border-slate-800 rounded-xl px-3 py-1.5 shadow-xl text-xs font-mono font-bold">
          {/* Coins */}
          <div className="flex items-center gap-1.5 px-2 py-1 bg-amber-500/10 border border-amber-500/30 rounded-lg text-amber-300">
            <span>🪙</span>
            <span>12,580</span>
          </div>

          {/* Diamonds */}
          <div className="flex items-center gap-1.5 px-2 py-1 bg-sky-500/10 border border-sky-500/30 rounded-lg text-sky-300">
            <span>💎</span>
            <span>250</span>
          </div>

          {/* Level */}
          <div className="px-2 py-1 bg-slate-800 text-slate-200 rounded-lg">
            Lv. 42
          </div>

          {/* Pause Button */}
          {onOpenPause && (
            <button
              onClick={() => {
                soundEngine.playUIClick();
                onOpenPause();
              }}
              className="h-8 w-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white flex items-center justify-center border border-slate-700 transition-all active:scale-95"
            >
              ⏸
            </button>
          )}
        </div>

      </div>

      {/* ========================================================================= */}
      {/* 2. MIDDLE ROW: Left Stacked Level Cards & Right Action Bar */}
      {/* ========================================================================= */}
      <div className="flex items-center justify-between flex-1 my-auto pointer-events-none">
        
        {/* Left Side: Floating Level Selector Stack matching screenshot */}
        <div className="pointer-events-auto flex flex-col gap-2 mt-4">
          {floorCards.map((fl) => {
            const isActive = currentFloor === fl.level;
            return (
              <button
                key={fl.level}
                onClick={() => {
                  soundEngine.playUIClick();
                  onSelectFloor(fl.level as 0 | 1 | 2 | 3 | 4);
                }}
                className={`relative flex items-center gap-3 w-48 p-2 rounded-xl backdrop-blur-md transition-all active:scale-95 text-left border ${
                  isActive
                    ? 'bg-gradient-to-r from-amber-950/90 via-slate-900/90 to-amber-950/70 border-amber-500 text-white shadow-[0_0_15px_rgba(245,158,11,0.4)]'
                    : 'bg-slate-950/80 hover:bg-slate-900/90 border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
                }`}
              >
                {/* Thumbnail Icon Preview */}
                <div
                  className={`h-11 w-11 rounded-lg flex items-center justify-center border shrink-0 bg-gradient-to-br ${fl.bgGradient} ${
                    isActive ? 'border-amber-400 shadow-md' : 'border-slate-700'
                  }`}
                >
                  {fl.icon}
                </div>

                {/* Card Text */}
                <div className="flex-1 overflow-hidden">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black tracking-wide font-mono text-white">
                      {fl.title}
                    </span>
                    {isActive && (
                      <span className="h-2 w-2 rounded-full bg-amber-400 animate-pulse"></span>
                    )}
                  </div>
                  <div className="text-[11px] text-slate-300 font-medium truncate">
                    {fl.sub}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Right Side: Action Buttons matching screenshot ([Journey] [Map] [Tickets] [Security] [Facilities]) */}
        <div className="pointer-events-auto flex flex-col gap-2">
          <div className="bg-slate-950/85 backdrop-blur-md border border-slate-800 rounded-2xl p-2 flex flex-col gap-2 shadow-2xl">
            <button
              onClick={() => { soundEngine.playUIClick(); onOpenJourney(); }}
              className="flex flex-col items-center justify-center w-14 h-14 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700 hover:border-amber-500/60 transition-all active:scale-95"
            >
              <span className="text-lg">🏭</span>
              <span className="text-[10px] font-bold font-mono tracking-wide">Journey</span>
            </button>

            <button
              onClick={() => { soundEngine.playUIClick(); onOpenMap(); }}
              className="flex flex-col items-center justify-center w-14 h-14 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700 hover:border-sky-500/60 transition-all active:scale-95"
            >
              <span className="text-lg">🗺️</span>
              <span className="text-[10px] font-bold font-mono tracking-wide">Map</span>
            </button>

            <button
              onClick={() => { soundEngine.playUIClick(); onOpenTickets(); }}
              className="flex flex-col items-center justify-center w-14 h-14 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700 hover:border-amber-500/60 transition-all active:scale-95"
            >
              <span className="text-lg">🎫</span>
              <span className="text-[10px] font-bold font-mono tracking-wide">Tickets</span>
            </button>

            <button
              onClick={() => { soundEngine.playUIClick(); onOpenOperations(); }}
              className="flex flex-col items-center justify-center w-14 h-14 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700 hover:border-emerald-500/60 transition-all active:scale-95"
            >
              <span className="text-lg">🛡️</span>
              <span className="text-[10px] font-bold font-mono tracking-wide">Security</span>
            </button>

            <button
              onClick={() => { soundEngine.playUIClick(); onOpenOperations(); }}
              className="flex flex-col items-center justify-center w-14 h-14 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700 hover:border-purple-500/60 transition-all active:scale-95"
            >
              <span className="text-lg">⚙️</span>
              <span className="text-[10px] font-bold font-mono tracking-wide">Facilities</span>
            </button>
          </div>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* 3. WAYPOINT BEACON INDICATOR (if active) */}
      {/* ========================================================================= */}
      {activeFacilityWaypoint && (
        <div className="self-center pointer-events-auto bg-amber-950/90 border border-amber-500/60 rounded-full px-4 py-1.5 shadow-2xl backdrop-blur-md flex items-center gap-2 text-xs font-semibold text-amber-200 mb-2">
          <span className="animate-bounce">📍</span>
          <span>Target: {activeFacilityWaypoint.label}</span>
          <span className="text-amber-400 font-mono">({Math.round(activeFacilityWaypoint.distanceMeters)}m away)</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. BOTTOM BAR: Train Status Pill & Quick Facility Nav Bar */}
      {/* ========================================================================= */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pointer-events-auto">
        
        {/* Bottom Left: Live Train Status Pill matching screenshot */}
        <div className="bg-slate-950/90 backdrop-blur-md border border-slate-700/80 rounded-full px-4 py-2 flex items-center gap-3 shadow-2xl">
          <div className="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-400 text-base">
            🚆
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="font-bold text-white font-mono">
              {activeTrainInfo?.trainName || 'Vande Bharat Express'}
            </span>
            <span className="text-slate-400">•</span>
            <span className="text-slate-300 font-sans">
              {activeTrainInfo?.route || 'Delhi ➔ Mumbai'}
            </span>
            <span className="text-slate-400">•</span>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold font-mono border border-emerald-500/30">
              {activeTrainInfo?.status ? (activeTrainInfo.status.includes('Doors Open') ? 'At Platform 2 (Doors Open)' : 'On Time') : 'On Time'}
            </span>
          </div>
        </div>

        {/* Bottom Right: Quick Facility Navigation Bar matching screenshot */}
        <div className="bg-slate-950/90 backdrop-blur-md border border-slate-800 rounded-full px-2.5 py-1.5 flex items-center gap-1.5 shadow-2xl overflow-x-auto max-w-full">
          {[
            { id: 'restaurant', label: 'Restaurant', icon: '🍽️' },
            { id: 'shops', label: 'Shops', icon: '🛍️' },
            { id: 'medical', label: 'Medical', icon: '➕' },
            { id: 'police', label: 'Police', icon: '👮' },
            { id: 'toilets', label: 'Toilets', icon: '🚻' },
            { id: 'lifts', label: 'Lifts', icon: '🛗' },
            { id: 'escalators', label: 'Escalators', icon: '🪜' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => {
                soundEngine.playUIClick();
                onNavigateToFacility(item.id as any);
              }}
              className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-slate-900/85 hover:bg-slate-800 text-slate-300 hover:text-white text-xs border border-slate-700/60 transition-all active:scale-95 whitespace-nowrap"
            >
              <span>{item.icon}</span>
              <span className="font-semibold text-[11px]">{item.label}</span>
            </button>
          ))}
        </div>

      </div>

    </div>
  );
};
