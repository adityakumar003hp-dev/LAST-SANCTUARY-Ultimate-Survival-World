# LAST SANCTUARY — Complete Survival Expansion

This is the updated Google AI Studio project ZIP, based on the original `deadzone-craft (1).zip` repository.

## Quick start
1. Open/import the complete project in Google AI Studio.
2. Install dependencies with `npm install`.
3. Start the development server with `npm run dev`.
4. Run `npm run build` before publishing.

## New integrated systems
- Expanded biome generation and chunk streaming through the existing chunk manager.
- Wildlife species manager for mammals, birds, dinosaurs, aquatic species and rare creatures.
- Survivor rescue manager with dialogue and persistent rescued state.
- Conversation modal and E-key survivor interaction.

Read `IMPLEMENTATION_UPDATE.md` for the exact implementation scope and known limitations. Read `public/assets/aistudio/LAST_SANCTUARY_REALISM_AND_WORLD_EXPANSION_MASTER_PROMPT.md` for the next-stage Google AI Studio instructions to upgrade procedural placeholders into high-realism assets and deeper simulation.

**Honest status:** this package contains integrated gameplay foundations and procedural placeholder models. It is not a photorealistic finished release. A complete build and mobile play-test should be run in Google AI Studio after import.


## Six-Day Campaign Update
The authoritative opening campaign is six days / 36 missions. See `SIX_DAY_CAMPAIGN_AND_STARTER_BASE_SPEC.md` and `src/data/sixDayCampaign.ts`. The apartment and military Starter Base use protected procedural no-spawn footprints. See `src/engine/world/ProtectedSpawnZones.ts`.


## Updated source delivery

For the updated project, use the root `package.json` and root `src/` directory as the active application. See `IMPLEMENTATION_DELIVERY_REPORT.md` for implemented code changes and exact validation limitations, and `IMPLEMENTATION_TRACEABILITY.md` for the subsystem-to-source map. The nested `latest_working_source/` and `ls_dev/` folders are retained as historical source snapshots.

## Railway basement dispatch control centre (November 2026)
The apartment now contains a dedicated underground railway dispatch room. The former upper-floor command desk has been removed and the new room is accessed by walking down to basement level and pressing **E** at the dispatch console. It includes one wide operations board, four auxiliary monitors, a keyboard desk, six-line railway map, six-service arrival/departure board, condition, speed, distance and next-stop details. Keyboard controls are listed in `RAILWAY_BASEMENT_CONTROL_CENTER_UPDATE.md`.

**Current limitation:** the dispatch dashboard is a functional UI prototype with authored timetable/demo values; live AI train telemetry and real train-control integration are not yet connected.
