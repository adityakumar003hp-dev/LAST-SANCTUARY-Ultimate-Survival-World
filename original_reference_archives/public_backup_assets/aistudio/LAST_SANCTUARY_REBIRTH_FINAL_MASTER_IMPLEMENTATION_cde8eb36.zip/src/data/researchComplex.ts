/**
 * Authored Military Research & Science Complex for Outpost 7.
 * The campus is deliberately built inside the protected military compound so
 * procedural vegetation, loot and hostile spawns cannot overwrite it.
 */
import * as THREE from 'three';
import { getTerrainHeight } from '../engine/Terrain';
import { RESEARCH_FACILITIES } from './researchFacilities';
import type { ResearchFacilityDefinition } from './researchFacilities';

export { RESEARCH_FACILITIES };
export type { ResearchFacilityDefinition };
export const RESEARCH_FACILITY_INDEX: ResearchFacilityDefinition[] = RESEARCH_FACILITIES;

export interface ResearchStoryUnlock {
  mission: number;
  facilityId: string;
  codename: string;
  unlockNote: string;
  clue: string;
}

export const RESEARCH_STORY_UNLOCKS: ResearchStoryUnlock[] = [
  { mission: 50, facilityId: 'sample_storage', codename: 'Specimen Cryo-Vault', unlockNote: 'Cold storage containment for meteor samples', clue: 'Cryogenic canisters holding active non-terrestrial spores.' },
  { mission: 51, facilityId: 'scientist_quarters', codename: 'Command Archives', unlockNote: 'Classified operational files and research logs', clue: 'Doctoral logs documenting rapid cellular mutation rates.' },
  { mission: 52, facilityId: 'quarantine_ward', codename: 'Bio-Observation Ward', unlockNote: 'Sealed isolation unit for survivor assessment', clue: 'Quarantine telemetry confirming airborne airborne virulence suppression.' },
  { mission: 53, facilityId: 'research_command', codename: 'Campus Central Hub', unlockNote: 'Campus power grid and automated laboratory monitors', clue: 'Mainframe access keys unlocking encrypted lab sub-networks.' },
  { mission: 54, facilityId: 'biology_lab', codename: 'Virology Suite', unlockNote: 'Cellular pathology and viral strain sequencing', clue: 'Electron microscopy confirming hybrid biological-mineral pathogens.' },
  { mission: 55, facilityId: 'meteor_lab', codename: 'Anomalous Materials', unlockNote: 'Deep spectrometry of meteor fragments and spore radiation', clue: 'Spectrometry revealing crystal structures emitting low-frequency radiation.' },
  { mission: 56, facilityId: 'infection_testing', codename: 'Aerosol Isolation Chambers', unlockNote: 'Environmental virulence testing', clue: 'Aerosol test footage proving rapid neuromuscular takeover in host tissue.' },
  { mission: 57, facilityId: 'genetics_lab', codename: 'Genome Splicing Wing', unlockNote: 'Mutation progression and adaptive countermeasures', clue: 'Synthesized genetic markers revealing accelerated evolutionary adaptation.' },
  { mission: 58, facilityId: 'medical_research', codename: 'Vaccine Synthesis', unlockNote: 'Active antigen stabilization and antibody production', clue: 'A viable neutralizing compound stabilizing infected blood tissue.' },
  { mission: 69, facilityId: 'secret_lab', codename: 'Classified Deep Bunker', unlockNote: 'Sub-level Origin Facility and zero-day pathogen records', clue: 'Operation Black Sky archives revealing pre-impact defense preparations.' },
];


export class ResearchComplexManager {
  public readonly root: THREE.Group;
  private readonly materials: THREE.Material[] = [];
  private readonly geometries: THREE.BufferGeometry[] = [];
  private readonly facilityMeshes = new Map<string, THREE.Group>();

  constructor(private readonly scene: THREE.Scene, centerX = 974, centerZ = 1, seed = 42) {
    this.root = new THREE.Group();
    this.root.name = 'Outpost7_Military_Research_Science_Complex';
    this.root.position.set(centerX, getTerrainHeight(centerX, centerZ, seed), centerZ);
    this.scene.add(this.root);
    this.buildCampus();
  }

  private material(color: number, roughness = 0.78, metalness = 0.18, emissive = 0): THREE.MeshStandardMaterial {
    const m = new THREE.MeshStandardMaterial({ color, roughness, metalness, emissive, emissiveIntensity: emissive ? 0.28 : 0 });
    this.materials.push(m);
    return m;
  }

  private box(parent: THREE.Object3D, name: string, x: number, y: number, z: number, sx: number, sy: number, sz: number, mat: THREE.Material): THREE.Mesh {
    const geo = new THREE.BoxGeometry(sx, sy, sz);
    this.geometries.push(geo);
    const mesh = new THREE.Mesh(geo, mat);
    mesh.name = name;
    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    parent.add(mesh);
    return mesh;
  }

  private buildCampus(): void {
    const concrete = this.material(0x737b7d);
    const wall = this.material(0x46545a, 0.72, 0.42);
    const roof = this.material(0x26343b, 0.58, 0.62);
    const glass = this.material(0x174b5a, 0.22, 0.55, 0x06232b);
    const trim = this.material(0xb5c1c2, 0.48, 0.72);
    const hazard = this.material(0xd69a32, 0.65, 0.28);
    const glow = this.material(0x42c8d4, 0.28, 0.55, 0x167d8a);
    const asphalt = this.material(0x30383b);

    // A compact, walled campus with a vehicle lane, central courtyard and secure entrance.
    this.box(this.root, 'CampusFoundation', 0, 0.04, 0, 39, 0.22, 35, concrete);
    this.box(this.root, 'MainAccessRoad', 0, 0.17, 17.2, 39, 0.12, 2.2, asphalt);
    // Boundary walls intentionally leave the south access gate open.
    this.box(this.root, 'NorthPerimeterWall', 0, 1.15, -17, 39, 2.3, 0.55, wall);
    this.box(this.root, 'WestPerimeterWall', -19.2, 1.15, 0, 0.55, 2.3, 34, wall);
    this.box(this.root, 'EastPerimeterWall', 19.2, 1.15, 0, 0.55, 2.3, 34, wall);
    this.box(this.root, 'SouthPerimeterWest', -14.2, 1.15, 17, 10, 2.3, 0.55, wall);
    this.box(this.root, 'SouthPerimeterEast', 14.2, 1.15, 17, 10, 2.3, 0.55, wall);
    this.box(this.root, 'ResearchGateHeader', 0, 3.2, 17, 8, 0.55, 0.8, roof);
    this.box(this.root, 'GateSign', 0, 3.85, 16.55, 6.8, 0.62, 0.12, glow);

    const placements: Array<[string, number, number, number, number]> = [
      ['research_command', -12, -10, 9, 6],
      ['biology_lab', 0, -10, 8, 6],
      ['medical_research', 12, -10, 9, 6],
      ['meteor_lab', -12, 0, 9, 6],
      ['infection_testing', 0, 0, 8, 6],
      ['genetics_lab', 12, 0, 9, 6],
      ['scientist_quarters', -12, 9, 9, 5],
      ['quarantine_ward', 0, 9, 8, 5],
      ['sample_storage', 12, 9, 9, 5],
    ];

    for (const [id, x, z, width, depth] of placements) {
      const def = RESEARCH_FACILITIES.find((f: ResearchFacilityDefinition) => f.id === id)!;
      const building = new THREE.Group();
      building.name = `Facility_${id}`;
      building.position.set(x, 0, z);
      this.root.add(building);
      this.box(building, `${id}_foundation`, 0, 0.22, 0, width, 0.44, depth, concrete);
      this.box(building, `${id}_walls`, 0, 2.05, 0, width - 0.35, 3.25, depth - 0.35, wall);
      this.box(building, `${id}_roof`, 0, 3.82, 0, width + 0.25, 0.38, depth + 0.25, roof);
      this.box(building, `${id}_front_glazing`, 0, 2.0, depth / 2 - 0.19, width * 0.58, 1.45, 0.08, glass);
      this.box(building, `${id}_nameplate`, 0, 3.12, depth / 2 + 0.04, width * 0.72, 0.32, 0.12, glow);
      this.box(building, `${id}_hazard_marker`, -width / 2 + 0.55, 3.1, depth / 2 + 0.06, 0.28, 0.38, 0.14, hazard);
      // Roof ventilation and small antenna give each wing a recognisable silhouette.
      this.box(building, `${id}_vent`, width / 2 - 0.8, 4.18, -depth / 2 + 0.8, 1.0, 0.48, 1.0, trim);
      const lightGeo = new THREE.CylinderGeometry(0.08, 0.08, 1.0, 8);
      this.geometries.push(lightGeo);
      const beacon = new THREE.Mesh(lightGeo, glow);
      beacon.position.set(width / 2 - 0.45, 4.45, depth / 2 - 0.45);
      building.add(beacon);
      building.userData.facility = def;
      this.facilityMeshes.set(id, building);
    }

    // Visible underground vault / secret lab access: reinforced hatch, stairwell surround and warning lights.
    const secret = new THREE.Group();
    secret.name = 'Secret_Underground_Laboratory_Access';
    secret.position.set(0, 0, -16);
    this.root.add(secret);
    this.box(secret, 'UndergroundAccessConcrete', 0, 0.28, 0, 5.8, 0.56, 4.2, concrete);
    this.box(secret, 'BlastHatch', 0, 0.62, 0, 3.7, 0.16, 2.6, roof);
    this.box(secret, 'HatchWarningStripe', 0, 0.72, 0, 3.3, 0.05, 0.18, hazard);
    this.box(secret, 'SecretLabEntryMarker', 0, 1.5, 2.15, 4.4, 1.25, 0.12, glow);
    secret.userData.facility = RESEARCH_FACILITIES.find((f: ResearchFacilityDefinition) => f.id === 'secret_lab');
    this.facilityMeshes.set('secret_lab', secret);

    // Floodlights and perimeter watch cameras.
    for (const [x, z] of [[-18, -15], [18, -15], [-18, 15], [18, 15]] as number[][]) {
      const poleGeo = new THREE.CylinderGeometry(0.09, 0.14, 5.5, 8);
      this.geometries.push(poleGeo);
      const pole = new THREE.Mesh(poleGeo, trim);
      pole.position.set(x, 2.75, z);
      this.root.add(pole);
      const lamp = this.box(this.root, 'PerimeterFloodlight', x, 5.45, z, 0.8, 0.28, 0.55, glow);
      lamp.castShadow = false;
    }

    const sign = this.box(this.root, 'ResearchComplexMonumentSign', 0, 1.35, 18.6, 9.5, 2.7, 0.35, roof);
    sign.userData.label = 'OUTPOST 7 — MILITARY RESEARCH & SCIENCE COMPLEX';
  }

  public getFacilityAt(worldPosition: THREE.Vector3, radius = 5): ResearchFacilityDefinition | null {
    const local = this.root.worldToLocal(worldPosition.clone());
    let nearest: { facility: ResearchFacilityDefinition; distance: number } | null = null;
    for (const group of this.facilityMeshes.values()) {
      const facility = group.userData.facility as ResearchFacilityDefinition | undefined;
      if (!facility) continue;
      const distance = Math.hypot(local.x - group.position.x, local.z - group.position.z);
      if (distance <= radius && (!nearest || distance < nearest.distance)) nearest = { facility, distance };
    }
    return nearest?.facility ?? null;
  }

  public dispose(): void {
    this.scene.remove(this.root);
    for (const geometry of this.geometries) geometry.dispose();
    for (const material of this.materials) material.dispose();
    this.facilityMeshes.clear();
  }
}
