import * as THREE from 'three';
import { UnifiedPhysicsManager } from '../physics/UnifiedPhysicsManager';
import { soundEngine } from '../../utils/audio';

export interface ApartmentState {
  tvOn: boolean;
  tvChannel: number;
  fanOn: boolean;
  fanSpeed: number;
  acOn: boolean;
  lightsOn: boolean;
  doorOpen: boolean;
  fridgeOpen: boolean;
  fridgeItems: string[];
}

export class ApartmentBuilding {
  public group: THREE.Group;
  public state: ApartmentState;

  // Floor groups for camera-aware cutaways
  public floor1Group: THREE.Group;
  public floor2Group: THREE.Group;
  public floor3Group: THREE.Group;
  public floor4Group: THREE.Group;
  public floor5Group: THREE.Group;
  public exteriorWalls: THREE.Group;
  public staircaseGroup: THREE.Group;

  // Dynamic meshes
  private tvMesh!: THREE.Mesh;
  private tvScreenMat: THREE.MeshBasicMaterial;
  private tvCanvas: HTMLCanvasElement;
  private tvContext: CanvasRenderingContext2D | null;
  private tvTexture: THREE.CanvasTexture;
  private fanBlades!: THREE.Group;
  private acMesh!: THREE.Mesh;
  private acLedMat!: THREE.MeshBasicMaterial;
  private fridgeDoor!: THREE.Group;
  private frontDoorMesh!: THREE.Group;
  private frontDoorLeftLeaf!: THREE.Group;
  private frontDoorRightLeaf!: THREE.Group;
  private compoundGateLeftLeaf!: THREE.Group;
  private compoundGateRightLeaf!: THREE.Group;
  private compoundGateGroup!: THREE.Group;
  private compoundPedestrianDoorLeft!: THREE.Group;
  private compoundPedestrianDoorRight!: THREE.Group;
  private compoundPedestrianDoorsOpen = [false, false];
  public poolWaterMesh!: THREE.Mesh;
  public indoorPoolWaterMesh!: THREE.Mesh;
  public backyardPoolWaterMesh!: THREE.Mesh;
  private floorLights: THREE.PointLight[] = [];
  private compoundGateOpen = true;
  private roofGateOpen = false;
  private roofAccessGate!: THREE.Group;

  // Reusable PBR materials
  private whiteWallMat: THREE.MeshStandardMaterial;
  private greyWallMat: THREE.MeshStandardMaterial;
  private armoryWallMat: THREE.MeshStandardMaterial;
  private brickFacadeMat: THREE.MeshStandardMaterial;
  private floorTileMat: THREE.MeshStandardMaterial;
  private woodFloorMat: THREE.MeshStandardMaterial;
  private glassMat: THREE.MeshStandardMaterial;
  private metalTrimMat: THREE.MeshStandardMaterial;
  private waterMat: THREE.MeshStandardMaterial;

  // Exterior wall sub-groups for directional camera cutaways
  private southWallMesh!: THREE.Group;
  private northWallMesh!: THREE.Group;
  private eastWallMesh!: THREE.Group;
  private westWallMesh!: THREE.Group;

  // Base building location
  public readonly origin = new THREE.Vector3(-26, 0, 38);

  // Pool water volume bounding box in world coordinates
  public readonly backyardPoolBounds = {
    minX: -17.5, maxX: -8.9, minY: 0.15, maxY: 1.5,
    minZ: -18.8, maxZ: -10.2,
  };

  public readonly poolWaterBounds = {
    minX: -31.5, maxX: -25.5,
    minY: 11.2, maxY: 14.0,
    minZ: 34.5, maxZ: 41.5,
  };

  constructor(parent: THREE.Scene | THREE.Group) {
    this.group = new THREE.Group();
    this.group.name = 'five_level_player_mansion';
    this.group.position.copy(this.origin);
    parent.add(this.group);

    this.state = {
      tvOn: false,
      tvChannel: 1,
      fanOn: true,
      fanSpeed: 4.5,
      acOn: true,
      lightsOn: true,
      doorOpen: true,
      fridgeOpen: false,
      fridgeItems: ['clean_water', 'canned_beans', 'fresh_oj', 'breakfast_sandwich', 'bandage'],
    };

    // Shared high-grade PBR materials
    this.whiteWallMat = new THREE.MeshStandardMaterial({
      color: 0xf5f5f5,
      roughness: 0.88,
      side: THREE.DoubleSide,
    });
    this.greyWallMat = new THREE.MeshStandardMaterial({
      color: 0x787c82, // Visually distinct grey for Floor 2
      roughness: 0.85,
      side: THREE.DoubleSide,
    });
    this.armoryWallMat = new THREE.MeshStandardMaterial({
      color: 0x22262d,
      roughness: 0.45,
      metalness: 0.65,
      side: THREE.DoubleSide,
    });
    this.brickFacadeMat = new THREE.MeshStandardMaterial({
      color: 0x8a4234,
      roughness: 0.9,
    });
    this.floorTileMat = new THREE.MeshStandardMaterial({
      color: 0xd2ceca,
      roughness: 0.6,
    });
    this.woodFloorMat = new THREE.MeshStandardMaterial({
      color: 0x583d26,
      roughness: 0.7,
    });
    this.glassMat = new THREE.MeshStandardMaterial({
      color: 0x8ec3d8,
      roughness: 0.1,
      metalness: 0.85,
      transparent: true,
      opacity: 0.45,
    });
    this.metalTrimMat = new THREE.MeshStandardMaterial({
      color: 0x25282d,
      metalness: 0.8,
      roughness: 0.35,
    });
    this.waterMat = new THREE.MeshStandardMaterial({
      color: 0x0099bb,
      roughness: 0.05,
      metalness: 0.25,
      transparent: true,
      opacity: 0.75,
    });

    // Procedural TV screen canvas
    this.tvCanvas = document.createElement('canvas');
    this.tvCanvas.width = 512;
    this.tvCanvas.height = 288;
    this.tvContext = this.tvCanvas.getContext('2d');
    this.updateTVScreenContent(false);
    this.tvTexture = new THREE.CanvasTexture(this.tvCanvas);
    this.tvTexture.colorSpace = THREE.SRGBColorSpace;
    this.tvScreenMat = new THREE.MeshBasicMaterial({ map: this.tvTexture });

    this.floor1Group = new THREE.Group();
    this.floor1Group.name = 'floor_1_white_living';
    this.floor2Group = new THREE.Group();
    this.floor2Group.name = 'floor_2_grey_residence';
    this.floor3Group = new THREE.Group();
    this.floor3Group.name = 'floor_3_armory_vault';
    this.floor4Group = new THREE.Group();
    this.floor4Group.name = 'floor_4_command_and_utilities';
    this.floor5Group = new THREE.Group();
    this.floor5Group.name = 'floor_5_rooftop_pool_terrace';
    this.exteriorWalls = new THREE.Group();
    this.exteriorWalls.name = 'exterior_cutaway_facade';
    this.staircaseGroup = new THREE.Group();
    this.staircaseGroup.name = 'continuous_staircase';

    this.group.add(
      this.floor1Group,
      this.floor2Group,
      this.floor3Group,
      this.floor4Group,
      this.floor5Group,
      this.exteriorWalls,
      this.staircaseGroup
    );

    // Build building architecture
    this.buildFloor1();
    this.buildFloor2();
    this.buildFloor3();
    this.buildFloor4();
    this.buildFloor5Pool();
    this.buildContinuousStaircase();
    this.buildExteriorFacade();
    this.buildEnclosedProperty();
    // Entrance starts open so movement between interior and exterior is unobstructed.
    this.frontDoorLeftLeaf.rotation.y = -Math.PI / 2;
    this.frontDoorRightLeaf.rotation.y = Math.PI / 2;
    this.compoundGateLeftLeaf.rotation.y = -Math.PI / 2;
    this.compoundGateRightLeaf.rotation.y = Math.PI / 2;

    this.registerBuildingColliders();
  }

  private registerBuildingColliders() {
    const phys = UnifiedPhysicsManager.getInstance();
    if (!phys) return;

    const ox = this.origin.x;
    const oy = this.origin.y;
    const oz = this.origin.z;

    // Exterior Apartment Walls (Solid boundary, cannot travel through walls)
    phys.registerBoxCollider('apt_north_wall', 'wall', [ox, oy + 8.0, oz + 6.8], 16.0, 16.0, 0.6);
    phys.registerBoxCollider('apt_east_wall', 'wall', [ox + 7.8, oy + 8.0, oz], 0.6, 16.0, 14.0);
    phys.registerBoxCollider('apt_west_wall', 'wall', [ox - 7.8, oy + 8.0, oz], 0.6, 16.0, 14.0);
    phys.registerBoxCollider('apt_south_wall_left', 'wall', [ox - 4.5, oy + 8.0, oz - 6.8], 7.0, 16.0, 0.6);
    phys.registerBoxCollider('apt_south_wall_right', 'wall', [ox + 4.5, oy + 8.0, oz - 6.8], 7.0, 16.0, 0.6);

    // Compound Perimeter Enclosure Walls (Zero gaps, only front double gate at center)
    phys.registerBoxCollider('apt_perim_west', 'wall', [ox - 19.0, oy + 1.7, oz + 2.5], 0.6, 3.4, 49.0);
    phys.registerBoxCollider('apt_perim_east', 'wall', [ox + 19.0, oy + 1.7, oz + 2.5], 0.6, 3.4, 49.0);
    phys.registerBoxCollider('apt_perim_rear', 'wall', [ox, oy + 1.7, oz + 27.0], 38.5, 3.4, 0.6);
    phys.registerBoxCollider('apt_perim_front_left_outer', 'wall', [ox - 15.86, oy + 1.7, oz - 22.0], 6.28, 3.4, 0.6);
    phys.registerBoxCollider('apt_perim_front_left_inner', 'wall', [ox - 6.915, oy + 1.7, oz - 22.0], 8.73, 3.4, 0.6);
    phys.registerBoxCollider('apt_perim_front_right_inner', 'wall', [ox + 6.915, oy + 1.7, oz - 22.0], 8.73, 3.4, 0.6);
    phys.registerBoxCollider('apt_perim_front_right_outer', 'wall', [ox + 15.86, oy + 1.7, oz - 22.0], 6.28, 3.4, 0.6);
  }

  // ==========================================
  // FLOOR SLAB WITH STAIR OPENING HELPER
  // ==========================================
  private createSlabWithStairwell(mat: THREE.Material, thickness: number, yPos: number): THREE.Group {
    const g = new THREE.Group();
    // West section: covers X = -8.0 to +4.5 (width 12.5, depth 14, center X = -1.75)
    const westSlab = new THREE.Mesh(new THREE.BoxGeometry(12.5, thickness, 14), mat);
    westSlab.position.set(-1.75, yPos, 0);
    westSlab.receiveShadow = true;

    // East North section: covers X = 4.5 to 8.0, Z = 2.0 to 7.0 (width 3.5, depth 5, center X = 6.25, Z = 4.5)
    const eastNorth = new THREE.Mesh(new THREE.BoxGeometry(3.5, thickness, 5.0), mat);
    eastNorth.position.set(6.25, yPos, 4.5);
    eastNorth.receiveShadow = true;

    // East South section: covers X = 4.5 to 8.0, Z = -7.0 to -4.5 (width 3.5, depth 2.5, center X = 6.25, Z = -5.75)
    const eastSouth = new THREE.Mesh(new THREE.BoxGeometry(3.5, thickness, 2.5), mat);
    eastSouth.position.set(6.25, yPos, -5.75);
    eastSouth.receiveShadow = true;

    g.add(westSlab, eastNorth, eastSouth);
    return g;
  }

  /** Build one authored bathroom suite. Four calls below create exactly four bathrooms. */
  private addBathroom(parent: THREE.Group, floorY: number, centerX: number, centerZ: number, id: string, wallMat: THREE.Material) {
    const room = new THREE.Group(); room.name = `mansion_bathroom_${id}`; parent.add(room);
    const floor = new THREE.Mesh(new THREE.BoxGeometry(3.15, 0.12, 3.05), this.floorTileMat);
    floor.position.set(centerX, floorY + 0.06, centerZ); floor.receiveShadow = true; room.add(floor);
    const wallH = 2.55, wallT = 0.16;
    const addWall = (w: number, h: number, d: number, x: number, y: number, z: number) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), wallMat); m.position.set(x,y,z); m.castShadow = true; m.receiveShadow = true; room.add(m);
    };
    addWall(3.15, wallH, wallT, centerX, floorY + wallH/2, centerZ - 1.52);
    addWall(wallT, wallH, 3.05, centerX - 1.57, floorY + wallH/2, centerZ);
    addWall(wallT, wallH, 3.05, centerX + 1.57, floorY + wallH/2, centerZ);
    // Front wall is split to leave a real 0.95m doorway.
    addWall(1.1, wallH, wallT, centerX - 1.02, floorY + wallH/2, centerZ + 1.52);
    addWall(1.1, wallH, wallT, centerX + 1.02, floorY + wallH/2, centerZ + 1.52);
    const ceramic = new THREE.MeshStandardMaterial({ color: 0xf0f2f3, roughness: 0.28 });
    const chrome = new THREE.MeshStandardMaterial({ color: 0x9da7ad, metalness: 0.82, roughness: 0.22 });
    const toiletBase = new THREE.Mesh(new THREE.CylinderGeometry(0.28,0.34,0.48,12), ceramic);
    toiletBase.position.set(centerX - 0.75, floorY + 0.3, centerZ - 0.75); room.add(toiletBase);
    const toiletSeat = new THREE.Mesh(new THREE.TorusGeometry(0.24,0.055,8,18), ceramic);
    toiletSeat.rotation.x = Math.PI/2; toiletSeat.position.set(centerX - 0.75, floorY + 0.56, centerZ - 0.75); room.add(toiletSeat);
    const vanity = new THREE.Mesh(new THREE.BoxGeometry(0.95,0.78,0.55), chrome);
    vanity.position.set(centerX + 0.83, floorY + 0.42, centerZ - 0.85); room.add(vanity);
    const basin = new THREE.Mesh(new THREE.CylinderGeometry(0.32,0.25,0.12,16), ceramic);
    basin.position.set(centerX + 0.83, floorY + 0.85, centerZ - 0.85); room.add(basin);
    const showerBase = new THREE.Mesh(new THREE.BoxGeometry(1.05,0.12,1.0), ceramic);
    showerBase.position.set(centerX + 0.82, floorY + 0.12, centerZ + 0.72); room.add(showerBase);
    const glass = new THREE.Mesh(new THREE.BoxGeometry(0.06,2.15,1.0), this.glassMat);
    glass.position.set(centerX + 0.25, floorY + 1.12, centerZ + 0.72); room.add(glass);
    const lamp = new THREE.PointLight(0xfff4dc,0.55,5,1.4); lamp.position.set(centerX,floorY+2.25,centerZ); room.add(lamp);
  }

  // ==========================================
  // FLOOR 1: WHITE WALL MAIN LIVING AREA
  // ==========================================
  private buildFloor1() {
    const f1 = this.floor1Group;

    // Ground Floor Solid Base
    const floorSlab = new THREE.Mesh(new THREE.BoxGeometry(16, 0.25, 14), this.woodFloorMat);
    floorSlab.position.set(0, 0.12, 0);
    floorSlab.receiveShadow = true;
    f1.add(floorSlab);

    // Ceiling with stairwell cutout so player head is never blocked
    const ceiling = this.createSlabWithStairwell(this.whiteWallMat, 0.2, 3.1);
    f1.add(ceiling);

    // Interior White Dividing Walls (Dividing Bedroom, Kitchen, Living Room)
    const bedDivider = new THREE.Mesh(new THREE.BoxGeometry(0.25, 2.9, 7.5), this.whiteWallMat);
    bedDivider.position.set(-2.5, 1.6, 2.8);
    const kitchenDivider = new THREE.Mesh(new THREE.BoxGeometry(0.25, 2.9, 5.0), this.whiteWallMat);
    kitchenDivider.position.set(2.5, 1.6, 4.0);
    f1.add(bedDivider, kitchenDivider);

    // Warm Interior Ceiling Lamps
    const lamp1 = new THREE.PointLight(0xffecd0, 1.8, 14, 1.3);
    lamp1.position.set(-4.5, 2.7, 2.5);
    const lamp2 = new THREE.PointLight(0xffeed0, 2.0, 15, 1.3);
    lamp2.position.set(0, 2.7, 0);
    this.floorLights.push(lamp1, lamp2);
    f1.add(lamp1, lamp2);

    // --- 1. BEDROOM ---
    const bedFrame = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.5, 2.8), this.metalTrimMat);
    bedFrame.position.set(-5.5, 0.35, 3.8);
    const headboard = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.4, 0.2), this.woodFloorMat);
    headboard.position.set(-5.5, 0.9, 5.15);
    const mattress = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.35, 2.5), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9 }));
    mattress.position.set(-5.5, 0.65, 3.8);
    const blanket = new THREE.Mesh(new THREE.BoxGeometry(2.22, 0.38, 1.7), new THREE.MeshStandardMaterial({ color: 0x1f3c5e, roughness: 0.85 }));
    blanket.position.set(-5.5, 0.66, 3.3);
    const pillow1 = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.16, 0.55), new THREE.MeshStandardMaterial({ color: 0xf0f0f0, roughness: 0.9 }));
    pillow1.position.set(-6.1, 0.85, 4.6);
    const pillow2 = pillow1.clone();
    pillow2.position.x = -4.9;

    const nightstand = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.65, 0.7), this.woodFloorMat);
    nightstand.position.set(-7.2, 0.45, 4.8);
    const nightLamp = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.2, 0.4, 8), new THREE.MeshBasicMaterial({ color: 0xfff0dd }));
    nightLamp.position.set(-7.2, 0.95, 4.8);

    f1.add(bedFrame, headboard, mattress, blanket, pillow1, pillow2, nightstand, nightLamp);

    // --- 2. WORKING TELEVISION WITH BROADCAST SCREEN ---
    const tvStand = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.65, 0.6), this.metalTrimMat);
    tvStand.position.set(-5.5, 0.45, 0.0);
    const tvFrame = new THREE.Mesh(new THREE.BoxGeometry(2.0, 1.25, 0.1), new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.85 }));
    tvFrame.position.set(-5.5, 1.55, 0.0);

    this.tvMesh = new THREE.Mesh(new THREE.PlaneGeometry(1.9, 1.15), this.tvScreenMat);
    this.tvMesh.rotation.y = Math.PI;
    this.tvMesh.position.set(-5.5, 1.55, -0.06);
    f1.add(tvStand, tvFrame, this.tvMesh);

    // --- 3. REFRIGERATOR WITH INTERACTION ---
    const fridgeBody = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 2.2, 1.0),
      new THREE.MeshStandardMaterial({ color: 0xd8d8d8, metalness: 0.6, roughness: 0.25 })
    );
    fridgeBody.position.set(4.5, 1.22, 5.8);

    this.fridgeDoor = new THREE.Group();
    this.fridgeDoor.position.set(4.5, 1.22, 5.3);
    const doorPanel = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 2.18, 0.1),
      new THREE.MeshStandardMaterial({ color: 0xe2e2e2, metalness: 0.65, roughness: 0.25 })
    );
    const doorHandle = new THREE.Mesh(
      new THREE.BoxGeometry(0.08, 0.6, 0.08),
      new THREE.MeshStandardMaterial({ color: 0x444444, metalness: 0.9 })
    );
    doorHandle.position.set(0.48, 0, -0.08);
    this.fridgeDoor.add(doorPanel, doorHandle);
    f1.add(fridgeBody, this.fridgeDoor);

    // --- 4. KITCHENETTE COUNTER & SINK ---
    const kitchenCounter = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.9, 1.0), this.metalTrimMat);
    kitchenCounter.position.set(5.8, 0.57, 3.2);
    const sink = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.35, 0.7), new THREE.MeshStandardMaterial({ color: 0x999999, metalness: 0.85 }));
    sink.position.set(5.8, 0.85, 3.2);
    const faucet = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.35, 6), new THREE.MeshStandardMaterial({ color: 0xcccccc, metalness: 0.9 }));
    faucet.position.set(5.8, 1.15, 3.5);
    f1.add(kitchenCounter, sink, faucet);

    // --- 5. LIVING ROOM SOFA, COFFEE TABLE & SMARTPHONE ---
    const sofa = new THREE.Mesh(
      new THREE.BoxGeometry(2.8, 0.85, 1.2),
      new THREE.MeshStandardMaterial({ color: 0x2e4033, roughness: 0.85 })
    );
    sofa.position.set(0, 0.55, 0.5);

    const coffeeTable = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.45, 0.9), this.woodFloorMat);
    coffeeTable.position.set(0, 0.35, -1.2);

    // Smartphone prop on coffee table
    const phoneMesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.18, 0.02, 0.34),
      new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.8, roughness: 0.2 })
    );
    phoneMesh.position.set(0.3, 0.59, -1.2);
    const phoneScreen = new THREE.Mesh(
      new THREE.PlaneGeometry(0.16, 0.3),
      new THREE.MeshBasicMaterial({ color: 0x00d2d3 })
    );
    phoneScreen.rotation.x = -Math.PI / 2;
    phoneScreen.position.set(0.3, 0.605, -1.2);
    f1.add(sofa, coffeeTable, phoneMesh, phoneScreen);

    // --- 6. WORKING CEILING FAN ---
    const fanHub = new THREE.Group();
    fanHub.position.set(0, 2.95, 0.5);
    const fanStem = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.3, 6), this.metalTrimMat);
    fanStem.position.y = -0.15;
    const fanMotor = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.15, 10), this.metalTrimMat);
    fanMotor.position.y = -0.3;

    this.fanBlades = new THREE.Group();
    this.fanBlades.position.y = -0.32;
    for (let i = 0; i < 4; i++) {
      const blade = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.02, 0.16), this.woodFloorMat);
      blade.rotation.y = (i * Math.PI) / 2;
      blade.position.set(Math.cos(blade.rotation.y) * 0.55, 0, Math.sin(blade.rotation.y) * 0.55);
      this.fanBlades.add(blade);
    }
    fanHub.add(fanStem, fanMotor, this.fanBlades);
    f1.add(fanHub);

    // --- 7. WALL-MOUNTED AIR CONDITIONER ---
    this.acMesh = new THREE.Mesh(
      new THREE.BoxGeometry(1.8, 0.5, 0.4),
      new THREE.MeshStandardMaterial({ color: 0xfafafa, roughness: 0.4 })
    );
    this.acMesh.position.set(-2.5, 2.5, -6.6);

    this.acLedMat = new THREE.MeshBasicMaterial({ color: 0x00ff88 });
    const acLed = new THREE.Mesh(new THREE.SphereGeometry(0.03, 6, 6), this.acLedMat);
    acLed.position.set(-1.8, 2.4, -6.38);
    f1.add(this.acMesh, acLed);

    // --- 8. FULL-HEIGHT DOUBLE FRONT ENTRANCE DOORS ---
    // The two leaves fill the complete doorway and extend to the finished floor;
    // no visible threshold gap is left beneath either panel.
    this.frontDoorMesh = new THREE.Group();
    this.frontDoorMesh.name = 'apartment_double_front_doors';
    const doorHeight = 2.38;
    const doorLeafWidth = 0.99;
    const doorThickness = 0.14;
    // Floor 1 finished surface is approximately y=0.245; sink the panel very
    // slightly into the floor slab so lighting cannot reveal a floating gap.
    this.frontDoorMesh.position.set(0, 1.4, -6.9);

    const doorMaterial = this.woodFloorMat;
    const handleMaterial = new THREE.MeshStandardMaterial({
      color: 0xdaa520,
      metalness: 0.9,
      roughness: 0.25,
    });

    this.frontDoorLeftLeaf = new THREE.Group();
    this.frontDoorLeftLeaf.name = 'frontDoorLeftLeaf';
    this.frontDoorLeftLeaf.position.x = -0.98;
    const leftPanel = new THREE.Mesh(
      new THREE.BoxGeometry(doorLeafWidth, doorHeight, doorThickness),
      doorMaterial
    );
    leftPanel.position.set(doorLeafWidth / 2, 0, 0);
    leftPanel.castShadow = true;
    leftPanel.receiveShadow = true;
    const leftHandle = new THREE.Mesh(new THREE.SphereGeometry(0.055, 10, 8), handleMaterial);
    leftHandle.position.set(doorLeafWidth - 0.13, 0, 0.105);
    this.frontDoorLeftLeaf.add(leftPanel, leftHandle);

    this.frontDoorRightLeaf = new THREE.Group();
    this.frontDoorRightLeaf.name = 'frontDoorRightLeaf';
    this.frontDoorRightLeaf.position.x = 0.98;
    const rightPanel = new THREE.Mesh(
      new THREE.BoxGeometry(doorLeafWidth, doorHeight, doorThickness),
      doorMaterial
    );
    rightPanel.position.set(-doorLeafWidth / 2, 0, 0);
    rightPanel.castShadow = true;
    rightPanel.receiveShadow = true;
    const rightHandle = new THREE.Mesh(new THREE.SphereGeometry(0.055, 10, 8), handleMaterial);
    rightHandle.position.set(-doorLeafWidth + 0.13, 0, 0.105);
    this.frontDoorRightLeaf.add(rightPanel, rightHandle);

    this.frontDoorMesh.add(this.frontDoorLeftLeaf, this.frontDoorRightLeaf);
    f1.add(this.frontDoorMesh);

    // Indoor ground-floor plunge pool with a visible water surface and walkable entry steps.
    const indoorPool = new THREE.Group(); indoorPool.name = 'mansion_indoor_pool'; indoorPool.position.set(-0.4,0,4.6); f1.add(indoorPool);
    const poolTile = new THREE.MeshStandardMaterial({ color: 0x8ed4df, roughness:0.28 });
    const poolBase = new THREE.Mesh(new THREE.BoxGeometry(3.6,0.28,2.6),this.metalTrimMat); poolBase.position.set(0,0.28,0); indoorPool.add(poolBase);
    for (const [x,z,w,d] of [[0,-1.3,3.6,0.18],[-1.8,0,0.18,2.6],[1.8,0,0.18,2.6],[-0.95,1.3,2.5,0.18],[1.25,1.3,0.3,0.18]] as number[][]) { const rim=new THREE.Mesh(new THREE.BoxGeometry(w,0.75,d),poolTile); rim.position.set(x,0.65,z); indoorPool.add(rim); }
    this.indoorPoolWaterMesh = new THREE.Mesh(new THREE.PlaneGeometry(3.25,2.25),new THREE.MeshStandardMaterial({ color:0x08a9d0,transparent:true,opacity:0.76,roughness:0.08,side:THREE.DoubleSide }));
    this.indoorPoolWaterMesh.rotation.x=-Math.PI/2; this.indoorPoolWaterMesh.position.set(0,0.82,0); indoorPool.add(this.indoorPoolWaterMesh);
    for(let i=0;i<3;i++){const step=new THREE.Mesh(new THREE.BoxGeometry(0.75,0.13,0.42),poolTile);step.position.set(1.1,0.22+i*0.18,0.9-i*0.42);indoorPool.add(step);}

    // Ground-floor guest bathroom (bathroom 1 of exactly 4).
    this.addBathroom(f1, 0.245, 5.0, -3.25, 'ground_guest', this.whiteWallMat);
  }

  // ==========================================
  // FLOOR 2: GREY WALL RESIDENTIAL FLOOR
  // ==========================================
  private buildFloor2() {
    const f2 = this.floor2Group;
    const yOff = 3.2;

    // Floor Slab with stairwell opening
    const floorSlab = this.createSlabWithStairwell(this.floorTileMat, 0.25, yOff + 0.12);
    f2.add(floorSlab);

    // Ceiling with stairwell cutout
    const ceiling = this.createSlabWithStairwell(this.greyWallMat, 0.2, yOff + 3.1);
    f2.add(ceiling);

    // Grey Interior Walls (Visually distinct from Floor 1 white walls)
    const divider1 = new THREE.Mesh(new THREE.BoxGeometry(0.25, 2.9, 8.0), this.greyWallMat);
    divider1.position.set(-2.0, yOff + 1.6, 1.5);
    const divider2 = new THREE.Mesh(new THREE.BoxGeometry(6.0, 2.9, 0.25), this.greyWallMat);
    divider2.position.set(-5.0, yOff + 1.6, 1.5);
    f2.add(divider1, divider2);

    // Study Desk & Bookshelf
    const desk = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.85, 1.0), this.woodFloorMat);
    desk.position.set(-5.5, yOff + 0.55, 4.5);
    const deskLamp = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.18, 0.35, 6), new THREE.MeshBasicMaterial({ color: 0xffeedd }));
    deskLamp.position.set(-5.8, yOff + 1.1, 4.5);

    const bookshelf = new THREE.Mesh(new THREE.BoxGeometry(2.6, 2.2, 0.6), this.woodFloorMat);
    bookshelf.position.set(-6.5, yOff + 1.25, 1.8);

    // Lounge sofa
    const loungeSofa = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.8, 1.1), new THREE.MeshStandardMaterial({ color: 0x4a4f56, roughness: 0.85 }));
    loungeSofa.position.set(1.5, yOff + 0.55, 3.5);

    f2.add(desk, deskLamp, bookshelf, loungeSofa);

    // Ceiling light for Floor 2
    const lamp = new THREE.PointLight(0xffeed0, 1.7, 15, 1.3);
    lamp.position.set(0, yOff + 2.7, 1.0);
    this.floorLights.push(lamp);
    f2.add(lamp);

    // Floor 2 Plaque
    const plaque = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.6), new THREE.MeshBasicMaterial({ color: 0x333333 }));
    plaque.position.set(4.4, yOff + 1.8, -3.8);
    plaque.rotation.y = -Math.PI / 2;
    f2.add(plaque);

    // Master bedroom and two additional bedrooms; the study/library and lounge remain separate.
    const bedroomMat = new THREE.MeshStandardMaterial({ color: 0x3b536d, roughness:0.86 });
    const makeBedroom = (x:number,z:number,name:string) => {
      const frame=new THREE.Mesh(new THREE.BoxGeometry(2.1,0.38,2.5),this.metalTrimMat); frame.position.set(x,yOff+0.38,z); frame.name=`mansion_${name}_bed_frame`;
      const mattress=new THREE.Mesh(new THREE.BoxGeometry(2.0,0.28,2.4),new THREE.MeshStandardMaterial({color:0xe8e8e8,roughness:0.92})); mattress.position.set(x,yOff+0.68,z);
      const blanket=new THREE.Mesh(new THREE.BoxGeometry(2.02,0.12,1.45),bedroomMat); blanket.position.set(x,yOff+0.84,z+0.35);
      const headboard=new THREE.Mesh(new THREE.BoxGeometry(2.1,1.1,0.15),this.woodFloorMat); headboard.position.set(x,yOff+0.95,z-1.25);
      f2.add(frame,mattress,blanket,headboard);
    };
    makeBedroom(-5.2,0.3,'master_bedroom'); makeBedroom(3.7,3.6,'bedroom_two'); makeBedroom(3.7,-0.2,'bedroom_three');

    // First-floor medical wing: examination bed, recovery bed, supply cabinets and clinical storage.
    const medicalMat = new THREE.MeshStandardMaterial({color:0xe7ecef,roughness:0.72});
    const medicalAccent = new THREE.MeshStandardMaterial({color:0x3d8792,metalness:0.25,roughness:0.45});
    const examBed = new THREE.Mesh(new THREE.BoxGeometry(1.15,0.62,2.1),medicalMat); examBed.position.set(-0.1,yOff+0.48,-1.0); f2.add(examBed);
    const examMattress = new THREE.Mesh(new THREE.BoxGeometry(1.08,0.18,1.95),new THREE.MeshStandardMaterial({color:0xf7f8f8,roughness:0.9})); examMattress.position.set(-0.1,yOff+0.85,-1.0); f2.add(examMattress);
    const recoveryBed = new THREE.Mesh(new THREE.BoxGeometry(1.15,0.62,2.1),medicalMat); recoveryBed.position.set(1.7,yOff+0.48,1.2); f2.add(recoveryBed);
    const recoveryMattress = new THREE.Mesh(new THREE.BoxGeometry(1.08,0.18,1.95),new THREE.MeshStandardMaterial({color:0xf7f8f8,roughness:0.9})); recoveryMattress.position.set(1.7,yOff+0.85,1.2); f2.add(recoveryMattress);
    for(let i=0;i<3;i++){const cabinet=new THREE.Mesh(new THREE.BoxGeometry(0.72,1.55,0.55),medicalAccent);cabinet.position.set(-1.8+i*0.9,yOff+0.95,-4.8);f2.add(cabinet);}
    const medicalMonitor = new THREE.Mesh(new THREE.BoxGeometry(0.65,0.55,0.1),new THREE.MeshBasicMaterial({color:0x20b8a5})); medicalMonitor.position.set(0.8,yOff+1.55,-1.0); f2.add(medicalMonitor);
    const medicalLight = new THREE.PointLight(0xe1fbff,1.25,9,1.4); medicalLight.position.set(0.4,yOff+2.6,-1.2); f2.add(medicalLight); this.floorLights.push(medicalLight);

    // First-floor master ensuite and shared bathroom (bathrooms 2 and 3).
    this.addBathroom(f2, 3.445, -5.15, -4.05, 'master_ensuite', this.greyWallMat);
    this.addBathroom(f2, 3.445, 5.15, -4.05, 'first_floor_shared', this.greyWallMat);
  }

  // ==========================================
  // FLOOR 3: FICTIONAL 100-ITEM GAME ARMORY
  // ==========================================
  private buildFloor3() {
    const f3 = this.floor3Group;
    const yOff = 6.4;

    // Floor Slab with stairwell cutout
    const floorSlab = this.createSlabWithStairwell(this.metalTrimMat, 0.25, yOff + 0.12);
    f3.add(floorSlab);

    // Ceiling with stairwell cutout
    const ceiling = this.createSlabWithStairwell(this.metalTrimMat, 0.2, yOff + 3.1);
    f3.add(ceiling);

    // High-tech Secure Armory Room Walls (Dark graphite with cyan indicator strips)
    const divider = new THREE.Mesh(new THREE.BoxGeometry(0.25, 2.9, 10.0), this.armoryWallMat);
    divider.position.set(-1.5, yOff + 1.6, 0);
    f3.add(divider);

    // Cyan Neon Accent Lines
    const stripMat = new THREE.MeshBasicMaterial({ color: 0x00d2d3 });
    const strip1 = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.1, 9.8), stripMat);
    strip1.position.set(-1.35, yOff + 2.2, 0);
    f3.add(strip1);

    // Weapon Storage Lockers along West Wall
    for (let z = -4.5; z <= 4.5; z += 2.2) {
      const locker = new THREE.Mesh(
        new THREE.BoxGeometry(1.2, 2.4, 1.8),
        new THREE.MeshStandardMaterial({ color: 0x2e3440, metalness: 0.85, roughness: 0.35 })
      );
      locker.position.set(-6.5, yOff + 1.35, z);
      f3.add(locker);

      // Weapon rack display inside
      const rackGun = new THREE.Mesh(
        new THREE.BoxGeometry(0.12, 0.35, 1.2),
        new THREE.MeshStandardMaterial({ color: 0x5e81ac, metalness: 0.8 })
      );
      rackGun.position.set(-5.8, yOff + 1.4, z);
      f3.add(rackGun);
    }

    // Ammunition Crates & Heavy Ordnance Shelves along North Wall
    for (let x = -4.5; x <= 2.5; x += 2.4) {
      const crate = new THREE.Mesh(
        new THREE.BoxGeometry(1.6, 0.9, 1.1),
        new THREE.MeshStandardMaterial({ color: 0x434c5e, metalness: 0.6, roughness: 0.5 })
      );
      crate.position.set(x, yOff + 0.6, 5.8);
      f3.add(crate);
    }

    // Interactive Armory Console / Master Terminal (Center East)
    const consolePedestal = new THREE.Mesh(
      new THREE.CylinderGeometry(0.4, 0.6, 1.1, 8),
      this.metalTrimMat
    );
    consolePedestal.position.set(2.0, yOff + 0.65, 0.0);

    const consoleScreen = new THREE.Mesh(
      new THREE.BoxGeometry(1.4, 0.8, 0.1),
      new THREE.MeshBasicMaterial({ color: 0x00e5ff })
    );
    consoleScreen.rotation.x = -Math.PI / 4;
    consoleScreen.position.set(2.0, yOff + 1.45, 0.0);
    f3.add(consolePedestal, consoleScreen);

    // High-tech Armory Spotlights
    const armoryLight1 = new THREE.PointLight(0x00e5ff, 2.2, 14, 1.4);
    armoryLight1.position.set(-4.0, yOff + 2.7, 0);
    const armoryLight2 = new THREE.PointLight(0xffffff, 1.8, 14, 1.3);
    armoryLight2.position.set(2.0, yOff + 2.7, 0);
    this.floorLights.push(armoryLight1, armoryLight2);
    f3.add(armoryLight1, armoryLight2);

    // Floor 3 Signboard
    const plaque = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 0.7), new THREE.MeshBasicMaterial({ color: 0x111111 }));
    plaque.position.set(4.4, yOff + 1.8, -3.8);
    plaque.rotation.y = -Math.PI / 2;
    f3.add(plaque);

    // Second-floor common bathroom (bathroom 4 of exactly 4).
    this.addBathroom(f3, 6.645, 5.15, -4.05, 'second_floor_common', this.armoryWallMat);
    // Gaming lounge and fitness equipment occupy the open east side of this level.
    const gameConsole = new THREE.Mesh(new THREE.BoxGeometry(1.4,0.7,0.55), this.metalTrimMat);
    gameConsole.position.set(3.4, yOff + 0.55, 2.0); f3.add(gameConsole);
    const cinemaScreen = new THREE.Mesh(new THREE.PlaneGeometry(3.2,1.7), new THREE.MeshBasicMaterial({ color: 0x111a25 }));
    cinemaScreen.position.set(4.0, yOff + 2.0, -1.0); cinemaScreen.rotation.y = -Math.PI/2; f3.add(cinemaScreen);
    const gymMat = new THREE.MeshStandardMaterial({ color: 0x303840, metalness:0.65, roughness:0.4 });
    for (let i=0;i<2;i++) { const weight = new THREE.Mesh(new THREE.CylinderGeometry(0.35,0.35,0.18,12),gymMat); weight.rotation.z=Math.PI/2; weight.position.set(2.8+i*1.0,yOff+0.35,4.5); f3.add(weight); }
  }

  // ==========================================
  // FLOOR 4: THIRD-FLOOR COMMAND, FARMING AND UTILITIES
  // ==========================================
  private buildFloor4() {
    const f4 = this.floor4Group;
    const yOff = 9.6;
    const slab = this.createSlabWithStairwell(this.floorTileMat, 0.25, yOff + 0.12);
    const ceiling = this.createSlabWithStairwell(this.whiteWallMat, 0.2, yOff + 3.1);
    f4.add(slab, ceiling);
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x77858a, roughness: 0.78 });
    const darkMat = new THREE.MeshStandardMaterial({ color: 0x202a32, metalness: 0.55, roughness: 0.42 });
    const screenMat = new THREE.MeshBasicMaterial({ color: 0x19c6d2 });
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x70533b, roughness: 0.82 });
    const addBox = (name: string, w: number, h: number, d: number, x: number, y: number, z: number, mat: THREE.Material) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      mesh.name = name; mesh.position.set(x, yOff + y, z); mesh.castShadow = true; mesh.receiveShadow = true; f4.add(mesh); return mesh;
    };
    // Command centre desk and live map screens.
    addBox('mansion_command_desk', 4.8, 0.85, 1.25, -4.8, 0.62, -4.6, woodMat);
    for (let i = 0; i < 3; i++) addBox(`mansion_command_display_${i+1}`, 1.15, 0.82, 0.12, -6.0 + i * 1.25, 1.75, -5.05, screenMat);
    // Indoor farming racks with visible growing trays and grow lights.
    for (let row = 0; row < 2; row++) {
      const z = 1.8 + row * 2.3;
      addBox(`mansion_farm_rack_${row+1}`, 5.8, 0.18, 1.0, -4.8, 0.45, z, darkMat);
      for (let i = 0; i < 5; i++) {
        const planter = addBox(`mansion_indoor_planter_${row}_${i}`, 0.78, 0.22, 0.72, -7.0 + i * 1.1, 0.66, z, woodMat);
        const leaf = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 6), new THREE.MeshStandardMaterial({ color: 0x4b9b50, roughness: 0.9 }));
        leaf.position.set(planter.position.x, yOff + 1.0, planter.position.z); f4.add(leaf);
      }
      addBox(`mansion_grow_light_${row+1}`, 5.8, 0.08, 0.5, -4.8, 2.55, z, screenMat);
    }
    // Food cold storage and utility cabinets.
    for (let i = 0; i < 3; i++) {
      addBox(`mansion_cold_storage_${i+1}`, 1.2, 2.1, 1.0, 5.7, 1.2, -4.6 + i * 1.5, new THREE.MeshStandardMaterial({ color: 0xcbd3d8, metalness: 0.45, roughness: 0.3 }));
    }
    // Water purification plant: tanks, filters and pipework.
    for (let i = 0; i < 2; i++) {
      const tank = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 1.9, 16), new THREE.MeshStandardMaterial({ color: 0x6e9aa6, metalness: 0.6, roughness: 0.35 }));
      tank.position.set(5.6 + i * 1.35, yOff + 1.0, 2.4); tank.castShadow = true; f4.add(tank);
      addBox(`mansion_filter_${i+1}`, 0.6, 0.75, 0.6, 5.6 + i * 1.35, 0.45, 4.0, darkMat);
    }
    // Backup generator and electrical switchgear.
    addBox('mansion_backup_generator', 2.4, 1.45, 1.5, 1.8, 0.85, -4.7, darkMat);
    addBox('mansion_electrical_switchgear', 1.5, 2.2, 0.5, 1.8, 1.2, -2.7, wallMat);
    // Workshop benches and emergency storage.
    addBox('mansion_workshop_bench', 4.2, 0.9, 1.1, 1.8, 0.65, 4.8, woodMat);
    for (let i = 0; i < 4; i++) addBox(`mansion_emergency_storage_${i+1}`, 0.8, 1.1, 0.8, -1.2 + i * 1.15, 0.65, 4.8, darkMat);
    // Light and interior wayfinding.
    const light = new THREE.PointLight(0xc7f4ff, 2.0, 18, 1.2); light.position.set(0, yOff + 2.7, 0); f4.add(light); this.floorLights.push(light);
    const plaque = new THREE.Mesh(new THREE.PlaneGeometry(2.5, 0.6), new THREE.MeshBasicMaterial({ color: 0x101b22 }));
    plaque.position.set(4.4, yOff + 1.8, -3.8); plaque.rotation.y = -Math.PI / 2; f4.add(plaque);
  }

  // ==========================================
  // FLOOR 5: ROOFTOP SWIMMING POOL & DECK
  // ==========================================
  private buildFloor5Pool() {
    const f4 = this.floor5Group;
    const yOff = 12.8;
    const deck = this.createSlabWithStairwell(this.floorTileMat, 0.3, yOff + 0.15);
    f4.add(deck);

    // Raised rooftop swimming pool: the surrounding deck remains dry and walkable.
    const poolGroup = new THREE.Group();
    poolGroup.name = 'rooftop_swimming_pool_with_exit_steps';
    poolGroup.position.set(-2.5, 0, 0);
    f4.add(poolGroup);
    const poolOuterMat = new THREE.MeshStandardMaterial({ color: 0x315a68, roughness: 0.42 });
    const poolTileMat = new THREE.MeshStandardMaterial({ color: 0x8ed4df, roughness: 0.28 });
    const poolWaterMat = new THREE.MeshStandardMaterial({
      color: 0x08a9d0, roughness: 0.08, metalness: 0.12,
      transparent: true, opacity: 0.76, side: THREE.DoubleSide
    });
    const poolBottom = new THREE.Mesh(new THREE.BoxGeometry(6.0, 0.28, 6.0), poolOuterMat);
    poolBottom.position.set(0, yOff - 1.25, 0);
    poolBottom.receiveShadow = true;
    poolGroup.add(poolBottom);
    // Four raised basin walls; a stair opening is left on the south/east side.
    const poolWalls = [
      [0, yOff - 0.60, -2.92, 6.0, 1.9, 0.22],
      [-2.92, yOff - 0.60, 0, 0.22, 1.9, 6.0],
      [2.92, yOff - 0.60, 0, 0.22, 1.9, 6.0],
      [-1.15, yOff - 0.60, 2.92, 3.7, 1.9, 0.22],
      [2.35, yOff - 0.60, 2.92, 1.15, 1.9, 0.22]
    ];
    for (const [x,y,z,w,h,d] of poolWalls) {
      const wall = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), poolTileMat);
      wall.position.set(x,y,z); wall.castShadow = true; wall.receiveShadow = true;
      poolGroup.add(wall);
    }
    const water = new THREE.Mesh(new THREE.PlaneGeometry(5.55, 5.55), poolWaterMat);
    water.rotation.x = -Math.PI / 2;
    water.position.set(0, yOff + 0.02, 0);
    poolGroup.add(water);
    this.poolWaterMesh = water;
    // Three broad submerged steps provide a visible, climbable entry/exit.
    for (let i = 0; i < 4; i++) {
      const step = new THREE.Mesh(new THREE.BoxGeometry(1.35, 0.16, 0.62), poolTileMat);
      step.position.set(1.2, yOff - 1.02 + i * 0.28, 2.25 - i * 0.58);
      step.receiveShadow = true;
      poolGroup.add(step);
    }

    const glassBoundaryMat = new THREE.MeshStandardMaterial({ color: 0x9ed8e8, transparent: true, opacity: 0.34, roughness: 0.12, metalness: 0.18, side: THREE.DoubleSide });
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x303a42, metalness: 0.82, roughness: 0.28 });
    const addGlassPanel = (w:number,h:number,d:number,x:number,z:number) => { const panel = new THREE.Mesh(new THREE.BoxGeometry(w,h,d),glassBoundaryMat); panel.position.set(x,yOff+0.95,z); panel.castShadow=true; f4.add(panel); };
    // Continuous glass safety boundary. The east side has one controlled access gate.
    addGlassPanel(15.8,1.8,0.12,0,6.85); addGlassPanel(15.8,1.8,0.12,0,-6.85); addGlassPanel(0.12,1.8,13.7,-7.85,0);
    addGlassPanel(0.12,1.8,5.2,7.85,-4.25); addGlassPanel(0.12,1.8,5.2,7.85,4.25);
    for (const x of [-7.85,0,7.85]) for (const z of [-6.85,0,6.85]) { const post=new THREE.Mesh(new THREE.BoxGeometry(0.13,2.0,0.13),frameMat); post.position.set(x,yOff+1.0,z); f4.add(post); }
    this.roofAccessGate = new THREE.Group(); this.roofAccessGate.name = 'mansion_rooftop_access_gate';
    this.roofAccessGate.position.set(7.85,yOff+0.1,-0.8);
    const roofGateLeaf = new THREE.Mesh(new THREE.BoxGeometry(0.12,1.8,1.7),glassBoundaryMat); roofGateLeaf.position.set(0,0.9,0.85); this.roofAccessGate.add(roofGateLeaf);
    const roofGateFrame = new THREE.Mesh(new THREE.BoxGeometry(0.18,1.95,0.12),frameMat); roofGateFrame.position.set(0,0.95,0); this.roofAccessGate.add(roofGateFrame);
    f4.add(this.roofAccessGate);
    const pergolaMat = new THREE.MeshStandardMaterial({ color: 0x343b42, metalness: 0.55, roughness: 0.45 });
    for (const x of [2.5,7.0]) for (const z of [-2.8,2.8]) {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.16,2.4,0.16),pergolaMat);
      post.position.set(x,yOff+1.35,z); f4.add(post);
    }
    for (let i=0;i<5;i++) {
      const beam = new THREE.Mesh(new THREE.BoxGeometry(5.0,0.12,0.14),pergolaMat);
      beam.position.set(4.75,yOff+2.55,-2.8+i*1.4); f4.add(beam);
    }
    const benchMat = new THREE.MeshStandardMaterial({ color: 0x7b573c, roughness: 0.8 });
    for (const z of [-2.0,2.0]) {
      const bench = new THREE.Mesh(new THREE.BoxGeometry(2.2,0.22,0.65),benchMat);
      bench.position.set(-3.0,yOff+0.45,z); f4.add(bench);
    }
    // Rooftop garden, outdoor kitchen/dining, water tanks and observation deck.
    const planterMat = new THREE.MeshStandardMaterial({ color:0x5a4939,roughness:0.88 });
    const leafMat = new THREE.MeshStandardMaterial({ color:0x4b9b50,roughness:0.9 });
    for(let i=0;i<4;i++){
      const planter=new THREE.Mesh(new THREE.BoxGeometry(1.1,0.45,0.75),planterMat); planter.position.set(2.7+i*1.2,yOff+0.42,4.8); f4.add(planter);
      const shrub=new THREE.Mesh(new THREE.SphereGeometry(0.38,8,6),leafMat); shrub.position.set(2.7+i*1.2,yOff+0.82,4.8); f4.add(shrub);
    }
    const kitchenCounter = new THREE.Mesh(new THREE.BoxGeometry(3.0,0.9,0.8),this.metalTrimMat); kitchenCounter.position.set(4.7,yOff+0.55,-4.4); f4.add(kitchenCounter);
    const diningTable = new THREE.Mesh(new THREE.BoxGeometry(2.4,0.16,1.35),benchMat); diningTable.position.set(1.4,yOff+0.8,-4.1); f4.add(diningTable);
    for(const x of [0.5,2.3]) for(const z of [-4.1,-3.1]) { const chair=new THREE.Mesh(new THREE.BoxGeometry(0.5,0.8,0.5),benchMat); chair.position.set(x,yOff+0.45,z); f4.add(chair); }
    const tankMat = new THREE.MeshStandardMaterial({color:0x87949c,metalness:0.62,roughness:0.38});
    for(let i=0;i<2;i++){const tank=new THREE.Mesh(new THREE.CylinderGeometry(0.62,0.62,1.6,16),tankMat);tank.position.set(-5.7+i*1.5,yOff+0.95,5.0);f4.add(tank);}
    const observationDeck = new THREE.Mesh(new THREE.BoxGeometry(3.2,0.18,1.1),this.woodFloorMat); observationDeck.position.set(-1.2,yOff+0.38,6.0); f4.add(observationDeck);

    // Compact solar backup array supports the mansion emergency-power system.
    const solarMat = new THREE.MeshStandardMaterial({ color: 0x123b5b, metalness:0.65, roughness:0.25 });
    for (let i=0;i<3;i++) {
      const panel = new THREE.Mesh(new THREE.BoxGeometry(1.8,0.08,1.15),solarMat);
      panel.position.set(-5.7+i*2.0,yOff+0.55,-4.5); panel.rotation.x=-0.12; f4.add(panel);
    }
  }

  // ==========================================
  // CONTINUOUS FIVE-LEVEL STAIRCASE
  // ==========================================
  private buildContinuousStaircase() {
    const sc = this.staircaseGroup;
    // Four continuous switchback flights connect the ground, first, second,
    // third and rooftop levels without teleporting between floors.
    const stairMat = new THREE.MeshStandardMaterial({ color: 0x3d4147, metalness: 0.5, roughness: 0.6 });
    const handrailMat = new THREE.MeshStandardMaterial({ color: 0xd4af37, metalness: 0.9, roughness: 0.3 });
    const flightZ0 = -3.5;
    const flightZ1 = 0.7;
    const flightDepth = flightZ1 - flightZ0;
    const numSteps = 16;
    const stepH = 3.2 / numSteps;
    const stepD = flightDepth / numSteps;
    const lanes = [5.25, 6.75, 5.25, 6.75];

    for (let floorIdx = 0; floorIdx < 4; floorIdx++) {
      const baseH = floorIdx * 3.2;
      const laneX = lanes[floorIdx];
      const reverse = floorIdx % 2 === 1;
      const flightGroup = new THREE.Group();
      flightGroup.name = `stair_flight_${floorIdx + 1}_switchback`;
      for (let stepIndex = 0; stepIndex < numSteps; stepIndex++) {
        const t = (stepIndex + 0.5) / numSteps;
        const z = reverse ? flightZ1 - t * flightDepth : flightZ0 + t * flightDepth;
        const step = new THREE.Mesh(new THREE.BoxGeometry(1.18, stepH, stepD + 0.04), stairMat);
        step.position.set(laneX, baseH + (stepIndex + 0.5) * stepH, z);
        step.castShadow = true;
        step.receiveShadow = true;
        flightGroup.add(step);
      }

      // Parallel handrails and balusters on both sides of each flight.
      for (const sideX of [laneX - 0.66, laneX + 0.66]) {
        const rail = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, Math.hypot(3.2, flightDepth), 8), handrailMat);
        rail.rotation.x = Math.PI / 2 - Math.atan2(3.2, flightDepth) * (reverse ? -1 : 1);
        rail.position.set(sideX, baseH + 1.75, (flightZ0 + flightZ1) / 2);
        flightGroup.add(rail);
        for (let b = 0; b <= 8; b++) {
          const t = b / 8;
          const baluster = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.9, 6), handrailMat);
          baluster.position.set(sideX, baseH + 0.5 + t * 2.7, reverse ? flightZ1 - t * flightDepth : flightZ0 + t * flightDepth);
          flightGroup.add(baluster);
        }
      }
      sc.add(flightGroup);

      // Full-width alternating landings join the ends of successive flights.
      const landingZ = reverse ? flightZ0 : flightZ1;
      const landing = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.25, 1.15), this.floorTileMat);
      landing.position.set(6.0, baseH + 3.2 + 0.12, landingZ);
      landing.receiveShadow = true;
      sc.add(landing);
    }
  }

  // ==========================================
  // EXTERIOR FACADE & DIRECTIONAL CUTAWAY
  // ==========================================
  private buildExteriorFacade() {
    const ext = this.exteriorWalls;

    // Corner Pillars & Cornices for exterior architectural look
    for (const [cx, cz] of [[-7.9, -6.9], [7.9, -6.9], [-7.9, 6.9], [7.9, 6.9]]) {
      const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.8, 16.0, 0.8), this.metalTrimMat);
      pillar.position.set(cx, 8.0, cz);
      pillar.castShadow = true;
      ext.add(pillar);
    }

    // Floor Decorative Cornices between stories
    for (let f = 1; f <= 4; f++) {
      const cornice = new THREE.Mesh(new THREE.BoxGeometry(16.5, 0.35, 14.5), this.metalTrimMat);
      cornice.position.set(0, f * 3.2, 0);
      ext.add(cornice);
    }

    // 1. North Wall (Back)
    this.northWallMesh = new THREE.Group();
    const northWall = new THREE.Mesh(new THREE.BoxGeometry(16.0, 16.0, 0.5), this.brickFacadeMat);
    northWall.position.set(0, 8.0, 6.8);
    northWall.castShadow = true;
    this.northWallMesh.add(northWall);
    ext.add(this.northWallMesh);

    // 2. East Wall (Stairwell Bay)
    this.eastWallMesh = new THREE.Group();
    const eastWall = new THREE.Mesh(new THREE.BoxGeometry(0.5, 16.0, 14.0), this.brickFacadeMat);
    eastWall.position.set(7.8, 8.0, 0);
    eastWall.castShadow = true;
    this.eastWallMesh.add(eastWall);
    ext.add(this.eastWallMesh);

    // 3. West Wall (Bedrooms & Armory Display)
    this.westWallMesh = new THREE.Group();
    const westWall = new THREE.Mesh(new THREE.BoxGeometry(0.5, 16.0, 14.0), this.brickFacadeMat);
    westWall.position.set(-7.8, 8.0, 0);
    westWall.castShadow = true;
    this.westWallMesh.add(westWall);
    ext.add(this.westWallMesh);

    // 4. South Wall (Front Entrance Facade with door opening)
    this.southWallMesh = new THREE.Group();
    const southWallLeft = new THREE.Mesh(new THREE.BoxGeometry(7.0, 16.0, 0.5), this.brickFacadeMat);
    southWallLeft.position.set(-4.5, 8.0, -6.8);
    southWallLeft.castShadow = true;

    const southWallRight = new THREE.Mesh(new THREE.BoxGeometry(7.0, 16.0, 0.5), this.brickFacadeMat);
    southWallRight.position.set(4.5, 8.0, -6.8);
    southWallRight.castShadow = true;

    const southWallTop = new THREE.Mesh(new THREE.BoxGeometry(2.0, 13.4, 0.5), this.brickFacadeMat);
    southWallTop.position.set(0, 9.3, -6.8);

    this.southWallMesh.add(southWallLeft, southWallRight, southWallTop);
    ext.add(this.southWallMesh);
  }

  // ==========================================
  // ENCLOSED RESIDENTIAL PROPERTY + BACKYARD POOL
  // ==========================================
  private buildEnclosedProperty() {
    const property = new THREE.Group();
    property.name = 'apartment_enclosed_residential_compound';
    this.group.add(property);

    const wallMat = new THREE.MeshStandardMaterial({ color: 0x777d82, roughness: 0.88 });
    const capMat = new THREE.MeshStandardMaterial({ color: 0x343a40, roughness: 0.55, metalness: 0.35 });
    const pavingMat = new THREE.MeshStandardMaterial({ color: 0xaaa9a2, roughness: 0.92 });
    const grassMat = new THREE.MeshStandardMaterial({ color: 0x496b3b, roughness: 1 });
    const gateMat = new THREE.MeshStandardMaterial({ color: 0x202a32, metalness: 0.78, roughness: 0.32 });
    const waterMat = new THREE.MeshStandardMaterial({ color: 0x16a9c7, roughness: 0.08, metalness: 0.12, transparent: true, opacity: 0.82 });

    // Yard is a visual surface only; terrain remains the authoritative ground collider.
    const lawn = new THREE.Mesh(new THREE.PlaneGeometry(37, 48), grassMat);
    lawn.rotation.x = -Math.PI / 2;
    lawn.position.set(0, 0.025, 2.5);
    lawn.receiveShadow = true;
    property.add(lawn);

    const path = new THREE.Mesh(new THREE.BoxGeometry(4.4, 0.08, 17), pavingMat);
    path.position.set(0, 0.09, -13.0);
    path.receiveShadow = true;
    property.add(path);

    const wallH = 3.4;
    const wallT = 0.55;
    const wallY = wallH / 2;
    const addWall = (name: string, x: number, z: number, w: number, d: number) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, wallH, d), wallMat);
      mesh.name = name;
      mesh.position.set(x, wallY, z);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      property.add(mesh);
      const cap = new THREE.Mesh(new THREE.BoxGeometry(w + 0.12, 0.18, d + 0.12), capMat);
      cap.position.set(x, wallH + 0.08, z);
      property.add(cap);
    };

    // Continuous perimeter: only the front entrance is open, and it is closed by two gate leaves.
    addWall('compound_wall_west', -19.0, 2.5, wallT, 49.0);
    addWall('compound_wall_east', 19.0, 2.5, wallT, 49.0);
    addWall('compound_wall_rear', 0, 27.0, 38.5, wallT);
    // Front boundary has exactly one vehicle gate plus two pedestrian doors.
    // Wall sections stop at each opening; the doors themselves are solid colliders.
    addWall('compound_wall_front_left_outer', -15.86, -22.0, 6.28, wallT);
    addWall('compound_wall_front_left_inner', -6.915, -22.0, 8.73, wallT);
    addWall('compound_wall_front_right_inner', 6.915, -22.0, 8.73, wallT);
    addWall('compound_wall_front_right_outer', 15.86, -22.0, 6.28, wallT);

    // Reinforced gate pillars and a fully modelled, hinged double-leaf entrance.
    for (const x of [-2.8, 2.8]) {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.85, 4.0, 0.9), capMat);
      post.position.set(x, 2.0, -22.0);
      post.castShadow = true;
      property.add(post);
      const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.22, 0.45), new THREE.MeshStandardMaterial({ color: 0xffd58a, emissive: 0x8a5418, emissiveIntensity: 0.45 }));
      lamp.position.set(x, 4.12, -22.0);
      property.add(lamp);
    }

    this.compoundGateGroup = new THREE.Group();
    this.compoundGateGroup.name = 'compound_double_access_gate';
    this.compoundGateGroup.position.set(0, 1.65, -22.0);
    this.compoundGateLeftLeaf = new THREE.Group();
    this.compoundGateLeftLeaf.position.x = -2.55;
    this.compoundGateRightLeaf = new THREE.Group();
    this.compoundGateRightLeaf.position.x = 2.55;
    const makeLeaf = (pivot: THREE.Group, sign: number) => {
      const panel = new THREE.Mesh(new THREE.BoxGeometry(2.55, 3.15, 0.18), gateMat);
      panel.position.x = sign * 1.275;
      panel.castShadow = true;
      panel.receiveShadow = true;
      pivot.add(panel);
      for (let i = 0; i < 5; i++) {
        const bar = new THREE.Mesh(new THREE.BoxGeometry(0.08, 3.18, 0.22), capMat);
        bar.position.x = sign * (0.3 + i * 0.48);
        pivot.add(bar);
      }
      const rail = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.12, 0.24), capMat);
      rail.position.set(sign * 1.275, 0.85, 0);
      pivot.add(rail);
    };
    makeLeaf(this.compoundGateLeftLeaf, 1);
    makeLeaf(this.compoundGateRightLeaf, -1);
    this.compoundGateGroup.add(this.compoundGateLeftLeaf, this.compoundGateRightLeaf);
    property.add(this.compoundGateGroup);

    // Two secure pedestrian access doors. Both start closed and only become
    // traversable when their matching collider is explicitly opened.
    const makePedestrianDoor = (x: number, side: 'left' | 'right') => {
      const hinge = new THREE.Group();
      hinge.name = `compound_pedestrian_door_${side}`;
      hinge.position.set(x - 0.72, 0, -22.0);
      const leaf = new THREE.Mesh(new THREE.BoxGeometry(1.44, 3.0, 0.16), gateMat);
      leaf.position.set(0.72, 1.5, 0);
      leaf.castShadow = true;
      leaf.receiveShadow = true;
      hinge.add(leaf);
      for (let y = 0.45; y < 2.8; y += 0.75) {
        const brace = new THREE.Mesh(new THREE.BoxGeometry(1.35, 0.07, 0.2), capMat);
        brace.position.set(0.72, y, 0);
        hinge.add(brace);
      }
      property.add(hinge);
      return hinge;
    };
    this.compoundPedestrianDoorLeft = makePedestrianDoor(-12.0, 'left');
    this.compoundPedestrianDoorRight = makePedestrianDoor(12.0, 'right');

    // Backyard pool sits BEHIND the apartment (positive local Z), at ground level.
    const pool = new THREE.Group();
    pool.name = 'backyard_swimming_pool';
    pool.position.set(-13.2, 0, -14.5);
    property.add(pool);
    const deck = new THREE.Mesh(new THREE.BoxGeometry(10.0, 0.16, 10.0), pavingMat);
    deck.position.y = 0.08;
    deck.receiveShadow = true;
    pool.add(deck);
    const basinMat = new THREE.MeshStandardMaterial({ color: 0x315a68, roughness: 0.42 });
    const basin = new THREE.Mesh(new THREE.BoxGeometry(8.6, 0.55, 8.6), basinMat);
    basin.position.y = 0.16;
    pool.add(basin);
    const water = new THREE.Mesh(new THREE.PlaneGeometry(8.0, 8.0), waterMat);
    water.rotation.x = -Math.PI / 2;
    water.position.y = 0.48;
    water.receiveShadow = true;
    pool.add(water);
    this.backyardPoolWaterMesh = water;

    // Pool coping and shallow steps; open centre remains available for swimming.
    const copingMat = new THREE.MeshStandardMaterial({ color: 0xe2ded4, roughness: 0.7 });
    const coping = [
      [0, 0.48, -4.45, 8.8, 0.35, 0.42], [-2.6, 0.48, 4.45, 3.4, 0.35, 0.42], [2.6, 0.48, 4.45, 3.4, 0.35, 0.42],
      [-4.45, 0.48, 0, 0.42, 0.35, 8.8], [4.45, 0.48, 0, 0.42, 0.35, 8.8],
    ];
    for (const [x,y,z,w,h,d] of coping) {
      const edge = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), copingMat);
      edge.position.set(x,y,z);
      edge.castShadow = true;
      pool.add(edge);
    }
    const steps = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.18, 1.2), copingMat);
    steps.position.set(-3.4, 0.28, 3.6);
    pool.add(steps);
    for (let i = 0; i < 3; i++) {
      const entryStep = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.16, 0.55), copingMat);
      entryStep.position.set(0, 0.16 + i * 0.14, 4.9 - i * 0.48);
      pool.add(entryStep);
    }

    // Poolside loungers and low garden lights make the west garden readable and usable.
    const loungerMat = new THREE.MeshStandardMaterial({ color: 0xf0eee8, roughness: 0.72 });
    for (const x of [-18.0, -8.6]) {
      const lounger = new THREE.Mesh(new THREE.BoxGeometry(1.25, 0.22, 2.4), loungerMat);
      lounger.position.set(x, 0.28, -14.5);
      lounger.rotation.y = x < 0 ? 0.12 : -0.12;
      lounger.castShadow = true;
      property.add(lounger);
      const light = new THREE.PointLight(0x8bdfff, 0.75, 9, 1.8);
      light.position.set(x, 1.0, -14.5);
      property.add(light);
      this.floorLights.push(light);
    }
      
    // The old single-sedan garage was removed; the five-bay physical garage is authored by VehicleParkingManager.

}

  public updateTVScreenContent(isOn: boolean, isEmergency: boolean = false) {
    if (!this.tvContext) return;
    const ctx = this.tvContext;
    const w = this.tvCanvas.width;
    const h = this.tvCanvas.height;

    if (!isOn) {
      ctx.fillStyle = '#0a0a0a';
      ctx.fillRect(0, 0, w, h);
      return;
    }

    if (isEmergency) {
      // Day 2 Emergency Alert System Broadcast
      ctx.fillStyle = '#1c0505';
      ctx.fillRect(0, 0, w, h);

      // Red Alert Header Banner
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(0, 0, w, 55);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 22px sans-serif';
      ctx.fillText('EMERGENCY ALERT SYSTEM (EAS) · ACTIVE BROADCAST', 16, 36);

      // Flashing Alert Ticker
      ctx.fillStyle = '#7f1d1d';
      ctx.fillRect(0, h - 50, w, 50);
      ctx.fillStyle = '#fef08a';
      ctx.font = 'bold 16px sans-serif';
      ctx.fillText('CRITICAL: HIGH-DENSITY BOLIDE IMPACT CORRIDOR — SECTOR 4 RIDGE', 16, h - 20);

      // Emergency Body Text
      ctx.fillStyle = '#fca5a5';
      ctx.font = 'bold 16px monospace';
      ctx.fillText('WARNING: ATMOSPHERIC TRAJECTORY DETECTED OVER VALLEY', 24, 95);
      ctx.fillText('CIVILIAN ADVISORY: PREPARE FOR SEISMIC SHOCKWAVES', 24, 125);
      ctx.fillText('POWER GRID: FLUCTUATIONS REPORTED ACROSS SECTOR 1-4', 24, 155);
      ctx.fillText('ALL RESIDENTS: AVOID WINDOWS & ASSEMBLE EMERGENCY SUPPLIES', 24, 185);
    } else {
      // Day 1 Peaceful Channel 4 News
      ctx.fillStyle = '#061626';
      ctx.fillRect(0, 0, w, h);

      // Blue header banner
      ctx.fillStyle = '#0284c7';
      ctx.fillRect(0, 0, w, 50);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 24px sans-serif';
      ctx.fillText('OAKRIDGE CHANNEL 4 NEWS · LIVE', 20, 35);

      // Ticker bar
      ctx.fillStyle = '#0369a1';
      ctx.fillRect(0, h - 45, w, 45);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 16px sans-serif';
      ctx.fillText('SCIENCE UPDATE: UNIDENTIFIED CELESTIAL OBJECT DETECTED IN DEEP SPACE', 20, h - 16);

      // News content
      ctx.fillStyle = '#38bdf8';
      ctx.font = '16px monospace';
      ctx.fillText('ASTRONOMY: OBJECT ON UNUSUAL TRAJECTORY PAST INNER SYSTEM', 30, 95);
      ctx.fillText('SCIENTISTS: MONITORING DATA · NO IMMEDIATE THREAT EXPECTED', 30, 125);
      ctx.fillText('WEATHER: 72°F · PLEASANT WARM SUMMER AFTERNOON IN OAKRIDGE', 30, 155);
      ctx.fillText('MUNICIPAL: ANNUAL VALLEY RIDGE PARK FESTIVAL THIS WEEKEND', 30, 185);
    }

    // Broadcast icon
    ctx.strokeStyle = isEmergency ? '#ef4444' : '#38bdf8';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(w - 70, 130, 32, 0, Math.PI * 2);
    ctx.stroke();
  }

  // ==========================================
  // UPDATE LOOP & CAMERA-AWARE VISIBILITY
  // ==========================================
  public update(delta: number, playerPos: THREE.Vector3, cameraPos: THREE.Vector3) {
    // 1. Ceiling Fan Rotation
    if (this.state.fanOn && this.fanBlades) {
      this.fanBlades.rotation.y += this.state.fanSpeed * delta;
    }

    // 2. Pool Water Wave Ripple Animation
    if (this.poolWaterMesh) {
      const t = performance.now() * 0.002;
      this.poolWaterMesh.position.y = 12.82 + Math.sin(t) * 0.025;
      if (this.indoorPoolWaterMesh) this.indoorPoolWaterMesh.position.y = 0.82 + Math.sin(t * 0.9) * 0.012;
      if (this.backyardPoolWaterMesh) this.backyardPoolWaterMesh.position.y = 0.48 + Math.sin(t * 0.8) * 0.018;
    }

    // 3. Camera-Aware Cutaway Architecture:
    const relX = playerPos.x - this.origin.x;
    const relY = playerPos.y - this.origin.y;
    const relZ = playerPos.z - this.origin.z;

    const isInsideBuilding = Math.abs(relX) < 8.2 && Math.abs(relZ) < 7.2 && relY >= 0 && relY <= 17.0;

    if (isInsideBuilding) {
      // In 3rd person mode, hide the wall between camera and player so the interior is NEVER obstructed
      const camRelZ = cameraPos.z - this.origin.z;
      const camRelX = cameraPos.x - this.origin.x;

      this.southWallMesh.visible = !(camRelZ < relZ - 0.5);
      this.northWallMesh.visible = !(camRelZ > relZ + 0.5);
      this.westWallMesh.visible = !(camRelX < relX - 0.5);
      this.eastWallMesh.visible = !(camRelX > relX + 0.5);

      // Floor cutaways: ensure furniture on player's current floor and adjacent floor is visible
      if (relY < 3.2) {
        // Floor 1
        this.floor1Group.visible = true;
        this.floor2Group.visible = true;
        this.floor3Group.visible = false;
        this.floor4Group.visible = false;
        this.floor5Group.visible = false;
      } else if (relY < 6.4) {
        // Floor 2
        this.floor1Group.visible = true;
        this.floor2Group.visible = true;
        this.floor3Group.visible = true;
        this.floor4Group.visible = false;
        this.floor5Group.visible = false;
      } else if (relY < 9.6) {
        // Floor 3 (Armory)
        this.floor1Group.visible = false;
        this.floor2Group.visible = true;
        this.floor3Group.visible = true;
        this.floor4Group.visible = false;
        this.floor5Group.visible = false;
      } else if (relY < 12.8) {
        // Floor 4 (third-floor command and utilities)
        this.floor1Group.visible = false;
        this.floor2Group.visible = false;
        this.floor3Group.visible = true;
        this.floor4Group.visible = true;
        this.floor5Group.visible = false;
      } else {
        // Floor 5 (rooftop pool and terrace)
        this.floor1Group.visible = false;
        this.floor2Group.visible = false;
        this.floor3Group.visible = false;
        this.floor4Group.visible = true;
        this.floor5Group.visible = true;
      }
    } else {
      // Player is outside: all exterior walls and floors visible
      this.southWallMesh.visible = true;
      this.northWallMesh.visible = true;
      this.westWallMesh.visible = true;
      this.eastWallMesh.visible = true;
      this.floor1Group.visible = true;
      this.floor2Group.visible = true;
      this.floor3Group.visible = true;
      this.floor4Group.visible = true;
      this.floor5Group.visible = true;
    }
  }

  // ==========================================
  // INTERACTION SYSTEM & DISCOVERY HOOKS
  // ==========================================
  public getInteraction(pos: THREE.Vector3): {
    id: 'bed' | 'phone' | 'fridge' | 'tv' | 'fan' | 'ac' | 'armory' | 'pool' | 'roofGate' | 'backyardPool' | 'medicalWing' | 'commandConsole' | 'waterPlant' | 'generator' | 'workshop' | 'foodStorage' | 'indoorFarm' | 'door' | 'compoundGate' | 'compoundDoorLeft' | 'compoundDoorRight';
    label: string;
    prompt: string;
  } | null {
    const relX = pos.x - this.origin.x;
    const relY = pos.y - this.origin.y;
    const relZ = pos.z - this.origin.z;

    // Outer double gate and backyard pool are outside the apartment footprint.
    if (Math.abs(relX) < 4.2 && Math.abs(relZ + 22) < 2.8 && relY < 3.2) {
      return { id: 'compoundGate', label: 'Residential Compound Double Gate', prompt: `Press [E] to ${this.compoundGateOpen ? 'Close' : 'Open'} Property Gate` };
    }
    if (Math.abs(relX + 12.0) < 2.0 && Math.abs(relZ + 22) < 2.2 && relY < 3.0) {
      return { id: 'compoundDoorLeft', label: 'West Perimeter Pedestrian Door', prompt: `Press [E] to ${this.compoundPedestrianDoorsOpen[0] ? 'Close' : 'Open'} Pedestrian Door` };
    }
    if (Math.abs(relX - 12.0) < 2.0 && Math.abs(relZ + 22) < 2.2 && relY < 3.0) {
      return { id: 'compoundDoorRight', label: 'East Perimeter Pedestrian Door', prompt: `Press [E] to ${this.compoundPedestrianDoorsOpen[1] ? 'Close' : 'Open'} Pedestrian Door` };
    }
    if (Math.abs(relX + 13.2) < 5.2 && relZ > -19.5 && relZ < -9.5 && relY < 2.2) {
      return { id: 'backyardPool', label: 'Backyard Swimming Pool', prompt: 'Press [E] to Enter Backyard Swimming Pool' };
    }
    // Apartment interactions are limited to the building footprint.
    if (Math.abs(relX) > 11 || Math.abs(relZ) > 10) return null;

    // --- FLOOR 1 INTERACTIONS ---
    if (relY < 3.0) {
      // 1. Bed at (-5.5, 3.8)
      if (Math.hypot(relX - (-5.5), relZ - 3.8) < 2.4) {
        return { id: 'bed', label: 'Apartment Bed', prompt: 'Press [E] to Rest & Sleep in Bed' };
      }
      // 2. TV at (-5.5, 0.0)
      if (Math.hypot(relX - (-5.5), relZ - 0.0) < 2.5) {
        return {
          id: 'tv',
          label: 'Smart Television',
          prompt: `Press [E] to Turn ${this.state.tvOn ? 'OFF' : 'ON'} News Television`,
        };
      }
      // 3. Refrigerator at (4.5, 5.8)
      if (Math.hypot(relX - 4.5, relZ - 5.8) < 2.2) {
        return { id: 'fridge', label: 'Apartment Refrigerator', prompt: 'Press [E] to Open Refrigerator Food Storage' };
      }
      // 4. Smartphone on coffee table at (0.3, -1.2)
      if (Math.hypot(relX - 0.3, relZ - (-1.2)) < 2.0) {
        return { id: 'phone', label: 'Smartphone', prompt: 'Press [E] to Check In-Game Phone Messages' };
      }
      // 5. Ceiling fan switch
      if (Math.hypot(relX - 0, relZ - 0.5) < 2.2) {
        return {
          id: 'fan',
          label: 'Ceiling Fan',
          prompt: `Press [E] to ${this.state.fanOn ? 'Stop' : 'Start'} Ceiling Fan`,
        };
      }
      // 6. Air conditioner switch at (-2.5, -6.6)
      if (Math.hypot(relX - (-2.5), relZ - (-6.6)) < 2.2) {
        return {
          id: 'ac',
          label: 'Air Conditioner',
          prompt: `Press [E] to ${this.state.acOn ? 'Turn OFF' : 'Turn ON'} Air Conditioner`,
        };
      }
      // 7. Front entrance door at (0, -6.9)
      if (Math.hypot(relX - 0, relZ - (-6.9)) < 2.2) {
        return {
          id: 'door',
          label: 'Apartment Front Door',
          prompt: `Press [E] to ${this.state.doorOpen ? 'Close' : 'Open'} Entrance Door`,
        };
      }
    }

    // --- FLOOR 3 (ARMORY) INTERACTIONS ---
    if (relY >= 6.0 && relY < 9.4) {
      if (Math.hypot(relX - 2.0, relZ - 0.0) < 3.2 || Math.hypot(relX - (-5.0), relZ - 0.0) < 4.0) {
        return {
          id: 'armory',
          label: 'Sector Armory & Weapon Vault',
          prompt: 'Press [E] to Access 100-Item Fictional Armory Vault',
        };
      }
    }

    // First-floor medical wing.
    if (relY >= 3.2 && relY < 6.4 && Math.abs(relX) < 2.6 && relZ > -5.8 && relZ < 2.4) {
      return { id: 'medicalWing', label: 'Mansion Medical Wing', prompt: 'Press [E] to inspect the examination, recovery and medical storage rooms' };
    }

    // Third-floor self-sufficiency systems.
    if (relY >= 9.2 && relY < 12.4) {
      if (Math.abs(relX + 4.8) < 2.8 && Math.abs(relZ + 4.6) < 1.8) return { id: 'commandConsole', label: 'Mansion Command Centre', prompt: 'Press [E] to access the sanctuary command terminal' };
      if (Math.abs(relX - 5.7) < 1.8 && Math.abs(relZ + 4.6) < 1.8) return { id: 'foodStorage', label: 'Food and Cold Storage', prompt: 'Press [E] to inspect food reserves and cold storage' };
      if (Math.abs(relX + 4.8) < 3.2 && Math.abs(relZ - 2.9) < 3.2) return { id: 'indoorFarm', label: 'Indoor Farming Racks', prompt: 'Press [E] to inspect the indoor farming system' };
      if (Math.abs(relX - 5.6) < 2.0 && Math.abs(relZ - 2.4) < 2.0) return { id: 'waterPlant', label: 'Water Purification Plant', prompt: 'Press [E] to inspect water purification systems' };
      if (Math.abs(relX - 1.8) < 2.0 && Math.abs(relZ + 4.7) < 1.8) return { id: 'generator', label: 'Backup Generator', prompt: 'Press [E] to inspect backup power and electrical systems' };
      if (Math.abs(relX - 1.8) < 2.6 && Math.abs(relZ - 4.8) < 1.8) return { id: 'workshop', label: 'Mansion Workshop', prompt: 'Press [E] to inspect the workshop and emergency storage' };
    }

    // --- FLOOR 5 (ROOFTOP POOL AND ACCESS GATE) INTERACTIONS ---
    if (relY >= 12.4) {
      if (Math.abs(relX - 7.85) < 2.0 && Math.abs(relZ) < 2.0) return { id: 'roofGate', label: 'Rooftop Safety Gate', prompt: `Press [E] to ${this.roofGateOpen ? 'Close' : 'Open'} Rooftop Access Gate` };
      if (Math.hypot(relX - (-2.5), relZ - 0.0) < 5.0) {
        return {
          id: 'pool',
          label: 'Rooftop Swimming Pool',
          prompt: 'Press [E] to Dive into Rooftop Swimming Pool',
        };
      }
    }

    return null;
  }

  public toggleRoofGate(): boolean {
    this.roofGateOpen = !this.roofGateOpen;
    if (this.roofAccessGate) this.roofAccessGate.rotation.y = this.roofGateOpen ? -Math.PI / 2 : 0;
    UnifiedPhysicsManager.getInstance()?.setDoorOpenState('mansion_roof_access_gate', this.roofGateOpen);
    soundEngine.playUIClick();
    return this.roofGateOpen;
  }

  public toggleTV(forceState?: boolean, isEmergency: boolean = false): boolean {
    this.state.tvOn = forceState !== undefined ? forceState : !this.state.tvOn;
    this.updateTVScreenContent(this.state.tvOn, isEmergency);
    this.tvTexture.needsUpdate = true;
    soundEngine.playUIClick();
    return this.state.tvOn;
  }

  public toggleFan(): boolean {
    this.state.fanOn = !this.state.fanOn;
    soundEngine.playUIClick();
    return this.state.fanOn;
  }

  public toggleAC(): boolean {
    this.state.acOn = !this.state.acOn;
    this.acLedMat.color.setHex(this.state.acOn ? 0x00ff88 : 0x441111);
    soundEngine.playUIClick();
    return this.state.acOn;
  }

  public toggleDoor(): boolean {
    this.state.doorOpen = !this.state.doorOpen;
    if (this.frontDoorLeftLeaf && this.frontDoorRightLeaf) {
      // Both leaves swing away from the centre and stay synchronized.
      this.frontDoorLeftLeaf.rotation.y = this.state.doorOpen ? -Math.PI / 2 : 0;
      this.frontDoorRightLeaf.rotation.y = this.state.doorOpen ? Math.PI / 2 : 0;
    }
    UnifiedPhysicsManager.getInstance()?.setDoorOpenState('apt_front_door', this.state.doorOpen);
    soundEngine.playGateToggle(this.state.doorOpen);
    return this.state.doorOpen;
  }

  public toggleCompoundGate(): boolean {
    this.compoundGateOpen = !this.compoundGateOpen;
    if (this.compoundGateLeftLeaf && this.compoundGateRightLeaf) {
      this.compoundGateLeftLeaf.rotation.y = this.compoundGateOpen ? -Math.PI / 2 : 0;
      this.compoundGateRightLeaf.rotation.y = this.compoundGateOpen ? Math.PI / 2 : 0;
    }
    UnifiedPhysicsManager.getInstance()?.setDoorOpenState('apt_compound_gate', this.compoundGateOpen);
    soundEngine.playGateToggle(this.compoundGateOpen);
    return this.compoundGateOpen;
  }

  public toggleCompoundPedestrianDoor(side: 'left' | 'right'): boolean {
    const index = side === 'left' ? 0 : 1;
    this.compoundPedestrianDoorsOpen[index] = !this.compoundPedestrianDoorsOpen[index];
    const hinge = side === 'left' ? this.compoundPedestrianDoorLeft : this.compoundPedestrianDoorRight;
    if (hinge) hinge.rotation.y = this.compoundPedestrianDoorsOpen[index] ? (side === 'left' ? -Math.PI / 2 : Math.PI / 2) : 0;
    UnifiedPhysicsManager.getInstance()?.setDoorOpenState(`apt_compound_door_${side}`, this.compoundPedestrianDoorsOpen[index]);
    soundEngine.playGateToggle(this.compoundPedestrianDoorsOpen[index]);
    return this.compoundPedestrianDoorsOpen[index];
  }

  /** Access points used by companion navigation. A closed access point is never selected. */
  public getOpenCompoundAccessPoints(): THREE.Vector3[] {
    const ox = this.origin.x;
    const oz = this.origin.z;
    const points: THREE.Vector3[] = [];
    if (this.compoundGateOpen) points.push(new THREE.Vector3(ox, 0, oz - 22));
    if (this.compoundPedestrianDoorsOpen[0]) points.push(new THREE.Vector3(ox - 12, 0, oz - 22));
    if (this.compoundPedestrianDoorsOpen[1]) points.push(new THREE.Vector3(ox + 12, 0, oz - 22));
    return points;
  }

  /**
   * Return a legal doorway waypoint when a companion and its destination are
   * on opposite sides of the mansion or compound boundary. Closed access points
   * are deliberately excluded, so the companion remains blocked by the wall.
   */
  public getCompanionNavigationWaypoint(from: THREE.Vector3, to: THREE.Vector3): THREE.Vector3 | null {
    const ox = this.origin.x;
    const oz = this.origin.z;
    const buildingFrontZ = oz - 6.9;
    const insideBuilding = (p: THREE.Vector3) => p.x > ox - 8.2 && p.x < ox + 8.2 && p.z > buildingFrontZ && p.z < oz + 7.2;
    const fromInBuilding = insideBuilding(from);
    const toInBuilding = insideBuilding(to);

    // Mansion front entrance: both leaves must be open for traversal.
    if (fromInBuilding !== toInBuilding && this.state.doorOpen) {
      const insideZ = buildingFrontZ + 1.15;
      const outsideZ = buildingFrontZ - 1.15;
      return new THREE.Vector3(ox, Math.max(0, getTerrainHeight(ox, fromInBuilding ? outsideZ : insideZ)), fromInBuilding ? outsideZ : insideZ);
    }

    const boundaryZ = oz - 22;
    const fromInsideCompound = from.z > boundaryZ;
    const toInsideCompound = to.z > boundaryZ;
    if (fromInsideCompound !== toInsideCompound) {
      const openPoints = this.getOpenCompoundAccessPoints();
      if (openPoints.length === 0) return null;
      openPoints.sort((a, b) => Math.hypot(a.x - from.x, a.z - from.z) - Math.hypot(b.x - from.x, b.z - from.z));
      const access = openPoints[0];
      const crossZ = boundaryZ + (fromInsideCompound ? -1.1 : 1.1);
      return new THREE.Vector3(access.x, getTerrainHeight(access.x, crossZ), crossZ);
    }
    return null;
  }

  public isCompoundGateOpen(): boolean { return this.compoundGateOpen; }
  public isFrontDoorOpen(): boolean { return this.state.doorOpen; }

  public checkPlayerInPool(playerPos: THREE.Vector3): boolean {
    const inRoofPool = playerPos.x >= this.origin.x - 5.5 && playerPos.x <= this.origin.x + 0.5 && playerPos.z >= this.origin.z - 3.0 && playerPos.z <= this.origin.z + 3.0 && playerPos.y >= 11.2 && playerPos.y <= 14.0;
    const inIndoorPool = playerPos.x >= this.origin.x - 2.2 && playerPos.x <= this.origin.x + 1.4 && playerPos.z >= this.origin.z + 3.3 && playerPos.z <= this.origin.z + 5.9 && playerPos.y >= 0.15 && playerPos.y <= 1.5;
    const backyard = this.backyardPoolBounds;
    const inBackyardPool = playerPos.x >= this.origin.x + backyard.minX && playerPos.x <= this.origin.x + backyard.maxX &&
      playerPos.z >= this.origin.z + backyard.minZ && playerPos.z <= this.origin.z + backyard.maxZ &&
      playerPos.y >= backyard.minY && playerPos.y <= backyard.maxY + 1.2;
    return inRoofPool || inIndoorPool || inBackyardPool;
  }

  // ==========================================
  // UNIFIED PHYSICS COLLIDER REGISTRATION
  // ==========================================
  public registerColliders(physMgr: UnifiedPhysicsManager) {
    const ox = this.origin.x;
    const oz = this.origin.z;

    // IMPORTANT: floor slabs and stair flights are walkable surfaces, not walls.
    // PlayerController already computes the five level heights and staircase
    // support. Registering these slabs as ordinary solid boxes made the movement
    // resolver push the player out through the nearest exterior wall.

    // 1. Exterior perimeter walls. The south wall intentionally has a 2m doorway.
    physMgr.registerBoxCollider('apt_wall_north', 'wall', [ox, 8.0, oz + 6.8], 16.0, 16.0, 0.6);
    physMgr.registerBoxCollider('apt_wall_east', 'wall', [ox + 7.8, 8.0, oz], 0.6, 16.0, 14.0);
    physMgr.registerBoxCollider('apt_wall_west', 'wall', [ox - 7.8, 8.0, oz], 0.6, 16.0, 14.0);
    physMgr.registerBoxCollider('apt_wall_south_l', 'wall', [ox - 4.5, 8.0, oz - 6.8], 7.0, 16.0, 0.6);
    physMgr.registerBoxCollider('apt_wall_south_r', 'wall', [ox + 4.5, 8.0, oz - 6.8], 7.0, 16.0, 0.6);

    // A single doorway collider is disabled while the double doors are open.
    // This keeps the entrance genuinely passable without making the doors ghostly
    // when the player closes them.
    physMgr.registerBoxCollider(
      'apt_front_door',
      'wall',
      [ox, 1.4, oz - 6.9],
      1.96,
      2.38,
      0.22,
      0,
      this.state.doorOpen
    );

    // Ground-floor indoor pool basin walls; the stair opening remains accessible.
    physMgr.registerBoxCollider('mansion_indoor_pool_n','wall',[ox-0.4,0.62,oz+3.3],3.6,0.75,0.18);
    physMgr.registerBoxCollider('mansion_indoor_pool_w','wall',[ox-2.2,0.62,oz+4.6],0.18,0.75,2.6);
    physMgr.registerBoxCollider('mansion_indoor_pool_e','wall',[ox+1.4,0.62,oz+4.6],0.18,0.75,2.6);
    physMgr.registerBoxCollider('mansion_indoor_pool_s_l','wall',[ox-1.35,0.62,oz+5.9],2.5,0.75,0.18);
    physMgr.registerBoxCollider('mansion_indoor_pool_s_r','wall',[ox+0.85,0.62,oz+5.9],0.3,0.75,0.18);

    // 2. Rooftop pool basin walls on level five.
    physMgr.registerBoxCollider('apt_pool_rim_n', 'wall', [ox - 2.5, 12.2, oz - 2.92], 6.0, 1.9, 0.22);
    physMgr.registerBoxCollider('apt_pool_rim_w', 'wall', [ox - 5.42, 12.2, oz], 0.22, 1.9, 6.0);
    physMgr.registerBoxCollider('apt_pool_rim_e', 'wall', [ox + 0.42, 12.2, oz], 0.22, 1.9, 6.0);
    physMgr.registerBoxCollider('apt_pool_rim_s_l', 'wall', [ox - 3.65, 12.2, oz + 2.92], 3.7, 1.9, 0.22);
    physMgr.registerBoxCollider('apt_pool_rim_s_r', 'wall', [ox - 0.15, 12.2, oz + 2.92], 1.15, 1.9, 0.22);

    // Solid interior partitions across the four enclosed mansion levels.
    physMgr.registerBoxCollider('mansion_ground_bedroom_partition','wall',[ox-2.5,1.6,oz+2.8],0.25,2.9,7.5);
    physMgr.registerBoxCollider('mansion_ground_kitchen_partition','wall',[ox+2.5,1.6,oz+4.0],0.25,2.9,5.0);
    physMgr.registerBoxCollider('mansion_first_partition_vertical','wall',[ox-2.0,4.8,oz+1.5],0.25,2.9,8.0);
    physMgr.registerBoxCollider('mansion_first_partition_horizontal','wall',[ox-5.0,4.8,oz+1.5],6.0,2.9,0.25);
    physMgr.registerBoxCollider('mansion_second_armory_partition','wall',[ox-1.5,8.0,oz],0.25,2.9,10.0);

    // Beds, medical equipment, command desks and utility machines are solid props.
    physMgr.registerBoxCollider('mansion_master_bed','prop',[ox-5.2,4.0,oz+0.3],2.1,0.95,2.5);
    physMgr.registerBoxCollider('mansion_bedroom_two','prop',[ox+3.7,4.0,oz+3.6],2.1,0.95,2.5);
    physMgr.registerBoxCollider('mansion_bedroom_three','prop',[ox+3.7,4.0,oz-0.2],2.1,0.95,2.5);
    physMgr.registerBoxCollider('mansion_medical_exam_bed','prop',[ox-0.1,4.0,oz-1.0],1.15,0.95,2.1);
    physMgr.registerBoxCollider('mansion_medical_recovery_bed','prop',[ox+1.7,4.0,oz+1.2],1.15,0.95,2.1);
    physMgr.registerBoxCollider('mansion_command_desk','prop',[ox-4.8,10.25,oz-4.6],4.8,0.9,1.25);
    physMgr.registerBoxCollider('mansion_backup_generator','prop',[ox+1.8,10.45,oz-4.7],2.4,1.5,1.5);
    physMgr.registerBoxCollider('mansion_workshop_bench','prop',[ox+1.8,10.3,oz+4.8],4.2,0.95,1.1);
    for(let i=0;i<3;i++) physMgr.registerBoxCollider(`mansion_cold_storage_${i+1}`,'prop',[ox+5.7,10.8,oz-4.6+i*1.5],1.2,2.1,1.0);
    for(let i=0;i<2;i++) physMgr.registerCylinderCollider(`mansion_water_tank_${i+1}`,'prop',[ox+5.6+i*1.35,10.6,oz+2.4],0.58,1.9);

    // Bathroom partition collision: four suites, exactly one ground, two first-floor and one second-floor.
    const addBathroomColliders = (id:string, floorY:number, cx:number, cz:number) => {
      const h=2.55, t=0.16, cy=floorY+h/2;
      physMgr.registerBoxCollider(`${id}_back`, 'wall', [ox+cx,cy,oz+cz-1.52],3.15,h,t);
      physMgr.registerBoxCollider(`${id}_left`, 'wall', [ox+cx-1.57,cy,oz+cz],t,h,3.05);
      physMgr.registerBoxCollider(`${id}_right`, 'wall', [ox+cx+1.57,cy,oz+cz],t,h,3.05);
      physMgr.registerBoxCollider(`${id}_front_l`, 'wall', [ox+cx-1.02,cy,oz+cz+1.52],1.1,h,t);
      physMgr.registerBoxCollider(`${id}_front_r`, 'wall', [ox+cx+1.02,cy,oz+cz+1.52],1.1,h,t);
    };
    addBathroomColliders('mansion_bathroom_ground_guest',0.245,5.0,-3.25);
    addBathroomColliders('mansion_bathroom_master_ensuite',3.445,-5.15,-4.05);
    addBathroomColliders('mansion_bathroom_first_shared',3.445,5.15,-4.05);
    addBathroomColliders('mansion_bathroom_second_common',6.645,5.15,-4.05);

    // Fifth-level glass safety boundary and its independently operable gate.
    physMgr.registerBoxCollider('mansion_roof_glass_north','wall',[ox,13.75,oz+6.85],15.8,1.8,0.12);
    physMgr.registerBoxCollider('mansion_roof_glass_south','wall',[ox,13.75,oz-6.85],15.8,1.8,0.12);
    physMgr.registerBoxCollider('mansion_roof_glass_west','wall',[ox-7.85,13.75,oz],0.12,1.8,13.7);
    physMgr.registerBoxCollider('mansion_roof_glass_east_n','wall',[ox+7.85,13.75,oz-4.25],0.12,1.8,5.2);
    physMgr.registerBoxCollider('mansion_roof_glass_east_s','wall',[ox+7.85,13.75,oz+4.25],0.12,1.8,5.2);
    physMgr.registerBoxCollider('mansion_roof_access_gate','wall',[ox+7.85,13.75,oz],0.18,1.8,1.7,0,this.roofGateOpen);

    // 3. Fully enclosed residential compound. The front wall has a 5.1m double-gate opening.
    physMgr.registerBoxCollider('apt_compound_wall_west', 'wall', [ox - 19.0, 1.7, oz + 2.5], 0.65, 3.4, 49.0);
    physMgr.registerBoxCollider('apt_compound_wall_east', 'wall', [ox + 19.0, 1.7, oz + 2.5], 0.65, 3.4, 49.0);
    physMgr.registerBoxCollider('apt_compound_wall_rear', 'wall', [ox, 1.7, oz + 27.0], 38.5, 3.4, 0.65);
    physMgr.registerBoxCollider('apt_compound_wall_front_left_outer', 'wall', [ox - 15.86, 1.7, oz - 22.0], 6.28, 3.4, 0.65);
    physMgr.registerBoxCollider('apt_compound_wall_front_left_inner', 'wall', [ox - 6.915, 1.7, oz - 22.0], 8.73, 3.4, 0.65);
    physMgr.registerBoxCollider('apt_compound_wall_front_right_inner', 'wall', [ox + 6.915, 1.7, oz - 22.0], 8.73, 3.4, 0.65);
    physMgr.registerBoxCollider('apt_compound_wall_front_right_outer', 'wall', [ox + 15.86, 1.7, oz - 22.0], 6.28, 3.4, 0.65);
    physMgr.registerBoxCollider('apt_compound_gate', 'wall', [ox, 1.65, oz - 22.0], 5.1, 3.15, 0.28, 0, this.compoundGateOpen);
    // Two independently operable pedestrian doors in the same perimeter wall.
    physMgr.registerBoxCollider('apt_compound_door_left', 'wall', [ox - 12.0, 1.55, oz - 22.0], 1.55, 3.0, 0.24, 0, this.compoundPedestrianDoorsOpen[0]);
    physMgr.registerBoxCollider('apt_compound_door_right', 'wall', [ox + 12.0, 1.55, oz - 22.0], 1.55, 3.0, 0.24, 0, this.compoundPedestrianDoorsOpen[1]);

    // Backyard pool is relocated to the west garden so it no longer overlaps the five-bay garage.
    physMgr.registerBoxCollider('apt_backyard_pool_n', 'wall', [ox - 13.2, 0.42, oz - 18.8], 8.6, 0.7, 0.45);
    physMgr.registerBoxCollider('apt_backyard_pool_s_l', 'wall', [ox - 15.8, 0.42, oz - 10.2], 3.4, 0.7, 0.45);
    physMgr.registerBoxCollider('apt_backyard_pool_s_r', 'wall', [ox - 10.6, 0.42, oz - 10.2], 3.4, 0.7, 0.45);
    physMgr.registerBoxCollider('apt_backyard_pool_w', 'wall', [ox - 17.5, 0.42, oz - 14.5], 0.45, 0.7, 8.6);
    physMgr.registerBoxCollider('apt_backyard_pool_e', 'wall', [ox - 8.9, 0.42, oz - 14.5], 0.45, 0.7, 8.6);

    // 3. Solid interior furniture on Floor 1.
    physMgr.registerBoxCollider('apt_bed', 'prop', [ox - 5.5, 0.45, oz + 3.8], 2.4, 0.9, 2.8);
    physMgr.registerBoxCollider('apt_sofa', 'prop', [ox, 0.55, oz + 0.5], 2.8, 0.85, 1.2);
    physMgr.registerBoxCollider('apt_tvstand', 'prop', [ox - 5.5, 0.45, oz], 2.4, 0.65, 0.6);
    physMgr.registerBoxCollider('apt_fridge', 'prop', [ox + 4.5, 1.2, oz + 5.8], 1.2, 2.2, 1.0);
    physMgr.registerBoxCollider('apt_kitchen', 'prop', [ox + 5.8, 0.55, oz + 3.2], 3.6, 0.9, 1.0);
  }

  public dispose() {
    this.group.traverse((o) => {
      if (o instanceof THREE.Mesh) {
        o.geometry.dispose();
        if (Array.isArray(o.material)) o.material.forEach((m) => m.dispose());
        else o.material.dispose();
      }
    });
    this.floorLights = [];
  }
}
