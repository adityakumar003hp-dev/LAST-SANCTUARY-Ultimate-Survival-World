import React from 'react';
import { X, MapPin, Shield, Skull, Compass } from 'lucide-react';
import { PlacedStructure, ZombieEntity, HarvestableResource } from '../types/game';

interface MapModalProps {
  isOpen: boolean;
  onClose: () => void;
  playerPos: [number, number, number];
  playerYaw: number;
  safeZoneCenter: [number, number, number];
  safeZoneRadius: number;
  structures: PlacedStructure[];
  zombies: ZombieEntity[];
  resources: HarvestableResource[];
}

export const MapModal: React.FC<MapModalProps> = ({
  isOpen,
  onClose,
  playerPos,
  playerYaw,
  safeZoneCenter,
  safeZoneRadius,
  structures,
  zombies,
  resources,
}) => {
  if (!isOpen) return null;

  // World bounds: -130 to +130 (260m)
  const worldSize = 260;
  const mapCanvasSize = 500;

  // World to canvas coordinate transform
  const toMapCoord = (x: number, z: number): [number, number] => {
    const normX = (x + worldSize / 2) / worldSize;
    const normZ = (z + worldSize / 2) / worldSize;
    return [normX * mapCanvasSize, normZ * mapCanvasSize];
  };

  const [playerMapX, playerMapZ] = toMapCoord(playerPos[0], playerPos[2]);
  const [safeMapX, safeMapZ] = toMapCoord(safeZoneCenter[0], safeZoneCenter[2]);
  const safeMapRadius = (safeZoneRadius / worldSize) * mapCanvasSize;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="flex h-[85vh] w-full max-w-3xl flex-col rounded-2xl bg-neutral-950/95 border border-neutral-800 shadow-2xl text-neutral-100 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-800 px-6 py-4">
          <div className="flex items-center gap-2">
            <Compass className="h-5 w-5 text-amber-500" />
            <h2 className="text-lg font-bold tracking-wide">Topographical Surveillance Radar</h2>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs font-mono text-neutral-400">
              Pos: X {Math.round(playerPos[0])}, Z {Math.round(playerPos[2])}
            </span>
            <button
              onClick={onClose}
              className="rounded-lg p-1.5 hover:bg-neutral-800 transition-colors text-neutral-400 hover:text-white cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Map Center Viewport */}
        <div className="flex-1 flex items-center justify-center p-6 bg-neutral-950">
          <div
            className="relative rounded-2xl border-2 border-neutral-800 bg-[#1c2419] overflow-hidden shadow-2xl"
            style={{ width: `${mapCanvasSize}px`, height: `${mapCanvasSize}px` }}
          >
            {/* Grid overlay */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:50px_50px]" />

            {/* River bed */}
            <div
              className="absolute bg-sky-900/60 blur-[1px]"
              style={{
                left: `${((50 + worldSize / 2) / worldSize) * mapCanvasSize - 20}px`,
                top: 0,
                width: '40px',
                height: '100%',
              }}
            />

            {/* Sanctuary Safe Zone Circle */}
            <div
              className="absolute rounded-full border-2 border-emerald-500/80 bg-emerald-500/10 pointer-events-none -translate-x-1/2 -translate-y-1/2"
              style={{
                left: `${safeMapX}px`,
                top: `${safeMapZ}px`,
                width: `${safeMapRadius * 2}px`,
                height: `${safeMapRadius * 2}px`,
              }}
            />

            {/* Starter Base Center Home Marker */}
            <div
              className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center pointer-events-none z-10"
              style={{ left: `${safeMapX}px`, top: `${safeMapZ - 6}px` }}
            >
              <div className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-500 border border-emerald-200 shadow-md">
                <Shield className="h-3 w-3 text-neutral-950 fill-neutral-950" />
              </div>
              <span className="text-[9px] font-bold font-mono text-emerald-300 bg-neutral-950/80 px-1 rounded mt-0.5 whitespace-nowrap">
                Sanctuary Outpost 7
              </span>
            </div>

            {/* Harvestable Resource dots */}
            {resources.map((r) => {
              const [rx, rz] = toMapCoord(r.position[0], r.position[2]);
              let dotColor = '#2d5a27'; // green tree
              if (r.type === 'rock') dotColor = '#808488';
              else if (r.type === 'metal_scrap') dotColor = '#946638';
              else if (r.type === 'berry_bush') dotColor = '#aa2244';
              else if (r.type === 'supply_crate') dotColor = '#eab308';

              return (
                <div
                  key={r.id}
                  className="absolute h-1.5 w-1.5 rounded-full -translate-x-1/2 -translate-y-1/2"
                  style={{
                    left: `${rx}px`,
                    top: `${rz}px`,
                    backgroundColor: dotColor,
                  }}
                  title={r.type}
                />
              );
            })}

            {/* Placed Structures dots */}
            {structures.map((s) => {
              const [sx, sz] = toMapCoord(s.position[0], s.position[2]);
              return (
                <div
                  key={s.uid}
                  className="absolute h-2.5 w-2.5 rounded-xs bg-amber-400 border border-amber-950 -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${sx}px`, top: `${sz}px` }}
                  title={s.typeId}
                />
              );
            })}

            {/* Zombie Pings */}
            {zombies.map((z) => {
              if (z.state === 'dead') return null;
              const [zx, zz] = toMapCoord(z.position[0], z.position[2]);
              return (
                <div
                  key={z.id}
                  className="absolute h-2 w-2 rounded-full bg-rose-500 border border-rose-950 -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${zx}px`, top: `${zz}px` }}
                  title={`Infected (${z.type})`}
                />
              );
            })}

            {/* Player Icon & Direction Needle */}
            <div
              className="absolute -translate-x-1/2 -translate-y-1/2 flex items-center justify-center z-20"
              style={{
                left: `${playerMapX}px`,
                top: `${playerMapZ}px`,
              }}
            >
              <div
                className="h-4 w-4 text-emerald-400 transform transition-transform"
                style={{ transform: `rotate(${-playerYaw}rad)` }}
              >
                <div className="w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-b-[12px] border-b-emerald-400 mx-auto" />
              </div>
            </div>
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center justify-center gap-6 border-t border-neutral-800 bg-neutral-900/60 px-6 py-3 text-xs text-neutral-300">
          <div className="flex items-center gap-1.5">
            <div className="h-3 w-3 rounded-full border border-emerald-500 bg-emerald-500/20" />
            <span>Safe Zone Perimeter</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="h-2.5 w-2.5 rounded-xs bg-amber-400" />
            <span>Fortifications / Base</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="h-2.5 w-2.5 rounded-full bg-rose-500" />
            <span>Infected Hostiles</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-0 h-0 border-l-[4px] border-l-transparent border-r-[4px] border-r-transparent border-b-[8px] border-b-emerald-400" />
            <span>Player</span>
          </div>
        </div>
      </div>
    </div>
  );
};
