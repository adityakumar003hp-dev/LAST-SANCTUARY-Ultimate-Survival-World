import React, { useRef, useState, useEffect } from 'react';
import { Hammer, Hand, ArrowUp, Zap, Sparkles } from 'lucide-react';

interface MobileControlsProps {
  onMoveChange: (move: { forward: boolean; backward: boolean; left: boolean; right: boolean }) => void;
  onLookDelta: (dx: number, dy: number) => void;
  onJump: () => void;
  onSprintToggle: (sprint: boolean) => void;
  onPrimaryAction: () => void;
  onInteract: () => void;
  onOpenBuild: () => void;
}

export const MobileControls: React.FC<MobileControlsProps> = ({
  onMoveChange,
  onLookDelta,
  onJump,
  onSprintToggle,
  onPrimaryAction,
  onInteract,
  onOpenBuild,
}) => {
  const [isMobile, setIsMobile] = useState(false);
  const [isSprinting, setIsSprinting] = useState(false);

  // Joystick touch tracking
  const joystickBaseRef = useRef<HTMLDivElement>(null);
  const [joystickPos, setJoystickPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDraggingJoystick, setIsDraggingJoystick] = useState(false);
  const joystickTouchId = useRef<number | null>(null);

  // Look pad touch tracking
  const lookTouchId = useRef<number | null>(null);
  const lastLookPos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  useEffect(() => {
    // Only display on touch devices
    const checkTouch = () => {
      setIsMobile('ontouchstart' in window || navigator.maxTouchPoints > 0);
    };
    checkTouch();
    window.addEventListener('resize', checkTouch);
    return () => window.removeEventListener('resize', checkTouch);
  }, []);

  if (!isMobile) return null;

  // Touch Handlers for Joystick
  const handleJoystickTouchStart = (e: React.TouchEvent) => {
    e.preventDefault();
    const touch = e.changedTouches[0];
    joystickTouchId.current = touch.identifier;
    setIsDraggingJoystick(true);
    updateJoystick(touch.clientX, touch.clientY);
  };

  const handleJoystickTouchMove = (e: React.TouchEvent) => {
    e.preventDefault();
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === joystickTouchId.current) {
        updateJoystick(touch.clientX, touch.clientY);
        break;
      }
    }
  };

  const handleJoystickTouchEnd = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === joystickTouchId.current) {
        joystickTouchId.current = null;
        setIsDraggingJoystick(false);
        setJoystickPos({ x: 0, y: 0 });
        onMoveChange({ forward: false, backward: false, left: false, right: false });
        break;
      }
    }
  };

  const updateJoystick = (clientX: number, clientY: number) => {
    if (!joystickBaseRef.current) return;
    const rect = joystickBaseRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    let dx = clientX - centerX;
    let dy = clientY - centerY;
    const maxRadius = 40;
    const dist = Math.hypot(dx, dy);

    if (dist > maxRadius) {
      dx = (dx / dist) * maxRadius;
      dy = (dy / dist) * maxRadius;
    }

    setJoystickPos({ x: dx, y: dy });

    const threshold = 12;
    onMoveChange({
      forward: dy < -threshold,
      backward: dy > threshold,
      left: dx < -threshold,
      right: dx > threshold,
    });
  };

  // Touch Handlers for Look area (right half of screen)
  const handleLookTouchStart = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier !== joystickTouchId.current && touch.clientX > window.innerWidth / 2) {
        lookTouchId.current = touch.identifier;
        lastLookPos.current = { x: touch.clientX, y: touch.clientY };
        break;
      }
    }
  };

  const handleLookTouchMove = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === lookTouchId.current) {
        const dx = touch.clientX - lastLookPos.current.x;
        const dy = touch.clientY - lastLookPos.current.y;
        lastLookPos.current = { x: touch.clientX, y: touch.clientY };
        onLookDelta(dx, dy);
        break;
      }
    }
  };

  const handleLookTouchEnd = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === lookTouchId.current) {
        lookTouchId.current = null;
        break;
      }
    }
  };

  return (
    <div
      className="pointer-events-none absolute inset-0 z-30 select-none overflow-hidden"
      onTouchStart={handleLookTouchStart}
      onTouchMove={handleLookTouchMove}
      onTouchEnd={handleLookTouchEnd}
    >
      {/* Virtual Joystick (Bottom Left) */}
      <div className="absolute bottom-8 left-8 pointer-events-auto">
        <div
          ref={joystickBaseRef}
          onTouchStart={handleJoystickTouchStart}
          onTouchMove={handleJoystickTouchMove}
          onTouchEnd={handleJoystickTouchEnd}
          className="relative flex h-28 w-28 items-center justify-center rounded-full bg-neutral-900/60 border border-neutral-700/60 backdrop-blur-sm"
        >
          <div
            className="h-12 w-12 rounded-full bg-amber-500/80 border border-amber-300 shadow-md transform transition-transform"
            style={{
              transform: `translate(${joystickPos.x}px, ${joystickPos.y}px)`,
            }}
          />
        </div>
      </div>

      {/* Action Buttons (Bottom Right) */}
      <div className="absolute bottom-8 right-8 flex flex-col items-end gap-3 pointer-events-auto">
        {/* Top row of secondary buttons */}
        <div className="flex items-center gap-3">
          <button
            onTouchStart={() => {
              const next = !isSprinting;
              setIsSprinting(next);
              onSprintToggle(next);
            }}
            className={`flex h-12 w-12 items-center justify-center rounded-full border shadow-lg cursor-pointer ${
              isSprinting ? 'bg-amber-500 border-amber-300 text-neutral-950 font-bold' : 'bg-neutral-900/80 border-neutral-700 text-neutral-300'
            }`}
          >
            <Zap className="h-5 w-5" />
          </button>

          <button
            onTouchStart={onJump}
            className="flex h-12 w-12 items-center justify-center rounded-full bg-neutral-900/80 border border-neutral-700 text-neutral-200 shadow-lg cursor-pointer"
          >
            <ArrowUp className="h-5 w-5" />
          </button>

          <button
            onTouchStart={onInteract}
            className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-600/90 border border-emerald-400 text-white shadow-lg cursor-pointer font-bold text-xs"
          >
            USE
          </button>
        </div>

        {/* Big Action / Attack Button */}
        <button
          onTouchStart={onPrimaryAction}
          className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-tr from-amber-600 to-amber-400 border-2 border-amber-200 text-neutral-950 shadow-2xl cursor-pointer active:scale-95 transition-transform"
        >
          <Hand className="h-7 w-7" />
        </button>
      </div>
    </div>
  );
};
