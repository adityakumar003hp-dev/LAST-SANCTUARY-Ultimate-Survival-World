import React from 'react';
import { 
  Heart, 
  Zap, 
  Apple, 
  Droplet, 
  Shield, 
  Sun, 
  Moon, 
  Compass, 
  Hammer, 
  Package, 
  User, 
  Map as MapIcon, 
  BookOpen, 
  Eye, 
  Flashlight 
} from 'lucide-react';
import { PlayerStats, InventorySlot, Quest } from '../types/game';

interface HUDProps {
  stats: PlayerStats;
  timeMinutes: number;
  dayCount: number;
  isNight: boolean;
  isDusk: boolean;
  interactionPrompt: string | null;
  hotbar: (InventorySlot | null)[];
  selectedIndex: number;
  onSelectSlot: (index: number) => void;
  activeQuest: Quest | null;
  cameraView: 'first' | 'third' | 'second';
  isFlashlightOn: boolean;
  onOpenBuild: () => void;
  onOpenInventory: () => void;
  onOpenCharacter: () => void;
  onOpenMap: () => void;
  onOpenJournal: () => void;
  onToggleCamera: () => void;
  onToggleFlashlight: () => void;
  onOpenPause: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  stats,
  timeMinutes,
  dayCount,
  isNight,
  isDusk,
  interactionPrompt,
  hotbar,
  selectedIndex,
  onSelectSlot,
  activeQuest,
  cameraView,
  isFlashlightOn,
  onOpenBuild,
  onOpenInventory,
  onOpenCharacter,
  onOpenMap,
  onOpenJournal,
  onToggleCamera,
  onToggleFlashlight,
}) => {
  const hours = Math.floor(timeMinutes / 60);
  const mins = Math.floor(timeMinutes % 60);
  const timeStr = `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`;

  const firstIncompleteObj = activeQuest?.objectives.find((o) => !o.completed);

  return (
    <div className="pointer-events-none absolute inset-0 select-none overflow-hidden font-sans">
      {/* --- Top Left: Survivor Vital Status Bars --- */}
      <div className="absolute top-4 left-4 flex flex-col gap-2 rounded-xl bg-neutral-950/80 p-3.5 shadow-2xl backdrop-blur-md border border-neutral-800/80 w-64">
        {/* Health */}
        <div className="flex items-center gap-2">
          <Heart className="h-4 w-4 text-rose-500 fill-rose-500/30 shrink-0" />
          <div className="relative h-3 w-full overflow-hidden rounded-full bg-neutral-900 border border-neutral-700/50">
            <div
              className="h-full rounded-full bg-gradient-to-r from-red-600 to-rose-500 transition-all duration-300"
              style={{ width: `${Math.max(0, Math.min(100, (stats.health / stats.maxHealth) * 100))}%` }}
            />
          </div>
          <span className="w-10 text-right text-xs font-mono font-bold text-rose-400">
            {Math.round(stats.health)}
          </span>
        </div>

        {/* Stamina */}
        <div className="flex items-center gap-2">
          <Zap className="h-4 w-4 text-amber-400 fill-amber-400/30 shrink-0" />
          <div className="relative h-2.5 w-full overflow-hidden rounded-full bg-neutral-900 border border-neutral-700/50">
            <div
              className="h-full rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 transition-all duration-150"
              style={{ width: `${Math.max(0, Math.min(100, (stats.stamina / stats.maxStamina) * 100))}%` }}
            />
          </div>
          <span className="w-10 text-right text-xs font-mono font-bold text-amber-300">
            {Math.round(stats.stamina)}
          </span>
        </div>

        {/* Hunger & Thirst Split */}
        <div className="grid grid-cols-2 gap-2 pt-1 border-t border-neutral-800">
          <div className="flex items-center gap-1.5">
            <Apple className="h-3.5 w-3.5 text-orange-400 shrink-0" />
            <div className="h-2 w-full overflow-hidden rounded-full bg-neutral-900 border border-neutral-700/40">
              <div
                className="h-full bg-orange-500 transition-all duration-300"
                style={{ width: `${Math.max(0, Math.min(100, stats.hunger))}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-neutral-300">{Math.round(stats.hunger)}%</span>
          </div>

          <div className="flex items-center gap-1.5">
            <Droplet className="h-3.5 w-3.5 text-sky-400 shrink-0" />
            <div className="h-2 w-full overflow-hidden rounded-full bg-neutral-900 border border-neutral-700/40">
              <div
                className="h-full bg-sky-500 transition-all duration-300"
                style={{ width: `${Math.max(0, Math.min(100, stats.thirst))}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-neutral-300">{Math.round(stats.thirst)}%</span>
          </div>
        </div>

        {/* Level & XP */}
        <div className="flex items-center justify-between pt-1 text-[11px] text-neutral-400 border-t border-neutral-800">
          <span className="font-semibold text-emerald-400">LVL {stats.level} Survivor</span>
          <span className="font-mono text-neutral-400">XP: {stats.xp}/{stats.xpToNextLevel}</span>
        </div>
      </div>

      {/* --- Top Right: Time, Day, & Cycle Clock --- */}
      <div className="absolute top-4 right-4 flex items-center gap-3 rounded-xl bg-neutral-950/80 p-3 shadow-2xl backdrop-blur-md border border-neutral-800/80">
        <div className="flex items-center gap-2 pr-3 border-r border-neutral-800">
          {isNight ? (
            <Moon className="h-5 w-5 text-rose-500 animate-pulse" />
          ) : isDusk ? (
            <Sun className="h-5 w-5 text-amber-500" />
          ) : (
            <Sun className="h-5 w-5 text-yellow-400" />
          )}
          <div className="flex flex-col">
            <span className="text-sm font-bold tracking-wider text-neutral-100 font-mono">
              {timeStr}
            </span>
            <span className="text-[10px] uppercase font-semibold text-neutral-400">
              DAY {dayCount} {isNight ? '• BLOOD MOON' : isDusk ? '• DUSK WARNING' : '• DAYLIGHT'}
            </span>
          </div>
        </div>

        {/* Safe Zone Compound Status */}
        <div className="flex items-center gap-1.5 text-xs font-medium text-emerald-400">
          <Shield className="h-4 w-4" />
          <span>Sanctuary</span>
        </div>
      </div>

      {/* --- Top Center: Active Quest Tracker --- */}
      {activeQuest && firstIncompleteObj && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 flex flex-col items-center rounded-xl bg-neutral-950/85 px-4 py-2 border border-neutral-800/80 shadow-xl backdrop-blur-md max-w-md text-center">
          <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400 uppercase tracking-wider">
            <Compass className="h-3.5 w-3.5" />
            <span>{activeQuest.title}</span>
          </div>
          <div className="text-sm text-neutral-200 font-medium mt-0.5">
            {firstIncompleteObj.description}
          </div>
          <div className="text-xs font-mono text-amber-300/90 mt-0.5">
            Progress: {firstIncompleteObj.current} / {firstIncompleteObj.target}
          </div>
        </div>
      )}

      {/* --- Center: Reticle & Contextual Interaction Prompt --- */}
      <div className="absolute inset-0 flex items-center justify-center">
        {/* Subtle Crosshair */}
        <div className="relative flex items-center justify-center">
          <div className="h-1.5 w-1.5 rounded-full bg-white/70" />
          <div className="absolute -top-3 h-2 w-[1px] bg-white/40" />
          <div className="absolute -bottom-3 h-2 w-[1px] bg-white/40" />
          <div className="absolute -left-3 w-2 h-[1px] bg-white/40" />
          <div className="absolute -right-3 w-2 h-[1px] bg-white/40" />
        </div>

        {/* Interaction Prompt Box */}
        {interactionPrompt && (
          <div className="absolute mt-16 rounded-lg bg-neutral-950/90 px-3.5 py-1.5 text-xs font-semibold text-neutral-100 shadow-xl border border-neutral-700/80 tracking-wide backdrop-blur-sm">
            {interactionPrompt}
          </div>
        )}
      </div>

      {/* --- Bottom Center: Hotbar & Collapsible Control Dock --- */}
      <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 pointer-events-auto">
        {/* Quick Dock Action Buttons */}
        <div className="flex items-center gap-1.5 rounded-xl bg-neutral-950/80 px-3 py-1.5 border border-neutral-800/80 backdrop-blur-md shadow-lg text-neutral-300 text-xs">
          <button
            onClick={onOpenBuild}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer text-amber-400 font-medium"
            title="Open Building Catalog [B]"
          >
            <Hammer className="h-3.5 w-3.5" />
            <span>Build [B]</span>
          </button>
          <div className="h-3 w-[1px] bg-neutral-800" />

          <button
            onClick={onOpenInventory}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer text-neutral-200"
            title="Open Inventory [I]"
          >
            <Package className="h-3.5 w-3.5" />
            <span>Bag [I]</span>
          </button>
          <div className="h-3 w-[1px] bg-neutral-800" />

          <button
            onClick={onOpenCharacter}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer text-neutral-200"
            title="Character RPG Stats [C]"
          >
            <User className="h-3.5 w-3.5" />
            <span>Stats [C]</span>
          </button>
          <div className="h-3 w-[1px] bg-neutral-800" />

          <button
            onClick={onOpenMap}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer text-neutral-200"
            title="Map & Radar [M]"
          >
            <MapIcon className="h-3.5 w-3.5" />
            <span>Map [M]</span>
          </button>
          <div className="h-3 w-[1px] bg-neutral-800" />

          <button
            onClick={onOpenJournal}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer text-neutral-200"
            title="Quest Journal [J]"
          >
            <BookOpen className="h-3.5 w-3.5" />
            <span>Journal [J]</span>
          </button>
          <div className="h-3 w-[1px] bg-neutral-800" />

          <button
            onClick={onToggleCamera}
            className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer text-neutral-200"
            title="Cycle First / Third / Second-person Observer [V]"
          >
            <Eye className="h-3.5 w-3.5" />
            <span>{cameraView === 'first' ? '1st' : cameraView === 'third' ? '3rd' : '2nd'} [V]</span>
          </button>

          <button
            onClick={onToggleFlashlight}
            className={`flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer ${
              isFlashlightOn ? 'text-yellow-400 bg-neutral-800/80' : 'text-neutral-400'
            }`}
            title="Flashlight [F]"
          >
            <Flashlight className="h-3.5 w-3.5" />
            <span>[F]</span>
          </button>
        </div>

        {/* 8-Slot Hotbar */}
        <div className="flex items-center gap-1.5 rounded-2xl bg-neutral-950/90 p-2 border border-neutral-800/90 shadow-2xl backdrop-blur-md">
          {hotbar.slice(0, 8).map((slot, idx) => {
            const isSelected = selectedIndex === idx;
            return (
              <button
                key={idx}
                onClick={() => onSelectSlot(idx)}
                className={`relative flex h-14 w-14 flex-col items-center justify-center rounded-xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'border-amber-400 bg-amber-500/20 shadow-lg shadow-amber-500/20'
                    : 'border-neutral-800 bg-neutral-900/80 hover:border-neutral-700'
                }`}
              >
                {/* Number Key Indicator */}
                <span className="absolute top-1 left-1.5 text-[9px] font-mono text-neutral-400 font-bold">
                  {idx + 1}
                </span>

                {slot ? (
                  <>
                    <span className="text-xs font-semibold text-neutral-100 truncate px-1 text-center">
                      {slot.item.name.split(' ')[0]}
                    </span>
                    {slot.count > 1 && (
                      <span className="absolute bottom-1 right-1.5 font-mono text-[10px] font-bold text-amber-300">
                        x{slot.count}
                      </span>
                    )}
                  </>
                ) : (
                  <span className="text-neutral-700 text-xs font-mono">-</span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
