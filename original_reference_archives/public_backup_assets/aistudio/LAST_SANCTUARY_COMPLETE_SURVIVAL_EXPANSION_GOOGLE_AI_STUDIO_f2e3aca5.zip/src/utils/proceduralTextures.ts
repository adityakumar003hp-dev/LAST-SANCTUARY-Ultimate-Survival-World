import * as THREE from 'three';

const textureCache: Record<string, THREE.CanvasTexture> = {};

function createProceduralCanvas(
  width: number,
  height: number,
  draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;
  draw(ctx, width, height);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  return texture;
}

export function getTerrainTexture(): THREE.CanvasTexture {
  if (textureCache['terrain']) return textureCache['terrain'];

  textureCache['terrain'] = createProceduralCanvas(512, 512, (ctx, w, h) => {
    // Rich forest floor / mossy soil
    ctx.fillStyle = '#3a4f29';
    ctx.fillRect(0, 0, w, h);

    // Soil and pebble specks
    for (let i = 0; i < 4000; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      const r = Math.random() * 2.5 + 0.5;
      const shade = Math.random();
      if (shade > 0.6) {
        ctx.fillStyle = '#485e33';
      } else if (shade > 0.3) {
        ctx.fillStyle = '#2d3a20';
      } else {
        ctx.fillStyle = '#5c4b32'; // mud patch
      }
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }

    // Faint grass blades
    ctx.strokeStyle = '#547537';
    ctx.lineWidth = 1;
    for (let i = 0; i < 600; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + (Math.random() - 0.5) * 6, y - Math.random() * 8);
      ctx.stroke();
    }
  });

  return textureCache['terrain'];
}

export function getWoodPlankTexture(): THREE.CanvasTexture {
  if (textureCache['wood']) return textureCache['wood'];

  textureCache['wood'] = createProceduralCanvas(256, 256, (ctx, w, h) => {
    ctx.fillStyle = '#61432a';
    ctx.fillRect(0, 0, w, h);

    // Plank lines
    const plankHeight = h / 4;
    for (let p = 0; p < 4; p++) {
      const y = p * plankHeight;
      ctx.fillStyle = p % 2 === 0 ? '#6c4a30' : '#573b24';
      ctx.fillRect(0, y, w, plankHeight - 2);

      // Wood grain lines
      ctx.strokeStyle = '#432d1c';
      ctx.lineWidth = 1;
      for (let g = 0; g < 15; g++) {
        const gy = y + Math.random() * plankHeight;
        ctx.beginPath();
        ctx.moveTo(0, gy);
        ctx.bezierCurveTo(
          w * 0.3, gy + (Math.random() - 0.5) * 4,
          w * 0.7, gy + (Math.random() - 0.5) * 4,
          w, gy
        );
        ctx.stroke();
      }

      // Nails
      ctx.fillStyle = '#222222';
      ctx.beginPath();
      ctx.arc(12, y + plankHeight / 2, 2.5, 0, Math.PI * 2);
      ctx.arc(w - 12, y + plankHeight / 2, 2.5, 0, Math.PI * 2);
      ctx.fill();
    }
  });

  return textureCache['wood'];
}

export function getStoneTexture(): THREE.CanvasTexture {
  if (textureCache['stone']) return textureCache['stone'];

  textureCache['stone'] = createProceduralCanvas(256, 256, (ctx, w, h) => {
    ctx.fillStyle = '#686b6e';
    ctx.fillRect(0, 0, w, h);

    // Granite speckling
    for (let i = 0; i < 3000; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      const r = Math.random() * 2 + 0.5;
      const val = Math.random();
      ctx.fillStyle = val > 0.5 ? '#808488' : '#4d5053';
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }

    // Subtle fracture lines
    ctx.strokeStyle = '#393b3d';
    ctx.lineWidth = 1;
    for (let i = 0; i < 5; i++) {
      ctx.beginPath();
      let cx = Math.random() * w;
      let cy = Math.random() * h;
      ctx.moveTo(cx, cy);
      for (let j = 0; j < 4; j++) {
        cx += (Math.random() - 0.5) * 35;
        cy += (Math.random() - 0.5) * 35;
        ctx.lineTo(cx, cy);
      }
      ctx.stroke();
    }
  });

  return textureCache['stone'];
}

export function getMetalScrapTexture(): THREE.CanvasTexture {
  if (textureCache['metal']) return textureCache['metal'];

  textureCache['metal'] = createProceduralCanvas(256, 256, (ctx, w, h) => {
    ctx.fillStyle = '#555b61';
    ctx.fillRect(0, 0, w, h);

    // Rust oxidation spots
    for (let i = 0; i < 25; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      const r = Math.random() * 25 + 6;
      const grad = ctx.createRadialGradient(x, y, 1, x, y, r);
      grad.addColorStop(0, '#8c4826');
      grad.addColorStop(0.7, '#643820');
      grad.addColorStop(1, 'rgba(85, 91, 97, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }

    // Scratches and rivets
    ctx.strokeStyle = '#858d94';
    ctx.lineWidth = 1;
    for (let i = 0; i < 15; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + Math.random() * 20, y + (Math.random() - 0.5) * 10);
      ctx.stroke();
    }
  });

  return textureCache['metal'];
}

export function getHazardStripeTexture(): THREE.CanvasTexture {
  if (textureCache['hazard']) return textureCache['hazard'];

  textureCache['hazard'] = createProceduralCanvas(128, 128, (ctx, w, h) => {
    ctx.fillStyle = '#e6ad12';
    ctx.fillRect(0, 0, w, h);

    ctx.fillStyle = '#1c1b18';
    const stripeWidth = 24;
    for (let x = -w; x < w * 2; x += stripeWidth * 2) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x + stripeWidth, 0);
      ctx.lineTo(x + stripeWidth + h, h);
      ctx.lineTo(x + h, h);
      ctx.closePath();
      ctx.fill();
    }
  });

  return textureCache['hazard'];
}
