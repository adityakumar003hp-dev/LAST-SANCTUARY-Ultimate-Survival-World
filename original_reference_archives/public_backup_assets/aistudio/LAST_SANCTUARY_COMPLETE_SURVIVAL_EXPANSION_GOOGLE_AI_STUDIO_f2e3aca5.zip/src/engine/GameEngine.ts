import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { WorldTerrain, getTerrainHeight } from './Terrain';
import { BuildingManager } from './BuildingManager';
import { ZombieManager } from './ZombieManager';
import { PlayerController } from './PlayerController';
import { soundEngine } from '../utils/audio';
import { HarvestableResource, PlacedStructure, PlayerStats, Quest, SaveSlotMetadata, FullGameSave, GameMode, Difficulty, ItemDefinition } from '../types/game';
import { ITEMS } from '../data/items';
import { saveGameToSlot } from '../utils/storage';
import { ChunkManager } from './world/ChunkManager';
import { WorldPersistence } from './world/WorldPersistence';
import { WildlifeManager } from './WildlifeManager';
import { SurvivorRescueManager, SurvivorDialogue } from './SurvivorRescueManager';
import { NPCSettlementManager } from './base/NPCSettlementManager';

export interface GameEngineCallbacks {
  onStatsChange: (stats: PlayerStats) => void;
  onTimeChange: (timeMinutes: number, dayCount: number, isNight: boolean, isDusk: boolean) => void;
  onHordeEvent: (event: 'dusk_warning' | 'night_horde_start' | 'dawn_victory' | null) => void;
  onInteractionPrompt: (prompt: string | null) => void;
  onQuestsUpdate: (quests: Quest[]) => void;
  onOpenStorage: (struct: PlacedStructure) => void;
  onOpenCrafting: (stationType?: string) => void;
  onResourceHarvested: (res: HarvestableResource, item: ItemDefinition, amount: number) => void;
  onItemCollected: (itemId: string, count: number) => void;
  onOpenNoticeBoard: () => void;
  onGameOver: () => void;
  onOpenDialogue?: (dialogue: SurvivorDialogue) => void;
}

export class GameEngine {
  public container: HTMLDivElement;
  public renderer: THREE.WebGLRenderer;
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;

  // Subsystems
  public terrain: WorldTerrain;
  public buildingMgr: BuildingManager;
  public zombieMgr: ZombieManager;
  public player: PlayerController;
  public chunkManager: ChunkManager;
  public worldPersistence: WorldPersistence;
  public wildlifeManager: WildlifeManager;
  public rescueManager: SurvivorRescueManager;
  public npcSettlementManager: NPCSettlementManager;

  // Environment & Lights
  private dirLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;
  private pmremGenerator: THREE.PMREMGenerator;

  // Time & Horde Simulation
  public gameTimeMinutes: number = 480; // 08:00 AM
  public dayCount: number = 1;
  public isNight: boolean = false;
  public isDusk: boolean = false;
  private duskWarningFired: boolean = false;
  private hordeWaveTimer: number = 0;
  private dawnVictoryFired: boolean = false;
  public nightHordesDefeated: number = 0;

  // Player RPG stats & inventory
  public playerStats: PlayerStats;
  public quests: Quest[];
  public activeSlotItem: ItemDefinition | null = null;
  public gameMode: GameMode = 'survival';
  public difficulty: Difficulty = 'standard';

  // Game Loop Controls
  private isRunning: boolean = false;
  private isPaused: boolean = false;
  private frameId: number = 0;
  private clock: THREE.Clock;
  private callbacks: GameEngineCallbacks;
  private autoSaveTimer: number = 0;

  // Input State
  public inputState = {
    forward: false,
    backward: false,
    left: false,
    right: false,
    jump: false,
    sprint: false,
  };

  // Crosshair Raycaster
  private raycaster: THREE.Raycaster = new THREE.Raycaster();
  private screenCenter: THREE.Vector2 = new THREE.Vector2(0, 0);

  // Software WebGL flag
  public isSoftwareGl: boolean = false;

  constructor(
    container: HTMLDivElement,
    initialSave: FullGameSave | null,
    callbacks: GameEngineCallbacks
  ) {
    this.container = container;
    this.callbacks = callbacks;
    this.clock = new THREE.Clock();

    // 1. Detect Software WebGL
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Initialize Three.js Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2)
    );
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(this.renderer.domElement);

    // 3. Scene & Camera
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x87ceeb); // daytime sky blue
    this.scene.fog = new THREE.FogExp2(0x87ceeb, 0.012);

    this.camera = new THREE.PerspectiveCamera(
      70,
      container.clientWidth / container.clientHeight,
      0.1,
      400
    );

    // 4. Studio Environment Reflection
    this.pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = this.pmremGenerator.fromScene(
      new RoomEnvironment(),
      0.04
    ).texture;

    // 5. Lighting Rig
    this.hemiLight = new THREE.HemisphereLight(0x7ec0ee, 0x3d3024, 0.65);
    this.scene.add(this.hemiLight);

    this.dirLight = new THREE.DirectionalLight(0xfff4d6, 2.2);
    this.dirLight.position.set(60, 90, 40);
    this.dirLight.castShadow = !this.isSoftwareGl;
    this.dirLight.shadow.mapSize.width = 1024;
    this.dirLight.shadow.mapSize.height = 1024;
    this.dirLight.shadow.camera.near = 10;
    this.dirLight.shadow.camera.far = 250;
    const d = 45;
    this.dirLight.shadow.camera.left = -d;
    this.dirLight.shadow.camera.right = d;
    this.dirLight.shadow.camera.top = d;
    this.dirLight.shadow.camera.bottom = -d;
    this.dirLight.shadow.bias = -0.0005;
    this.scene.add(this.dirLight);

    // 6. Subsystem Instantiation
    const seed = initialSave ? initialSave.worldSeed : 101;
    this.terrain = new WorldTerrain(this.scene, seed);
    this.buildingMgr = new BuildingManager(this.scene);
    this.zombieMgr = new ZombieManager(this.scene);
    this.player = new PlayerController(this.scene, this.camera);
    this.worldPersistence = new WorldPersistence();
    if (initialSave) this.worldPersistence.importSaveData({ discoveredChunks: initialSave.discoveredChunks, waypoints: initialSave.waypoints, chunkModifications: initialSave.chunkModifications });
    this.chunkManager = new ChunkManager(this.scene, seed, 'medium', this.worldPersistence);
    this.wildlifeManager = new WildlifeManager(this.scene, seed);
    this.rescueManager = new SurvivorRescueManager(this.scene, seed);
    this.npcSettlementManager = new NPCSettlementManager(this.scene);
    if (initialSave) this.rescueManager.importRescued(initialSave.rescuedSurvivorIds);

    // 7. Load or Initialize Game State
    if (initialSave) {
      this.gameTimeMinutes = initialSave.gameTimeMinutes;
      this.dayCount = initialSave.dayCount;
      this.nightHordesDefeated = initialSave.nightHordeCountDefeated;
      this.playerStats = initialSave.playerStats;
      this.quests = initialSave.quests;
      this.player.position.set(...initialSave.playerPosition);
      this.player.yaw = initialSave.playerRotation;
      if (initialSave.structures && initialSave.structures.length > 0) {
        this.buildingMgr.loadSavedStructures(initialSave.structures);
      } else {
        this.buildingMgr.initStarterBase();
      }
      this.gameMode = initialSave.metadata.gameMode;
      this.difficulty = initialSave.metadata.difficulty;
    } else {
      // New Game: Initialize full pre-built starter base compound
      this.buildingMgr.initStarterBase();
      // Position player in the sunny starter compound yard facing the cabin and facilities
      this.player.position.set(0, getTerrainHeight(0, 0), 0);
      this.player.yaw = 0;

      this.playerStats = {
        health: 100,
        maxHealth: 100,
        stamina: 100,
        maxStamina: 100,
        hunger: 90,
        thirst: 95,
        temperature: 24,
        infection: 0,
        level: 1,
        xp: 0,
        xpToNextLevel: 100,
        skillPoints: 0,
        skills: {
          strength: 1,
          endurance: 1,
          engineering: 1,
          survival: 1,
        },
      };
      this.quests = [];
    }

    // Spawn starter wandering zombies outside safe radius
    for (let i = 0; i < 5; i++) {
      const angle = (i / 5) * Math.PI * 2;
      const x = Math.cos(angle) * 45;
      const z = Math.sin(angle) * 45;
      this.zombieMgr.spawnZombie('walker', [x, 0, z]);
    }

    // Attach resize listener
    window.addEventListener('resize', this.onResize);

    // Start loop
    this.isRunning = true;
    this.startLoop();
  }

  public setPaused(paused: boolean) {
    this.isPaused = paused;
    if (!paused) {
      this.clock.getDelta(); // reset delta step
    }
  }

  public onResize = () => {
    if (!this.container) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  private startLoop() {
    const tick = () => {
      if (!this.isRunning) return;

      if (!this.isPaused) {
        const delta = Math.min(0.1, this.clock.getDelta());
        this.update(delta);
      }

      this.renderer.render(this.scene, this.camera);

      if (this.isSoftwareGl) {
        // Pace loop on software WebGL to avoid starving main thread
        this.frameId = window.setTimeout(tick, 80);
      } else {
        this.frameId = requestAnimationFrame(tick);
      }
    };

    if (this.isSoftwareGl) {
      this.frameId = window.setTimeout(tick, 80);
    } else {
      this.frameId = requestAnimationFrame(tick);
    }
  }

  // --- Core Game Update ---
  private update(delta: number) {
    // 1. Advance Game Time (1 real sec = 2 game mins)
    this.gameTimeMinutes += delta * 2.0;
    if (this.gameTimeMinutes >= 1440) {
      this.gameTimeMinutes -= 1440;
      this.dayCount += 1;
    }

    const hour = this.gameTimeMinutes / 60;
    this.isNight = hour >= 21.0 || hour < 5.0;
    this.isDusk = hour >= 18.0 && hour < 21.0;

    // Trigger audio ambience
    soundEngine.updateNightAmbience(this.isNight);

    // Dusk warning
    if (this.isDusk && !this.duskWarningFired) {
      this.duskWarningFired = true;
      soundEngine.playDuskWarningHorn();
      this.callbacks.onHordeEvent('dusk_warning');
    }

    // Night horde start
    if (this.isNight && this.duskWarningFired) {
      this.duskWarningFired = false;
      this.dawnVictoryFired = false;
      this.callbacks.onHordeEvent('night_horde_start');
    }

    // Dawn victory event
    if (!this.isNight && !this.isDusk && hour >= 6.0 && hour < 7.0 && !this.dawnVictoryFired) {
      this.dawnVictoryFired = true;
      this.nightHordesDefeated += 1;
      soundEngine.playDawnVictoryChime();
      this.callbacks.onHordeEvent('dawn_victory');
      this.addXP(150);
      this.updateQuestProgress('survive_night', 1);
      this.updateQuestProgress('survive_hordes', 1);
    }

    // Update Celestial Lighting & Sky
    this.updateAtmosphere(hour);

    // 2. Player Movement & Physics
    const { staminaDelta } = this.player.update(
      delta,
      this.inputState,
      this.playerStats.stamina,
      this.buildingMgr
    );

    // Stream the expanded world after leaving the original sanctuary starter region.
    // The legacy starter terrain remains intact; distant chunks are generated in small batches.
    const distanceFromStarter = Math.hypot(this.player.position.x, this.player.position.z);
    this.terrain.mesh.visible = distanceFromStarter <= 138;
    this.terrain.waterMesh.visible = distanceFromStarter <= 138;
    this.chunkManager.updatePlayerPosition(this.player.position);
    const starterChunk = this.chunkManager.activeChunks.get('0_0');
    if (starterChunk) { starterChunk.terrainMesh.visible = false; if (starterChunk.waterMesh) starterChunk.waterMesh.visible = false; }
    this.wildlifeManager.update(delta, this.player.position, (x, z) => this.chunkManager.getCurrentBiome(x, z).id, this.isNight);
    this.npcSettlementManager.update(delta, this.isNight, true);
    const rescuedNow = this.rescueManager.update(delta, this.player.position, this.buildingMgr.safeZoneCenter, this.buildingMgr.safeZoneRadius);
    rescuedNow.forEach(() => { this.addXP(75); this.callbacks.onItemCollected('canned_beans', 2); this.callbacks.onItemCollected('clean_water', 2); this.callbacks.onInteractionPrompt('Survivor safely escorted to the sanctuary.'); });

    // 3. Player Stats Update
    this.playerStats.stamina = Math.max(
      0,
      Math.min(this.playerStats.maxStamina, this.playerStats.stamina + staminaDelta)
    );

    // Distance to Safe Zone Center
    const distToSafe = Math.hypot(
      this.player.position.x - this.buildingMgr.safeZoneCenter.x,
      this.player.position.z - this.buildingMgr.safeZoneCenter.z
    );
    const inSafeZone = distToSafe < this.buildingMgr.safeZoneRadius;

    // Hunger & Thirst Drains (slower in safe zone)
    const drainMultiplier = inSafeZone ? 0.6 : 1.0;
    this.playerStats.hunger = Math.max(0, this.playerStats.hunger - delta * 0.12 * drainMultiplier);
    this.playerStats.thirst = Math.max(0, this.playerStats.thirst - delta * 0.18 * drainMultiplier);

    // Starvation / Dehydration Health Damage
    if (this.playerStats.hunger <= 0 || this.playerStats.thirst <= 0) {
      this.damagePlayer(delta * 2.5);
    }

    // Passive Health Regen if well-fed & hydrated
    if (this.playerStats.hunger > 60 && this.playerStats.thirst > 60 && this.playerStats.health < this.playerStats.maxHealth) {
      this.playerStats.health = Math.min(this.playerStats.maxHealth, this.playerStats.health + delta * 1.5);
    }

    this.callbacks.onStatsChange({ ...this.playerStats });
    this.callbacks.onTimeChange(this.gameTimeMinutes, this.dayCount, this.isNight, this.isDusk);

    // 4. Horde Director Waves at Night
    if (this.isNight) {
      this.hordeWaveTimer += delta;
      if (this.hordeWaveTimer >= 35.0) {
        this.hordeWaveTimer = 0;
        const waveCount = 3 + Math.min(6, this.dayCount * 2);
        this.zombieMgr.spawnHordeWave(this.player.position, waveCount);
      }
    }

    // 5. Update Zombies
    this.zombieMgr.update(delta, this.player.position, this.buildingMgr, (dmg) => {
      this.damagePlayer(dmg);
    });

    // 6. Raycast Interaction Prompt
    this.checkInteractionPrompt();

    // 7. Auto-save every 60s
    this.autoSaveTimer += delta;
    if (this.autoSaveTimer >= 60.0) {
      this.autoSaveTimer = 0;
      this.triggerAutoSave();
    }
  }

  private updateAtmosphere(hour: number) {
    let sunIntensity = 2.2;
    let skyColor = new THREE.Color(0x87ceeb); // noon blue
    let sunColor = new THREE.Color(0xfff4d6);

    if (hour >= 5.0 && hour < 8.0) {
      // Dawn
      const t = (hour - 5.0) / 3.0;
      skyColor.setRGB(0.7 + t * 0.1, 0.45 + t * 0.35, 0.3 + t * 0.6);
      sunColor.setRGB(1.0, 0.6 + t * 0.35, 0.3 + t * 0.6);
      sunIntensity = 1.0 + t * 1.2;
    } else if (hour >= 8.0 && hour < 17.0) {
      // Full daylight
      skyColor.setRGB(0.53, 0.75, 0.92);
      sunColor.setRGB(1.0, 0.95, 0.85);
      sunIntensity = 2.2;
    } else if (hour >= 17.0 && hour < 20.5) {
      // Sunset / Dusk
      const t = (hour - 17.0) / 3.5;
      skyColor.setRGB(0.6 - t * 0.45, 0.3 - t * 0.22, 0.2 - t * 0.12);
      sunColor.setRGB(1.0, 0.45 - t * 0.3, 0.15);
      sunIntensity = 1.8 - t * 1.4;
    } else {
      // Night (blood-tinged deep twilight)
      skyColor.setRGB(0.04, 0.05, 0.1);
      sunColor.setRGB(0.6, 0.25, 0.25); // Red blood moon
      sunIntensity = 0.35;
    }

    this.scene.background = skyColor;
    if (this.scene.fog instanceof THREE.FogExp2) {
      this.scene.fog.color = skyColor;
      this.scene.fog.density = this.isNight ? 0.022 : 0.01;
    }

    this.dirLight.color = sunColor;
    this.dirLight.intensity = sunIntensity;

    // Orbit sun / moon
    const sunAngle = ((hour - 6.0) / 24.0) * Math.PI * 2;
    this.dirLight.position.set(
      Math.cos(sunAngle) * 80,
      Math.max(10, Math.sin(sunAngle) * 90),
      Math.sin(sunAngle) * 60
    );
  }

  // --- Interaction & Action Handling ---

  public handlePrimaryAction(inventory: { hasCrossbowBolts: boolean; consumeBolt: () => boolean }): boolean {
    this.player.triggerActionSwing();

    // 1. If currently in Building Mode -> place active structure
    if (this.buildingMgr.activeDef) {
      const snapTarget = this.getPlacementAimPoint();
      if (snapTarget) {
        const placed = this.buildingMgr.placeActiveStructure(snapTarget);
        if (placed) {
          soundEngine.playBuildSnap();
          this.updateQuestProgress('build_foundation', placed.typeId === 'wooden_foundation' ? 1 : 0);
          this.updateQuestProgress('build_wall', placed.typeId === 'wooden_wall' ? 1 : 0);
          this.updateQuestProgress('build_gate', placed.typeId === 'wooden_gate' ? 1 : 0);
          this.updateQuestProgress('build_spikes', placed.typeId === 'defense_spikes' ? 1 : 0);
          this.updateQuestProgress('build_watchtower', placed.typeId === 'watchtower' ? 1 : 0);
          this.updateQuestProgress('build_lights', (placed.typeId === 'perimeter_torch' || placed.typeId === 'solar_spotlight') ? 1 : 0);
          this.updateQuestProgress('build_workbench', placed.typeId === 'workbench' ? 1 : 0);
          return true;
        }
      }
      return false;
    }

    // 2. Ranged Crossbow Attack
    if (this.activeSlotItem?.id === 'pulse_crossbow') {
      if (inventory.hasCrossbowBolts && inventory.consumeBolt()) {
        soundEngine.playCrossbowShot();
        this.performRangedShot();
        return true;
      }
      return false;
    }

    // 3. Stun Baton Shock Discharge
    if (this.activeSlotItem?.id === 'stun_baton') {
      soundEngine.playShockDischarge();
    }

    // 4. Melee Raycast against Zombies or Harvestables
    this.performMeleeRaycast();
    return true;
  }

  private performMeleeRaycast() {
    this.raycaster.setFromCamera(this.screenCenter, this.camera);
    const range = 3.2;

    // Check zombies first
    let hitZombie: { id: string; dist: number } | null = null;
    for (const z of this.zombieMgr.zombies) {
      const dx = z.position[0] - this.player.position.x;
      const dz = z.position[2] - this.player.position.z;
      const d = Math.hypot(dx, dz);
      if (d < range) {
        if (!hitZombie || d < hitZombie.dist) {
          hitZombie = { id: z.id, dist: d };
        }
      }
    }

    if (hitZombie) {
      let dmg = 20;
      let knockback = 1.5;
      if (this.activeSlotItem) {
        dmg = this.activeSlotItem.damage || 20;
        if (this.activeSlotItem.id === 'stun_baton') knockback = 4.0;
      }
      const res = this.zombieMgr.damageZombie(hitZombie.id, dmg, knockback);
      if (res) {
        soundEngine.playHurt();
        if (res.killed) {
          this.addXP(res.xp);
          // Drop loot (cloth / metal)
          this.callbacks.onItemCollected('cloth_fabric', 2);
          if (Math.random() > 0.5) this.callbacks.onItemCollected('nails_bolts', 2);
        }
      }
      return;
    }

    // Check harvestable resources
    let nearestRes: HarvestableResource | null = null;
    let minResDist = 3.5;

    for (const r of this.terrain.resources) {
      const dx = r.position[0] - this.player.position.x;
      const dz = r.position[2] - this.player.position.z;
      const d = Math.hypot(dx, dz);
      if (d < minResDist) {
        nearestRes = r;
        minResDist = d;
      }
    }

    if (nearestRes) {
      const toolType = this.activeSlotItem?.toolType || 'none';
      let dmg = 25;
      if (nearestRes.type === 'tree') {
        soundEngine.playChopWood();
        dmg = toolType === 'axe' ? 50 : 20;
      } else if (nearestRes.type === 'rock' || nearestRes.type === 'metal_scrap') {
        soundEngine.playMineRock();
        dmg = toolType === 'pickaxe' ? 55 : 18;
      } else {
        soundEngine.playChopWood();
        dmg = 40;
      }

      const damaged = this.terrain.damageResource(nearestRes.id, dmg);
      if (damaged && damaged.health <= 0) {
        // Collect yield
        const itemDef = ITEMS[damaged.yieldItem];
        if (itemDef) {
          this.callbacks.onResourceHarvested(damaged, itemDef, damaged.yieldAmount);
          this.callbacks.onItemCollected(itemDef.id, damaged.yieldAmount);
          this.addXP(15);
          if (damaged.yieldItem === 'wood') {
            this.updateQuestProgress('gather_wood', damaged.yieldAmount);
          } else if (damaged.yieldItem === 'stone') {
            this.updateQuestProgress('gather_stone', damaged.yieldAmount);
          }
        }
      }
      return;
    }

    // Check for structure repair with hammer
    if (this.activeSlotItem?.toolType === 'hammer') {
      for (const s of this.buildingMgr.structures) {
        const dx = s.position[0] - this.player.position.x;
        const dz = s.position[2] - this.player.position.z;
        if (Math.hypot(dx, dz) < 3.2) {
          if (this.buildingMgr.repairStructure(s.uid, 250)) {
            soundEngine.playBuildSnap();
          }
          break;
        }
      }
    }
  }

  private performRangedShot() {
    this.raycaster.setFromCamera(this.screenCenter, this.camera);
    const range = 50.0;

    // Check hit on closest zombie
    let nearestZombie: { id: string; dist: number } | null = null;
    for (const z of this.zombieMgr.zombies) {
      const dx = z.position[0] - this.player.position.x;
      const dz = z.position[2] - this.player.position.z;
      const d = Math.hypot(dx, dz);
      if (d < range) {
        if (!nearestZombie || d < nearestZombie.dist) {
          nearestZombie = { id: z.id, dist: d };
        }
      }
    }

    if (nearestZombie) {
      const res = this.zombieMgr.damageZombie(nearestZombie.id, 65, 3.0);
      if (res) {
        soundEngine.playHurt();
        if (res.killed) {
          this.addXP(res.xp);
          this.callbacks.onItemCollected('cloth_fabric', 2);
        }
      }
    }
  }

  public handleInteractKey() {
    // E Key interaction
    const range = 3.5;

    // Nearby survivor conversation/rescue takes priority over world props.
    const survivor = this.rescueManager.nearest(this.player.position, range);
    if (survivor) {
      const dialogue = this.rescueManager.getDialogue(survivor.id);
      if (dialogue) this.callbacks.onOpenDialogue?.(dialogue);
      return;
    }

    // Check placed structures
    for (const struct of this.buildingMgr.structures) {
      const dx = struct.position[0] - this.player.position.x;
      const dz = struct.position[2] - this.player.position.z;
      if (Math.hypot(dx, dz) < range) {
        const def = this.buildingMgr.activeDef; // check type
        if (struct.typeId === 'wooden_gate' || struct.typeId === 'starter_cabin') {
          const isOpen = this.buildingMgr.toggleDoor(struct.uid);
          soundEngine.playGateToggle(isOpen);
          return;
        } else if (struct.typeId === 'survivor_bed') {
          this.updateQuestProgress('rest_in_bed', 1);
          this.sleepUntilDawn();
          return;
        } else if (struct.typeId === 'notice_board') {
          soundEngine.playUIClick();
          this.updateQuestProgress('read_notice_board', 1);
          this.callbacks.onOpenNoticeBoard();
          return;
        } else if (struct.typeId === 'farm_plot') {
          const result = this.buildingMgr.tendFarmPlot(struct.uid, true);
          this.updateQuestProgress('tend_farm', 1);
          if (result.action === 'harvested') {
            soundEngine.playBuildSnap();
            this.callbacks.onItemCollected('wild_berries', result.yieldAmount || 4);
            this.addXP(25);
          } else if (result.action === 'planted') {
            soundEngine.playBuildSnap();
          }
          return;
        } else if (struct.typeId === 'water_collector') {
          soundEngine.playUIClick();
          this.callbacks.onItemCollected('clean_water', 1);
          return;
        } else if (struct.typeId === 'storage_chest') {
          soundEngine.playUIClick();
          this.updateQuestProgress('open_storage_stash', 1);
          this.callbacks.onOpenStorage(struct);
          return;
        } else if (struct.typeId === 'workbench') {
          soundEngine.playUIClick();
          this.callbacks.onOpenCrafting('workbench');
          return;
        } else if (struct.typeId === 'campfire') {
          soundEngine.playUIClick();
          this.callbacks.onOpenCrafting('campfire');
          return;
        }
      }
    }

    // Check supply crate
    const crate = this.terrain.resources.find((r) => r.type === 'supply_crate');
    if (crate) {
      const dx = crate.position[0] - this.player.position.x;
      const dz = crate.position[2] - this.player.position.z;
      if (Math.hypot(dx, dz) < range) {
        this.terrain.damageResource(crate.id, 100);
        soundEngine.playBuildSnap();
        this.callbacks.onItemCollected('canned_beans', 3);
        this.callbacks.onItemCollected('clean_water', 2);
        this.callbacks.onItemCollected('nails_bolts', 8);
        return;
      }
    }
  }

  public resolveSurvivorChoice(id: string, choice: string) {
    if (choice === 'Help me reach the sanctuary') {
      const started = this.rescueManager.beginEscort(id);
      if (started) this.callbacks.onInteractionPrompt('Survivor is following you. Lead them back inside the sanctuary perimeter.');
    }
  }

  public sleepUntilDawn() {
    soundEngine.playDawnVictoryChime();
    this.gameTimeMinutes = 360; // 06:00 AM Dawn
    this.dayCount += 1;
    this.playerStats.health = this.playerStats.maxHealth;
    this.playerStats.stamina = this.playerStats.maxStamina;
    this.playerStats.temperature = 24;
    this.buildingMgr.advanceFarmCrops();
    this.callbacks.onStatsChange({ ...this.playerStats });
    this.callbacks.onTimeChange(this.gameTimeMinutes, this.dayCount, false, false);
    this.callbacks.onHordeEvent('dawn_victory');
    this.updateQuestProgress('survive_night', 1);
    this.triggerAutoSave();
  }

  private checkInteractionPrompt() {
    if (this.buildingMgr.activeDef) {
      this.callbacks.onInteractionPrompt('[Left-Click] Place Structure | [R] Rotate | [B / Esc] Cancel');
      const aim = this.getPlacementAimPoint();
      if (aim) {
        this.buildingMgr.updatePreview(aim, true);
      }
      return;
    }

    const range = 3.5;
    const nearbySurvivor = this.rescueManager.nearest(this.player.position, range);
    if (nearbySurvivor) {
      this.callbacks.onInteractionPrompt(`[E] Talk to ${nearbySurvivor.name} · ${nearbySurvivor.role}`);
      return;
    }
    for (const struct of this.buildingMgr.structures) {
      const dx = struct.position[0] - this.player.position.x;
      const dz = struct.position[2] - this.player.position.z;
      if (Math.hypot(dx, dz) < range) {
        if (this.activeSlotItem?.toolType === 'hammer' && struct.currentHealth < struct.maxHealth) {
          const name = struct.typeId === 'wooden_wall' ? 'Fortified Palisade Wall' : struct.typeId === 'wooden_gate' ? 'Perimeter Gate' : 'Structure';
          this.callbacks.onInteractionPrompt(`[Left-Click] Repair ${name} (${Math.round(struct.currentHealth)}/${struct.maxHealth} HP)`);
          return;
        }
        if (struct.typeId === 'wooden_gate' || struct.typeId === 'starter_cabin') {
          this.callbacks.onInteractionPrompt(`[E] ${struct.isOpen ? 'Close Gate / Door' : 'Open Gate / Door'}`);
          return;
        } else if (struct.typeId === 'survivor_bed') {
          this.callbacks.onInteractionPrompt('[E] Sleep in Bed until Morning (Heals & Recovers Stamina)');
          return;
        } else if (struct.typeId === 'notice_board') {
          this.callbacks.onInteractionPrompt('[E] Read Sanctuary Notice Board & Directives');
          return;
        } else if (struct.typeId === 'farm_plot') {
          const stage = struct.farmStage || 0;
          if (stage === 0) {
            this.callbacks.onInteractionPrompt('[E] Plant Seed Packet in Soil');
          } else if (stage === 1) {
            this.callbacks.onInteractionPrompt('[E] Tend Farm Plot (Crops are Growing)');
          } else {
            this.callbacks.onInteractionPrompt('[E] Harvest Ripe Berries (+4 Crops)');
          }
          return;
        } else if (struct.typeId === 'water_collector') {
          this.callbacks.onInteractionPrompt('[E] Draw Clean Water from Cistern');
          return;
        } else if (struct.typeId === 'storage_chest') {
          this.callbacks.onInteractionPrompt('[E] Open Storage Stash');
          return;
        } else if (struct.typeId === 'workbench') {
          this.callbacks.onInteractionPrompt('[E] Use Artisan Workbench');
          return;
        } else if (struct.typeId === 'campfire') {
          this.callbacks.onInteractionPrompt('[E] Cook / Boil Water at Campfire');
          return;
        }
      }
    }

    // Check resource prompt
    for (const res of this.terrain.resources) {
      const dx = res.position[0] - this.player.position.x;
      const dz = res.position[2] - this.player.position.z;
      if (Math.hypot(dx, dz) < 3.2) {
        if (res.type === 'tree') {
          this.callbacks.onInteractionPrompt('[Left-Click] Fell Timber Pine (Equip Axe)');
          return;
        } else if (res.type === 'rock') {
          this.callbacks.onInteractionPrompt('[Left-Click] Quarry Granite Boulder (Equip Pickaxe)');
          return;
        } else if (res.type === 'metal_scrap') {
          this.callbacks.onInteractionPrompt('[Left-Click] Salvage Vehicle Scrap (Equip Pickaxe)');
          return;
        } else if (res.type === 'berry_bush') {
          this.callbacks.onInteractionPrompt('[Left-Click] Forage Wild Berries');
          return;
        } else if (res.type === 'supply_crate') {
          this.callbacks.onInteractionPrompt('[E] Scavenge Outpost Supply Crate');
          return;
        }
      }
    }

    this.callbacks.onInteractionPrompt(null);
  }

  private getPlacementAimPoint(): THREE.Vector3 | null {
    // Project ray forward 6 meters onto terrain
    const forwardX = Math.sin(this.player.yaw) * 4.5;
    const forwardZ = Math.cos(this.player.yaw) * 4.5;
    return new THREE.Vector3(
      this.player.position.x + forwardX,
      0,
      this.player.position.z + forwardZ
    );
  }

  public damagePlayer(amount: number) {
    if (this.gameMode === 'creative') return;
    this.playerStats.health = Math.max(0, this.playerStats.health - amount);
    soundEngine.playHurt();

    if (this.playerStats.health <= 0) {
      this.callbacks.onGameOver();
    }
  }

  public addXP(amount: number) {
    this.playerStats.xp += amount;
    while (this.playerStats.xp >= this.playerStats.xpToNextLevel) {
      this.playerStats.xp -= this.playerStats.xpToNextLevel;
      this.playerStats.level += 1;
      this.playerStats.skillPoints += 1;
      this.playerStats.xpToNextLevel = Math.floor(this.playerStats.xpToNextLevel * 1.5);
    }
  }

  public updateQuestProgress(objectiveId: string, amount: number) {
    let changed = false;
    this.quests.forEach((q) => {
      if (q.completed) return;
      q.objectives.forEach((obj) => {
        if (obj.id === objectiveId && !obj.completed) {
          obj.current = Math.min(obj.target, obj.current + amount);
          if (obj.current >= obj.target) {
            obj.completed = true;
          }
          changed = true;
        }
      });
      // Check if entire quest completed
      const allDone = q.objectives.every((o) => o.completed);
      if (allDone && !q.completed) {
        q.completed = true;
        this.addXP(q.rewards.xp);
        if (q.rewards.items) {
          q.rewards.items.forEach((rew) => {
            this.callbacks.onItemCollected(rew.itemId, rew.count);
          });
        }
      }
    });

    if (changed) {
      this.callbacks.onQuestsUpdate([...this.quests]);
    }
  }

  public triggerAutoSave() {
    const meta: SaveSlotMetadata = {
      id: 'autosave',
      name: 'Autosave Slot',
      characterName: 'Survivor',
      dayCount: this.dayCount,
      timeString: `${Math.floor(this.gameTimeMinutes / 60).toString().padStart(2, '0')}:${Math.floor(this.gameTimeMinutes % 60).toString().padStart(2, '0')}`,
      timestamp: Date.now(),
      difficulty: this.difficulty,
      gameMode: this.gameMode,
    };

    const saveData: FullGameSave = {
      metadata: meta,
      worldSeed: this.terrain.seed,
      playerPosition: [this.player.position.x, this.player.position.y, this.player.position.z],
      playerRotation: this.player.yaw,
      playerStats: { ...this.playerStats },
      inventory: [],
      hotbar: [],
      selectedHotbarIndex: 0,
      structures: [...this.buildingMgr.structures],
      quests: [...this.quests],
      gameTimeMinutes: this.gameTimeMinutes,
      dayCount: this.dayCount,
      nightHordeCountDefeated: this.nightHordesDefeated,
      ...this.worldPersistence.exportSaveData(),
      rescuedSurvivorIds: this.rescueManager.exportRescued(),
    };

    saveGameToSlot(saveData);
  }

  public dispose() {
    this.isRunning = false;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    window.removeEventListener('resize', this.onResize);
    this.chunkManager.dispose();
    this.wildlifeManager.dispose();
    this.rescueManager.dispose();
    this.npcSettlementManager.dispose();
    this.terrain.dispose();
    this.buildingMgr.dispose();
    this.zombieMgr.dispose();
    this.pmremGenerator.dispose();
    this.renderer.dispose();

    if (this.container && this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
