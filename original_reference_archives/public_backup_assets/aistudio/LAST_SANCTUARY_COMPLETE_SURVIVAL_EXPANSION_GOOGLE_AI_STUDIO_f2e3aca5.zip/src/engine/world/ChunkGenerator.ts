/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { ChunkCoord, ChunkData, HarvestableResource, POIStructure, GraphicsQuality } from '../../types/game';
import { CHUNK_SIZE, WorldCoordinates } from './WorldCoordinates';
import { BiomeGenerator, BIOMES } from './BiomeGenerator';
import { TerrainGenerator } from './TerrainGenerator';
import { RoadGenerator } from './RoadGenerator';
import { POIGenerator } from './POIGenerator';
import { VegetationGenerator } from './VegetationGenerator';
import { LODManager } from './LODManager';
import { getTerrainTexture } from '../../utils/proceduralTextures';

export interface GeneratedChunk {
  data: ChunkData;
  group: THREE.Group;
  terrainMesh: THREE.Mesh;
  waterMesh: THREE.Mesh | null;
  roadMesh: THREE.Mesh | null;
  resourceMeshes: Map<string, THREE.Group>;
  poiMeshes: Map<string, THREE.Group>;
  dispose: () => void;
}

export class ChunkGenerator {
  /**
   * Builds an entire 256x256 chunk with terrain, water, roads, harvestables, and POIs
   */
  public static createChunk(
    coord: ChunkCoord,
    worldSeed: number,
    lodLevel: number,
    quality: GraphicsQuality = 'medium',
    destroyedResourceIds: Set<string> = new Set(),
    lootedPoiIds: Set<string> = new Set()
  ): GeneratedChunk {
    const key = WorldCoordinates.chunkKey(coord.cx, coord.cz);
    const [minX, minZ] = WorldCoordinates.chunkToWorldOrigin(coord.cx, coord.cz);
    const [centerX, centerZ] = WorldCoordinates.chunkToWorldCenter(coord.cx, coord.cz);

    const biomeDef = BiomeGenerator.getBiomeAt(centerX, centerZ, worldSeed);
    const group = new THREE.Group();
    group.name = `chunk_${key}`;

    // 1. Terrain Mesh
    const segments = LODManager.getSegmentsForLOD(lodLevel, quality);
    const geometry = new THREE.PlaneGeometry(CHUNK_SIZE, CHUNK_SIZE, segments, segments);
    geometry.rotateX(-Math.PI / 2);

    let minElevation = 9999;
    let maxElevation = -9999;

    const pos = geometry.attributes.position;
    const colors = new Float32Array(pos.count * 3);
    const baseColor = new THREE.Color(biomeDef.groundColor);

    for (let i = 0; i < pos.count; i++) {
      // Local plane geometry is centered at 0, offset by world origin + half size
      const lx = pos.getX(i);
      const lz = pos.getZ(i);
      const wx = minX + CHUNK_SIZE * 0.5 + lx;
      const wz = minZ + CHUNK_SIZE * 0.5 + lz;

      const y = TerrainGenerator.getHeight(wx, wz, worldSeed);
      pos.setY(i, y);

      if (y < minElevation) minElevation = y;
      if (y > maxElevation) maxElevation = y;

      // Subtle natural vertex color variation
      const tintFactor = 0.85 + (Math.sin(wx * 0.08) * Math.cos(wz * 0.08) + 1.0) * 0.15;
      colors[i * 3 + 0] = baseColor.r * tintFactor;
      colors[i * 3 + 1] = baseColor.g * tintFactor;
      colors[i * 3 + 2] = baseColor.b * tintFactor;
    }

    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geometry.computeVertexNormals();

    const terrainTexture = getTerrainTexture();
    terrainTexture.repeat.set(16, 16);

    const terrainMat = new THREE.MeshStandardMaterial({
      map: terrainTexture,
      vertexColors: true,
      roughness: biomeDef.roughness,
      metalness: 0.08,
      flatShading: lodLevel === 2,
    });

    const terrainMesh = new THREE.Mesh(geometry, terrainMat);
    terrainMesh.position.set(minX + CHUNK_SIZE * 0.5, 0, minZ + CHUNK_SIZE * 0.5);
    terrainMesh.receiveShadow = quality !== 'low';
    group.add(terrainMesh);

    // 2. River / Lake Water Plane
    let waterMesh: THREE.Mesh | null = null;
    const riverWave = Math.sin(centerZ * 0.004) * 45;
    const riverDist = Math.abs(centerX - 50 - riverWave);

    if (riverDist < 120 || biomeDef.waterColor) {
      const waterColor = biomeDef.waterColor || 0x225577;
      const waterGeo = new THREE.PlaneGeometry(CHUNK_SIZE, CHUNK_SIZE);
      waterGeo.rotateX(-Math.PI / 2);

      const waterMat = new THREE.MeshStandardMaterial({
        color: waterColor,
        roughness: 0.15,
        metalness: 0.7,
        transparent: true,
        opacity: 0.82,
      });

      waterMesh = new THREE.Mesh(waterGeo, waterMat);
      waterMesh.position.set(minX + CHUNK_SIZE * 0.5, -0.6, minZ + CHUNK_SIZE * 0.5);
      group.add(waterMesh);
    }

    // 3. Roads & Pathways
    const roadMesh = RoadGenerator.generateChunkRoadMesh(minX, minZ, CHUNK_SIZE, worldSeed);
    if (roadMesh) {
      group.add(roadMesh);
    }

    // 4. Harvestable Resources (avoid destroyed)
    const rawResources = VegetationGenerator.generateResourcesForChunk(coord.cx, coord.cz, biomeDef.id, worldSeed);
    const resources: HarvestableResource[] = [];
    const resourceMeshes: Map<string, THREE.Group> = new Map();

    for (let i = 0; i < rawResources.length; i++) {
      const r = rawResources[i];
      if (destroyedResourceIds.has(r.id)) continue;

      resources.push(r);
      // Only instantiate 3D resource models if LOD <= 1 to conserve GPU memory
      if (lodLevel <= 1) {
        const rMesh = VegetationGenerator.createResourceMesh(r);
        resourceMeshes.set(r.id, rMesh);
        group.add(rMesh);
      }
    }

    // 5. Procedural POIs
    const rawPOIs = POIGenerator.getPOIsForChunk(coord.cx, coord.cz, worldSeed);
    const pois: POIStructure[] = [];
    const poiMeshes: Map<string, THREE.Group> = new Map();

    for (let i = 0; i < rawPOIs.length; i++) {
      const p = rawPOIs[i];
      if (lootedPoiIds.has(p.id)) {
        p.isLooted = true;
      }
      pois.push(p);

      const pMesh = POIGenerator.createPOIMesh(p);
      poiMeshes.set(p.id, pMesh);
      group.add(pMesh);
    }

    const chunkData: ChunkData = {
      coord,
      key,
      seed: worldSeed,
      biome: biomeDef.id,
      resources,
      pois,
      isLoaded: true,
      lodLevel,
      minElevation,
      maxElevation,
    };

    // Cleanup disposal callback
    const dispose = () => {
      geometry.dispose();
      terrainMat.dispose();
      if (waterMesh) {
        waterMesh.geometry.dispose();
        if (Array.isArray(waterMesh.material)) {
          waterMesh.material.forEach((m) => m.dispose());
        } else {
          waterMesh.material.dispose();
        }
      }
      if (roadMesh) {
        roadMesh.geometry.dispose();
        if (Array.isArray(roadMesh.material)) {
          roadMesh.material.forEach((m) => m.dispose());
        } else {
          roadMesh.material.dispose();
        }
      }
      resourceMeshes.forEach((m) => {
        m.traverse((child) => {
          if (child instanceof THREE.Mesh) {
            child.geometry?.dispose();
          }
        });
      });
      resourceMeshes.clear();
      poiMeshes.forEach((m) => {
        m.traverse((child) => {
          if (child instanceof THREE.Mesh) {
            child.geometry?.dispose();
          }
        });
      });
      poiMeshes.clear();
    };

    return {
      data: chunkData,
      group,
      terrainMesh,
      waterMesh,
      roadMesh,
      resourceMeshes,
      poiMeshes,
      dispose,
    };
  }
}
