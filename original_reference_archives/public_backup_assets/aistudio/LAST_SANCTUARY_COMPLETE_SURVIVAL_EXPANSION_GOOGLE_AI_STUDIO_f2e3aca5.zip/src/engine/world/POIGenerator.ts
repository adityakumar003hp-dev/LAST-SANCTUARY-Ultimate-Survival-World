/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { POIStructure } from '../../types/game';
import { TerrainGenerator } from './TerrainGenerator';
import { getWoodPlankTexture, getStoneTexture, getMetalScrapTexture } from '../../utils/proceduralTextures';

export class POIGenerator {
  /**
   * Deterministically decides if a chunk has a POI structure
   */
  public static getPOIsForChunk(
    cx: number,
    cz: number,
    worldSeed: number = 42
  ): POIStructure[] {
    // Sanctuary Base is at Chunk (0, 0), so we don't spawn abandoned ruins on top of the modern estate
    if (cx === 0 && cz === 0) return [];

    const pois: POIStructure[] = [];

    // Hash function based on chunk coordinate
    const h = Math.abs(Math.sin(cx * 12.9898 + cz * 78.233 + worldSeed) * 43758.5453) % 1;

    // ~35% of chunks have an interesting POI structure
    if (h > 0.65) {
      const offsetX = 40 + ((h * 1337) % 1) * 176;
      const offsetZ = 40 + ((h * 9973) % 1) * 176;
      const worldX = cx * 256 + offsetX;
      const worldZ = cz * 256 + offsetZ;
      const y = TerrainGenerator.getHeight(worldX, worldZ, worldSeed);

      let type: POIStructure['type'] = 'cabin';
      let name = 'Abandoned Survivor Shack';

      if (h > 0.94) {
        type = 'research_lab';
        name = 'Apex Bio-Tech Field Annex';
      } else if (h > 0.88) {
        type = 'warehouse';
        name = 'Overgrown Logistics Depot';
      } else if (h > 0.82) {
        type = 'gas_station';
        name = 'Route 9 Auto Service Station';
      } else if (h > 0.75) {
        type = 'watchtower';
        name = 'Forestry Fire Lookout';
      } else if (h > 0.70) {
        type = 'radio_bunker';
        name = 'Civil Defense Comms Bunker';
      }

      pois.push({
        id: `poi_${cx}_${cz}_1`,
        type,
        name,
        position: [worldX, y, worldZ],
        rotationY: ((h * 6.28) % (Math.PI * 2)),
        hasLoot: true,
        isLooted: false,
      });
    }

    return pois;
  }

  /**
   * Builds high-fidelity composite 3D meshes (3-10 parts) for procedural POIs
   */
  public static createPOIMesh(poi: POIStructure): THREE.Group {
    const group = new THREE.Group();
    group.name = poi.id;

    const woodMat = new THREE.MeshStandardMaterial({
      map: getWoodPlankTexture(),
      roughness: 0.85,
    });
    const stoneMat = new THREE.MeshStandardMaterial({
      map: getStoneTexture(),
      roughness: 0.9,
    });
    const metalMat = new THREE.MeshStandardMaterial({
      map: getMetalScrapTexture(),
      roughness: 0.6,
      metalness: 0.7,
    });

    switch (poi.type) {
      case 'research_lab': {
        // High-tech modular prefab lab: concrete base, steel walls, tinted glass, radar dish, ventilation
        const foundation = new THREE.Mesh(new THREE.BoxGeometry(14, 0.6, 10), stoneMat);
        foundation.position.y = 0.3;

        const mainHull = new THREE.Mesh(new THREE.BoxGeometry(13.6, 4.2, 9.6), metalMat);
        mainHull.position.y = 2.4;

        const glassMat = new THREE.MeshPhysicalMaterial({ color: 0x1a4552, roughness: 0.2, metalness: 0.8, transmission: 0.6 });
        const windowStrip = new THREE.Mesh(new THREE.BoxGeometry(13.8, 1.2, 0.2), glassMat);
        windowStrip.position.set(0, 3.2, 4.8);

        // Roof AC vents
        const vent = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.2, 2.2), metalMat);
        vent.position.set(-3, 5.0, 0);

        // Satellite comms mast
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 3.5, 8), metalMat);
        pole.position.set(3.5, 6.0, 0);
        const dish = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 0.3, 0.4, 12), metalMat);
        dish.rotation.x = Math.PI / 4;
        dish.position.set(3.5, 7.5, 0);

        group.add(foundation, mainHull, windowStrip, vent, pole, dish);
        break;
      }

      case 'warehouse': {
        // Corrugated metal industrial depot
        const base = new THREE.Mesh(new THREE.BoxGeometry(16, 0.4, 12), stoneMat);
        base.position.y = 0.2;

        const walls = new THREE.Mesh(new THREE.BoxGeometry(15.6, 5.5, 11.6), metalMat);
        walls.position.y = 2.95;

        // Large roll-up loading door
        const doorMat = new THREE.MeshStandardMaterial({ color: 0x8a4b2a, roughness: 0.7 });
        const door = new THREE.Mesh(new THREE.BoxGeometry(5.0, 4.0, 0.3), doorMat);
        door.position.set(0, 2.0, 5.85);

        // Roof trusses
        const roof = new THREE.Mesh(new THREE.BoxGeometry(16.4, 0.4, 12.4), metalMat);
        roof.position.y = 5.8;

        group.add(base, walls, door, roof);
        break;
      }

      case 'gas_station': {
        // Roadside gas canopy and pump island
        const island = new THREE.Mesh(new THREE.BoxGeometry(10, 0.4, 4), stoneMat);
        island.position.y = 0.2;

        const pylonL = new THREE.Mesh(new THREE.BoxGeometry(0.5, 4.5, 0.5), metalMat);
        pylonL.position.set(-3.5, 2.25, 0);
        const pylonR = new THREE.Mesh(new THREE.BoxGeometry(0.5, 4.5, 0.5), metalMat);
        pylonR.position.set(3.5, 2.25, 0);

        const canopy = new THREE.Mesh(new THREE.BoxGeometry(12, 0.6, 6), metalMat);
        canopy.position.y = 4.8;

        // Dual gas dispensers
        const pumpGeo = new THREE.BoxGeometry(0.9, 1.8, 0.7);
        const pumpMat = new THREE.MeshStandardMaterial({ color: 0xb5352a, roughness: 0.5 });
        const pump1 = new THREE.Mesh(pumpGeo, pumpMat);
        pump1.position.set(-1.8, 1.1, 0);
        const pump2 = new THREE.Mesh(pumpGeo, pumpMat);
        pump2.position.set(1.8, 1.1, 0);

        group.add(island, pylonL, pylonR, canopy, pump1, pump2);
        break;
      }

      case 'watchtower': {
        // Timber observation pylon
        const pylonGeo = new THREE.CylinderGeometry(0.2, 0.25, 8.0, 6);
        for (const [px, pz] of [[-1.8, -1.8], [1.8, -1.8], [-1.8, 1.8], [1.8, 1.8]]) {
          const leg = new THREE.Mesh(pylonGeo, woodMat);
          leg.position.set(px, 4.0, pz);
          group.add(leg);
        }

        const deck = new THREE.Mesh(new THREE.BoxGeometry(4.5, 0.4, 4.5), woodMat);
        deck.position.y = 8.0;

        const rail = new THREE.Mesh(new THREE.BoxGeometry(4.5, 1.0, 4.5), metalMat);
        rail.position.y = 8.7;

        const roofPillars = new THREE.Mesh(new THREE.BoxGeometry(0.2, 2.2, 0.2), woodMat);
        roofPillars.position.set(0, 9.5, 0);

        const roofCap = new THREE.Mesh(new THREE.ConeGeometry(3.5, 1.5, 4), woodMat);
        roofCap.position.y = 11.2;
        roofCap.rotation.y = Math.PI / 4;

        group.add(deck, rail, roofPillars, roofCap);
        break;
      }

      default: {
        // Rustic wooden cabin
        const foundation = new THREE.Mesh(new THREE.BoxGeometry(7, 0.4, 6), stoneMat);
        foundation.position.y = 0.2;

        const walls = new THREE.Mesh(new THREE.BoxGeometry(6.6, 2.8, 5.6), woodMat);
        walls.position.y = 1.6;

        const roofPitched = new THREE.Mesh(new THREE.ConeGeometry(4.8, 1.8, 4), woodMat);
        roofPitched.rotation.y = Math.PI / 4;
        roofPitched.position.y = 3.9;

        const chimney = new THREE.Mesh(new THREE.BoxGeometry(0.8, 4.2, 0.8), stoneMat);
        chimney.position.set(2.4, 2.4, -1.8);

        group.add(foundation, walls, roofPitched, chimney);
      }
    }

    // Supply crate loot container inside / near POI
    if (poi.hasLoot && !poi.isLooted) {
      const crateMat = new THREE.MeshStandardMaterial({ color: 0xb5893e, roughness: 0.8 });
      const crate = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.9, 1.0), crateMat);
      crate.name = `loot_${poi.id}`;
      crate.position.set(0.5, 0.6, 1.2);
      group.add(crate);
    }

    group.position.set(poi.position[0], poi.position[1], poi.position[2]);
    group.rotation.y = poi.rotationY;

    return group;
  }
}
