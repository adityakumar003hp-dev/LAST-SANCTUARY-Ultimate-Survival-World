/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { VehicleState } from '../../types/game';
import { TerrainGenerator } from '../world/TerrainGenerator';

export class VehicleParkingManager {
  public scene: THREE.Scene;
  public vehicleState: VehicleState = {
    id: 'veh_recon_buggy_01',
    name: 'Apex Nomad Electric Recon Buggy',
    position: [10.0, 0, -2.5],
    rotationY: 0,
    batteryPercent: 95,
    headlightsOn: true,
    isOccupied: false,
    trunkInventory: new Array(8).fill(null),
  };

  public mesh: THREE.Group;
  public currentSpeed: number = 0;
  public maxSpeed: number = 18.0; // ~65 km/h
  public headlights: THREE.SpotLight[] = [];

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.mesh = this.createBuggyMesh();
    this.mesh.position.set(
      this.vehicleState.position[0],
      TerrainGenerator.getHeight(this.vehicleState.position[0], this.vehicleState.position[2]) + 0.35,
      this.vehicleState.position[2]
    );
    this.scene.add(this.mesh);
  }

  private createBuggyMesh(): THREE.Group {
    const group = new THREE.Group();

    const bodyMat = new THREE.MeshStandardMaterial({ color: 0x2b3830, roughness: 0.5, metalness: 0.8 }); // Military olive steel
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.6, metalness: 0.9 }); // Roll cage tubular steel
    const tireMat = new THREE.MeshStandardMaterial({ color: 0x1f1f1f, roughness: 0.9 }); // Heavy tread rubber
    const rimMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.4, metalness: 0.8 }); // Amber rims
    const lightMat = new THREE.MeshBasicMaterial({ color: 0xfff0aa });

    // 1. Lower Chassis
    const chassis = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.45, 3.2), bodyMat);
    chassis.position.y = 0.55;
    chassis.castShadow = true;
    group.add(chassis);

    // 2. Tubular Roll Cage
    const cageGeo = new THREE.CylinderGeometry(0.05, 0.05, 1.4, 8);
    for (const [cx, cz] of [[-0.8, -0.9], [0.8, -0.9], [-0.8, 0.7], [0.8, 0.7]]) {
      const pylon = new THREE.Mesh(cageGeo, frameMat);
      pylon.position.set(cx, 1.3, cz);
      group.add(pylon);
    }
    const roofRack = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.1, 1.8), frameMat);
    roofRack.position.set(0, 2.0, -0.1);
    group.add(roofRack);

    // 3. Bucket Seats
    const seatMat = new THREE.MeshStandardMaterial({ color: 0x333333, roughness: 0.8 });
    const seatL = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.65, 0.5), seatMat);
    seatL.position.set(-0.4, 0.95, -0.1);
    const seatR = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.65, 0.5), seatMat);
    seatR.position.set(0.4, 0.95, -0.1);
    group.add(seatL, seatR);

    // 4. Wheels (4 all-terrain wheels)
    const wheelGeo = new THREE.CylinderGeometry(0.45, 0.45, 0.35, 12);
    wheelGeo.rotateZ(Math.PI / 2);

    const makeWheel = (x: number, z: number, name: string) => {
      const wGroup = new THREE.Group();
      wGroup.name = name;
      const tire = new THREE.Mesh(wheelGeo, tireMat);
      tire.castShadow = true;
      const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.36, 10), rimMat);
      rim.rotateZ(Math.PI / 2);
      wGroup.add(tire, rim);
      wGroup.position.set(x, 0.45, z);
      return wGroup;
    };

    group.add(makeWheel(-1.05, -1.1, 'wheel_fl'));
    group.add(makeWheel(1.05, -1.1, 'wheel_fr'));
    group.add(makeWheel(-1.05, 1.1, 'wheel_rl'));
    group.add(makeWheel(1.05, 1.1, 'wheel_rr'));

    // 5. Dual LED Headlights
    const hlL = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.15, 0.1), lightMat);
    hlL.position.set(-0.6, 0.85, 1.6);
    const hlR = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.15, 0.1), lightMat);
    hlR.position.set(0.6, 0.85, 1.6);
    group.add(hlL, hlR);

    const spotL = new THREE.SpotLight(0xfff0bb, 2.5, 35, Math.PI / 5, 0.4);
    spotL.position.set(-0.6, 0.85, 1.7);
    spotL.target.position.set(-0.6, 0, 15);
    group.add(spotL);
    group.add(spotL.target);

    const spotR = new THREE.SpotLight(0xfff0bb, 2.5, 35, Math.PI / 5, 0.4);
    spotR.position.set(0.6, 0.85, 1.7);
    spotR.target.position.set(0.6, 0, 15);
    group.add(spotR);
    group.add(spotR.target);

    this.headlights = [spotL, spotR];

    return group;
  }

  public update(
    delta: number,
    input: { forward: boolean; backward: boolean; left: boolean; right: boolean },
    worldSeed: number
  ) {
    if (!this.vehicleState.isOccupied) return;

    // Acceleration & Braking
    const accel = 14.0;
    const drag = 3.5;
    if (input.forward && this.vehicleState.batteryPercent > 0) {
      this.currentSpeed = Math.min(this.maxSpeed, this.currentSpeed + accel * delta);
      this.vehicleState.batteryPercent = Math.max(0, this.vehicleState.batteryPercent - delta * 0.15);
    } else if (input.backward && this.vehicleState.batteryPercent > 0) {
      this.currentSpeed = Math.max(-8.0, this.currentSpeed - accel * 0.6 * delta);
    } else {
      if (this.currentSpeed > 0) {
        this.currentSpeed = Math.max(0, this.currentSpeed - drag * delta);
      } else if (this.currentSpeed < 0) {
        this.currentSpeed = Math.min(0, this.currentSpeed + drag * delta);
      }
    }

    // Steering
    const steerSpeed = 1.8;
    if (Math.abs(this.currentSpeed) > 0.2) {
      const dir = this.currentSpeed >= 0 ? 1 : -1;
      if (input.left) {
        this.vehicleState.rotationY += steerSpeed * delta * dir;
      }
      if (input.right) {
        this.vehicleState.rotationY -= steerSpeed * delta * dir;
      }
    }

    // Position integration along forward heading
    const moveDist = this.currentSpeed * delta;
    this.vehicleState.position[0] += Math.sin(this.vehicleState.rotationY) * moveDist;
    this.vehicleState.position[2] += Math.cos(this.vehicleState.rotationY) * moveDist;

    // Follow terrain height smoothly
    const groundY = TerrainGenerator.getHeight(
      this.vehicleState.position[0],
      this.vehicleState.position[2],
      worldSeed
    );
    this.vehicleState.position[1] = groundY + 0.35;

    // Update 3D mesh
    this.mesh.position.set(
      this.vehicleState.position[0],
      this.vehicleState.position[1],
      this.vehicleState.position[2]
    );
    this.mesh.rotation.y = this.vehicleState.rotationY;

    // Wheel spin animation
    const spinDelta = (this.currentSpeed * delta) / 0.45;
    for (const name of ['wheel_fl', 'wheel_fr', 'wheel_rl', 'wheel_rr']) {
      const wheel = this.mesh.getObjectByName(name);
      if (wheel) wheel.rotation.x += spinDelta;
    }
  }

  public toggleHeadlights(): boolean {
    this.vehicleState.headlightsOn = !this.vehicleState.headlightsOn;
    this.headlights.forEach((h) => (h.visible = this.vehicleState.headlightsOn));
    return this.vehicleState.headlightsOn;
  }

  public setOccupied(occupied: boolean) {
    this.vehicleState.isOccupied = occupied;
    if (!occupied) {
      this.currentSpeed = 0;
    }
  }

  public chargeBattery(amount: number) {
    this.vehicleState.batteryPercent = Math.min(100, this.vehicleState.batteryPercent + amount);
  }

  public dispose() {
    this.scene.remove(this.mesh);
  }
}
