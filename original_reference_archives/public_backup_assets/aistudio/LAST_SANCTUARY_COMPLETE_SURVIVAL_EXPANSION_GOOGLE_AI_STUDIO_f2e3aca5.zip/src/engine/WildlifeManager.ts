import * as THREE from 'three';
import { getTerrainHeight } from './Terrain';

export type WildlifeKind = 'mammal' | 'bird' | 'dinosaur' | 'aquatic' | 'reptile' | 'amphibian' | 'insect' | 'rare';
export interface WildlifeSpecies { id: string; name: string; kind: WildlifeKind; biomes: string[]; color: number; scale: number; speed: number; temperament: 'shy' | 'neutral' | 'territorial'; }
interface WildlifeAgent { id: string; species: WildlifeSpecies; group: THREE.Group; velocity: THREE.Vector3; target: THREE.Vector3; state: 'roam'|'rest'|'flee'; stateTimer: number; }

// Data-driven species registry. Models are procedural placeholders designed to be replaceable by GLTF assets.
export const WILDLIFE_SPECIES: WildlifeSpecies[] = [
  {id:'deer',name:'Red Deer',kind:'mammal',biomes:['dense_forest','green_plains','valley','tropical_jungle','ancient_forest','bamboo_forest','savannah'],color:0x8a5735,scale:1.0,speed:4.2,temperament:'shy'},
  {id:'wolf',name:'Grey Wolf',kind:'mammal',biomes:['dense_forest','mountain_range','snow_peaks','taiga','tundra','ancient_forest'],color:0x777b80,scale:0.82,speed:5.2,temperament:'territorial'},
  {id:'bear',name:'Brown Bear',kind:'mammal',biomes:['dense_forest','mountain_range'],color:0x493326,scale:1.35,speed:3.4,temperament:'territorial'},
  {id:'fox',name:'Red Fox',kind:'mammal',biomes:['dense_forest','green_plains','valley','tropical_jungle','ancient_forest','bamboo_forest','savannah'],color:0xb65d25,scale:0.58,speed:4.8,temperament:'shy'},
  {id:'boar',name:'Wild Boar',kind:'mammal',biomes:['dense_forest','wetlands','tropical_jungle','mangrove_delta'],color:0x514039,scale:0.78,speed:3.8,temperament:'territorial'},
  {id:'elephant',name:'Asian Elephant',kind:'mammal',biomes:['green_plains','wetlands'],color:0x77766f,scale:1.9,speed:2.8,temperament:'neutral'},
  {id:'eagle',name:'Golden Eagle',kind:'bird',biomes:['mountain_range','snow_peaks','valley','alpine_meadow','tundra'],color:0x8b6844,scale:0.7,speed:8.5,temperament:'shy'},
  {id:'parrot',name:'Scarlet Macaw',kind:'bird',biomes:['dense_forest','wetlands','tropical_jungle','mangrove_delta'],color:0xd52c24,scale:0.42,speed:7.2,temperament:'shy'},
  {id:'owl',name:'Great Horned Owl',kind:'bird',biomes:['dense_forest','valley'],color:0x8a7459,scale:0.48,speed:6.4,temperament:'shy'},
  {id:'duck',name:'Wild Duck',kind:'bird',biomes:['river_basin','lake_district','wetlands','mangrove_delta','coral_coast'],color:0x55765a,scale:0.38,speed:4.2,temperament:'shy'},
  {id:'penguin',name:'Penguin',kind:'bird',biomes:['snow_peaks'],color:0x222b35,scale:0.58,speed:1.8,temperament:'neutral'},
  {id:'raptor',name:'Velociraptor',kind:'dinosaur',biomes:['dense_forest','valley','green_plains','tropical_jungle','savannah','ancient_forest','bamboo_forest'],color:0x55704a,scale:1.0,speed:6.0,temperament:'territorial'},
  {id:'triceratops',name:'Triceratops',kind:'dinosaur',biomes:['green_plains','valley','savannah','alpine_meadow'],color:0x69734b,scale:1.65,speed:2.5,temperament:'neutral'},
  {id:'stegosaurus',name:'Stegosaurus',kind:'dinosaur',biomes:['dense_forest','green_plains','tropical_jungle','ancient_forest'],color:0x6c7650,scale:1.5,speed:2.2,temperament:'neutral'},
  {id:'longneck',name:'Brachiosaurus',kind:'dinosaur',biomes:['green_plains','valley','savannah','alpine_meadow'],color:0x8c9871,scale:2.2,speed:1.8,temperament:'neutral'},
  {id:'glow_moth',name:'Luminous Moth',kind:'rare',biomes:['cave_system','wetlands','dense_forest','crystal_cavern','mangrove_delta'],color:0x76e6d1,scale:0.3,speed:3.2,temperament:'shy'},
  {id:'turtle',name:'Freshwater Turtle',kind:'aquatic',biomes:['river_basin','lake_district','wetlands','mangrove_delta','coral_coast'],color:0x456b4b,scale:0.5,speed:1.2,temperament:'shy'},
  {id:'tiger',name:'Bengal Tiger',kind:'mammal',biomes:['tropical_jungle','dense_forest','bamboo_forest'],color:0xc66a22,scale:1.25,speed:5.5,temperament:'territorial'},
  {id:'lion',name:'African Lion',kind:'mammal',biomes:['savannah','green_plains'],color:0xb58a4c,scale:1.3,speed:4.8,temperament:'territorial'},
  {id:'giraffe',name:'Giraffe',kind:'mammal',biomes:['savannah'],color:0xb98b48,scale:1.65,speed:3.2,temperament:'neutral'},
  {id:'zebra',name:'Plains Zebra',kind:'mammal',biomes:['savannah'],color:0xd8d3c8,scale:1.0,speed:4.4,temperament:'shy'},
  {id:'horse',name:'Wild Horse',kind:'mammal',biomes:['green_plains','savannah','alpine_meadow'],color:0x79533b,scale:1.05,speed:6.0,temperament:'shy'},
  {id:'monkey',name:'Macaque',kind:'mammal',biomes:['tropical_jungle','bamboo_forest','ancient_forest'],color:0x8b654a,scale:0.55,speed:4.5,temperament:'shy'},
  {id:'buffalo',name:'Wild Water Buffalo',kind:'mammal',biomes:['savannah','wetlands','mangrove_delta'],color:0x403b35,scale:1.35,speed:2.9,temperament:'territorial'},
  {id:'flamingo',name:'Greater Flamingo',kind:'bird',biomes:['wetlands','mangrove_delta','coral_coast'],color:0xe58b9e,scale:0.72,speed:5.5,temperament:'shy'},
  {id:'crow',name:'Carrion Crow',kind:'bird',biomes:['abandoned_city','green_plains','dense_forest'],color:0x20232a,scale:0.38,speed:7.0,temperament:'shy'},
  {id:'crocodile',name:'Saltwater Crocodile',kind:'reptile',biomes:['wetlands','mangrove_delta','coral_coast'],color:0x52614b,scale:1.2,speed:2.0,temperament:'territorial'},
  {id:'frog',name:'Tree Frog',kind:'amphibian',biomes:['wetlands','tropical_jungle','mangrove_delta'],color:0x54a85a,scale:0.22,speed:1.5,temperament:'shy'},
  {id:'butterfly',name:'Monarch Butterfly',kind:'insect',biomes:['green_plains','tropical_jungle','ancient_forest'],color:0xe68a28,scale:0.18,speed:2.8,temperament:'shy'},
  {id:'firefly',name:'Firefly',kind:'insect',biomes:['wetlands','dense_forest','ancient_forest'],color:0xd7e77a,scale:0.12,speed:1.8,temperament:'shy'},
  {id:'dolphin',name:'Bottlenose Dolphin',kind:'aquatic',biomes:['coral_coast','coastline','island'],color:0x658a9b,scale:0.95,speed:5.0,temperament:'neutral'},
  {id:'shark',name:'Reef Shark',kind:'aquatic',biomes:['coral_coast','coastline','island'],color:0x596b78,scale:1.1,speed:4.5,temperament:'neutral'},
  {id:'whale',name:'Humpback Whale',kind:'aquatic',biomes:['coral_coast','coastline','island'],color:0x455969,scale:2.4,speed:2.8,temperament:'neutral'},
  {id:'reef_fish',name:'Reef Fish School',kind:'aquatic',biomes:['coral_coast','coastline','island','lake_district'],color:0x35a9b4,scale:0.28,speed:3.2,temperament:'shy'},
];

export class WildlifeManager {
  private scene: THREE.Scene;
  private agents = new Map<string, WildlifeAgent>();
  private seed: number;
  private spawnClock = 0;
  private maxAgents = 28;
  constructor(scene: THREE.Scene, seed: number) { this.scene = scene; this.seed = seed; }

  update(delta: number, player: THREE.Vector3, biomeAt: (x:number,z:number)=>string, isNight: boolean) {
    this.spawnClock += delta;
    if (this.spawnClock > 4 && this.agents.size < this.maxAgents) { this.spawnClock = 0; this.spawnAround(player, biomeAt, isNight); }
    for (const [id,a] of this.agents) {
      const dx = a.group.position.x-player.x, dz = a.group.position.z-player.z;
      const distance = Math.hypot(dx,dz);
      if (distance > 150) { this.scene.remove(a.group); this.disposeGroup(a.group); this.agents.delete(id); continue; }
      a.stateTimer -= delta;
      if (distance < 13 && a.species.temperament === 'shy' && a.state !== 'flee') {
        a.state = 'flee'; a.stateTimer = 3.5;
        a.target.set(a.group.position.x + dx/(distance||1)*24, a.group.position.y, a.group.position.z + dz/(distance||1)*24);
      } else if (a.stateTimer <= 0) {
        a.state = Math.random() < 0.18 ? 'rest' : 'roam'; a.stateTimer = 3 + Math.random()*7;
        const angle = Math.random()*Math.PI*2, radius = 8+Math.random()*18;
        a.target.set(a.group.position.x+Math.cos(angle)*radius, a.group.position.y, a.group.position.z+Math.sin(angle)*radius);
      }
      if (a.state !== 'rest') {
        const direction = new THREE.Vector3(a.target.x-a.group.position.x,0,a.target.z-a.group.position.z);
        if (direction.lengthSq()>0.2) {
          direction.normalize(); a.group.position.addScaledVector(direction, a.species.speed*delta*(a.state==='flee'?1.7:1));
          a.group.rotation.y = Math.atan2(direction.x,direction.z);
        }
      }
      if (a.species.kind === 'bird' || a.species.kind === 'insect') a.group.position.y += Math.sin(performance.now()*0.002 + a.group.position.x)*0.003;
      else a.group.position.y = getTerrainHeight(a.group.position.x,a.group.position.z,this.seed) + (['aquatic','reptile','amphibian'].includes(a.species.kind) ? -0.25 : 0);
      // Low-frequency idle motion; night-active species receive a mild activity bias.
      a.group.rotation.z = a.species.kind==='bird' ? Math.sin(performance.now()*0.01)*0.035 : 0;
    }
  }

  private spawnAround(player: THREE.Vector3, biomeAt: (x:number,z:number)=>string, isNight:boolean) {
    const angle = Math.random()*Math.PI*2, radius = 28+Math.random()*65;
    const x=player.x+Math.cos(angle)*radius, z=player.z+Math.sin(angle)*radius;
    const biome=biomeAt(x,z);
    let pool=WILDLIFE_SPECIES.filter(s=>s.biomes.includes(biome));
    if (isNight) pool=pool.filter(s=>!['parrot','duck'].includes(s.id));
    if (!pool.length) pool=WILDLIFE_SPECIES.filter(s=>s.kind==='mammal');
    const species=pool[Math.floor(Math.random()*pool.length)];
    const id=`wild_${species.id}_${Math.floor(x)}_${Math.floor(z)}`;
    if(this.agents.has(id)) return;
    const group=this.createCreature(species); group.position.set(x,getTerrainHeight(x,z,this.seed)+(['bird','insect'].includes(species.kind)?5:0),z); this.scene.add(group);
    this.agents.set(id,{id,species,group,velocity:new THREE.Vector3(),target:new THREE.Vector3(x,group.position.y,z),state:'roam',stateTimer:2+Math.random()*5});
  }

  private createCreature(s: WildlifeSpecies) {
    const g=new THREE.Group(); g.name=`wildlife_${s.id}`; g.scale.setScalar(s.scale);
    const mat=new THREE.MeshStandardMaterial({color:s.color,roughness:0.92});
    const dark=new THREE.MeshStandardMaterial({color:0x292522,roughness:0.8});
    const body=new THREE.Mesh(new THREE.SphereGeometry(0.55,12,9),mat); body.scale.set(0.85,0.62,1.25); body.position.y=0.85; body.castShadow=true; g.add(body);
    const head=new THREE.Mesh(new THREE.SphereGeometry(0.29,10,8),mat); head.position.set(0,1.12,0.72); head.castShadow=true; g.add(head);
    const legs:number[]=[-0.32,0.32]; legs.forEach(x=>[-0.35,0.35].forEach(z=>{const leg=new THREE.Mesh(new THREE.CylinderGeometry(0.075,0.09,0.58,7),dark);leg.position.set(x,0.35,z);leg.castShadow=true;g.add(leg);}));
    if(s.kind==='dinosaur') { const tail=new THREE.Mesh(new THREE.ConeGeometry(0.22,1.05,7),mat);tail.rotation.x=-Math.PI/2;tail.position.set(0,0.88,-0.95);g.add(tail); const crest=new THREE.Mesh(new THREE.ConeGeometry(0.18,0.48,6),dark);crest.position.set(0,1.5,0.7);g.add(crest); }
    if(s.kind==='bird') { const wingGeo=new THREE.BoxGeometry(0.9,0.08,0.42);[-0.5,0.5].forEach(x=>{const wing=new THREE.Mesh(wingGeo,mat);wing.position.set(x,1.05,0);wing.rotation.z=x<0?-0.25:0.25;g.add(wing);}); }
    return g;
  }
  private disposeGroup(g:THREE.Group){g.traverse(o=>{if(o instanceof THREE.Mesh){o.geometry.dispose(); if(Array.isArray(o.material))o.material.forEach(m=>m.dispose());else o.material.dispose();}});}
  get count(){return this.agents.size;}
  dispose(){for(const a of this.agents.values()){this.scene.remove(a.group);this.disposeGroup(a.group);}this.agents.clear();}
}
