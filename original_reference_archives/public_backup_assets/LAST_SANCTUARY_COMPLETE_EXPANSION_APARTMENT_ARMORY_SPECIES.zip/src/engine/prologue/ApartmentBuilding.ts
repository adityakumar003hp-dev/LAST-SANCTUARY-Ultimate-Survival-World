import * as THREE from 'three';
import { UnifiedPhysicsManager } from '../physics/UnifiedPhysicsManager';
import { soundEngine } from '../../utils/audio';

export interface ApartmentState {
  tvOn: boolean;
  tvChannel: number;
  fanOn: boolean;
  fanSpeed: number;
  acOn: boolean;
  lightsOn: boolean;
  doorOpen: boolean;
  fridgeOpen: boolean;
  fridgeItems: string[];
}

export class ApartmentBuilding {
  public group: THREE.Group;
  public state: ApartmentState;

  // Floor groups for camera-aware cutaways
  public floor1Group: THREE.Group;
  public floor2Group: THREE.Group;
  public floor3Group: THREE.Group;
  public floor4Group: THREE.Group;
  public exteriorWalls: THREE.Group;
  public staircaseGroup: THREE.Group;

  // Dynamic meshes
  private tvMesh!: THREE.Mesh;
  private tvScreenMat: THREE.MeshBasicMaterial;
  private tvCanvas: HTMLCanvasElement;
  private tvContext: CanvasRenderingContext2D | null;
  private tvTexture: THREE.CanvasTexture;
  private fanBlades!: THREE.Group;
  private acMesh!: THREE.Mesh;
  private acLedMat!: THREE.MeshBasicMaterial;
  private fridgeDoor!: THREE.Group;
  private frontDoorMesh!: THREE.Group;
  public poolWaterMesh!: THREE.Mesh;
  private floorLights: THREE.PointLight[] = [];

  // Reusable PBR materials
  private whiteWallMat: THREE.MeshStandardMaterial;
  private greyWallMat: THREE.MeshStandardMaterial;
  private armoryWallMat: THREE.MeshStandardMaterial;
  private brickFacadeMat: THREE.MeshStandardMaterial;
  private floorTileMat: THREE.MeshStandardMaterial;
  private woodFloorMat: THREE.MeshStandardMaterial;
  private glassMat: THREE.MeshStandardMaterial;
  private metalTrimMat: THREE.MeshStandardMaterial;
  private waterMat: THREE.MeshStandardMaterial;

  // Exterior wall sub-groups for directional camera cutaways
  private southWallMesh!: THREE.Group;
  private northWallMesh!: THREE.Group;
  private eastWallMesh!: THREE.Group;
  private westWallMesh!: THREE.Group;

  // Base building location
  public readonly origin = new THREE.Vector3(-26, 0, 38);

  // Pool water volume bounding box in world coordinates
  public readonly poolWaterBounds = {
    minX: -26 - 4.5,
    maxX: -26 + 1.5,
    minY: 8.0,
    maxY: 9.8,
    minZ: 38 - 3.2,
    maxZ: 38 + 3.2,
  };

  constructor(parent: THREE.Scene | THREE.Group) {
    this.group = new THREE.Group();
    this.group.name = 'four_floor_apartment_complex';
    this.group.position.copy(this.origin);
    parent.add(this.group);

    this.state = {
      tvOn: false,
      tvChannel: 1,
      fanOn: true,
      fanSpeed: 4.5,
      acOn: true,
      lightsOn: true,
      doorOpen: false,
      fridgeOpen: false,
      fridgeItems: ['clean_water', 'canned_beans', 'fresh_oj', 'breakfast_sandwich', 'bandage'],
    };

    // Shared high-grade PBR materials
    this.whiteWallMat = new THREE.MeshStandardMaterial({
      color: 0xf5f5f5,
      roughness: 0.88,
      side: THREE.DoubleSide,
    });
    this.greyWallMat = new THREE.MeshStandardMaterial({
      color: 0x787c82, // Visually distinct grey for Floor 2
      roughness: 0.85,
      side: THREE.DoubleSide,
    });
    this.armoryWallMat = new THREE.MeshStandardMaterial({
      color: 0x22262d,
      roughness: 0.45,
      metalness: 0.65,
      side: THREE.DoubleSide,
    });
    this.brickFacadeMat = new THREE.MeshStandardMaterial({
      color: 0x8a4234,
      roughness: 0.9,
    });
    this.floorTileMat = new THREE.MeshStandardMaterial({
      color: 0xd2ceca,
      roughness: 0.6,
    });
    this.woodFloorMat = new THREE.MeshStandardMaterial({
      color: 0x583d26,
      roughness: 0.7,
    });
    this.glassMat = new THREE.MeshStandardMaterial({
      color: 0x8ec3d8,
      roughness: 0.1,
      metalness: 0.85,
      transparent: true,
      opacity: 0.45,
    });
    this.metalTrimMat = new THREE.MeshStandardMaterial({
      color: 0x25282d,
      metalness: 0.8,
      roughness: 0.35,
    });
    this.waterMat = new THREE.MeshStandardMaterial({
      color: 0x0099bb,
      roughness: 0.05,
      metalness: 0.25,
      transparent: true,
      opacity: 0.75,
    });

    // Procedural TV screen canvas
    this.tvCanvas = document.createElement('canvas');
    this.tvCanvas.width = 512;
    this.tvCanvas.height = 288;
    this.tvContext = this.tvCanvas.getContext('2d');
    this.updateTVScreenContent(false);
    this.tvTexture = new THREE.CanvasTexture(this.tvCanvas);
    this.tvTexture.colorSpace = THREE.SRGBColorSpace;
    this.tvScreenMat = new THREE.MeshBasicMaterial({ map: this.tvTexture });

    this.floor1Group = new THREE.Group();
    this.floor1Group.name = 'floor_1_white_living';
    this.floor2Group = new THREE.Group();
    this.floor2Group.name = 'floor_2_grey_residence';
    this.floor3Group = new THREE.Group();
    this.floor3Group.name = 'floor_3_armory_vault';
    this.floor4Group = new THREE.Group();
    this.floor4Group.name = 'floor_4_rooftop_pool';
    this.exteriorWalls = new THREE.Group();
    this.exteriorWalls.name = 'exterior_cutaway_facade';
    this.staircaseGroup = new THREE.Group();
    this.staircaseGroup.name = 'continuous_staircase';

    this.group.add(
      this.floor1Group,
      this.floor2Group,
      this.floor3Group,
      this.floor4Group,
      this.exteriorWalls,
      this.staircaseGroup
    );

    // Build building architecture
    this.buildFloor1();
    this.buildFloor2();
    this.buildFloor3();
    this.buildFloor4Pool();
    this.buildContinuousStaircase();
    this.buildExteriorFacade();
  }

  // ==========================================
  // FLOOR SLAB WITH STAIR OPENING HELPER
  // ==========================================
  private createSlabWithStairwell(mat: THREE.Material, thickness: number, yPos: number): THREE.Group {
    const g = new THREE.Group();
    // West section: covers X = -8.0 to +4.5 (width 12.5, depth 14, center X = -1.75)
    const westSlab = new THREE.Mesh(new THREE.BoxGeometry(12.5, thickness, 14), mat);
    westSlab.position.set(-1.75, yPos, 0);
    westSlab.receiveShadow = true;

    // East North section: covers X = 4.5 to 8.0, Z = 2.0 to 7.0 (width 3.5, depth 5, center X = 6.25, Z = 4.5)
    const eastNorth = new THREE.Mesh(new THREE.BoxGeometry(3.5, thickness, 5.0), mat);
    eastNorth.position.set(6.25, yPos, 4.5);
    eastNorth.receiveShadow = true;

    // East South section: covers X = 4.5 to 8.0, Z = -7.0 to -4.5 (width 3.5, depth 2.5, center X = 6.25, Z = -5.75)
    const eastSouth = new THREE.Mesh(new THREE.BoxGeometry(3.5, thickness, 2.5), mat);
    eastSouth.position.set(6.25, yPos, -5.75);
    eastSouth.receiveShadow = true;

    g.add(westSlab, eastNorth, eastSouth);
    return g;
  }

  // ==========================================
  // FLOOR 1: WHITE WALL MAIN LIVING AREA
  // ==========================================
  private buildFloor1() {
    const f1 = this.floor1Group;

    // Ground Floor Solid Base
    const floorSlab = new THREE.Mesh(new THREE.BoxGeometry(16, 0.25, 14), this.woodFloorMat);
    floorSlab.position.set(0, 0.12, 0);
    floorSlab.receiveShadow = true;
    f1.add(floorSlab);

    // Ceiling with stairwell cutout so player head is never blocked
    const ceiling = this.createSlabWithStairwell(this.whiteWallMat, 0.2, 3.1);
    f1.add(ceiling);

    // Interior White Dividing Walls (Dividing Bedroom, Kitchen, Living Room)
    const bedDivider = new THREE.Mesh(new THREE.BoxGeometry(0.25, 2.9, 7.5), this.whiteWallMat);
    bedDivider.position.set(-2.5, 1.6, 2.8);
    const kitchenDivider = new THREE.Mesh(new THREE.BoxGeometry(0.25, 2.9, 5.0), this.whiteWallMat);
    kitchenDivider.position.set(2.5, 1.6, 4.0);
    f1.add(bedDivider, kitchenDivider);

    // Warm Interior Ceiling Lamps
    const lamp1 = new THREE.PointLight(0xffecd0, 1.8, 14, 1.3);
    lamp1.position.set(-4.5, 2.7, 2.5);
    const lamp2 = new THREE.PointLight(0xffeed0, 2.0, 15, 1.3);
    lamp2.position.set(0, 2.7, 0);
    this.floorLights.push(lamp1, lamp2);
    f1.add(lamp1, lamp2);

    // --- 1. BEDROOM ---
    const bedFrame = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.5, 2.8), this.metalTrimMat);
    bedFrame.position.set(-5.5, 0.35, 3.8);
    const headboard = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.4, 0.2), this.woodFloorMat);
    headboard.position.set(-5.5, 0.9, 5.15);
    const mattress = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.35, 2.5), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9 }));
    mattress.position.set(-5.5, 0.65, 3.8);
    const blanket = new THREE.Mesh(new THREE.BoxGeometry(2.22, 0.38, 1.7), new THREE.MeshStandardMaterial({ color: 0x1f3c5e, roughness: 0.85 }));
    blanket.position.set(-5.5, 0.66, 3.3);
    const pillow1 = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.16, 0.55), new THREE.MeshStandardMaterial({ color: 0xf0f0f0, roughness: 0.9 }));
    pillow1.position.set(-6.1, 0.85, 4.6);
    const pillow2 = pillow1.clone();
    pillow2.position.x = -4.9;

    const nightstand = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.65, 0.7), this.woodFloorMat);
    nightstand.position.set(-7.2, 0.45, 4.8);
    const nightLamp = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.2, 0.4, 8), new THREE.MeshBasicMaterial({ color: 0xfff0dd }));
    nightLamp.position.set(-7.2, 0.95, 4.8);

    f1.add(bedFrame, headboard, mattress, blanket, pillow1, pillow2, nightstand, nightLamp);

    // --- 2. WORKING TELEVISION WITH BROADCAST SCREEN ---
    const tvStand = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.65, 0.6), this.metalTrimMat);
    tvStand.position.set(-5.5, 0.45, 0.0);
    const tvFrame = new THREE.Mesh(new THREE.BoxGeometry(2.0, 1.25, 0.1), new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.85 }));
    tvFrame.position.set(-5.5, 1.55, 0.0);

    this.tvMesh = new THREE.Mesh(new THREE.PlaneGeometry(1.9, 1.15), this.tvScreenMat);
    this.tvMesh.rotation.y = Math.PI;
    this.tvMesh.position.set(-5.5, 1.55, -0.06);
    f1.add(tvStand, tvFrame, this.tvMesh);

    // --- 3. REFRIGERATOR WITH INTERACTION ---
    const fridgeBody = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 2.2, 1.0),
      new THREE.MeshStandardMaterial({ color: 0xd8d8d8, metalness: 0.6, roughness: 0.25 })
    );
    fridgeBody.position.set(4.5, 1.22, 5.8);

    this.fridgeDoor = new THREE.Group();
    this.fridgeDoor.position.set(4.5, 1.22, 5.3);
    const doorPanel = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 2.18, 0.1),
      new THREE.MeshStandardMaterial({ color: 0xe2e2e2, metalness: 0.65, roughness: 0.25 })
    );
    const doorHandle = new THREE.Mesh(
      new THREE.BoxGeometry(0.08, 0.6, 0.08),
      new THREE.MeshStandardMaterial({ color: 0x444444, metalness: 0.9 })
    );
    doorHandle.position.set(0.48, 0, -0.08);
    this.fridgeDoor.add(doorPanel, doorHandle);
    f1.add(fridgeBody, this.fridgeDoor);

    // --- 4. KITCHENETTE COUNTER & SINK ---
    const kitchenCounter = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.9, 1.0), this.metalTrimMat);
    kitchenCounter.position.set(5.8, 0.57, 3.2);
    const sink = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.35, 0.7), new THREE.MeshStandardMaterial({ color: 0x999999, metalness: 0.85 }));
    sink.position.set(5.8, 0.85, 3.2);
    const faucet = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.35, 6), new THREE.MeshStandardMaterial({ color: 0xcccccc, metalness: 0.9 }));
    faucet.position.set(5.8, 1.15, 3.5);
    f1.add(kitchenCounter, sink, faucet);

    // --- 5. LIVING ROOM SOFA, COFFEE TABLE & SMARTPHONE ---
    const sofa = new THREE.Mesh(
      new THREE.BoxGeometry(2.8, 0.85, 1.2),
      new THREE.MeshStandardMaterial({ color: 0x2e4033, roughness: 0.85 })
    );
    sofa.position.set(0, 0.55, 0.5);

    const coffeeTable = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.45, 0.9), this.woodFloorMat);
    coffeeTable.position.set(0, 0.35, -1.2);

    // Smartphone prop on coffee table
    const phoneMesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.18, 0.02, 0.34),
      new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.8, roughness: 0.2 })
    );
    phoneMesh.position.set(0.3, 0.59, -1.2);
    const phoneScreen = new THREE.Mesh(
      new THREE.PlaneGeometry(0.16, 0.3),
      new THREE.MeshBasicMaterial({ color: 0x00d2d3 })
    );
    phoneScreen.rotation.x = -Math.PI / 2;
    phoneScreen.position.set(0.3, 0.605, -1.2);
    f1.add(sofa, coffeeTable, phoneMesh, phoneScreen);

    // --- 6. WORKING CEILING FAN ---
    const fanHub = new THREE.Group();
    fanHub.position.set(0, 2.95, 0.5);
    const fanStem = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.3, 6), this.metalTrimMat);
    fanStem.position.y = -0.15;
    const fanMotor = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.15, 10), this.metalTrimMat);
    fanMotor.position.y = -0.3;

    this.fanBlades = new THREE.Group();
    this.fanBlades.position.y = -0.32;
    for (let i = 0; i < 4; i++) {
      const blade = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.02, 0.16), this.woodFloorMat);
      blade.rotation.y = (i * Math.PI) / 2;
      blade.position.set(Math.cos(blade.rotation.y) * 0.55, 0, Math.sin(blade.rotation.y) * 0.55);
      this.fanBlades.add(blade);
    }
    fanHub.add(fanStem, fanMotor, this.fanBlades);
    f1.add(fanHub);

    // --- 7. WALL-MOUNTED AIR CONDITIONER ---
    this.acMesh = new THREE.Mesh(
      new THREE.BoxGeometry(1.8, 0.5, 0.4),
      new THREE.MeshStandardMaterial({ color: 0xfafafa, roughness: 0.4 })
    );
    this.acMesh.position.set(-2.5, 2.5, -6.6);

    this.acLedMat = new THREE.MeshBasicMaterial({ color: 0x00ff88 });
    const acLed = new THREE.Mesh(new THREE.SphereGeometry(0.03, 6, 6), this.acLedMat);
    acLed.position.set(-1.8, 2.4, -6.38);
    f1.add(this.acMesh, acLed);

    // --- 8. FRONT ENTRANCE DOORWAY ---
    this.frontDoorMesh = new THREE.Group();
    this.frontDoorMesh.position.set(0, 1.25, -6.9);
    const door = new THREE.Mesh(new THREE.BoxGeometry(1.4, 2.3, 0.12), this.woodFloorMat);
    const handle = new THREE.Mesh(new THREE.SphereGeometry(0.06, 6, 6), new THREE.MeshStandardMaterial({ color: 0xdaa520, metalness: 0.9 }));
    handle.position.set(0.5, 0, 0.08);
    this.frontDoorMesh.add(door, handle);
    f1.add(this.frontDoorMesh);
  }

  // ==========================================
  // FLOOR 2: GREY WALL RESIDENTIAL FLOOR
  // ==========================================
  private buildFloor2() {
    const f2 = this.floor2Group;
    const yOff = 3.2;

    // Floor Slab with stairwell opening
    const floorSlab = this.createSlabWithStairwell(this.floorTileMat, 0.25, yOff + 0.12);
    f2.add(floorSlab);

    // Ceiling with stairwell cutout
    const ceiling = this.createSlabWithStairwell(this.greyWallMat, 0.2, yOff + 3.1);
    f2.add(ceiling);

    // Grey Interior Walls (Visually distinct from Floor 1 white walls)
    const divider1 = new THREE.Mesh(new THREE.BoxGeometry(0.25, 2.9, 8.0), this.greyWallMat);
    divider1.position.set(-2.0, yOff + 1.6, 1.5);
    const divider2 = new THREE.Mesh(new THREE.BoxGeometry(6.0, 2.9, 0.25), this.greyWallMat);
    divider2.position.set(-5.0, yOff + 1.6, 1.5);
    f2.add(divider1, divider2);

    // Study Desk & Bookshelf
    const desk = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.85, 1.0), this.woodFloorMat);
    desk.position.set(-5.5, yOff + 0.55, 4.5);
    const deskLamp = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.18, 0.35, 6), new THREE.MeshBasicMaterial({ color: 0xffeedd }));
    deskLamp.position.set(-5.8, yOff + 1.1, 4.5);

    const bookshelf = new THREE.Mesh(new THREE.BoxGeometry(2.6, 2.2, 0.6), this.woodFloorMat);
    bookshelf.position.set(-6.5, yOff + 1.25, 1.8);

    // Lounge sofa
    const loungeSofa = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.8, 1.1), new THREE.MeshStandardMaterial({ color: 0x4a4f56, roughness: 0.85 }));
    loungeSofa.position.set(1.5, yOff + 0.55, 3.5);

    f2.add(desk, deskLamp, bookshelf, loungeSofa);

    // Ceiling light for Floor 2
    const lamp = new THREE.PointLight(0xffeed0, 1.7, 15, 1.3);
    lamp.position.set(0, yOff + 2.7, 1.0);
    this.floorLights.push(lamp);
    f2.add(lamp);

    // Floor 2 Plaque
    const plaque = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.6), new THREE.MeshBasicMaterial({ color: 0x333333 }));
    plaque.position.set(4.4, yOff + 1.8, -3.8);
    plaque.rotation.y = -Math.PI / 2;
    f2.add(plaque);
  }

  // ==========================================
  // FLOOR 3: FICTIONAL 100-ITEM GAME ARMORY
  // ==========================================
  private buildFloor3() {
    const f3 = this.floor3Group;
    const yOff = 6.4;

    // Floor Slab with stairwell cutout
    const floorSlab = this.createSlabWithStairwell(this.metalTrimMat, 0.25, yOff + 0.12);
    f3.add(floorSlab);

    // Ceiling with stairwell cutout
    const ceiling = this.createSlabWithStairwell(this.metalTrimMat, 0.2, yOff + 3.1);
    f3.add(ceiling);

    // High-tech Secure Armory Room Walls (Dark graphite with cyan indicator strips)
    const divider = new THREE.Mesh(new THREE.BoxGeometry(0.25, 2.9, 10.0), this.armoryWallMat);
    divider.position.set(-1.5, yOff + 1.6, 0);
    f3.add(divider);

    // Cyan Neon Accent Lines
    const stripMat = new THREE.MeshBasicMaterial({ color: 0x00d2d3 });
    const strip1 = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.1, 9.8), stripMat);
    strip1.position.set(-1.35, yOff + 2.2, 0);
    f3.add(strip1);

    // Weapon Storage Lockers along West Wall
    for (let z = -4.5; z <= 4.5; z += 2.2) {
      const locker = new THREE.Mesh(
        new THREE.BoxGeometry(1.2, 2.4, 1.8),
        new THREE.MeshStandardMaterial({ color: 0x2e3440, metalness: 0.85, roughness: 0.35 })
      );
      locker.position.set(-6.5, yOff + 1.35, z);
      f3.add(locker);

      // Weapon rack display inside
      const rackGun = new THREE.Mesh(
        new THREE.BoxGeometry(0.12, 0.35, 1.2),
        new THREE.MeshStandardMaterial({ color: 0x5e81ac, metalness: 0.8 })
      );
      rackGun.position.set(-5.8, yOff + 1.4, z);
      f3.add(rackGun);
    }

    // Ammunition Crates & Heavy Ordnance Shelves along North Wall
    for (let x = -4.5; x <= 2.5; x += 2.4) {
      const crate = new THREE.Mesh(
        new THREE.BoxGeometry(1.6, 0.9, 1.1),
        new THREE.MeshStandardMaterial({ color: 0x434c5e, metalness: 0.6, roughness: 0.5 })
      );
      crate.position.set(x, yOff + 0.6, 5.8);
      f3.add(crate);
    }

    // Interactive Armory Console / Master Terminal (Center East)
    const consolePedestal = new THREE.Mesh(
      new THREE.CylinderGeometry(0.4, 0.6, 1.1, 8),
      this.metalTrimMat
    );
    consolePedestal.position.set(2.0, yOff + 0.65, 0.0);

    const consoleScreen = new THREE.Mesh(
      new THREE.BoxGeometry(1.4, 0.8, 0.1),
      new THREE.MeshBasicMaterial({ color: 0x00e5ff })
    );
    consoleScreen.rotation.x = -Math.PI / 4;
    consoleScreen.position.set(2.0, yOff + 1.45, 0.0);
    f3.add(consolePedestal, consoleScreen);

    // High-tech Armory Spotlights
    const armoryLight1 = new THREE.PointLight(0x00e5ff, 2.2, 14, 1.4);
    armoryLight1.position.set(-4.0, yOff + 2.7, 0);
    const armoryLight2 = new THREE.PointLight(0xffffff, 1.8, 14, 1.3);
    armoryLight2.position.set(2.0, yOff + 2.7, 0);
    this.floorLights.push(armoryLight1, armoryLight2);
    f3.add(armoryLight1, armoryLight2);

    // Floor 3 Signboard
    const plaque = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 0.7), new THREE.MeshBasicMaterial({ color: 0x111111 }));
    plaque.position.set(4.4, yOff + 1.8, -3.8);
    plaque.rotation.y = -Math.PI / 2;
    f3.add(plaque);
  }

  // ==========================================
  // FLOOR 4: ROOFTOP SWIMMING POOL & DECK
  // ==========================================
  private buildFloor4Pool() {
    const f4 = this.floor4Group;
    const yOff = 9.6;

    // Rooftop Patio Deck Slab with stair opening
    const deck = this.createSlabWithStairwell(this.floorTileMat, 0.3, yOff + 0.15);
    f4.add(deck);

    // Swimming Pool Basin (West side: X: -6.5 to +1.5, Z: -3.2 to +3.2)
    const basinMat = new THREE.MeshStandardMaterial({
      color: 0x8fd3e8,
      roughness: 0.2,
      metalness: 0.1,
    });

    const basinFloor = new THREE.Mesh(new THREE.BoxGeometry(8.0, 0.2, 6.4), basinMat);
    basinFloor.position.set(-2.5, yOff - 1.4, 0);
    f4.add(basinFloor);

    // Pool Coping border (stone rim)
    const copingMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.5 });
    const rimNorth = new THREE.Mesh(new THREE.BoxGeometry(8.8, 0.3, 0.5), copingMat);
    rimNorth.position.set(-2.5, yOff + 0.35, 3.45);
    const rimSouth = new THREE.Mesh(new THREE.BoxGeometry(8.8, 0.3, 0.5), copingMat);
    rimSouth.position.set(-2.5, yOff + 0.35, -3.45);
    const rimWest = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.3, 7.4), copingMat);
    rimWest.position.set(-6.65, yOff + 0.35, 0);
    const rimEast = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.3, 7.4), copingMat);
    rimEast.position.set(1.65, yOff + 0.35, 0);
    f4.add(rimNorth, rimSouth, rimWest, rimEast);

    // Pool Water Surface
    this.poolWaterMesh = new THREE.Mesh(new THREE.PlaneGeometry(7.9, 6.3), this.waterMat);
    this.poolWaterMesh.rotation.x = -Math.PI / 2;
    this.poolWaterMesh.position.set(-2.5, yOff - 0.15, 0);
    f4.add(this.poolWaterMesh);

    // Pool Underwater Glow Lamps
    const poolLight1 = new THREE.PointLight(0x00d2ff, 2.5, 12, 1.5);
    poolLight1.position.set(-4.5, yOff - 0.7, 0);
    const poolLight2 = new THREE.PointLight(0x00d2ff, 2.5, 12, 1.5);
    poolLight2.position.set(0.0, yOff - 0.7, 0);
    this.floorLights.push(poolLight1, poolLight2);
    f4.add(poolLight1, poolLight2);

    // Stainless Steel Pool Ladder
    const ladderMat = new THREE.MeshStandardMaterial({ color: 0xeeeeee, metalness: 0.9, roughness: 0.2 });
    for (const lx of [-1.8, -1.2]) {
      const rail = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.8, 8), ladderMat);
      rail.position.set(lx - 1.0, yOff - 0.3, -3.3);
      f4.add(rail);
    }
    for (let r = 0; r < 3; r++) {
      const rung = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.6, 6), ladderMat);
      rung.rotation.z = Math.PI / 2;
      rung.position.set(-2.5, yOff - 0.4 - r * 0.4, -3.3);
      f4.add(rung);
    }

    // Perimeter Glass & Steel Safety Railing around Rooftop
    const railingGeoH = new THREE.BoxGeometry(16.0, 0.08, 0.08);
    const railTopN = new THREE.Mesh(railingGeoH, this.metalTrimMat);
    railTopN.position.set(0, yOff + 1.2, 6.9);
    const railTopS = new THREE.Mesh(railingGeoH, this.metalTrimMat);
    railTopS.position.set(0, yOff + 1.2, -6.9);
    f4.add(railTopN, railTopS);

    // Glass infill panels
    const glassPanelN = new THREE.Mesh(new THREE.PlaneGeometry(15.8, 1.0), this.glassMat);
    glassPanelN.position.set(0, yOff + 0.65, 6.9);
    const glassPanelS = new THREE.Mesh(new THREE.PlaneGeometry(15.8, 1.0), this.glassMat);
    glassPanelS.position.set(0, yOff + 0.65, -6.9);
    f4.add(glassPanelN, glassPanelS);

    // Poolside Sun Loungers on the East Deck
    for (let i = 0; i < 2; i++) {
      const lounger = new THREE.Mesh(
        new THREE.BoxGeometry(0.9, 0.4, 2.2),
        new THREE.MeshStandardMaterial({ color: 0xeeeeee, roughness: 0.8 })
      );
      lounger.position.set(5.5, yOff + 0.35, -2.0 + i * 3.5);
      f4.add(lounger);
    }
  }

  // ==========================================
  // CONTINUOUS 4-FLOOR STAIRCASE
  // ==========================================
  private buildContinuousStaircase() {
    const sc = this.staircaseGroup;
    // Stairwell located at X: 5.5 to 7.0, Z: -3.5 to 1.7 across all floors
    const stairMat = new THREE.MeshStandardMaterial({ color: 0x3d4147, metalness: 0.5, roughness: 0.6 });
    const handrailMat = new THREE.MeshStandardMaterial({ color: 0xd4af37, metalness: 0.9, roughness: 0.3 });

    // 3 continuous flights connecting 4 floors (F1 -> F2, F2 -> F3, F3 -> F4)
    for (let floorIdx = 0; floorIdx < 3; floorIdx++) {
      const baseH = floorIdx * 3.2;
      const numSteps = 16;
      const stepH = 3.2 / numSteps;
      const stepD = 4.2 / numSteps;

      const flightGroup = new THREE.Group();
      flightGroup.name = `stair_flight_${floorIdx + 1}_to_${floorIdx + 2}`;

      for (let s = 0; s < numSteps; s++) {
        const step = new THREE.Mesh(
          new THREE.BoxGeometry(1.6, stepH, stepD + 0.05),
          stairMat
        );
        step.position.set(6.2, baseH + (s + 0.5) * stepH, -3.5 + s * stepD);
        step.castShadow = true;
        flightGroup.add(step);
      }

      // Handrail angled along the flight
      const railLen = Math.hypot(3.2, 4.2);
      const railAngle = Math.atan2(3.2, 4.2);
      const rail = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, railLen, 8), handrailMat);
      rail.rotation.x = Math.PI / 2 - railAngle;
      rail.position.set(5.3, baseH + 1.8, -1.4);
      flightGroup.add(rail);

      // Floor Landing at top of flight (connects directly to next flight and room entrance)
      const landing = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.25, 2.0), this.floorTileMat);
      landing.position.set(6.2, baseH + 3.2 + 0.12, 1.7);
      flightGroup.add(landing);

      sc.add(flightGroup);
    }
  }

  // ==========================================
  // EXTERIOR FACADE & DIRECTIONAL CUTAWAY
  // ==========================================
  private buildExteriorFacade() {
    const ext = this.exteriorWalls;

    // Corner Pillars & Cornices for exterior architectural look
    for (const [cx, cz] of [[-7.9, -6.9], [7.9, -6.9], [-7.9, 6.9], [7.9, 6.9]]) {
      const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.8, 12.8, 0.8), this.metalTrimMat);
      pillar.position.set(cx, 6.4, cz);
      pillar.castShadow = true;
      ext.add(pillar);
    }

    // Floor Decorative Cornices between stories
    for (let f = 1; f <= 3; f++) {
      const cornice = new THREE.Mesh(new THREE.BoxGeometry(16.5, 0.35, 14.5), this.metalTrimMat);
      cornice.position.set(0, f * 3.2, 0);
      ext.add(cornice);
    }

    // 1. North Wall (Back)
    this.northWallMesh = new THREE.Group();
    const northWall = new THREE.Mesh(new THREE.BoxGeometry(16.0, 12.0, 0.5), this.brickFacadeMat);
    northWall.position.set(0, 6.0, 6.8);
    northWall.castShadow = true;
    this.northWallMesh.add(northWall);
    ext.add(this.northWallMesh);

    // 2. East Wall (Stairwell Bay)
    this.eastWallMesh = new THREE.Group();
    const eastWall = new THREE.Mesh(new THREE.BoxGeometry(0.5, 12.0, 14.0), this.brickFacadeMat);
    eastWall.position.set(7.8, 6.0, 0);
    eastWall.castShadow = true;
    this.eastWallMesh.add(eastWall);
    ext.add(this.eastWallMesh);

    // 3. West Wall (Bedrooms & Armory Display)
    this.westWallMesh = new THREE.Group();
    const westWall = new THREE.Mesh(new THREE.BoxGeometry(0.5, 12.0, 14.0), this.brickFacadeMat);
    westWall.position.set(-7.8, 6.0, 0);
    westWall.castShadow = true;
    this.westWallMesh.add(westWall);
    ext.add(this.westWallMesh);

    // 4. South Wall (Front Entrance Facade with door opening)
    this.southWallMesh = new THREE.Group();
    const southWallLeft = new THREE.Mesh(new THREE.BoxGeometry(7.0, 12.0, 0.5), this.brickFacadeMat);
    southWallLeft.position.set(-4.5, 6.0, -6.8);
    southWallLeft.castShadow = true;

    const southWallRight = new THREE.Mesh(new THREE.BoxGeometry(7.0, 12.0, 0.5), this.brickFacadeMat);
    southWallRight.position.set(4.5, 6.0, -6.8);
    southWallRight.castShadow = true;

    const southWallTop = new THREE.Mesh(new THREE.BoxGeometry(2.0, 9.4, 0.5), this.brickFacadeMat);
    southWallTop.position.set(0, 7.3, -6.8);

    this.southWallMesh.add(southWallLeft, southWallRight, southWallTop);
    ext.add(this.southWallMesh);
  }

  public updateTVScreenContent(isOn: boolean, isEmergency: boolean = false) {
    if (!this.tvContext) return;
    const ctx = this.tvContext;
    const w = this.tvCanvas.width;
    const h = this.tvCanvas.height;

    if (!isOn) {
      ctx.fillStyle = '#0a0a0a';
      ctx.fillRect(0, 0, w, h);
      return;
    }

    if (isEmergency) {
      // Day 2 Emergency Alert System Broadcast
      ctx.fillStyle = '#1c0505';
      ctx.fillRect(0, 0, w, h);

      // Red Alert Header Banner
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(0, 0, w, 55);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 22px sans-serif';
      ctx.fillText('EMERGENCY ALERT SYSTEM (EAS) · ACTIVE BROADCAST', 16, 36);

      // Flashing Alert Ticker
      ctx.fillStyle = '#7f1d1d';
      ctx.fillRect(0, h - 50, w, 50);
      ctx.fillStyle = '#fef08a';
      ctx.font = 'bold 16px sans-serif';
      ctx.fillText('CRITICAL: HIGH-DENSITY BOLIDE IMPACT CORRIDOR — SECTOR 4 RIDGE', 16, h - 20);

      // Emergency Body Text
      ctx.fillStyle = '#fca5a5';
      ctx.font = 'bold 16px monospace';
      ctx.fillText('WARNING: ATMOSPHERIC TRAJECTORY DETECTED OVER VALLEY', 24, 95);
      ctx.fillText('CIVILIAN ADVISORY: PREPARE FOR SEISMIC SHOCKWAVES', 24, 125);
      ctx.fillText('POWER GRID: FLUCTUATIONS REPORTED ACROSS SECTOR 1-4', 24, 155);
      ctx.fillText('ALL RESIDENTS: AVOID WINDOWS & ASSEMBLE EMERGENCY SUPPLIES', 24, 185);
    } else {
      // Day 1 Peaceful Channel 4 News
      ctx.fillStyle = '#061626';
      ctx.fillRect(0, 0, w, h);

      // Blue header banner
      ctx.fillStyle = '#0284c7';
      ctx.fillRect(0, 0, w, 50);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 24px sans-serif';
      ctx.fillText('OAKRIDGE CHANNEL 4 NEWS · LIVE', 20, 35);

      // Ticker bar
      ctx.fillStyle = '#0369a1';
      ctx.fillRect(0, h - 45, w, 45);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 16px sans-serif';
      ctx.fillText('SCIENCE UPDATE: UNIDENTIFIED CELESTIAL OBJECT DETECTED IN DEEP SPACE', 20, h - 16);

      // News content
      ctx.fillStyle = '#38bdf8';
      ctx.font = '16px monospace';
      ctx.fillText('ASTRONOMY: OBJECT ON UNUSUAL TRAJECTORY PAST INNER SYSTEM', 30, 95);
      ctx.fillText('SCIENTISTS: MONITORING DATA · NO IMMEDIATE THREAT EXPECTED', 30, 125);
      ctx.fillText('WEATHER: 72°F · PLEASANT WARM SUMMER AFTERNOON IN OAKRIDGE', 30, 155);
      ctx.fillText('MUNICIPAL: ANNUAL VALLEY RIDGE PARK FESTIVAL THIS WEEKEND', 30, 185);
    }

    // Broadcast icon
    ctx.strokeStyle = isEmergency ? '#ef4444' : '#38bdf8';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(w - 70, 130, 32, 0, Math.PI * 2);
    ctx.stroke();
  }

  // ==========================================
  // UPDATE LOOP & CAMERA-AWARE VISIBILITY
  // ==========================================
  public update(delta: number, playerPos: THREE.Vector3, cameraPos: THREE.Vector3) {
    // 1. Ceiling Fan Rotation
    if (this.state.fanOn && this.fanBlades) {
      this.fanBlades.rotation.y += this.state.fanSpeed * delta;
    }

    // 2. Pool Water Wave Ripple Animation
    if (this.poolWaterMesh) {
      const t = performance.now() * 0.002;
      this.poolWaterMesh.position.y = 9.6 - 0.15 + Math.sin(t) * 0.04;
    }

    // 3. Camera-Aware Cutaway Architecture:
    const relX = playerPos.x - this.origin.x;
    const relY = playerPos.y - this.origin.y;
    const relZ = playerPos.z - this.origin.z;

    const isInsideBuilding = Math.abs(relX) < 8.2 && Math.abs(relZ) < 7.2 && relY >= 0 && relY <= 14.0;

    if (isInsideBuilding) {
      // In 3rd person mode, hide the wall between camera and player so the interior is NEVER obstructed
      const camRelZ = cameraPos.z - this.origin.z;
      const camRelX = cameraPos.x - this.origin.x;

      this.southWallMesh.visible = !(camRelZ < relZ - 0.5);
      this.northWallMesh.visible = !(camRelZ > relZ + 0.5);
      this.westWallMesh.visible = !(camRelX < relX - 0.5);
      this.eastWallMesh.visible = !(camRelX > relX + 0.5);

      // Floor cutaways: ensure furniture on player's current floor and adjacent floor is visible
      if (relY < 3.2) {
        // Floor 1
        this.floor1Group.visible = true;
        this.floor2Group.visible = true;
        this.floor3Group.visible = false;
        this.floor4Group.visible = false;
      } else if (relY < 6.4) {
        // Floor 2
        this.floor1Group.visible = true;
        this.floor2Group.visible = true;
        this.floor3Group.visible = true;
        this.floor4Group.visible = false;
      } else if (relY < 9.6) {
        // Floor 3 (Armory)
        this.floor1Group.visible = false;
        this.floor2Group.visible = true;
        this.floor3Group.visible = true;
        this.floor4Group.visible = true;
      } else {
        // Floor 4 (Rooftop Pool)
        this.floor1Group.visible = false;
        this.floor2Group.visible = false;
        this.floor3Group.visible = true;
        this.floor4Group.visible = true;
      }
    } else {
      // Player is outside: all exterior walls and floors visible
      this.southWallMesh.visible = true;
      this.northWallMesh.visible = true;
      this.westWallMesh.visible = true;
      this.eastWallMesh.visible = true;
      this.floor1Group.visible = true;
      this.floor2Group.visible = true;
      this.floor3Group.visible = true;
      this.floor4Group.visible = true;
    }
  }

  // ==========================================
  // INTERACTION SYSTEM & DISCOVERY HOOKS
  // ==========================================
  public getInteraction(pos: THREE.Vector3): {
    id: 'bed' | 'phone' | 'fridge' | 'tv' | 'fan' | 'ac' | 'armory' | 'pool' | 'door';
    label: string;
    prompt: string;
  } | null {
    const relX = pos.x - this.origin.x;
    const relY = pos.y - this.origin.y;
    const relZ = pos.z - this.origin.z;

    // Check if within 12m perimeter
    if (Math.abs(relX) > 11 || Math.abs(relZ) > 10) return null;

    // --- FLOOR 1 INTERACTIONS ---
    if (relY < 3.0) {
      // 1. Bed at (-5.5, 3.8)
      if (Math.hypot(relX - (-5.5), relZ - 3.8) < 2.4) {
        return { id: 'bed', label: 'Apartment Bed', prompt: 'Press [E] to Rest & Sleep in Bed' };
      }
      // 2. TV at (-5.5, 0.0)
      if (Math.hypot(relX - (-5.5), relZ - 0.0) < 2.5) {
        return {
          id: 'tv',
          label: 'Smart Television',
          prompt: `Press [E] to Turn ${this.state.tvOn ? 'OFF' : 'ON'} News Television`,
        };
      }
      // 3. Refrigerator at (4.5, 5.8)
      if (Math.hypot(relX - 4.5, relZ - 5.8) < 2.2) {
        return { id: 'fridge', label: 'Apartment Refrigerator', prompt: 'Press [E] to Open Refrigerator Food Storage' };
      }
      // 4. Smartphone on coffee table at (0.3, -1.2)
      if (Math.hypot(relX - 0.3, relZ - (-1.2)) < 2.0) {
        return { id: 'phone', label: 'Smartphone', prompt: 'Press [E] to Check In-Game Phone Messages' };
      }
      // 5. Ceiling fan switch
      if (Math.hypot(relX - 0, relZ - 0.5) < 2.2) {
        return {
          id: 'fan',
          label: 'Ceiling Fan',
          prompt: `Press [E] to ${this.state.fanOn ? 'Stop' : 'Start'} Ceiling Fan`,
        };
      }
      // 6. Air conditioner switch at (-2.5, -6.6)
      if (Math.hypot(relX - (-2.5), relZ - (-6.6)) < 2.2) {
        return {
          id: 'ac',
          label: 'Air Conditioner',
          prompt: `Press [E] to ${this.state.acOn ? 'Turn OFF' : 'Turn ON'} Air Conditioner`,
        };
      }
      // 7. Front entrance door at (0, -6.9)
      if (Math.hypot(relX - 0, relZ - (-6.9)) < 2.2) {
        return {
          id: 'door',
          label: 'Apartment Front Door',
          prompt: `Press [E] to ${this.state.doorOpen ? 'Close' : 'Open'} Entrance Door`,
        };
      }
    }

    // --- FLOOR 3 (ARMORY) INTERACTIONS ---
    if (relY >= 6.0 && relY < 9.4) {
      if (Math.hypot(relX - 2.0, relZ - 0.0) < 3.2 || Math.hypot(relX - (-5.0), relZ - 0.0) < 4.0) {
        return {
          id: 'armory',
          label: 'Sector Armory & Weapon Vault',
          prompt: 'Press [E] to Access 100-Item Fictional Armory Vault',
        };
      }
    }

    // --- FLOOR 4 (ROOFTOP POOL) INTERACTIONS ---
    if (relY >= 9.2) {
      if (Math.hypot(relX - (-2.5), relZ - 0.0) < 5.0) {
        return {
          id: 'pool',
          label: 'Rooftop Swimming Pool',
          prompt: 'Press [E] to Dive into Rooftop Swimming Pool',
        };
      }
    }

    return null;
  }

  public toggleTV(forceState?: boolean, isEmergency: boolean = false): boolean {
    this.state.tvOn = forceState !== undefined ? forceState : !this.state.tvOn;
    this.updateTVScreenContent(this.state.tvOn, isEmergency);
    this.tvTexture.needsUpdate = true;
    soundEngine.playUIClick();
    return this.state.tvOn;
  }

  public toggleFan(): boolean {
    this.state.fanOn = !this.state.fanOn;
    soundEngine.playUIClick();
    return this.state.fanOn;
  }

  public toggleAC(): boolean {
    this.state.acOn = !this.state.acOn;
    this.acLedMat.color.setHex(this.state.acOn ? 0x00ff88 : 0x441111);
    soundEngine.playUIClick();
    return this.state.acOn;
  }

  public toggleDoor(): boolean {
    this.state.doorOpen = !this.state.doorOpen;
    if (this.frontDoorMesh) {
      this.frontDoorMesh.rotation.y = this.state.doorOpen ? Math.PI / 2 : 0;
    }
    soundEngine.playGateToggle(this.state.doorOpen);
    return this.state.doorOpen;
  }

  public checkPlayerInPool(playerPos: THREE.Vector3): boolean {
    const b = this.poolWaterBounds;
    return (
      playerPos.x >= b.minX &&
      playerPos.x <= b.maxX &&
      playerPos.z >= b.minZ &&
      playerPos.z <= b.maxZ &&
      playerPos.y >= b.minY &&
      playerPos.y <= b.maxY + 1.2
    );
  }

  // ==========================================
  // UNIFIED PHYSICS COLLIDER REGISTRATION
  // ==========================================
  public registerColliders(physMgr: UnifiedPhysicsManager) {
    const ox = this.origin.x; // -26
    const oz = this.origin.z; // 38

    // 1. Floor Slabs (Ground Floor 1, Floor 2, Floor 3, Floor 4 Deck)
    physMgr.registerBoxCollider('apt_floor_1', 'building', [ox, 0.12, oz], 16, 0.25, 14);
    physMgr.registerBoxCollider('apt_floor_2', 'building', [ox, 3.32, oz], 16, 0.25, 14);
    physMgr.registerBoxCollider('apt_floor_3', 'building', [ox, 6.52, oz], 16, 0.25, 14);
    physMgr.registerBoxCollider('apt_floor_4_deck', 'building', [ox, 9.72, oz], 16, 0.3, 14);

    // 2. Exterior Perimeter Walls
    physMgr.registerBoxCollider('apt_wall_north', 'wall', [ox, 6.0, oz + 6.8], 16.0, 12.0, 0.6);
    physMgr.registerBoxCollider('apt_wall_east', 'wall', [ox + 7.8, 6.0, oz], 0.6, 12.0, 14.0);
    physMgr.registerBoxCollider('apt_wall_west', 'wall', [ox - 7.8, 6.0, oz], 0.6, 12.0, 14.0);
    physMgr.registerBoxCollider('apt_wall_south_l', 'wall', [ox - 4.5, 6.0, oz - 6.8], 7.0, 12.0, 0.6);
    physMgr.registerBoxCollider('apt_wall_south_r', 'wall', [ox + 4.5, 6.0, oz - 6.8], 7.0, 12.0, 0.6);

    // 3. Staircase Walkable Collision Ramps (Floor 1 -> 2, 2 -> 3, 3 -> 4)
    for (let f = 0; f < 3; f++) {
      const baseY = f * 3.2;
      physMgr.registerBoxCollider(
        `apt_stair_ramp_${f + 1}`,
        'building',
        [ox + 6.2, baseY + 1.6, oz - 1.4],
        1.8,
        3.2,
        4.4
      );
    }

    // 4. Rooftop Swimming Pool Basin & Rims
    physMgr.registerBoxCollider('apt_pool_floor', 'building', [ox - 2.5, 8.2, oz], 8.0, 0.3, 6.4);
    physMgr.registerBoxCollider('apt_pool_rim_n', 'wall', [ox - 2.5, 9.9, oz + 3.45], 8.8, 0.6, 0.5);
    physMgr.registerBoxCollider('apt_pool_rim_s', 'wall', [ox - 2.5, 9.9, oz - 3.45], 8.8, 0.6, 0.5);
    physMgr.registerBoxCollider('apt_pool_rim_w', 'wall', [ox - 6.65, 9.9, oz], 0.5, 0.6, 7.4);
    physMgr.registerBoxCollider('apt_pool_rim_e', 'wall', [ox + 1.65, 9.9, oz], 0.5, 0.6, 7.4);

    // 5. Solid Interior Furniture on Floor 1
    physMgr.registerBoxCollider('apt_bed', 'prop', [ox - 5.5, 0.45, oz + 3.8], 2.4, 0.9, 2.8);
    physMgr.registerBoxCollider('apt_sofa', 'prop', [ox, 0.55, oz + 0.5], 2.8, 0.85, 1.2);
    physMgr.registerBoxCollider('apt_tvstand', 'prop', [ox - 5.5, 0.45, oz], 2.4, 0.65, 0.6);
    physMgr.registerBoxCollider('apt_fridge', 'prop', [ox + 4.5, 1.2, oz + 5.8], 1.2, 2.2, 1.0);
    physMgr.registerBoxCollider('apt_kitchen', 'prop', [ox + 5.8, 0.55, oz + 3.2], 3.6, 0.9, 1.0);
  }

  public dispose() {
    this.group.traverse((o) => {
      if (o instanceof THREE.Mesh) {
        o.geometry.dispose();
        if (Array.isArray(o.material)) o.material.forEach((m) => m.dispose());
        else o.material.dispose();
      }
    });
    this.floorLights = [];
  }
}
