/**
 * Authoritative no-procedural-spawn zones for story-authored safe compounds.
 * Coordinates are world X/Z. Intentional authored props, crops, vehicles,
 * furniture, equipment, NPCs and mission objects are not blocked by this utility.
 * Every procedural spawn system (hostile, wildlife, resource, loot, POI, vehicle,
 * ambient prop) must consult this same predicate before creating an object.
 */
export type ProtectedSpawnZone = { id: string; minX: number; maxX: number; minZ: number; maxZ: number };

export const PROTECTED_SPAWN_ZONES: readonly ProtectedSpawnZone[] = [
  // Apartment compound, including the building footprint, courtyard and garage.
  // Includes a 10m external canopy/prop buffer: tree crowns and large debris must
  // not overhang the wall into the playable yard or building approach.
  { id: 'apartment-compound', minX: -56, maxX: 4, minZ: 4, maxZ: 76 },
  // Military Starter Base at (954, 22) with reinforced perimeter clearing.
  // Nothing unrelated (trees, stone, scrap) can spawn inside or within boundary.
  { id: 'military-starter-base', minX: 915, maxX: 995, minZ: -18, maxZ: 62 },
  // Legacy central clearing around origin
  { id: 'legacy-sanctuary', minX: -40, maxX: 40, minZ: -40, maxZ: 40 },
];

export function isProtectedSpawnZone(x: number, z: number): boolean {
  return PROTECTED_SPAWN_ZONES.some(zone =>
    x >= zone.minX && x <= zone.maxX && z >= zone.minZ && z <= zone.maxZ
  );
}
