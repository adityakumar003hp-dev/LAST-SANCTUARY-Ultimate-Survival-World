import * as THREE from 'three';
import { UnifiedPhysicsManager } from '../physics/UnifiedPhysicsManager';
import { soundEngine } from '../../utils/audio';
import { ApartmentTurrets } from './ApartmentTurrets';
import { BasementControlRoom } from './BasementControlRoom';
import { ZombieManager } from '../ZombieManager';
import { WildlifeManager } from '../WildlifeManager';

export interface ApartmentState {
  tvOn: boolean;
  tvChannel: number;
  fanOn: boolean;
  fanSpeed: number;
  acOn: boolean;
  lightsOn: boolean;
  doorOpen: boolean;
  fridgeOpen: boolean;
  fridgeItems: string[];
}

export class ApartmentBuilding {
  public group: THREE.Group;
  public state: ApartmentState;
  public turrets: ApartmentTurrets;
  public basementRoom: BasementControlRoom;

  // Floor groups for camera-aware cutaways
  public floor1Group: THREE.Group;
  public floor2Group: THREE.Group;
  public floor3Group: THREE.Group;
  public floor4Group: THREE.Group;
  public exteriorWalls: THREE.Group;
  public staircaseGroup: THREE.Group;

  // Dynamic meshes
  private tvMesh!: THREE.Mesh;
  private tvScreenMat: THREE.MeshBasicMaterial;
  private tvCanvas: HTMLCanvasElement;
  private tvContext: CanvasRenderingContext2D | null;
  private tvTexture: THREE.CanvasTexture;
  private fanBlades!: THREE.Group;
  private acMesh!: THREE.Mesh;
  private acLedMat!: THREE.MeshBasicMaterial;
  private fridgeDoor!: THREE.Group;
  private frontDoorMesh!: THREE.Group;
  private frontDoorLeftLeaf!: THREE.Group;
  private frontDoorRightLeaf!: THREE.Group;
  private compoundGateLeftLeaf!: THREE.Group;
  private compoundGateRightLeaf!: THREE.Group;
  private compoundGateGroup!: THREE.Group;
  public poolWaterMesh!: THREE.Mesh;
  public backyardPoolWaterMesh!: THREE.Mesh;
  public garageShutterOpen: boolean = true;
  private garageShutterGroup!: THREE.Group;
  private floorLights: THREE.PointLight[] = [];
  public compoundGateOpen = true;

  // Reusable PBR materials
  private whiteWallMat: THREE.MeshStandardMaterial;
  private greyWallMat: THREE.MeshStandardMaterial;
  private armoryWallMat: THREE.MeshStandardMaterial;
  private brickFacadeMat: THREE.MeshStandardMaterial;
  private floorTileMat: THREE.MeshStandardMaterial;
  private woodFloorMat: THREE.MeshStandardMaterial;
  private glassMat: THREE.MeshStandardMaterial;
  private metalTrimMat: THREE.MeshStandardMaterial;
  private waterMat: THREE.MeshStandardMaterial;

  // Exterior wall sub-groups for directional camera cutaways
  private southWallMesh!: THREE.Group;
  private northWallMesh!: THREE.Group;
  private eastWallMesh!: THREE.Group;
  private westWallMesh!: THREE.Group;

  // Base building location
  public readonly origin = new THREE.Vector3(-26, 0, 38);

  // Pool water volume bounding box in world coordinates
  public readonly backyardPoolBounds = {
    minX: -5.0, maxX: 5.0, minY: 0.15, maxY: 1.5,
    minZ: 17.5, maxZ: 25.5,
  };

  public readonly poolWaterBounds = {
    minX: -31.5, maxX: -25.5,
    minY: 8.0, maxY: 10.8,
    minZ: 34.5, maxZ: 41.5,
  };

  constructor(parent: THREE.Scene | THREE.Group) {
    this.group = new THREE.Group();
    this.group.name = 'four_floor_apartment_complex';
    this.group.position.copy(this.origin);
    parent.add(this.group);

    this.state = {
      tvOn: false,
      tvChannel: 1,
      fanOn: true,
      fanSpeed: 4.5,
      acOn: true,
      lightsOn: true,
      doorOpen: true,
      fridgeOpen: false,
      fridgeItems: ['clean_water', 'canned_beans', 'fresh_oj', 'breakfast_sandwich', 'bandage'],
    };

    // Shared high-grade PBR materials
    this.whiteWallMat = new THREE.MeshStandardMaterial({
      color: 0xf5f5f5,
      roughness: 0.88,
      side: THREE.DoubleSide,
    });
    this.greyWallMat = new THREE.MeshStandardMaterial({
      color: 0x787c82, // Visually distinct grey for Floor 2
      roughness: 0.85,
      side: THREE.DoubleSide,
    });
    this.armoryWallMat = new THREE.MeshStandardMaterial({
      color: 0x22262d,
      roughness: 0.45,
      metalness: 0.65,
      side: THREE.DoubleSide,
    });
    this.brickFacadeMat = new THREE.MeshStandardMaterial({
      color: 0x8a4234,
      roughness: 0.9,
    });
    this.floorTileMat = new THREE.MeshStandardMaterial({
      color: 0xd2ceca,
      roughness: 0.6,
    });
    this.woodFloorMat = new THREE.MeshStandardMaterial({
      color: 0x583d26,
      roughness: 0.7,
    });
    this.glassMat = new THREE.MeshStandardMaterial({
      color: 0x8ec3d8,
      roughness: 0.1,
      metalness: 0.85,
      transparent: true,
      opacity: 0.45,
    });
    this.metalTrimMat = new THREE.MeshStandardMaterial({
      color: 0x25282d,
      metalness: 0.8,
      roughness: 0.35,
    });
    this.waterMat = new THREE.MeshStandardMaterial({
      color: 0x0099bb,
      roughness: 0.05,
      metalness: 0.25,
      transparent: true,
      opacity: 0.75,
    });

    // Procedural TV screen canvas
    this.tvCanvas = document.createElement('canvas');
    this.tvCanvas.width = 512;
    this.tvCanvas.height = 288;
    this.tvContext = this.tvCanvas.getContext('2d');
    this.updateTVScreenContent(false);
    this.tvTexture = new THREE.CanvasTexture(this.tvCanvas);
    this.tvTexture.colorSpace = THREE.SRGBColorSpace;
    this.tvScreenMat = new THREE.MeshBasicMaterial({ map: this.tvTexture });

    this.floor1Group = new THREE.Group();
    this.floor1Group.name = 'floor_1_white_living';
    this.floor2Group = new THREE.Group();
    this.floor2Group.name = 'floor_2_grey_residence';
    this.floor3Group = new THREE.Group();
    this.floor3Group.name = 'floor_3_armory_vault';
    this.floor4Group = new THREE.Group();
    this.floor4Group.name = 'floor_4_rooftop_pool';
    this.exteriorWalls = new THREE.Group();
    this.exteriorWalls.name = 'exterior_cutaway_facade';
    this.staircaseGroup = new THREE.Group();
    this.staircaseGroup.name = 'continuous_staircase';

    this.group.add(
      this.floor1Group,
      this.floor2Group,
      this.floor3Group,
      this.floor4Group,
      this.exteriorWalls,
      this.staircaseGroup
    );

    // Build building architecture
    this.buildFloor1();
    this.buildFloor2();
    this.buildFloor3();
    this.buildFloor4Pool();
    this.buildContinuousStaircase();
    this.buildExteriorFacade();
    this.buildEnclosedProperty();
    // Entrance starts open so movement between interior and exterior is unobstructed.
    this.frontDoorLeftLeaf.rotation.y = -Math.PI / 2;
    this.frontDoorRightLeaf.rotation.y = Math.PI / 2;
    this.compoundGateLeftLeaf.rotation.y = -Math.PI / 2;
    this.compoundGateRightLeaf.rotation.y = Math.PI / 2;

    // Two AI Defense Sentry Turrets guarding the main double gate entrance
    this.turrets = new ApartmentTurrets(this.group, this.origin);

    // Sub-Level 1: Basement Railway Control Centre beneath apartment
    this.basementRoom = new BasementControlRoom(this.group, this.origin);
  }

  // ==========================================
  // FLOOR SLAB WITH STAIR OPENING HELPER
  // ==========================================
  private createSlabWithStairwell(mat: THREE.Material, thickness: number, yPos: number): THREE.Group {
    const g = new THREE.Group();
    // West section: covers X = -8.0 to +4.5 (width 12.5, depth 14, center X = -1.75)
    const westSlab = new THREE.Mesh(new THREE.BoxGeometry(12.5, thickness, 14), mat);
    westSlab.position.set(-1.75, yPos, 0);
    westSlab.receiveShadow = true;

    // East North section: covers X = 4.5 to 8.0, Z = 2.0 to 7.0 (width 3.5, depth 5, center X = 6.25, Z = 4.5)
    const eastNorth = new THREE.Mesh(new THREE.BoxGeometry(3.5, thickness, 5.0), mat);
    eastNorth.position.set(6.25, yPos, 4.5);
    eastNorth.receiveShadow = true;

    // East South section: covers X = 4.5 to 8.0, Z = -7.0 to -4.5 (width 3.5, depth 2.5, center X = 6.25, Z = -5.75)
    const eastSouth = new THREE.Mesh(new THREE.BoxGeometry(3.5, thickness, 2.5), mat);
    eastSouth.position.set(6.25, yPos, -5.75);
    eastSouth.receiveShadow = true;

    g.add(westSlab, eastNorth, eastSouth);
    return g;
  }

  // ==========================================
  // FLOOR 1: WHITE WALL MAIN LIVING AREA
  // ==========================================
  private buildFloor1() {
    const f1 = this.floor1Group;

    // Ground Floor Base with Stairwell Opening connecting to Basement
    const floorSlab = this.createSlabWithStairwell(this.woodFloorMat, 0.25, 0.12);
    f1.add(floorSlab);

    // Ceiling with stairwell cutout so player head is never blocked
    const ceiling = this.createSlabWithStairwell(this.whiteWallMat, 0.2, 3.1);
    f1.add(ceiling);

    // Interior White Dividing Walls (Dividing Bedroom, Kitchen, Living Room)
    const bedDivider = new THREE.Mesh(new THREE.BoxGeometry(0.25, 2.9, 7.5), this.whiteWallMat);
    bedDivider.position.set(-2.5, 1.6, 2.8);
    const kitchenDivider = new THREE.Mesh(new THREE.BoxGeometry(0.25, 2.9, 5.0), this.whiteWallMat);
    kitchenDivider.position.set(2.5, 1.6, 4.0);
    f1.add(bedDivider, kitchenDivider);

    // Warm Interior Ceiling Lamps
    const lamp1 = new THREE.PointLight(0xffecd0, 1.8, 14, 1.3);
    lamp1.position.set(-4.5, 2.7, 2.5);
    const lamp2 = new THREE.PointLight(0xffeed0, 2.0, 15, 1.3);
    lamp2.position.set(0, 2.7, 0);
    this.floorLights.push(lamp1, lamp2);
    f1.add(lamp1, lamp2);

    // --- 1. BEDROOM ---
    const bedFrame = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.5, 2.8), this.metalTrimMat);
    bedFrame.position.set(-5.5, 0.35, 3.8);
    const headboard = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.4, 0.2), this.woodFloorMat);
    headboard.position.set(-5.5, 0.9, 5.15);
    const mattress = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.35, 2.5), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9 }));
    mattress.position.set(-5.5, 0.65, 3.8);
    const blanket = new THREE.Mesh(new THREE.BoxGeometry(2.22, 0.38, 1.7), new THREE.MeshStandardMaterial({ color: 0x1f3c5e, roughness: 0.85 }));
    blanket.position.set(-5.5, 0.66, 3.3);
    const pillow1 = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.16, 0.55), new THREE.MeshStandardMaterial({ color: 0xf0f0f0, roughness: 0.9 }));
    pillow1.position.set(-6.1, 0.85, 4.6);
    const pillow2 = pillow1.clone();
    pillow2.position.x = -4.9;

    const nightstand = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.65, 0.7), this.woodFloorMat);
    nightstand.position.set(-7.2, 0.45, 4.8);
    const nightLamp = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.2, 0.4, 8), new THREE.MeshBasicMaterial({ color: 0xfff0dd }));
    nightLamp.position.set(-7.2, 0.95, 4.8);

    f1.add(bedFrame, headboard, mattress, blanket, pillow1, pillow2, nightstand, nightLamp);

    // --- 2. WORKING TELEVISION WITH BROADCAST SCREEN ---
    const tvStand = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.65, 0.6), this.metalTrimMat);
    tvStand.position.set(-5.5, 0.45, 0.0);
    const tvFrame = new THREE.Mesh(new THREE.BoxGeometry(2.0, 1.25, 0.1), new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.85 }));
    tvFrame.position.set(-5.5, 1.55, 0.0);

    this.tvMesh = new THREE.Mesh(new THREE.PlaneGeometry(1.9, 1.15), this.tvScreenMat);
    this.tvMesh.rotation.y = Math.PI;
    this.tvMesh.position.set(-5.5, 1.55, -0.06);
    f1.add(tvStand, tvFrame, this.tvMesh);

    // --- 3. REFRIGERATOR WITH INTERACTION ---
    const fridgeBody = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 2.2, 1.0),
      new THREE.MeshStandardMaterial({ color: 0xd8d8d8, metalness: 0.6, roughness: 0.25 })
    );
    fridgeBody.position.set(4.5, 1.22, 5.8);

    this.fridgeDoor = new THREE.Group();
    this.fridgeDoor.position.set(4.5, 1.22, 5.3);
    const doorPanel = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 2.18, 0.1),
      new THREE.MeshStandardMaterial({ color: 0xe2e2e2, metalness: 0.65, roughness: 0.25 })
    );
    const doorHandle = new THREE.Mesh(
      new THREE.BoxGeometry(0.08, 0.6, 0.08),
      new THREE.MeshStandardMaterial({ color: 0x444444, metalness: 0.9 })
    );
    doorHandle.position.set(0.48, 0, -0.08);
    this.fridgeDoor.add(doorPanel, doorHandle);
    f1.add(fridgeBody, this.fridgeDoor);

    // --- 4. KITCHENETTE COUNTER & SINK ---
    const kitchenCounter = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.9, 1.0), this.metalTrimMat);
    kitchenCounter.position.set(5.8, 0.57, 3.2);
    const sink = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.35, 0.7), new THREE.MeshStandardMaterial({ color: 0x999999, metalness: 0.85 }));
    sink.position.set(5.8, 0.85, 3.2);
    const faucet = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.35, 6), new THREE.MeshStandardMaterial({ color: 0xcccccc, metalness: 0.9 }));
    faucet.position.set(5.8, 1.15, 3.5);
    f1.add(kitchenCounter, sink, faucet);

    // --- 5. LIVING ROOM SOFA, COFFEE TABLE & SMARTPHONE ---
    const sofa = new THREE.Mesh(
      new THREE.BoxGeometry(2.8, 0.85, 1.2),
      new THREE.MeshStandardMaterial({ color: 0x2e4033, roughness: 0.85 })
    );
    sofa.position.set(0, 0.55, 0.5);

    const coffeeTable = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.45, 0.9), this.woodFloorMat);
    coffeeTable.position.set(0, 0.35, -1.2);

    // Smartphone prop on coffee table
    const phoneMesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.18, 0.02, 0.34),
      new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.8, roughness: 0.2 })
    );
    phoneMesh.position.set(0.3, 0.59, -1.2);
    const phoneScreen = new THREE.Mesh(
      new THREE.PlaneGeometry(0.16, 0.3),
      new THREE.MeshBasicMaterial({ color: 0x00d2d3 })
    );
    phoneScreen.rotation.x = -Math.PI / 2;
    phoneScreen.position.set(0.3, 0.605, -1.2);
    f1.add(sofa, coffeeTable, phoneMesh, phoneScreen);

    // --- 6. WORKING CEILING FAN ---
    const fanHub = new THREE.Group();
    fanHub.position.set(0, 2.95, 0.5);
    const fanStem = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.3, 6), this.metalTrimMat);
    fanStem.position.y = -0.15;
    const fanMotor = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.15, 10), this.metalTrimMat);
    fanMotor.position.y = -0.3;

    this.fanBlades = new THREE.Group();
    this.fanBlades.position.y = -0.32;
    for (let i = 0; i < 4; i++) {
      const blade = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.02, 0.16), this.woodFloorMat);
      blade.rotation.y = (i * Math.PI) / 2;
      blade.position.set(Math.cos(blade.rotation.y) * 0.55, 0, Math.sin(blade.rotation.y) * 0.55);
      this.fanBlades.add(blade);
    }
    fanHub.add(fanStem, fanMotor, this.fanBlades);
    f1.add(fanHub);

    // --- 7. WALL-MOUNTED AIR CONDITIONER ---
    this.acMesh = new THREE.Mesh(
      new THREE.BoxGeometry(1.8, 0.5, 0.4),
      new THREE.MeshStandardMaterial({ color: 0xfafafa, roughness: 0.4 })
    );
    this.acMesh.position.set(-2.5, 2.5, -6.6);

    this.acLedMat = new THREE.MeshBasicMaterial({ color: 0x00ff88 });
    const acLed = new THREE.Mesh(new THREE.SphereGeometry(0.03, 6, 6), this.acLedMat);
    acLed.position.set(-1.8, 2.4, -6.38);
    f1.add(this.acMesh, acLed);

    // --- 8. FULL-HEIGHT DOUBLE FRONT ENTRANCE DOORS ---
    // The two leaves fill the complete doorway and extend to the finished floor;
    // no visible threshold gap is left beneath either panel.
    this.frontDoorMesh = new THREE.Group();
    this.frontDoorMesh.name = 'apartment_double_front_doors';
    const doorHeight = 2.38;
    const doorLeafWidth = 0.99;
    const doorThickness = 0.14;
    // Floor 1 finished surface is approximately y=0.245; sink the panel very
    // slightly into the floor slab so lighting cannot reveal a floating gap.
    this.frontDoorMesh.position.set(0, 1.4, -6.9);

    const doorMaterial = this.woodFloorMat;
    const handleMaterial = new THREE.MeshStandardMaterial({
      color: 0xdaa520,
      metalness: 0.9,
      roughness: 0.25,
    });

    this.frontDoorLeftLeaf = new THREE.Group();
    this.frontDoorLeftLeaf.name = 'frontDoorLeftLeaf';
    this.frontDoorLeftLeaf.position.x = -0.98;
    const leftPanel = new THREE.Mesh(
      new THREE.BoxGeometry(doorLeafWidth, doorHeight, doorThickness),
      doorMaterial
    );
    leftPanel.position.set(doorLeafWidth / 2, 0, 0);
    leftPanel.castShadow = true;
    leftPanel.receiveShadow = true;
    const leftHandle = new THREE.Mesh(new THREE.SphereGeometry(0.055, 10, 8), handleMaterial);
    leftHandle.position.set(doorLeafWidth - 0.13, 0, 0.105);
    this.frontDoorLeftLeaf.add(leftPanel, leftHandle);

    this.frontDoorRightLeaf = new THREE.Group();
    this.frontDoorRightLeaf.name = 'frontDoorRightLeaf';
    this.frontDoorRightLeaf.position.x = 0.98;
    const rightPanel = new THREE.Mesh(
      new THREE.BoxGeometry(doorLeafWidth, doorHeight, doorThickness),
      doorMaterial
    );
    rightPanel.position.set(-doorLeafWidth / 2, 0, 0);
    rightPanel.castShadow = true;
    rightPanel.receiveShadow = true;
    const rightHandle = new THREE.Mesh(new THREE.SphereGeometry(0.055, 10, 8), handleMaterial);
    rightHandle.position.set(-doorLeafWidth + 0.13, 0, 0.105);
    this.frontDoorRightLeaf.add(rightPanel, rightHandle);

    this.frontDoorMesh.add(this.frontDoorLeftLeaf, this.frontDoorRightLeaf);
    f1.add(this.frontDoorMesh);

    // --- 9. FIRST-FLOOR MEDICAL CLINIC SECTION ---
    // Physical medical wing: Reception, examination bed, recovery bed, medicine cabinet, medical fridge, workstation
    const medWing = new THREE.Group();
    medWing.name = 'floor1_medical_section';

    // Reception Counter & Check-in Desk at (3.8, 0.55, -5.2)
    const medDesk = new THREE.Mesh(
      new THREE.BoxGeometry(1.4, 0.9, 0.7),
      new THREE.MeshStandardMaterial({ color: 0x2a363f, roughness: 0.4, metalness: 0.3 })
    );
    medDesk.position.set(3.8, 0.55, -5.2);
    const medTerminal = new THREE.Mesh(
      new THREE.BoxGeometry(0.5, 0.4, 0.08),
      new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.8 })
    );
    medTerminal.position.set(3.8, 1.15, -5.2);
    const medScreen = new THREE.Mesh(
      new THREE.PlaneGeometry(0.44, 0.34),
      new THREE.MeshBasicMaterial({ color: 0x00d2d3 })
    );
    medScreen.position.set(3.8, 1.15, -5.15);
    medWing.add(medDesk, medTerminal, medScreen);

    // Examination Bed with adjustable headrest at (6.2, 0.5, -5.2)
    const examFrame = new THREE.Mesh(
      new THREE.BoxGeometry(0.9, 0.5, 2.0),
      new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.7, roughness: 0.3 })
    );
    examFrame.position.set(6.2, 0.35, -5.2);
    const examPad = new THREE.Mesh(
      new THREE.BoxGeometry(0.85, 0.2, 1.95),
      new THREE.MeshStandardMaterial({ color: 0x0d9488, roughness: 0.7 })
    );
    examPad.position.set(6.2, 0.65, -5.2);
    const examPillow = new THREE.Mesh(
      new THREE.BoxGeometry(0.7, 0.12, 0.4),
      new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9 })
    );
    examPillow.position.set(6.2, 0.78, -4.45);
    medWing.add(examFrame, examPad, examPillow);

    // Recovery Bed for resting patients at (6.2, 0.5, -6.4)
    const recovFrame = new THREE.Mesh(
      new THREE.BoxGeometry(0.9, 0.5, 1.8),
      new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.6, roughness: 0.4 })
    );
    recovFrame.position.set(6.2, 0.35, -6.4);
    const recovMattress = new THREE.Mesh(
      new THREE.BoxGeometry(0.85, 0.22, 1.75),
      new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.85 })
    );
    recovMattress.position.set(6.2, 0.66, -6.4);
    const recovBlanket = new THREE.Mesh(
      new THREE.BoxGeometry(0.87, 0.24, 1.1),
      new THREE.MeshStandardMaterial({ color: 0x0f766e, roughness: 0.85 })
    );
    recovBlanket.position.set(6.2, 0.68, -6.7);
    medWing.add(recovFrame, recovMattress, recovBlanket);

    // Medicine & Supply Storage Cabinet at (3.8, 1.2, -6.6)
    const medCabinet = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 1.8, 0.45),
      new THREE.MeshStandardMaterial({ color: 0xf1f5f9, metalness: 0.4, roughness: 0.3 })
    );
    medCabinet.position.set(3.8, 1.1, -6.6);
    const crossV = new THREE.Mesh(
      new THREE.PlaneGeometry(0.1, 0.4),
      new THREE.MeshBasicMaterial({ color: 0xef4444 })
    );
    crossV.position.set(3.8, 1.35, -6.36);
    const crossH = new THREE.Mesh(
      new THREE.PlaneGeometry(0.4, 0.1),
      new THREE.MeshBasicMaterial({ color: 0xef4444 })
    );
    crossH.position.set(3.8, 1.35, -6.35);
    medWing.add(medCabinet, crossV, crossH);

    // Medical Specimen & Vaccine Refrigerator at (4.8, 1.1, -6.6)
    const medFridge = new THREE.Mesh(
      new THREE.BoxGeometry(0.75, 1.8, 0.5),
      new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.8, roughness: 0.25 })
    );
    medFridge.position.set(4.8, 1.1, -6.6);
    const fridgeDisplay = new THREE.Mesh(
      new THREE.PlaneGeometry(0.2, 0.1),
      new THREE.MeshBasicMaterial({ color: 0x38bdf8 })
    );
    fridgeDisplay.position.set(4.8, 1.6, -6.34);
    medWing.add(medFridge, fridgeDisplay);

    // Clinical Overhead LED Fixture
    const medLight = new THREE.PointLight(0xe0f7fa, 1.6, 9.0, 1.4);
    medLight.position.set(5.2, 2.7, -5.6);
    this.floorLights.push(medLight);
    f1.add(medWing);

    // --- 10. GROUND-FLOOR SANCTUARY BUILDING MANAGEMENT & DEFENSE TERMINAL SCREEN ---
    const bmsGroup = new THREE.Group();
    bmsGroup.name = 'ground_floor_bms_terminal';
    bmsGroup.position.set(-1.8, 1.45, -6.65);

    // Wall console casing
    const bmsConsole = new THREE.Mesh(
      new THREE.BoxGeometry(0.9, 0.65, 0.08),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.85, roughness: 0.25 })
    );
    const bmsFrame = new THREE.Mesh(
      new THREE.BoxGeometry(0.82, 0.58, 0.09),
      new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.9, roughness: 0.2 })
    );
    const bmsScreen = new THREE.Mesh(
      new THREE.PlaneGeometry(0.76, 0.52),
      new THREE.MeshBasicMaterial({ color: 0x00d2d3 })
    );
    bmsScreen.position.z = 0.05;

    const bmsLed = new THREE.Mesh(
      new THREE.SphereGeometry(0.025, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0x10b981 })
    );
    bmsLed.position.set(0.35, 0.23, 0.06);

    const bmsGlow = new THREE.PointLight(0x00d2d3, 0.9, 4.0, 1.5);
    bmsGlow.position.set(0, 0, 0.25);

    bmsGroup.add(bmsConsole, bmsFrame, bmsScreen, bmsLed, bmsGlow);
    f1.add(bmsGroup);
  }

  // ==========================================
  // FLOOR 2: GREY WALL RESIDENTIAL FLOOR
  // ==========================================
  private buildFloor2() {
    const f2 = this.floor2Group;
    const yOff = 3.2;

    // Floor Slab with stairwell opening
    const floorSlab = this.createSlabWithStairwell(this.floorTileMat, 0.25, yOff + 0.12);
    f2.add(floorSlab);

    // Ceiling with stairwell cutout
    const ceiling = this.createSlabWithStairwell(this.greyWallMat, 0.2, yOff + 3.1);
    f2.add(ceiling);

    // Grey Interior Walls (Visually distinct from Floor 1 white walls)
    const divider1 = new THREE.Mesh(new THREE.BoxGeometry(0.25, 2.9, 8.0), this.greyWallMat);
    divider1.position.set(-2.0, yOff + 1.6, 1.5);
    const divider2 = new THREE.Mesh(new THREE.BoxGeometry(6.0, 2.9, 0.25), this.greyWallMat);
    divider2.position.set(-5.0, yOff + 1.6, 1.5);
    f2.add(divider1, divider2);

    // Study Desk & Bookshelf
    const desk = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.85, 1.0), this.woodFloorMat);
    desk.position.set(-5.5, yOff + 0.55, 4.5);
    const deskLamp = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.18, 0.35, 6), new THREE.MeshBasicMaterial({ color: 0xffeedd }));
    deskLamp.position.set(-5.8, yOff + 1.1, 4.5);

    const bookshelf = new THREE.Mesh(new THREE.BoxGeometry(2.6, 2.2, 0.6), this.woodFloorMat);
    bookshelf.position.set(-6.5, yOff + 1.25, 1.8);

    // Lounge sofa
    const loungeSofa = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.8, 1.1), new THREE.MeshStandardMaterial({ color: 0x4a4f56, roughness: 0.85 }));
    loungeSofa.position.set(1.5, yOff + 0.55, 3.5);

    f2.add(desk, deskLamp, bookshelf, loungeSofa);

    // Ceiling light for Floor 2
    const lamp = new THREE.PointLight(0xffeed0, 1.7, 15, 1.3);
    lamp.position.set(0, yOff + 2.7, 1.0);
    this.floorLights.push(lamp);
    f2.add(lamp);

    // Floor 2 Plaque
    const plaque = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.6), new THREE.MeshBasicMaterial({ color: 0x333333 }));
    plaque.position.set(4.4, yOff + 1.8, -3.8);
    plaque.rotation.y = -Math.PI / 2;
    f2.add(plaque);
  }

  // ==========================================
  // FLOOR 3: FICTIONAL 100-ITEM GAME ARMORY
  // ==========================================
  private buildFloor3() {
    const f3 = this.floor3Group;
    const yOff = 6.4;

    // Floor Slab with stairwell cutout
    const floorSlab = this.createSlabWithStairwell(this.metalTrimMat, 0.25, yOff + 0.12);
    f3.add(floorSlab);

    // Ceiling with stairwell cutout
    const ceiling = this.createSlabWithStairwell(this.metalTrimMat, 0.2, yOff + 3.1);
    f3.add(ceiling);

    // High-tech Secure Armory Room Walls (Dark graphite with cyan indicator strips)
    const divider = new THREE.Mesh(new THREE.BoxGeometry(0.25, 2.9, 10.0), this.armoryWallMat);
    divider.position.set(-1.5, yOff + 1.6, 0);
    f3.add(divider);

    // Cyan Neon Accent Lines
    const stripMat = new THREE.MeshBasicMaterial({ color: 0x00d2d3 });
    const strip1 = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.1, 9.8), stripMat);
    strip1.position.set(-1.35, yOff + 2.2, 0);
    f3.add(strip1);

    // Weapon Storage Lockers along West Wall
    for (let z = -4.5; z <= 4.5; z += 2.2) {
      const locker = new THREE.Mesh(
        new THREE.BoxGeometry(1.2, 2.4, 1.8),
        new THREE.MeshStandardMaterial({ color: 0x2e3440, metalness: 0.85, roughness: 0.35 })
      );
      locker.position.set(-6.5, yOff + 1.35, z);
      f3.add(locker);

      // Weapon rack display inside
      const rackGun = new THREE.Mesh(
        new THREE.BoxGeometry(0.12, 0.35, 1.2),
        new THREE.MeshStandardMaterial({ color: 0x5e81ac, metalness: 0.8 })
      );
      rackGun.position.set(-5.8, yOff + 1.4, z);
      f3.add(rackGun);
    }

    // Ammunition Crates & Heavy Ordnance Shelves along North Wall
    for (let x = -4.5; x <= 2.5; x += 2.4) {
      const crate = new THREE.Mesh(
        new THREE.BoxGeometry(1.6, 0.9, 1.1),
        new THREE.MeshStandardMaterial({ color: 0x434c5e, metalness: 0.6, roughness: 0.5 })
      );
      crate.position.set(x, yOff + 0.6, 5.8);
      f3.add(crate);
    }

    // Interactive Armory Console / Master Terminal (Center East)
    const consolePedestal = new THREE.Mesh(
      new THREE.CylinderGeometry(0.4, 0.6, 1.1, 8),
      this.metalTrimMat
    );
    consolePedestal.position.set(2.0, yOff + 0.65, 0.0);

    const consoleScreen = new THREE.Mesh(
      new THREE.BoxGeometry(1.4, 0.8, 0.1),
      new THREE.MeshBasicMaterial({ color: 0x00e5ff })
    );
    consoleScreen.rotation.x = -Math.PI / 4;
    consoleScreen.position.set(2.0, yOff + 1.45, 0.0);
    f3.add(consolePedestal, consoleScreen);

    // High-tech Armory Spotlights
    const armoryLight1 = new THREE.PointLight(0x00e5ff, 2.2, 14, 1.4);
    armoryLight1.position.set(-4.0, yOff + 2.7, 0);
    const armoryLight2 = new THREE.PointLight(0xffffff, 1.8, 14, 1.3);
    armoryLight2.position.set(2.0, yOff + 2.7, 0);
    this.floorLights.push(armoryLight1, armoryLight2);
    f3.add(armoryLight1, armoryLight2);

    // Floor 3 Signboard
    const plaque = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 0.7), new THREE.MeshBasicMaterial({ color: 0x111111 }));
    plaque.position.set(4.4, yOff + 1.8, -3.8);
    plaque.rotation.y = -Math.PI / 2;
    f3.add(plaque);
  }

  // ==========================================
  // FLOOR 4: ROOFTOP SWIMMING POOL & DECK
  // ==========================================
  private buildFloor4Pool() {
    const f4 = this.floor4Group;
    const yOff = 9.6;
    const deck = this.createSlabWithStairwell(this.floorTileMat, 0.3, yOff + 0.15);
    f4.add(deck);

    // Raised rooftop swimming pool: the surrounding deck remains dry and walkable.
    const poolGroup = new THREE.Group();
    poolGroup.name = 'rooftop_swimming_pool_with_exit_steps';
    poolGroup.position.set(-2.5, 0, 0);
    f4.add(poolGroup);
    const poolOuterMat = new THREE.MeshStandardMaterial({ color: 0x315a68, roughness: 0.42 });
    const poolTileMat = new THREE.MeshStandardMaterial({ color: 0x8ed4df, roughness: 0.28 });
    const poolWaterMat = new THREE.MeshStandardMaterial({
      color: 0x08a9d0, roughness: 0.08, metalness: 0.12,
      transparent: true, opacity: 0.76, side: THREE.DoubleSide
    });
    const poolBottom = new THREE.Mesh(new THREE.BoxGeometry(6.0, 0.28, 6.0), poolOuterMat);
    poolBottom.position.set(0, yOff - 1.25, 0);
    poolBottom.receiveShadow = true;
    poolGroup.add(poolBottom);
    // Four raised basin walls; a stair opening is left on the south/east side.
    const poolWalls = [
      [0, yOff - 0.60, -2.92, 6.0, 1.9, 0.22],
      [-2.92, yOff - 0.60, 0, 0.22, 1.9, 6.0],
      [2.92, yOff - 0.60, 0, 0.22, 1.9, 6.0],
      [-1.15, yOff - 0.60, 2.92, 3.7, 1.9, 0.22],
      [2.35, yOff - 0.60, 2.92, 1.15, 1.9, 0.22]
    ];
    for (const [x,y,z,w,h,d] of poolWalls) {
      const wall = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), poolTileMat);
      wall.position.set(x,y,z); wall.castShadow = true; wall.receiveShadow = true;
      poolGroup.add(wall);
    }
    const water = new THREE.Mesh(new THREE.PlaneGeometry(5.55, 5.55), poolWaterMat);
    water.rotation.x = -Math.PI / 2;
    water.position.set(0, yOff + 0.02, 0);
    poolGroup.add(water);
    this.poolWaterMesh = water;
    // Three broad submerged steps provide a visible, climbable entry/exit.
    for (let i = 0; i < 4; i++) {
      const step = new THREE.Mesh(new THREE.BoxGeometry(1.35, 0.16, 0.62), poolTileMat);
      step.position.set(1.2, yOff - 1.02 + i * 0.28, 2.25 - i * 0.58);
      step.receiveShadow = true;
      poolGroup.add(step);
    }

    const parapetMat = new THREE.MeshStandardMaterial({ color: 0x626b73, roughness: 0.75 });
    // Solid safety parapet around the rooftop terrace.
    for (const [x,z,w,d] of [[0,6.85,16,0.25],[0,-6.85,16,0.25],[-7.85,0,0.25,13.7],[7.85,0,0.25,13.7]] as number[][]) {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(w,1.05,d), parapetMat);
      rail.position.set(x,yOff+0.68,z); rail.castShadow = true; f4.add(rail);
    }
    const pergolaMat = new THREE.MeshStandardMaterial({ color: 0x343b42, metalness: 0.55, roughness: 0.45 });
    for (const x of [2.5,7.0]) for (const z of [-2.8,2.8]) {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.16,2.4,0.16),pergolaMat);
      post.position.set(x,yOff+1.35,z); f4.add(post);
    }
    for (let i=0;i<5;i++) {
      const beam = new THREE.Mesh(new THREE.BoxGeometry(5.0,0.12,0.14),pergolaMat);
      beam.position.set(4.75,yOff+2.55,-2.8+i*1.4); f4.add(beam);
    }
    const benchMat = new THREE.MeshStandardMaterial({ color: 0x7b573c, roughness: 0.8 });
    for (const z of [-2.0,2.0]) {
      const bench = new THREE.Mesh(new THREE.BoxGeometry(2.2,0.22,0.65),benchMat);
      bench.position.set(-3.0,yOff+0.45,z); f4.add(bench);
    }
    // Compact solar backup array supports the apartment emergency-power storyline.
    const solarMat = new THREE.MeshStandardMaterial({ color: 0x123b5b, metalness:0.65, roughness:0.25 });
    for (let i=0;i<3;i++) {
      const panel = new THREE.Mesh(new THREE.BoxGeometry(1.8,0.08,1.15),solarMat);
      panel.position.set(-5.7+i*2.0,yOff+0.55,-4.5); panel.rotation.x=-0.12; f4.add(panel);
    }
  }

  // ==========================================
  // CONTINUOUS 4-FLOOR STAIRCASE
  // ==========================================
  private buildContinuousStaircase() {
    const sc = this.staircaseGroup;
    // Switchback/U-turn staircase: first flight left-to-right landing,
    // second flight returns in the opposite direction, third repeats.
    // All three flights stay inside the existing stairwell opening.
    const stairMat = new THREE.MeshStandardMaterial({ color: 0x3d4147, metalness: 0.5, roughness: 0.6 });
    const handrailMat = new THREE.MeshStandardMaterial({ color: 0xd4af37, metalness: 0.9, roughness: 0.3 });
    const flightZ0 = -3.5;
    const flightZ1 = 0.7;
    const flightDepth = flightZ1 - flightZ0;
    const numSteps = 16;
    const stepH = 3.2 / numSteps;
    const stepD = flightDepth / numSteps;
    const lanes = [5.25, 6.75, 5.25];

    for (let floorIdx = 0; floorIdx < 3; floorIdx++) {
      const baseH = floorIdx * 3.2;
      const laneX = lanes[floorIdx];
      const reverse = floorIdx === 1;
      const flightGroup = new THREE.Group();
      flightGroup.name = `stair_flight_${floorIdx + 1}_switchback`;
      for (let stepIndex = 0; stepIndex < numSteps; stepIndex++) {
        const t = (stepIndex + 0.5) / numSteps;
        const z = reverse ? flightZ1 - t * flightDepth : flightZ0 + t * flightDepth;
        const step = new THREE.Mesh(new THREE.BoxGeometry(1.18, stepH, stepD + 0.04), stairMat);
        step.position.set(laneX, baseH + (stepIndex + 0.5) * stepH, z);
        step.castShadow = true;
        step.receiveShadow = true;
        flightGroup.add(step);
      }

      // Parallel handrails and balusters on both sides of each flight.
      for (const sideX of [laneX - 0.66, laneX + 0.66]) {
        const rail = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, Math.hypot(3.2, flightDepth), 8), handrailMat);
        rail.rotation.x = Math.PI / 2 - Math.atan2(3.2, flightDepth) * (reverse ? -1 : 1);
        rail.position.set(sideX, baseH + 1.75, (flightZ0 + flightZ1) / 2);
        flightGroup.add(rail);
        for (let b = 0; b <= 8; b++) {
          const t = b / 8;
          const baluster = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.9, 6), handrailMat);
          baluster.position.set(sideX, baseH + 0.5 + t * 2.7, reverse ? flightZ1 - t * flightDepth : flightZ0 + t * flightDepth);
          flightGroup.add(baluster);
        }
      }
      sc.add(flightGroup);

      // Full-width alternating landings join the ends of successive flights.
      const landingZ = reverse ? flightZ0 : flightZ1;
      const landing = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.25, 1.15), this.floorTileMat);
      landing.position.set(6.0, baseH + 3.2 + 0.12, landingZ);
      landing.receiveShadow = true;
      sc.add(landing);
    }
  }

  // ==========================================
  // EXTERIOR FACADE & DIRECTIONAL CUTAWAY
  // ==========================================
  private buildExteriorFacade() {
    const ext = this.exteriorWalls;

    // Corner Pillars & Cornices for exterior architectural look
    for (const [cx, cz] of [[-7.9, -6.9], [7.9, -6.9], [-7.9, 6.9], [7.9, 6.9]]) {
      const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.8, 12.8, 0.8), this.metalTrimMat);
      pillar.position.set(cx, 6.4, cz);
      pillar.castShadow = true;
      ext.add(pillar);
    }

    // Floor Decorative Cornices between stories
    for (let f = 1; f <= 3; f++) {
      const cornice = new THREE.Mesh(new THREE.BoxGeometry(16.5, 0.35, 14.5), this.metalTrimMat);
      cornice.position.set(0, f * 3.2, 0);
      ext.add(cornice);
    }

    // 1. North Wall (Back)
    this.northWallMesh = new THREE.Group();
    const northWall = new THREE.Mesh(new THREE.BoxGeometry(16.0, 12.0, 0.5), this.brickFacadeMat);
    northWall.position.set(0, 6.0, 6.8);
    northWall.castShadow = true;
    this.northWallMesh.add(northWall);
    ext.add(this.northWallMesh);

    // 2. East Wall (Stairwell Bay)
    this.eastWallMesh = new THREE.Group();
    const eastWall = new THREE.Mesh(new THREE.BoxGeometry(0.5, 12.0, 14.0), this.brickFacadeMat);
    eastWall.position.set(7.8, 6.0, 0);
    eastWall.castShadow = true;
    this.eastWallMesh.add(eastWall);
    ext.add(this.eastWallMesh);

    // 3. West Wall (Bedrooms & Armory Display)
    this.westWallMesh = new THREE.Group();
    const westWall = new THREE.Mesh(new THREE.BoxGeometry(0.5, 12.0, 14.0), this.brickFacadeMat);
    westWall.position.set(-7.8, 6.0, 0);
    westWall.castShadow = true;
    this.westWallMesh.add(westWall);
    ext.add(this.westWallMesh);

    // 4. South Wall (Front Entrance Facade with door opening)
    this.southWallMesh = new THREE.Group();
    const southWallLeft = new THREE.Mesh(new THREE.BoxGeometry(7.0, 12.0, 0.5), this.brickFacadeMat);
    southWallLeft.position.set(-4.5, 6.0, -6.8);
    southWallLeft.castShadow = true;

    const southWallRight = new THREE.Mesh(new THREE.BoxGeometry(7.0, 12.0, 0.5), this.brickFacadeMat);
    southWallRight.position.set(4.5, 6.0, -6.8);
    southWallRight.castShadow = true;

    const southWallTop = new THREE.Mesh(new THREE.BoxGeometry(2.0, 9.4, 0.5), this.brickFacadeMat);
    southWallTop.position.set(0, 7.3, -6.8);

    this.southWallMesh.add(southWallLeft, southWallRight, southWallTop);
    ext.add(this.southWallMesh);
  }

  // ==========================================
  // ENCLOSED RESIDENTIAL PROPERTY + BACKYARD POOL
  // ==========================================
  private buildEnclosedProperty() {
    const property = new THREE.Group();
    property.name = 'apartment_enclosed_residential_compound';
    this.group.add(property);

    const wallMat = new THREE.MeshStandardMaterial({ color: 0x777d82, roughness: 0.88 });
    const capMat = new THREE.MeshStandardMaterial({ color: 0x343a40, roughness: 0.55, metalness: 0.35 });
    const pavingMat = new THREE.MeshStandardMaterial({ color: 0xaaa9a2, roughness: 0.92 });
    const grassMat = new THREE.MeshStandardMaterial({ color: 0x496b3b, roughness: 1 });
    const gateMat = new THREE.MeshStandardMaterial({ color: 0x202a32, metalness: 0.78, roughness: 0.32 });
    const waterMat = new THREE.MeshStandardMaterial({ color: 0x16a9c7, roughness: 0.08, metalness: 0.12, transparent: true, opacity: 0.82 });

    // Yard is a visual surface only; terrain remains the authoritative ground collider.
    const lawn = new THREE.Mesh(new THREE.PlaneGeometry(37, 48), grassMat);
    lawn.rotation.x = -Math.PI / 2;
    lawn.position.set(0, 0.025, 2.5);
    lawn.receiveShadow = true;
    property.add(lawn);

    const path = new THREE.Mesh(new THREE.BoxGeometry(4.4, 0.08, 17), pavingMat);
    path.position.set(0, 0.09, -13.0);
    path.receiveShadow = true;
    property.add(path);

    const wallH = 3.4;
    const wallT = 0.55;
    const wallY = wallH / 2;
    const addWall = (name: string, x: number, z: number, w: number, d: number) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, wallH, d), wallMat);
      mesh.name = name;
      mesh.position.set(x, wallY, z);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      property.add(mesh);
      const cap = new THREE.Mesh(new THREE.BoxGeometry(w + 0.12, 0.18, d + 0.12), capMat);
      cap.position.set(x, wallH + 0.08, z);
      property.add(cap);
    };

    // Continuous perimeter: only the front entrance is open, and it is closed by two gate leaves.
    addWall('compound_wall_west', -19.0, 2.5, wallT, 49.0);
    addWall('compound_wall_east', 19.0, 2.5, wallT, 49.0);
    addWall('compound_wall_rear', 0, 27.0, 38.5, wallT);
    addWall('compound_wall_front_left', -10.75, -22.0, 16.5, wallT);
    addWall('compound_wall_front_right', 10.75, -22.0, 16.5, wallT);

    // Reinforced gate pillars and a fully modelled, hinged double-leaf entrance.
    for (const x of [-2.8, 2.8]) {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.85, 4.0, 0.9), capMat);
      post.position.set(x, 2.0, -22.0);
      post.castShadow = true;
      property.add(post);
      const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.22, 0.45), new THREE.MeshStandardMaterial({ color: 0xffd58a, emissive: 0x8a5418, emissiveIntensity: 0.45 }));
      lamp.position.set(x, 4.12, -22.0);
      property.add(lamp);
    }

    this.compoundGateGroup = new THREE.Group();
    this.compoundGateGroup.name = 'compound_double_access_gate';
    this.compoundGateGroup.position.set(0, 1.65, -22.0);
    this.compoundGateLeftLeaf = new THREE.Group();
    this.compoundGateLeftLeaf.position.x = -2.55;
    this.compoundGateRightLeaf = new THREE.Group();
    this.compoundGateRightLeaf.position.x = 2.55;
    const makeLeaf = (pivot: THREE.Group, sign: number) => {
      const panel = new THREE.Mesh(new THREE.BoxGeometry(2.55, 3.15, 0.18), gateMat);
      panel.position.x = sign * 1.275;
      panel.castShadow = true;
      panel.receiveShadow = true;
      pivot.add(panel);
      for (let i = 0; i < 5; i++) {
        const bar = new THREE.Mesh(new THREE.BoxGeometry(0.08, 3.18, 0.22), capMat);
        bar.position.x = sign * (0.3 + i * 0.48);
        pivot.add(bar);
      }
      const rail = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.12, 0.24), capMat);
      rail.position.set(sign * 1.275, 0.85, 0);
      pivot.add(rail);
    };
    makeLeaf(this.compoundGateLeftLeaf, 1);
    makeLeaf(this.compoundGateRightLeaf, -1);
    this.compoundGateGroup.add(this.compoundGateLeftLeaf, this.compoundGateRightLeaf);
    property.add(this.compoundGateGroup);

    // Backyard pool sits BEHIND the apartment (positive local Z), at ground level.
    const pool = new THREE.Group();
    pool.name = 'backyard_swimming_pool';
    pool.position.set(0, 0, 21.5);
    property.add(pool);
    const deck = new THREE.Mesh(new THREE.BoxGeometry(15.5, 0.16, 12.5), pavingMat);
    deck.position.y = 0.08;
    deck.receiveShadow = true;
    pool.add(deck);
    const basinMat = new THREE.MeshStandardMaterial({ color: 0x315a68, roughness: 0.42 });
    const basin = new THREE.Mesh(new THREE.BoxGeometry(10.8, 0.55, 8.8), basinMat);
    basin.position.y = 0.16;
    pool.add(basin);
    const water = new THREE.Mesh(new THREE.PlaneGeometry(9.9, 7.9), waterMat);
    water.rotation.x = -Math.PI / 2;
    water.position.y = 0.48;
    water.receiveShadow = true;
    pool.add(water);
    this.backyardPoolWaterMesh = water;

    // Pool coping and shallow steps; open centre remains available for swimming.
    const copingMat = new THREE.MeshStandardMaterial({ color: 0xe2ded4, roughness: 0.7 });
    const coping = [
      [0, 0.48, -4.45, 11.3, 0.35, 0.42], [-3.4, 0.48, 4.45, 4.5, 0.35, 0.42], [3.4, 0.48, 4.45, 4.5, 0.35, 0.42],
      [-5.45, 0.48, 0, 0.42, 0.35, 8.8], [5.45, 0.48, 0, 0.42, 0.35, 8.8],
    ];
    for (const [x,y,z,w,h,d] of coping) {
      const edge = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), copingMat);
      edge.position.set(x,y,z);
      edge.castShadow = true;
      pool.add(edge);
    }
    const steps = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.18, 1.2), copingMat);
    steps.position.set(-4.1, 0.28, 3.6);
    pool.add(steps);
    for (let i = 0; i < 3; i++) {
      const entryStep = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.16, 0.55), copingMat);
      entryStep.position.set(0, 0.16 + i * 0.14, 4.9 - i * 0.48);
      pool.add(entryStep);
    }

    // Poolside loungers and low garden lights make the rear yard readable and usable.
    const loungerMat = new THREE.MeshStandardMaterial({ color: 0xf0eee8, roughness: 0.72 });
    for (const x of [-6.1, 6.1]) {
      const lounger = new THREE.Mesh(new THREE.BoxGeometry(1.25, 0.22, 2.4), loungerMat);
      lounger.position.set(x, 0.28, 21.5);
      lounger.rotation.y = x < 0 ? 0.12 : -0.12;
      lounger.castShadow = true;
      property.add(lounger);
      const light = new THREE.PointLight(0x8bdfff, 0.75, 9, 1.8);
      light.position.set(x * 1.35, 1.0, 21.5);
      property.add(light);
      this.floorLights.push(light);
    }
      
    // Paved garden walkway connecting apartment patio and backyard pool directly to the garage
    const garageDriveway = new THREE.Mesh(new THREE.BoxGeometry(6.4, 0.06, 6.0), pavingMat);
    garageDriveway.position.set(-12.8, 0.03, 8.5);
    garageDriveway.receiveShadow = true;
    property.add(garageDriveway);

    // Spacious Backyard Private Garage at local (-12.8, 0, 14.5)
    const garage = new THREE.Group();
    garage.name = 'apartment_backyard_private_garage';
    garage.position.set(-12.8, 0, 14.5);
    property.add(garage);

    const garageWallMat = new THREE.MeshStandardMaterial({ color: 0xb5bac0, roughness: 0.82 });
    const garageDarkMat = new THREE.MeshStandardMaterial({ color: 0x272e35, metalness: 0.65, roughness: 0.38 });
    const garageFloorMat = new THREE.MeshStandardMaterial({ color: 0x93989c, roughness: 0.75 });
    const toolSteelMat = new THREE.MeshStandardMaterial({ color: 0x4a5568, metalness: 0.85, roughness: 0.3 });
    const woodBenchMat = new THREE.MeshStandardMaterial({ color: 0x6e492d, roughness: 0.78 });

    // 1. Smooth walkable polished concrete garage floor with sloped entrance threshold
    const garageFloor = new THREE.Mesh(new THREE.BoxGeometry(7.4, 0.08, 8.6), garageFloorMat);
    garageFloor.position.y = 0.04;
    garageFloor.receiveShadow = true;
    garage.add(garageFloor);

    // Bevelled entrance ramp ensuring zero step collision or catching
    const ramp = new THREE.Mesh(new THREE.BoxGeometry(6.6, 0.06, 0.8), pavingMat);
    ramp.position.set(0, 0.02, -4.5);
    ramp.rotation.x = 0.05;
    garage.add(ramp);

    // 2. Outer Garage Walls: left, rear, and right with open pedestrian door
    // Left outer wall
    const wallLeft = new THREE.Mesh(new THREE.BoxGeometry(0.25, 3.0, 8.6), garageWallMat);
    wallLeft.position.set(-3.7, 1.5, 0);
    wallLeft.castShadow = true;
    wallLeft.receiveShadow = true;
    garage.add(wallLeft);

    // Rear outer wall
    const wallRear = new THREE.Mesh(new THREE.BoxGeometry(7.4, 3.0, 0.25), garageWallMat);
    wallRear.position.set(0, 1.5, 4.3);
    wallRear.castShadow = true;
    wallRear.receiveShadow = true;
    garage.add(wallRear);

    // Right outer wall: split with a 1.4m open pedestrian doorway connecting to the pool patio
    const wallRightFront = new THREE.Mesh(new THREE.BoxGeometry(0.25, 3.0, 3.8), garageWallMat);
    wallRightFront.position.set(3.7, 1.5, -2.4);
    wallRightFront.castShadow = true;
    wallRightFront.receiveShadow = true;

    const wallRightRear = new THREE.Mesh(new THREE.BoxGeometry(0.25, 3.0, 3.8), garageWallMat);
    wallRightRear.position.set(3.7, 1.5, 2.4);
    wallRightRear.castShadow = true;
    wallRightRear.receiveShadow = true;

    const wallRightLintel = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.7, 1.4), garageWallMat);
    wallRightLintel.position.set(3.7, 2.65, 0);
    garage.add(wallRightFront, wallRightRear, wallRightLintel);

    // 3. Garage Roof & Overhead Shutter Housing
    const roof = new THREE.Mesh(new THREE.BoxGeometry(7.65, 0.22, 8.85), garageDarkMat);
    roof.position.set(0, 3.05, 0);
    garage.add(roof);

    // Shutter roll cylinder reel housing above entrance
    const shutterReel = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 6.4, 12), garageDarkMat);
    shutterReel.rotation.z = Math.PI / 2;
    shutterReel.position.set(0, 2.75, -4.25);
    garage.add(shutterReel);

    // 4. Retractable Motorized Garage Shutter (Starts OPEN by default at y = 2.7)
    this.garageShutterGroup = new THREE.Group();
    this.garageShutterGroup.name = 'motorized_garage_shutter';
    this.garageShutterGroup.position.set(0, 2.7, -4.25); // OPEN / RETRACTED

    const shutterPanel = new THREE.Mesh(new THREE.BoxGeometry(6.35, 2.55, 0.08), garageDarkMat);
    shutterPanel.position.y = 0;
    this.garageShutterGroup.add(shutterPanel);

    // Segmented horizontal shutter slats
    for (let slat = -5; slat <= 5; slat++) {
      const line = new THREE.Mesh(new THREE.BoxGeometry(6.3, 0.035, 0.04), capMat);
      line.position.set(0, slat * 0.22, 0.045);
      this.garageShutterGroup.add(line);
    }
    garage.add(this.garageShutterGroup);

    // 5. Interactive Garage Door Switch on the wall
    const switchBox = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.28, 0.18), garageDarkMat);
    switchBox.position.set(3.6, 1.4, -4.0);
    const switchBtn = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.1, 0.1), new THREE.MeshBasicMaterial({ color: 0x00ff88 }));
    switchBtn.position.set(3.53, 1.4, -4.0);
    garage.add(switchBox, switchBtn);

    // 6. Interior Props: Mechanic Workbench, Tool Racks, Diagnostic Monitor
    const workbench = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.9, 2.4), woodBenchMat);
    workbench.position.set(-3.1, 0.45, 0.5);
    workbench.castShadow = true;

    // Benchtop vise and tool chest
    const vise = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.25, 0.22), toolSteelMat);
    vise.position.set(-3.1, 1.02, 1.2);
    const toolBox = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.28, 0.65), new THREE.MeshStandardMaterial({ color: 0xd9381e, roughness: 0.4 }));
    toolBox.position.set(-3.1, 1.04, -0.2);

    // Wall-mounted tool pegboard with wrenches
    const pegboard = new THREE.Mesh(new THREE.BoxGeometry(0.06, 1.1, 2.2), new THREE.MeshStandardMaterial({ color: 0x2d3748, roughness: 0.8 }));
    pegboard.position.set(-3.55, 1.85, 0.5);

    // Storage shelving rack along the rear wall
    const shelf = new THREE.Mesh(new THREE.BoxGeometry(3.2, 2.2, 0.7), toolSteelMat);
    shelf.position.set(0, 1.1, 3.8);
    shelf.castShadow = true;

    // Spare tires on the shelf
    for (const sx of [-1.0, -0.5, 0, 0.5]) {
      const tire = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.36, 0.22, 12), new THREE.MeshStandardMaterial({ color: 0x17191b, roughness: 0.9 }));
      tire.rotation.z = Math.PI / 2;
      tire.position.set(sx, 1.45, 3.8);
      garage.add(tire);
    }

    garage.add(workbench, vise, toolBox, pegboard, shelf);

    // 7. Marked Garage Vehicle Bays (Dedicated bays for active vehicles)
    const bay1 = new THREE.Mesh(new THREE.BoxGeometry(2.7, 0.02, 4.8), new THREE.MeshStandardMaterial({ color: 0x1f2429, roughness: 0.85 }));
    bay1.position.set(-1.6, 0.05, 0);
    const bay2 = new THREE.Mesh(new THREE.BoxGeometry(2.7, 0.02, 4.8), new THREE.MeshStandardMaterial({ color: 0x1f2429, roughness: 0.85 }));
    bay2.position.set(1.6, 0.05, 0);
    garage.add(bay1, bay2);

    // 8. Overhead Garage LED Strip Lights
    const garageLight = new THREE.PointLight(0xffffff, 1.4, 14, 1.5);
    garageLight.position.set(0, 2.65, 0);
    garage.add(garageLight);
    this.floorLights.push(garageLight);
}

  public updateTVScreenContent(isOn: boolean, isEmergency: boolean = false) {
    if (!this.tvContext) return;
    const ctx = this.tvContext;
    const w = this.tvCanvas.width;
    const h = this.tvCanvas.height;

    if (!isOn) {
      ctx.fillStyle = '#0a0a0a';
      ctx.fillRect(0, 0, w, h);
      return;
    }

    if (isEmergency) {
      // Day 2 Emergency Alert System Broadcast
      ctx.fillStyle = '#1c0505';
      ctx.fillRect(0, 0, w, h);

      // Red Alert Header Banner
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(0, 0, w, 55);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 22px sans-serif';
      ctx.fillText('EMERGENCY ALERT SYSTEM (EAS) · ACTIVE BROADCAST', 16, 36);

      // Flashing Alert Ticker
      ctx.fillStyle = '#7f1d1d';
      ctx.fillRect(0, h - 50, w, 50);
      ctx.fillStyle = '#fef08a';
      ctx.font = 'bold 16px sans-serif';
      ctx.fillText('CRITICAL: HIGH-DENSITY BOLIDE IMPACT CORRIDOR — SECTOR 4 RIDGE', 16, h - 20);

      // Emergency Body Text
      ctx.fillStyle = '#fca5a5';
      ctx.font = 'bold 16px monospace';
      ctx.fillText('WARNING: ATMOSPHERIC TRAJECTORY DETECTED OVER VALLEY', 24, 95);
      ctx.fillText('CIVILIAN ADVISORY: PREPARE FOR SEISMIC SHOCKWAVES', 24, 125);
      ctx.fillText('POWER GRID: FLUCTUATIONS REPORTED ACROSS SECTOR 1-4', 24, 155);
      ctx.fillText('ALL RESIDENTS: AVOID WINDOWS & ASSEMBLE EMERGENCY SUPPLIES', 24, 185);
    } else {
      // Day 1 Peaceful Channel 4 News
      ctx.fillStyle = '#061626';
      ctx.fillRect(0, 0, w, h);

      // Blue header banner
      ctx.fillStyle = '#0284c7';
      ctx.fillRect(0, 0, w, 50);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 24px sans-serif';
      ctx.fillText('OAKRIDGE CHANNEL 4 NEWS · LIVE', 20, 35);

      // Ticker bar
      ctx.fillStyle = '#0369a1';
      ctx.fillRect(0, h - 45, w, 45);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 16px sans-serif';
      ctx.fillText('SCIENCE UPDATE: UNIDENTIFIED CELESTIAL OBJECT DETECTED IN DEEP SPACE', 20, h - 16);

      // News content
      ctx.fillStyle = '#38bdf8';
      ctx.font = '16px monospace';
      ctx.fillText('ASTRONOMY: OBJECT ON UNUSUAL TRAJECTORY PAST INNER SYSTEM', 30, 95);
      ctx.fillText('SCIENTISTS: MONITORING DATA · NO IMMEDIATE THREAT EXPECTED', 30, 125);
      ctx.fillText('WEATHER: 72°F · PLEASANT WARM SUMMER AFTERNOON IN OAKRIDGE', 30, 155);
      ctx.fillText('MUNICIPAL: ANNUAL VALLEY RIDGE PARK FESTIVAL THIS WEEKEND', 30, 185);
    }

    // Broadcast icon
    ctx.strokeStyle = isEmergency ? '#ef4444' : '#38bdf8';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(w - 70, 130, 32, 0, Math.PI * 2);
    ctx.stroke();
  }

  // ==========================================
  // UPDATE LOOP & CAMERA-AWARE VISIBILITY
  // ==========================================
  public update(
    delta: number,
    playerPos?: THREE.Vector3,
    cameraPos?: THREE.Vector3,
    zombieMgr?: ZombieManager | null,
    wildlifeMgr?: WildlifeManager | null,
    aiTrainMgr?: any
  ) {
    const pPos = playerPos || this.origin;
    const cPos = cameraPos || this.origin;

    // 0. Update AI Perimeter Defense Turrets
    if (this.turrets) {
      this.turrets.update(delta, zombieMgr || null, wildlifeMgr || null, pPos);
    }

    // Sub-Level 1: Update Basement Railway Control Room Monitors & Telemetry
    if (this.basementRoom) {
      this.basementRoom.update(delta, aiTrainMgr || null);
    }

    // 1. Ceiling Fan Rotation
    if (this.state.fanOn && this.fanBlades) {
      this.fanBlades.rotation.y += this.state.fanSpeed * delta;
    }

    // 2. Pool Water Wave Ripple Animation
    if (this.poolWaterMesh) {
      const t = performance.now() * 0.002;
      this.poolWaterMesh.position.y = 9.62 + Math.sin(t) * 0.025;
      if (this.backyardPoolWaterMesh) this.backyardPoolWaterMesh.position.y = 0.48 + Math.sin(t * 0.8) * 0.018;
    }

    // 3. Camera-Aware Cutaway Architecture:
    const relX = pPos.x - this.origin.x;
    const relY = pPos.y - this.origin.y;
    const relZ = pPos.z - this.origin.z;

    const isInsideBuilding = Math.abs(relX) < 8.2 && Math.abs(relZ) < 7.2 && relY >= 0 && relY <= 14.0;

    if (isInsideBuilding) {
      // In 3rd person mode, hide the wall between camera and player so the interior is NEVER obstructed
      const camRelZ = cPos.z - this.origin.z;
      const camRelX = cPos.x - this.origin.x;

      this.southWallMesh.visible = !(camRelZ < relZ - 0.5);
      this.northWallMesh.visible = !(camRelZ > relZ + 0.5);
      this.westWallMesh.visible = !(camRelX < relX - 0.5);
      this.eastWallMesh.visible = !(camRelX > relX + 0.5);

      // Floor cutaways: ensure furniture on player's current floor and adjacent floor is visible
      if (relY < 3.2) {
        // Floor 1
        this.floor1Group.visible = true;
        this.floor2Group.visible = true;
        this.floor3Group.visible = false;
        this.floor4Group.visible = false;
      } else if (relY < 6.4) {
        // Floor 2
        this.floor1Group.visible = true;
        this.floor2Group.visible = true;
        this.floor3Group.visible = true;
        this.floor4Group.visible = false;
      } else if (relY < 9.6) {
        // Floor 3 (Armory)
        this.floor1Group.visible = false;
        this.floor2Group.visible = true;
        this.floor3Group.visible = true;
        this.floor4Group.visible = true;
      } else {
        // Floor 4 (Rooftop Pool)
        this.floor1Group.visible = false;
        this.floor2Group.visible = false;
        this.floor3Group.visible = true;
        this.floor4Group.visible = true;
      }
    } else {
      // Player is outside: all exterior walls and floors visible
      this.southWallMesh.visible = true;
      this.northWallMesh.visible = true;
      this.westWallMesh.visible = true;
      this.eastWallMesh.visible = true;
      this.floor1Group.visible = true;
      this.floor2Group.visible = true;
      this.floor3Group.visible = true;
      this.floor4Group.visible = true;
    }
  }

  // ==========================================
  // INTERACTION SYSTEM & DISCOVERY HOOKS
  // ==========================================
  public getInteraction(pos: THREE.Vector3): {
    id: 'bed' | 'phone' | 'fridge' | 'tv' | 'fan' | 'ac' | 'armory' | 'pool' | 'backyardPool' | 'door' | 'compoundGate' | 'garageDoor' | 'turret' | 'railwayOperations' | 'medicalClinic' | 'apartmentStatus';
    label: string;
    prompt: string;
  } | null {
    // 0. Sub-Level 1: Basement Railway Operations Console Desk
    if (this.basementRoom) {
      const bInteraction = this.basementRoom.getInteraction(pos);
      if (bInteraction) return bInteraction;
    }

    // 1. Sentry Turrets near main double gate entrance
    if (this.turrets) {
      const turretInteraction = this.turrets.getInteraction(pos);
      if (turretInteraction) return turretInteraction;
    }

    const relX = pos.x - this.origin.x;
    const relY = pos.y - this.origin.y;
    const relZ = pos.z - this.origin.z;

    // 2. Backyard Garage Shutter Switch at local (-9.2, 1.4, 10.5)
    if (Math.hypot(relX - (-9.2), relZ - 10.5) < 3.2 && relY < 3.2) {
      return {
        id: 'garageDoor',
        label: 'Backyard Private Garage',
        prompt: `Press [E] to ${this.garageShutterOpen ? 'Lower' : 'Raise'} Garage Door [${this.garageShutterOpen ? 'OPEN' : 'CLOSED'}]`,
      };
    }

    // Outer double gate and backyard pool are outside the apartment footprint.
    if (Math.abs(relX) < 4.2 && Math.abs(relZ + 22) < 2.8 && relY < 3.2) {
      return { id: 'compoundGate', label: 'Residential Compound Double Gate', prompt: `Press [E] to ${this.compoundGateOpen ? 'Close' : 'Open'} Property Gate` };
    }
    if (Math.abs(relX) < 5.8 && relZ > 16.0 && relZ < 27.0 && relY < 2.2) {
      return { id: 'backyardPool', label: 'Backyard Swimming Pool', prompt: 'Press [E] to Enter Backyard Swimming Pool' };
    }
    // Apartment interactions are limited to the building footprint.
    if (Math.abs(relX) > 11 || Math.abs(relZ) > 10) return null;

    // --- FLOOR 1 INTERACTIONS ---
    if (relY < 3.0) {
      // 1. Bed at (-5.5, 3.8)
      if (Math.hypot(relX - (-5.5), relZ - 3.8) < 2.4) {
        return { id: 'bed', label: 'Apartment Bed', prompt: 'Press [E] to Rest & Sleep in Bed' };
      }
      // 2. TV at (-5.5, 0.0)
      if (Math.hypot(relX - (-5.5), relZ - 0.0) < 2.5) {
        return {
          id: 'tv',
          label: 'Smart Television',
          prompt: `Press [E] to Turn ${this.state.tvOn ? 'OFF' : 'ON'} News Television`,
        };
      }
      // 3. Refrigerator at (4.5, 5.8)
      if (Math.hypot(relX - 4.5, relZ - 5.8) < 2.2) {
        return { id: 'fridge', label: 'Apartment Refrigerator', prompt: 'Press [E] to Open Refrigerator Food Storage' };
      }
      // 4. Smartphone on coffee table at (0.3, -1.2)
      if (Math.hypot(relX - 0.3, relZ - (-1.2)) < 2.0) {
        return { id: 'phone', label: 'Smartphone', prompt: 'Press [E] to Check In-Game Phone Messages' };
      }
      // 5. Ceiling fan switch
      if (Math.hypot(relX - 0, relZ - 0.5) < 2.2) {
        return {
          id: 'fan',
          label: 'Ceiling Fan',
          prompt: `Press [E] to ${this.state.fanOn ? 'Stop' : 'Start'} Ceiling Fan`,
        };
      }
      // 6. Air conditioner switch at (-2.5, -6.6)
      if (Math.hypot(relX - (-2.5), relZ - (-6.6)) < 2.2) {
        return {
          id: 'ac',
          label: 'Air Conditioner',
          prompt: `Press [E] to ${this.state.acOn ? 'Turn OFF' : 'Turn ON'} Air Conditioner`,
        };
      }
      // 7. Front entrance door at (0, -6.9)
      if (Math.hypot(relX - 0, relZ - (-6.9)) < 2.2) {
        return {
          id: 'door',
          label: 'Apartment Front Door',
          prompt: `Press [E] to ${this.state.doorOpen ? 'Close' : 'Open'} Entrance Door`,
        };
      }
      // 8. First-Floor Medical Clinic at (5.0, -5.6)
      if (Math.hypot(relX - 5.0, relZ - (-5.6)) < 2.9) {
        return {
          id: 'medicalClinic',
          label: 'First-Floor Sanctuary Medical Clinic',
          prompt: 'Press [E] to Access First-Floor Medical Section & Health Station',
        };
      }
      // 9. Ground Floor Apartment Management System Screen at (-1.8, -6.65)
      if (Math.hypot(relX - (-1.8), relZ - (-6.65)) < 2.6) {
        return {
          id: 'apartmentStatus',
          label: 'Sanctuary Apartment Building Management System',
          prompt: 'Press [E] to Access Apartment Systems Monitor & Security OS',
        };
      }
    }

    // --- FLOOR 3 (ARMORY) INTERACTIONS ---
    if (relY >= 6.0 && relY < 9.4) {
      if (Math.hypot(relX - 2.0, relZ - 0.0) < 3.2 || Math.hypot(relX - (-5.0), relZ - 0.0) < 4.0) {
        return {
          id: 'armory',
          label: 'Sector Armory & Weapon Vault',
          prompt: 'Press [E] to Access 100-Item Fictional Armory Vault',
        };
      }
    }

    // --- FLOOR 4 (ROOFTOP POOL) INTERACTIONS ---
    if (relY >= 9.2) {
      if (Math.hypot(relX - (-2.5), relZ - 0.0) < 5.0) {
        return {
          id: 'pool',
          label: 'Rooftop Swimming Pool',
          prompt: 'Press [E] to Dive into Rooftop Swimming Pool',
        };
      }
    }

    return null;
  }

  public toggleTV(forceState?: boolean, isEmergency: boolean = false): boolean {
    this.state.tvOn = forceState !== undefined ? forceState : !this.state.tvOn;
    this.updateTVScreenContent(this.state.tvOn, isEmergency);
    this.tvTexture.needsUpdate = true;
    soundEngine.playUIClick();
    return this.state.tvOn;
  }

  public toggleFan(): boolean {
    this.state.fanOn = !this.state.fanOn;
    soundEngine.playUIClick();
    return this.state.fanOn;
  }

  public toggleAC(): boolean {
    this.state.acOn = !this.state.acOn;
    this.acLedMat.color.setHex(this.state.acOn ? 0x00ff88 : 0x441111);
    soundEngine.playUIClick();
    return this.state.acOn;
  }

  public toggleDoor(): boolean {
    this.state.doorOpen = !this.state.doorOpen;
    if (this.frontDoorLeftLeaf && this.frontDoorRightLeaf) {
      // Both leaves swing away from the centre and stay synchronized.
      this.frontDoorLeftLeaf.rotation.y = this.state.doorOpen ? -Math.PI / 2 : 0;
      this.frontDoorRightLeaf.rotation.y = this.state.doorOpen ? Math.PI / 2 : 0;
    }
    UnifiedPhysicsManager.getInstance()?.setDoorOpenState('apt_front_door', this.state.doorOpen);
    soundEngine.playGateToggle(this.state.doorOpen);
    return this.state.doorOpen;
  }

  public toggleCompoundGate(): boolean {
    this.compoundGateOpen = !this.compoundGateOpen;
    if (this.compoundGateLeftLeaf && this.compoundGateRightLeaf) {
      this.compoundGateLeftLeaf.rotation.y = this.compoundGateOpen ? -Math.PI / 2 : 0;
      this.compoundGateRightLeaf.rotation.y = this.compoundGateOpen ? Math.PI / 2 : 0;
    }
    UnifiedPhysicsManager.getInstance()?.setDoorOpenState('apt_compound_gate', this.compoundGateOpen);
    soundEngine.playGateToggle(this.compoundGateOpen);
    return this.compoundGateOpen;
  }

  public toggleGarageShutter(): boolean {
    this.garageShutterOpen = !this.garageShutterOpen;
    if (this.garageShutterGroup) {
      this.garageShutterGroup.position.y = this.garageShutterOpen ? 2.7 : 1.35;
    }
    UnifiedPhysicsManager.getInstance()?.setDoorOpenState('apt_garage_shutter', this.garageShutterOpen);
    soundEngine.playGateToggle(this.garageShutterOpen);
    return this.garageShutterOpen;
  }

  public checkPlayerInPool(playerPos: THREE.Vector3): boolean {
    // Rooftop is a solid dry terrace; only the backyard pool is swimmable.
    const inRoofPool = false;
    const backyard = this.backyardPoolBounds;
    const inBackyardPool = playerPos.x >= this.origin.x + backyard.minX && playerPos.x <= this.origin.x + backyard.maxX &&
      playerPos.z >= this.origin.z + backyard.minZ && playerPos.z <= this.origin.z + backyard.maxZ &&
      playerPos.y >= backyard.minY && playerPos.y <= backyard.maxY + 1.2;
    return inRoofPool || inBackyardPool;
  }

  // ==========================================
  // UNIFIED PHYSICS COLLIDER REGISTRATION
  // ==========================================
  public registerColliders(physMgr: UnifiedPhysicsManager) {
    const ox = this.origin.x;
    const oz = this.origin.z;

    // IMPORTANT: floor slabs and stair flights are walkable surfaces, not walls.
    // PlayerController already computes the four floor heights and staircase
    // support. Registering these slabs as ordinary solid boxes made the movement
    // resolver push the player out through the nearest exterior wall.

    // 1. Exterior perimeter walls. The south wall intentionally has a 2m doorway.
    physMgr.registerBoxCollider('apt_wall_north', 'wall', [ox, 6.0, oz + 6.8], 16.0, 12.0, 0.6);
    physMgr.registerBoxCollider('apt_wall_east', 'wall', [ox + 7.8, 6.0, oz], 0.6, 12.0, 14.0);
    physMgr.registerBoxCollider('apt_wall_west', 'wall', [ox - 7.8, 6.0, oz], 0.6, 12.0, 14.0);
    physMgr.registerBoxCollider('apt_wall_south_l', 'wall', [ox - 4.5, 6.0, oz - 6.8], 7.0, 12.0, 0.6);
    physMgr.registerBoxCollider('apt_wall_south_r', 'wall', [ox + 4.5, 6.0, oz - 6.8], 7.0, 12.0, 0.6);

    // A single doorway collider is disabled while the double doors are open.
    // This keeps the entrance genuinely passable without making the doors ghostly
    // when the player closes them.
    physMgr.registerBoxCollider(
      'apt_front_door',
      'wall',
      [ox, 1.4, oz - 6.9],
      1.96,
      2.38,
      0.22,
      0,
      this.state.doorOpen
    );

    // 2. Rooftop pool basin walls. The water surface is a swim zone;
    // the dry deck remains supported at y=9.9 by PlayerController.
    physMgr.registerBoxCollider('apt_pool_rim_n', 'wall', [ox - 2.5, 9.0, oz - 2.92], 6.0, 1.9, 0.22);
    physMgr.registerBoxCollider('apt_pool_rim_w', 'wall', [ox - 5.42, 9.0, oz], 0.22, 1.9, 6.0);
    physMgr.registerBoxCollider('apt_pool_rim_e', 'wall', [ox + 0.42, 9.0, oz], 0.22, 1.9, 6.0);
    physMgr.registerBoxCollider('apt_pool_rim_s_l', 'wall', [ox - 3.65, 9.0, oz + 2.92], 3.7, 1.9, 0.22);
    physMgr.registerBoxCollider('apt_pool_rim_s_r', 'wall', [ox - 0.15, 9.0, oz + 2.92], 1.15, 1.9, 0.22);

    // 3. Fully enclosed residential compound. The front wall has a 5.1m double-gate opening.
    physMgr.registerBoxCollider('apt_compound_wall_west', 'wall', [ox - 19.0, 1.7, oz + 2.5], 0.65, 3.4, 49.0);
    physMgr.registerBoxCollider('apt_compound_wall_east', 'wall', [ox + 19.0, 1.7, oz + 2.5], 0.65, 3.4, 49.0);
    physMgr.registerBoxCollider('apt_compound_wall_rear', 'wall', [ox, 1.7, oz + 27.0], 38.5, 3.4, 0.65);
    physMgr.registerBoxCollider('apt_compound_wall_front_l', 'wall', [ox - 10.75, 1.7, oz - 22.0], 16.5, 3.4, 0.65);
    physMgr.registerBoxCollider('apt_compound_wall_front_r', 'wall', [ox + 10.75, 1.7, oz - 22.0], 16.5, 3.4, 0.65);
    physMgr.registerBoxCollider('apt_compound_gate', 'wall', [ox, 1.65, oz - 22.0], 5.1, 3.15, 0.28, 0, this.compoundGateOpen);

    // Backyard pool edge blockers. The water surface remains open for swimming.
    physMgr.registerBoxCollider('apt_backyard_pool_n', 'wall', [ox, 0.42, oz + 17.05], 11.2, 0.7, 0.45);
    physMgr.registerBoxCollider('apt_backyard_pool_s_l', 'wall', [ox - 3.4, 0.42, oz + 25.95], 4.5, 0.7, 0.45);
    physMgr.registerBoxCollider('apt_backyard_pool_s_r', 'wall', [ox + 3.4, 0.42, oz + 25.95], 4.5, 0.7, 0.45);
    physMgr.registerBoxCollider('apt_backyard_pool_w', 'wall', [ox - 5.55, 0.42, oz + 21.5], 0.45, 0.7, 8.9);
    physMgr.registerBoxCollider('apt_backyard_pool_e', 'wall', [ox + 5.55, 0.42, oz + 21.5], 0.45, 0.7, 8.9);

    // 4. Backyard Private Garage Colliders at local (-12.8, 0, 14.5)
    const gx = ox - 12.8;
    const gz = oz + 14.5;
    // Left outer wall
    physMgr.registerBoxCollider('apt_garage_wall_left', 'wall', [gx - 3.7, 1.5, gz], 0.3, 3.0, 8.6);
    // Rear outer wall
    physMgr.registerBoxCollider('apt_garage_wall_rear', 'wall', [gx, 1.5, gz + 4.3], 7.4, 3.0, 0.3);
    // Right wall (split with 1.4m open pedestrian doorway at gz to pool patio)
    physMgr.registerBoxCollider('apt_garage_wall_right_front', 'wall', [gx + 3.7, 1.5, gz - 2.4], 0.3, 3.0, 3.8);
    physMgr.registerBoxCollider('apt_garage_wall_right_rear', 'wall', [gx + 3.7, 1.5, gz + 2.4], 0.3, 3.0, 3.8);
    // Front roll-up shutter (open by default, so isOpen is true and movement is completely unhindered)
    physMgr.registerBoxCollider('apt_garage_shutter', 'door', [gx, 1.35, gz - 4.25], 6.4, 2.7, 0.2, 0, this.garageShutterOpen);

    // 5. Solid interior furniture on Floor 1.
    physMgr.registerBoxCollider('apt_bed', 'prop', [ox - 5.5, 0.45, oz + 3.8], 2.4, 0.9, 2.8);
    physMgr.registerBoxCollider('apt_sofa', 'prop', [ox, 0.55, oz + 0.5], 2.8, 0.85, 1.2);
    physMgr.registerBoxCollider('apt_tvstand', 'prop', [ox - 5.5, 0.45, oz], 2.4, 0.65, 0.6);
    physMgr.registerBoxCollider('apt_fridge', 'prop', [ox + 4.5, 1.2, oz + 5.8], 1.2, 2.2, 1.0);
    physMgr.registerBoxCollider('apt_kitchen', 'prop', [ox + 5.8, 0.55, oz + 3.2], 3.6, 0.9, 1.0);
    // First-Floor Medical Clinic furniture colliders
    physMgr.registerBoxCollider('apt_med_desk', 'prop', [ox + 3.8, 0.6, oz - 5.2], 1.4, 1.0, 0.8);
    physMgr.registerBoxCollider('apt_med_cabinet', 'prop', [ox + 3.8, 1.2, oz - 6.6], 1.2, 2.0, 0.5);
    physMgr.registerBoxCollider('apt_med_fridge', 'prop', [ox + 4.8, 1.1, oz - 6.6], 0.8, 2.0, 0.6);
    physMgr.registerBoxCollider('apt_med_exambed', 'prop', [ox + 6.2, 0.5, oz - 5.2], 1.0, 0.8, 2.0);
    physMgr.registerBoxCollider('apt_med_recovbed', 'prop', [ox + 6.2, 0.5, oz - 6.4], 1.0, 0.8, 1.8);

    // 6. Sub-Level 1: Basement Railway Operations Room Walls and Equipment (y = -4.0 to 0.0)
    physMgr.registerBoxCollider('apt_basement_wall_n', 'wall', [ox, -2.0, oz + 6.8], 16.0, 4.0, 0.6);
    physMgr.registerBoxCollider('apt_basement_wall_s', 'wall', [ox, -2.0, oz - 6.8], 16.0, 4.0, 0.6);
    physMgr.registerBoxCollider('apt_basement_wall_e', 'wall', [ox + 7.8, -2.0, oz], 0.6, 4.0, 14.0);
    physMgr.registerBoxCollider('apt_basement_wall_w', 'wall', [ox - 7.8, -2.0, oz], 0.6, 4.0, 14.0);
    physMgr.registerBoxCollider('apt_basement_desk', 'prop', [ox, -3.5, oz + 1.2], 4.8, 1.2, 1.4);
  }

  public dispose() {
    if (this.turrets) {
      this.turrets.dispose();
    }
    if (this.basementRoom) {
      this.basementRoom.dispose();
    }
    this.group.traverse((o) => {
      if (o instanceof THREE.Mesh) {
        o.geometry.dispose();
        if (Array.isArray(o.material)) o.material.forEach((m) => m.dispose());
        else o.material.dispose();
      }
    });
    this.floorLights = [];
  }
}
