/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { BiomeType, HarvestableResource } from '../../types/game';
import { TerrainGenerator } from './TerrainGenerator';
import { RoadGenerator } from './RoadGenerator';
import { getWoodPlankTexture, getStoneTexture, getMetalScrapTexture } from '../../utils/proceduralTextures';
import { getBarkPBR, getRockPBR } from '../rendering/ProceduralTextures';

export class VegetationGenerator {
  /**
   * Generates harvestable resources for a given chunk
   */
  public static generateResourcesForChunk(
    cx: number,
    cz: number,
    biome: BiomeType,
    worldSeed: number = 42
  ): HarvestableResource[] {
    const resources: HarvestableResource[] = [];
    const minX = cx * 256;
    const minZ = cz * 256;

    // Deterministic pseudo-random based on chunk coordinates
    let s = (cx * 73856093) ^ (cz * 19349663) ^ worldSeed;
    const rnd = () => {
      s = (s * 1664525 + 1013904223) % 4294967296;
      return Math.abs(s / 4294967296);
    };

    // Calculate count based on biome
    let treeCount = Math.floor(25 + rnd() * 30);
    let rockCount = Math.floor(15 + rnd() * 20);
    let scrapCount = Math.floor(10 + rnd() * 15);
    let berryCount = Math.floor(6 + rnd() * 10);

    if (biome === 'dense_forest' || biome === 'tropical_jungle' || biome === 'ancient_forest' || biome === 'bamboo_forest') {
      treeCount = Math.floor((biome === 'tropical_jungle' || biome === 'ancient_forest' ? 72 : 65) + rnd() * 25);
    } else if (biome === 'savanna') {
      treeCount = Math.floor(5 + rnd() * 7);
    } else if (biome === 'volcanic_lands') {
      treeCount = Math.floor(1 + rnd() * 3);
      rockCount = Math.floor(48 + rnd() * 20);
    } else if (biome === 'snow_forest' || biome === 'autumn_forest') {
      treeCount = Math.floor(42 + rnd() * 22);
    } else if (biome === 'desert') {
      treeCount = Math.floor(2 + rnd() * 4);
      rockCount = Math.floor(35 + rnd() * 20);
    } else if (biome === 'mountain_range' || biome === 'snow_peaks') {
      rockCount = Math.floor(55 + rnd() * 25);
      treeCount = Math.floor(15 + rnd() * 15);
    } else if (biome === 'industrial_zone' || biome === 'abandoned_city') {
      scrapCount = Math.floor(40 + rnd() * 20);
      treeCount = Math.floor(6 + rnd() * 8);
    }

    let idCounter = 1;

    // Helper to add resource safely avoiding roads & riverbeds
    const tryAddResource = (
      type: HarvestableResource['type'],
      yieldItem: string,
      yieldAmount: number,
      reqTool: HarvestableResource['requiredTool']
    ) => {
      const rx = minX + 12 + rnd() * 232;
      const rz = minZ + 12 + rnd() * 232;

      // Don't place on roads
      if (RoadGenerator.isRoad(rx, rz).isRoad) return;

      // Don't place underwater in river
      const riverDist = Math.abs(rx - 50 - Math.sin(rz * 0.004) * 45);
      if (riverDist < 14) return;

      // Don't place inside Starter Sanctuary clearing at (0, 0)
      if (cx === 0 && cz === 0 && Math.hypot(rx, rz) < 26) return;

      const y = TerrainGenerator.getHeight(rx, rz, worldSeed);

      resources.push({
        id: `c_${cx}_${cz}_${type}_${idCounter++}`,
        type,
        position: [rx, y, rz],
        health: type === 'tree' ? 100 : type === 'rock' ? 120 : type === 'metal_scrap' ? 80 : 40,
        maxHealth: type === 'tree' ? 100 : type === 'rock' ? 120 : type === 'metal_scrap' ? 80 : 40,
        yieldItem,
        yieldAmount,
        requiredTool: reqTool,
      });
    };

    // 1. Trees
    for (let i = 0; i < treeCount; i++) {
      tryAddResource('tree', 'wood', 4, 'axe');
    }

    // 2. Granite Rocks
    for (let i = 0; i < rockCount; i++) {
      tryAddResource('rock', 'stone', 3, 'pickaxe');
    }

    // 3. Scrap Metal
    for (let i = 0; i < scrapCount; i++) {
      tryAddResource('metal_scrap', 'metal_scrap', 3, 'pickaxe');
    }

    // 4. Berry Bushes
    for (let i = 0; i < berryCount; i++) {
      tryAddResource('berry_bush', 'wild_berries', 3, 'none');
    }

    return resources;
  }

  /**
   * Instantiates the 3D model for a harvestable resource
   */
  public static createResourceMesh(res: HarvestableResource, biome?: BiomeType): THREE.Group {
    const group = new THREE.Group();
    group.name = res.id;

    const barkPBR = getBarkPBR();
    barkPBR.albedo.repeat.set(1, 3);
    barkPBR.normal.repeat.set(1, 3);
    barkPBR.roughness.repeat.set(1, 3);

    const woodMat = new THREE.MeshStandardMaterial({
      map: barkPBR.albedo,
      normalMap: barkPBR.normal,
      roughnessMap: barkPBR.roughness,
      roughness: 0.88,
      metalness: 0.05,
    });

    const rockPBR = getRockPBR();
    rockPBR.albedo.repeat.set(2, 2);
    rockPBR.normal.repeat.set(2, 2);
    rockPBR.roughness.repeat.set(2, 2);

    const stoneMat = new THREE.MeshStandardMaterial({
      map: rockPBR.albedo,
      normalMap: rockPBR.normal,
      roughnessMap: rockPBR.roughness,
      roughness: 0.85,
      metalness: 0.1,
    });

    const scrapMat = new THREE.MeshStandardMaterial({
      map: getMetalScrapTexture(),
      roughness: 0.55,
      metalness: 0.75,
    });

    if (res.type === 'tree') {
      // Realistic composite tree: flared root collar, tapered trunk, multi-tiered leafy crowns
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.46, 4.2, 8), woodMat);
      trunk.position.y = 2.1;
      trunk.castShadow = true;
      group.add(trunk);

      // Flared root base
      const rootBase = new THREE.Mesh(new THREE.CylinderGeometry(0.46, 0.72, 0.6, 8), woodMat);
      rootBase.position.y = 0.3;
      rootBase.castShadow = true;
      group.add(rootBase);

      const foliageColor = biome === 'autumn_forest' ? 0xb55a21 : biome === 'snow_forest' || biome === 'snow_peaks' ? 0x48615e : biome === 'savanna' ? 0x7a853a : biome === 'bamboo_forest' ? 0x4b8a3b : biome === 'tropical_jungle' ? 0x165c2b : biome === 'ancient_forest' ? 0x1e3f23 : 0x1d4023;
      const foliageMat = new THREE.MeshStandardMaterial({
        color: foliageColor,
        roughness: 0.85,
        metalness: 0.05,
      });

      if (biome === 'bamboo_forest') {
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.16, 9.0, 6), new THREE.MeshStandardMaterial({ color: 0x6e9145, roughness: 0.75 }));
        pole.position.y = 4.5;
        pole.castShadow = true;
        group.add(pole);
        for (let j = 0; j < 6; j++) {
          const ring = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.025, 4, 8), foliageMat);
          ring.rotation.x = Math.PI / 2;
          ring.position.set(0, 1.2 + j * 1.45, 0);
          group.add(ring);
        }
      } else if (biome === 'savanna') {
        const crown = new THREE.Mesh(new THREE.CylinderGeometry(2.8, 1.2, 0.8, 8), foliageMat);
        crown.position.y = 4.8;
        crown.castShadow = true;
        const subCrown = new THREE.Mesh(new THREE.CylinderGeometry(2.1, 0.9, 0.7, 8), foliageMat);
        subCrown.position.set(0.6, 5.4, 0.3);
        subCrown.castShadow = true;
        group.add(crown, subCrown);
      } else if (biome === 'tropical_jungle' || biome === 'ancient_forest') {
        const rad = biome === 'ancient_forest' ? 3.4 : 2.6;
        const crown = new THREE.Mesh(new THREE.DodecahedronGeometry(rad, 1), foliageMat);
        crown.scale.set(1.1, 0.95, 1.05);
        crown.position.y = biome === 'ancient_forest' ? 7.2 : 5.4;
        crown.castShadow = true;
        group.add(crown);
      } else {
        // Coniferous Pine with layered skirt tiers
        const t1 = new THREE.Mesh(new THREE.ConeGeometry(2.5, 2.8, 8), foliageMat);
        t1.position.y = 3.8;
        t1.castShadow = true;
        const t2 = new THREE.Mesh(new THREE.ConeGeometry(1.9, 2.4, 8), foliageMat);
        t2.position.y = 5.2;
        t2.castShadow = true;
        const t3 = new THREE.Mesh(new THREE.ConeGeometry(1.2, 2.0, 7), foliageMat);
        t3.position.y = 6.6;
        t3.castShadow = true;
        group.add(t1, t2, t3);
      }
    } else if (res.type === 'rock') {
      // Faceted weathered granite boulder with fractured sub-rocks
      const mainRock = new THREE.Mesh(new THREE.DodecahedronGeometry(1.25, 1), stoneMat);
      mainRock.position.y = 0.85;
      mainRock.rotation.set(0.2, 0.4, 0.1);
      mainRock.castShadow = true;

      const sub1 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.75, 1), stoneMat);
      sub1.position.set(0.85, 0.45, 0.35);
      sub1.rotation.set(0.4, 0.1, 0.5);
      sub1.castShadow = true;

      const sub2 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.55, 0), stoneMat);
      sub2.position.set(-0.75, 0.35, -0.45);
      sub2.castShadow = true;

      group.add(mainRock, sub1, sub2);
    } else if (res.type === 'metal_scrap') {
      // Rusted vehicular debris & twisted steel girder
      const chassis = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.55, 1.3), scrapMat);
      chassis.position.y = 0.35;
      chassis.rotation.z = 0.12;
      chassis.castShadow = true;

      const beam = new THREE.Mesh(new THREE.BoxGeometry(0.22, 2.0, 0.22), scrapMat);
      beam.position.set(0.65, 0.85, 0.25);
      beam.rotation.x = 0.38;
      beam.castShadow = true;

      const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.25, 10), scrapMat);
      rim.position.set(-0.7, 0.3, 0.6);
      rim.rotation.x = Math.PI / 2;
      rim.castShadow = true;

      group.add(chassis, beam, rim);
    } else if (res.type === 'berry_bush') {
      // Organic tangled foliage bush with ripe glistening berries
      const leafMat = new THREE.MeshStandardMaterial({ color: 0x2b5728, roughness: 0.85 });
      const berryMat = new THREE.MeshStandardMaterial({ color: 0xc41427, roughness: 0.25, metalness: 0.1 });

      const bush = new THREE.Mesh(new THREE.DodecahedronGeometry(0.8, 1), leafMat);
      bush.position.y = 0.65;
      bush.scale.set(1.1, 0.8, 1.05);
      bush.castShadow = true;

      const berry1 = new THREE.Mesh(new THREE.SphereGeometry(0.14, 6, 6), berryMat);
      berry1.position.set(0.35, 0.85, 0.42);
      const berry2 = new THREE.Mesh(new THREE.SphereGeometry(0.13, 6, 6), berryMat);
      berry2.position.set(-0.38, 0.75, -0.32);
      const berry3 = new THREE.Mesh(new THREE.SphereGeometry(0.12, 6, 6), berryMat);
      berry3.position.set(0.1, 0.95, -0.4);

      group.add(bush, berry1, berry2, berry3);
    }

    group.position.set(res.position[0], res.position[1], res.position[2]);
    return group;
  }
}
