/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BiomeDefinition, BiomeType } from '../../types/game';

export const BIOMES: Record<BiomeType, BiomeDefinition> = {
  dense_forest: {
    id: 'dense_forest',
    name: 'Pinecone Wildwood',
    description: 'Thick, ancient conifer forest with towering pines and abundant timber resources.',
    groundColor: 0x2b4a2b,
    fogColor: 0x415b49,
    foliageColor: 0x1f3b23,
    temperature: 18,
    elevationMultiplier: 1.0,
    roughness: 0.6,
    treeDensity: 0.85,
    rockDensity: 0.35,
    scrapDensity: 0.15,
    zombieThreatLevel: 2,
  },
  green_plains: {
    id: 'green_plains',
    name: 'Verdant Meadowlands',
    description: 'Expansive rolling grasslands, fertile soil, and open sightlines ideal for survival building.',
    groundColor: 0x4e7a3e,
    fogColor: 0x7aa579,
    foliageColor: 0x3d6630,
    temperature: 22,
    elevationMultiplier: 0.4,
    roughness: 0.25,
    treeDensity: 0.3,
    rockDensity: 0.2,
    scrapDensity: 0.15,
    zombieThreatLevel: 1,
  },
  abandoned_city: {
    id: 'abandoned_city',
    name: 'Metropolis Ruins',
    description: 'Crumbling skyscrapers, overgrown asphalt avenues, and high-value salvaged electronics.',
    groundColor: 0x3a3c3e,
    fogColor: 0x484b4d,
    foliageColor: 0x3f4f3a,
    temperature: 19,
    elevationMultiplier: 0.2,
    roughness: 0.15,
    treeDensity: 0.15,
    rockDensity: 0.3,
    scrapDensity: 0.95,
    zombieThreatLevel: 4,
  },
  small_village: {
    id: 'small_village',
    name: 'Rural Settlement',
    description: 'Clustered rustic homes, community stores, and pre-war survivor stockpiles.',
    groundColor: 0x4f6b45,
    fogColor: 0x6e8766,
    foliageColor: 0x36542f,
    temperature: 20,
    elevationMultiplier: 0.35,
    roughness: 0.3,
    treeDensity: 0.4,
    rockDensity: 0.25,
    scrapDensity: 0.6,
    zombieThreatLevel: 2,
  },
  farmland: {
    id: 'farmland',
    name: 'Golden Valley Agrarian Fields',
    description: 'Irrigated crop fields, old silos, and wild berry bushes with rich organic harvest.',
    groundColor: 0x5a6d3f,
    fogColor: 0x82916b,
    foliageColor: 0x66783c,
    temperature: 23,
    elevationMultiplier: 0.25,
    roughness: 0.2,
    treeDensity: 0.25,
    rockDensity: 0.15,
    scrapDensity: 0.3,
    zombieThreatLevel: 2,
  },
  industrial_zone: {
    id: 'industrial_zone',
    name: 'Ironworks Industrial Complex',
    description: 'Heavy manufacturing plants, refineries, scrap yards, and structural steel beams.',
    groundColor: 0x333538,
    fogColor: 0x4b4640,
    foliageColor: 0x2b382d,
    temperature: 16,
    elevationMultiplier: 0.3,
    roughness: 0.2,
    treeDensity: 0.1,
    rockDensity: 0.4,
    scrapDensity: 0.9,
    zombieThreatLevel: 4,
  },
  mountain_range: {
    id: 'mountain_range',
    name: 'Craggy Highlands',
    description: 'Dramatic granite peaks, quarry cliffs, deep fissures, and mineral veins.',
    groundColor: 0x5a5856,
    fogColor: 0x6b7178,
    foliageColor: 0x273629,
    temperature: 8,
    elevationMultiplier: 2.8,
    roughness: 0.95,
    treeDensity: 0.3,
    rockDensity: 0.95,
    scrapDensity: 0.2,
    zombieThreatLevel: 3,
  },
  valley: {
    id: 'valley',
    name: 'Mistwood Hollow',
    description: 'Sheltered lowlands nestled between ridges with moderate climate and steady wind.',
    groundColor: 0x42613d,
    fogColor: 0x66856a,
    foliageColor: 0x2d4d29,
    temperature: 20,
    elevationMultiplier: 0.5,
    roughness: 0.4,
    treeDensity: 0.6,
    rockDensity: 0.35,
    scrapDensity: 0.3,
    zombieThreatLevel: 2,
  },
  river_basin: {
    id: 'river_basin',
    name: 'Willow River Watershed',
    description: 'Winding freshwater tributary flanked by fertile banks, gravel bars, and water reeds.',
    groundColor: 0x3f5c40,
    fogColor: 0x597870,
    foliageColor: 0x305234,
    temperature: 21,
    elevationMultiplier: 0.2,
    roughness: 0.3,
    treeDensity: 0.5,
    rockDensity: 0.45,
    scrapDensity: 0.25,
    zombieThreatLevel: 2,
    waterColor: 0x1f5c7a,
  },
  lake_district: {
    id: 'lake_district',
    name: 'Emerald Water Basin',
    description: 'Scenic expansive freshwater lake surrounded by clay banks and wooden docks.',
    groundColor: 0x38523b,
    fogColor: 0x537780,
    foliageColor: 0x294a2e,
    temperature: 19,
    elevationMultiplier: 0.15,
    roughness: 0.25,
    treeDensity: 0.45,
    rockDensity: 0.3,
    scrapDensity: 0.2,
    zombieThreatLevel: 2,
    waterColor: 0x174d6b,
  },
  coastline: {
    id: 'coastline',
    name: 'Driftwood Shoreline',
    description: 'Sandy dunes, sea-weathered timber, and coastal winds opening into the ocean shelf.',
    groundColor: 0xb59e6d,
    fogColor: 0x8ab8c7,
    foliageColor: 0x5e734a,
    temperature: 24,
    elevationMultiplier: 0.1,
    roughness: 0.2,
    treeDensity: 0.2,
    rockDensity: 0.35,
    scrapDensity: 0.4,
    zombieThreatLevel: 2,
    waterColor: 0x166885,
  },
  island: {
    id: 'island',
    name: 'Isolated Archipelago',
    description: 'Natural sanctuary surrounded on all sides by deep water; excellent natural moat.',
    groundColor: 0x486b45,
    fogColor: 0x6e9ea8,
    foliageColor: 0x2e5730,
    temperature: 23,
    elevationMultiplier: 0.4,
    roughness: 0.45,
    treeDensity: 0.55,
    rockDensity: 0.5,
    scrapDensity: 0.25,
    zombieThreatLevel: 1,
    waterColor: 0x135978,
  },
  desert: {
    id: 'desert',
    name: 'Scorched Dunes Wastes',
    description: 'Arid sandstone dunes, blazing sun, dehydration danger, and exposed mineral deposits.',
    groundColor: 0xc49a56,
    fogColor: 0xbfa37a,
    foliageColor: 0x85774a,
    temperature: 36,
    elevationMultiplier: 0.8,
    roughness: 0.5,
    treeDensity: 0.05,
    rockDensity: 0.6,
    scrapDensity: 0.35,
    zombieThreatLevel: 3,
  },
  snow_peaks: {
    id: 'snow_peaks',
    name: 'Glacial Summit',
    description: 'Sub-zero blizzards, frost-covered pines, hypothermia risk, and silent frozen expanses.',
    groundColor: 0xd9e3eb,
    fogColor: 0xc9d4de,
    foliageColor: 0x5c7069,
    temperature: -5,
    elevationMultiplier: 2.5,
    roughness: 0.8,
    treeDensity: 0.4,
    rockDensity: 0.7,
    scrapDensity: 0.15,
    zombieThreatLevel: 3,
  },
  wetlands: {
    id: 'wetlands',
    name: 'Sunken Marshlands',
    description: 'Muddy bogs, weeping willows, murky standing water, and abundant medical herbal flora.',
    groundColor: 0x384732,
    fogColor: 0x4c5e47,
    foliageColor: 0x2b422a,
    temperature: 21,
    elevationMultiplier: 0.15,
    roughness: 0.35,
    treeDensity: 0.55,
    rockDensity: 0.2,
    scrapDensity: 0.35,
    zombieThreatLevel: 3,
    waterColor: 0x2b4238,
  },
  cave_system: {
    id: 'cave_system',
    name: 'Subterranean Cavern Outcrop',
    description: 'Dark limestone hollows, subterranean drippings, sheltered from surface storms.',
    groundColor: 0x3b3735,
    fogColor: 0x2e2926,
    foliageColor: 0x243325,
    temperature: 14,
    elevationMultiplier: 1.2,
    roughness: 0.85,
    treeDensity: 0.1,
    rockDensity: 0.95,
    scrapDensity: 0.4,
    zombieThreatLevel: 4,
  },
  subway_tunnels: {
    id: 'subway_tunnels',
    name: 'Metro Underground Transit',
    description: 'Old concrete tunnel arteries connecting city sectors; infested with lurking screamers.',
    groundColor: 0x2b2b2b,
    fogColor: 0x212121,
    foliageColor: 0x1f2b20,
    temperature: 15,
    elevationMultiplier: 0.2,
    roughness: 0.1,
    treeDensity: 0.05,
    rockDensity: 0.3,
    scrapDensity: 0.9,
    zombieThreatLevel: 5,
  },
  research_facility: {
    id: 'research_facility',
    name: 'Apex Bio-Tech Complex',
    description: 'High-security containment labs, satellite comms, military caches, and brute variants.',
    groundColor: 0x42464a,
    fogColor: 0x3d434a,
    foliageColor: 0x26382b,
    temperature: 18,
    elevationMultiplier: 0.3,
    roughness: 0.15,
    treeDensity: 0.15,
    rockDensity: 0.35,
    scrapDensity: 0.85,
    zombieThreatLevel: 5,
  },
  tropical_jungle: { id: 'tropical_jungle', name: 'Emerald Rainforest', description: 'Dense humid jungle with layered canopy, vines and tropical wildlife.', groundColor: 0x315b35, fogColor: 0x54765b, foliageColor: 0x174b29, temperature: 29, elevationMultiplier: 0.65, roughness: 0.55, treeDensity: 0.95, rockDensity: 0.2, scrapDensity: 0.1, zombieThreatLevel: 2 },
  savanna: { id: 'savanna', name: 'Sunfire Savanna', description: 'Wide golden grasslands dotted with acacia trees and watering holes.', groundColor: 0x9a8747, fogColor: 0xb8a36c, foliageColor: 0x6c7837, temperature: 31, elevationMultiplier: 0.25, roughness: 0.3, treeDensity: 0.12, rockDensity: 0.25, scrapDensity: 0.12, zombieThreatLevel: 1 },
  snow_forest: { id: 'snow_forest', name: 'Frostpine Woods', description: 'Snow-laden evergreen forest with frozen clearings and sheltered dens.', groundColor: 0xcbd7df, fogColor: 0xb9cbd5, foliageColor: 0x405d58, temperature: -8, elevationMultiplier: 0.75, roughness: 0.7, treeDensity: 0.72, rockDensity: 0.35, scrapDensity: 0.12, zombieThreatLevel: 2 },
  autumn_forest: { id: 'autumn_forest', name: 'Copperleaf Forest', description: 'Amber and russet woodland with open glades and abundant small wildlife.', groundColor: 0x80633d, fogColor: 0x9c8060, foliageColor: 0xa45c26, temperature: 13, elevationMultiplier: 0.55, roughness: 0.45, treeDensity: 0.7, rockDensity: 0.25, scrapDensity: 0.16, zombieThreatLevel: 1 },
  volcanic_lands: { id: 'volcanic_lands', name: 'Ashfall Caldera', description: 'Dark basalt fields, ash-covered slopes and glowing volcanic fissures.', groundColor: 0x393332, fogColor: 0x66504a, foliageColor: 0x514735, temperature: 42, elevationMultiplier: 1.5, roughness: 0.95, treeDensity: 0.04, rockDensity: 0.95, scrapDensity: 0.22, zombieThreatLevel: 4 },
  ancient_forest: { id: 'ancient_forest', name: 'Elderroot Wilds', description: 'Primeval giant trees, mossy stones and quiet forest clearings.', groundColor: 0x344c35, fogColor: 0x526957, foliageColor: 0x25452a, temperature: 16, elevationMultiplier: 0.9, roughness: 0.65, treeDensity: 0.92, rockDensity: 0.4, scrapDensity: 0.12, zombieThreatLevel: 2 },
  bamboo_forest: { id: 'bamboo_forest', name: 'Whispering Bamboo', description: 'Tall bamboo groves, shaded paths and mountain-fed streams.', groundColor: 0x557448, fogColor: 0x789174, foliageColor: 0x4b8a3b, temperature: 22, elevationMultiplier: 0.5, roughness: 0.35, treeDensity: 0.88, rockDensity: 0.22, scrapDensity: 0.1, zombieThreatLevel: 1 },
  dinosaur_valley: { id: 'dinosaur_valley', name: 'Lost World Basin', description: 'A remote prehistoric preserve with giant cycads, fern fields and ancient creatures.', groundColor: 0x53613a, fogColor: 0x75805a, foliageColor: 0x3c582c, temperature: 27, elevationMultiplier: 0.85, roughness: 0.5, treeDensity: 0.68, rockDensity: 0.5, scrapDensity: 0.08, zombieThreatLevel: 2 },
};

/** Fifteen featured exploration environments. Existing settlement and underground biomes remain as supporting sub-regions. */
export const FEATURED_ENVIRONMENTS = [
  { name: 'Tropical Jungle', biome: 'tropical_jungle' as BiomeType, wildlife: 'Monkeys, parrots and wild boar' },
  { name: 'African Savanna', biome: 'savanna' as BiomeType, wildlife: 'Elephants, zebras and lions' },
  { name: 'Snow Forest', biome: 'snow_forest' as BiomeType, wildlife: 'Wolves, bears and foxes' },
  { name: 'Desert', biome: 'desert' as BiomeType, wildlife: 'Camels and desert foxes' },
  { name: 'Tropical Island', biome: 'island' as BiomeType, wildlife: 'Parrots, turtles and crabs' },
  { name: 'Swampland', biome: 'wetlands' as BiomeType, wildlife: 'Crocodiles, turtles and crabs' },
  { name: 'Mountains', biome: 'mountain_range' as BiomeType, wildlife: 'Mountain goats and eagles' },
  { name: 'Autumn Forest', biome: 'autumn_forest' as BiomeType, wildlife: 'Deer, foxes and rabbits' },
  { name: 'Ocean Coast', biome: 'coastline' as BiomeType, wildlife: 'Turtles and shore crabs' },
  { name: 'Volcanic Lands', biome: 'volcanic_lands' as BiomeType, wildlife: 'Sparse highland wildlife' },
  { name: 'Ancient Forest', biome: 'ancient_forest' as BiomeType, wildlife: 'Deer, bears and wild boar' },
  { name: 'Countryside', biome: 'farmland' as BiomeType, wildlife: 'Cows, horses and chickens' },
  { name: 'Abandoned City', biome: 'abandoned_city' as BiomeType, wildlife: 'Foxes and rabbits' },
  { name: 'Bamboo Forest', biome: 'bamboo_forest' as BiomeType, wildlife: 'Pandas and monkeys' },
  { name: 'Dinosaur Valley', biome: 'dinosaur_valley' as BiomeType, wildlife: 'Prehistoric creatures' },
] as const;

export class BiomeGenerator {
  /**
   * Deterministically samples temperature, moisture, and continental noise to select a biome at (x, z)
   */
  public static getBiomeAt(x: number, z: number, seed: number = 42): BiomeDefinition {
    // Sanctuary Base safe clearing around origin (0, 0)
    const distFromOrigin = Math.hypot(x, z);
    if (distFromOrigin < 160) {
      return BIOMES.green_plains;
    }

    // Macro continental noise (scale: ~1200m)
    const cX = x * 0.0008;
    const cZ = z * 0.0008;
    const tempNoise = Math.sin(cX + seed * 3.1) * Math.cos(cZ + seed * 1.7);
    const moistNoise = Math.cos(cX * 1.3 - seed * 2.3) * Math.sin(cZ * 1.1 + seed * 4.9);
    const elevNoise = Math.sin(cX * 0.7 + cZ * 0.5 + seed);

    // River distance approximation
    const riverNoise = Math.abs(Math.sin(x * 0.003 + Math.cos(z * 0.002) * 2.5));
    if (riverNoise < 0.035 && distFromOrigin > 100) {
      return BIOMES.river_basin;
    }

    // High elevation -> Mountain Range or Snow Peaks
    if (elevNoise > 0.65) {
      return tempNoise < -0.1 ? BIOMES.snow_peaks : BIOMES.mountain_range;
    }

    // Arid / Hot -> Desert
    if (tempNoise > 0.45 && moistNoise < -0.2) {
      return BIOMES.desert;
    }

    // Wet & Low -> Wetlands
    if (moistNoise > 0.4 && elevNoise < -0.3) {
      return BIOMES.wetlands;
    }

    // Deep water / Ocean -> Coastline / Island
    if (elevNoise < -0.65) {
      return moistNoise > 0.2 ? BIOMES.island : BIOMES.coastline;
    }

    // Additional large-scale regions are selected before the generic cold/forest fallback.
    // Their noise is deterministic, so adjacent chunks remain visually consistent.
    const regionNoise = Math.sin(cX * 0.83 + seed * 0.37) * Math.cos(cZ * 0.91 - seed * 0.21);
    const regionHash = Math.abs(Math.sin(Math.floor(x / 1800) * 19.19 + Math.floor(z / 1800) * 73.73 + seed * 0.13) * 10000) % 1;
    if (distFromOrigin > 900 && tempNoise < -0.55 && moistNoise > -0.15) return BIOMES.snow_forest;
    if (distFromOrigin > 900 && regionNoise > 0.76) return BIOMES.tropical_jungle;
    if (distFromOrigin > 900 && regionNoise < -0.78) return BIOMES.savanna;
    if (distFromOrigin > 900 && regionHash > 0.97) return BIOMES.volcanic_lands;
    if (distFromOrigin > 900 && regionHash > 0.94) return BIOMES.dinosaur_valley;
    if (distFromOrigin > 900 && regionHash > 0.90) return BIOMES.bamboo_forest;
    if (distFromOrigin > 900 && regionHash > 0.86) return BIOMES.autumn_forest;
    if (distFromOrigin > 900 && regionHash > 0.82) return BIOMES.ancient_forest;

    // Cold -> Valley or Dense Forest
    if (tempNoise < -0.3) {
      return moistNoise > 0 ? BIOMES.dense_forest : BIOMES.valley;
    }

    // Civilized structures: POI clusters based on secondary grid
    const poiGridX = Math.floor((x + 500) / 700);
    const poiGridZ = Math.floor((z + 500) / 700);
    const poiHash = Math.abs(Math.sin(poiGridX * 37.1 + poiGridZ * 91.3 + seed) * 10000) % 1;

    if (distFromOrigin > 300) {
      if (poiHash > 0.88) return BIOMES.abandoned_city;
      if (poiHash > 0.78) return BIOMES.research_facility;
      if (poiHash > 0.68) return BIOMES.industrial_zone;
      if (poiHash > 0.58) return BIOMES.small_village;
      if (poiHash > 0.48) return BIOMES.farmland;
    }

    // Lake cluster
    const lakeNoise = Math.sin(x * 0.005) * Math.cos(z * 0.005);
    if (lakeNoise > 0.75 && distFromOrigin > 250) {
      return BIOMES.lake_district;
    }

    // Default to lush forests or green plains
    return moistNoise > 0.0 ? BIOMES.dense_forest : BIOMES.green_plains;
  }
}
