import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { WorldTerrain, getTerrainHeight } from './Terrain';
import { BuildingManager } from './BuildingManager';
import { ZombieManager } from './ZombieManager';
import { PlayerController } from './PlayerController';
import { soundEngine } from '../utils/audio';
import { 
  HarvestableResource, 
  PlacedStructure, 
  PlayerStats, 
  Quest, 
  SaveSlotMetadata, 
  FullGameSave, 
  GameMode, 
  Difficulty, 
  ItemDefinition,
  GraphicsQuality,
  VehicleState,
  BaseState,
  MapWaypoint,
  NPCRole
} from '../types/game';
import { ITEMS } from '../data/items';
import { saveGameToSlot } from '../utils/storage';
import { ChunkManager } from './world/ChunkManager';
import { WorldPersistence } from './world/WorldPersistence';
import { BaseManager } from './base/BaseManager';
import { TerrainGenerator } from './world/TerrainGenerator';
import { WildlifeManager } from './world/WildlifeManager';
import { AtmosphericSky } from './rendering/AtmosphericSky';
import { getWaterRippleNormalMap } from './rendering/ProceduralTextures';

export interface GameEngineCallbacks {
  onStatsChange: (stats: PlayerStats) => void;
  onTimeChange: (timeMinutes: number, dayCount: number, isNight: boolean, isDusk: boolean) => void;
  onHordeEvent: (event: 'dusk_warning' | 'night_horde_start' | 'dawn_victory' | null) => void;
  onInteractionPrompt: (prompt: string | null) => void;
  onQuestsUpdate: (quests: Quest[]) => void;
  onOpenStorage: (struct: PlacedStructure) => void;
  onOpenCrafting: (stationType?: string) => void;
  onResourceHarvested: (res: HarvestableResource, item: ItemDefinition, amount: number) => void;
  onItemCollected: (itemId: string, count: number) => void;
  onOpenNoticeBoard: () => void;
  onOpenBaseDashboard?: () => void;
  onVehicleStateChange?: (state: VehicleState, isDriving: boolean, speed: number) => void;
  onBiomeChange?: (biomeName: string, temp: number) => void;
  onGameOver: () => void;
}

export class GameEngine {
  public container: HTMLDivElement;
  public renderer: THREE.WebGLRenderer;
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;

  // Subsystems
  public terrain: WorldTerrain;
  public chunkMgr: ChunkManager;
  public persistence: WorldPersistence;
  public baseMgr: BaseManager;
  public buildingMgr: BuildingManager;
  public zombieMgr: ZombieManager;
  public wildlifeMgr: WildlifeManager;
  public player: PlayerController;

  // Graphics & Driving
  public graphicsQuality: GraphicsQuality = 'medium';
  public isDriving: boolean = false;
  private sentryCooldown: number = 0;

  // Environment & Lights
  private dirLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;
  private pmremGenerator: THREE.PMREMGenerator;
  public atmosphericSky: AtmosphericSky;

  // Time & Horde Simulation
  public gameTimeMinutes: number = 480; // 08:00 AM
  public dayCount: number = 1;
  public isNight: boolean = false;
  public isDusk: boolean = false;
  private duskWarningFired: boolean = false;
  private hordeWaveTimer: number = 0;
  private dawnVictoryFired: boolean = false;
  public nightHordesDefeated: number = 0;

  // Player RPG stats & inventory
  public playerStats: PlayerStats;
  public quests: Quest[];
  public activeSlotItem: ItemDefinition | null = null;
  public gameMode: GameMode = 'survival';
  public difficulty: Difficulty = 'standard';

  // Game Loop Controls
  private isRunning: boolean = false;
  private isPaused: boolean = false;
  private frameId: number = 0;
  private clock: THREE.Clock;
  private callbacks: GameEngineCallbacks;
  private autoSaveTimer: number = 0;

  // Input State
  public inputState = {
    forward: false,
    backward: false,
    left: false,
    right: false,
    jump: false,
    sprint: false,
    analogX: 0,
    analogZ: 0,
    isAnalog: false,
  };

  // Crosshair Raycaster
  private raycaster: THREE.Raycaster = new THREE.Raycaster();
  private screenCenter: THREE.Vector2 = new THREE.Vector2(0, 0);

  // Software WebGL flag
  public isSoftwareGl: boolean = false;

  constructor(
    container: HTMLDivElement,
    initialSave: FullGameSave | null,
    callbacks: GameEngineCallbacks
  ) {
    this.container = container;
    this.callbacks = callbacks;
    this.clock = new THREE.Clock();

    // 1. Detect Software WebGL
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Initialize Three.js Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 1.5)
    );
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(this.renderer.domElement);

    // 3. Scene & Camera
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x87ceeb); // daytime sky blue
    this.scene.fog = new THREE.FogExp2(0x87ceeb, 0.012);

    this.camera = new THREE.PerspectiveCamera(
      70,
      container.clientWidth / container.clientHeight,
      0.1,
      400
    );

    // 4. Studio Environment Reflection
    this.pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = this.pmremGenerator.fromScene(
      new RoomEnvironment(),
      0.04
    ).texture;

    // 5. Lighting Rig & Atmospheric Sky
    this.hemiLight = new THREE.HemisphereLight(0x7ec0ee, 0x3d3024, 0.7);
    this.scene.add(this.hemiLight);

    this.dirLight = new THREE.DirectionalLight(0xfff4d6, 2.2);
    this.dirLight.position.set(60, 90, 40);
    this.dirLight.castShadow = !this.isSoftwareGl;
    this.dirLight.shadow.mapSize.width = this.isSoftwareGl ? 1024 : 2048;
    this.dirLight.shadow.mapSize.height = this.isSoftwareGl ? 1024 : 2048;
    this.dirLight.shadow.camera.near = 5;
    this.dirLight.shadow.camera.far = 280;
    const d = 55;
    this.dirLight.shadow.camera.left = -d;
    this.dirLight.shadow.camera.right = d;
    this.dirLight.shadow.camera.top = d;
    this.dirLight.shadow.camera.bottom = -d;
    this.dirLight.shadow.bias = -0.0004;
    this.dirLight.shadow.normalBias = 0.02;
    this.scene.add(this.dirLight);
    this.scene.add(this.dirLight.target);

    this.atmosphericSky = new AtmosphericSky(this.scene, this.dirLight);

    // 6. Subsystem Instantiation
    const seed = initialSave ? initialSave.worldSeed : 101;
    this.persistence = new WorldPersistence();
    if (initialSave) {
      this.persistence.importSaveData({
        discoveredChunks: initialSave.discoveredChunks,
        waypoints: initialSave.waypoints,
        chunkModifications: initialSave.chunkModifications,
      });
    }

    this.chunkMgr = new ChunkManager(this.scene, seed, this.graphicsQuality, this.persistence);
    this.terrain = new WorldTerrain(this.scene, seed);
    this.baseMgr = new BaseManager(this.scene);
    this.buildingMgr = new BuildingManager(this.scene);
    this.zombieMgr = new ZombieManager(this.scene);
    this.wildlifeMgr = new WildlifeManager(this.scene, seed, (x, z) => getTerrainHeight(x, z, seed));
    this.player = new PlayerController(this.scene, this.camera, seed);

    // 7. Load or Initialize Game State
    if (initialSave) {
      this.gameTimeMinutes = initialSave.gameTimeMinutes;
      this.dayCount = initialSave.dayCount;
      this.nightHordesDefeated = initialSave.nightHordeCountDefeated;
      this.playerStats = initialSave.playerStats;
      this.quests = initialSave.quests;
      this.player.position.set(...initialSave.playerPosition);
      this.player.yaw = initialSave.playerRotation;
      if (initialSave.structures && initialSave.structures.length > 0) {
        this.buildingMgr.loadSavedStructures(initialSave.structures);
      } else {
        this.buildingMgr.initStarterBase();
      }
      this.gameMode = initialSave.metadata.gameMode;
      this.difficulty = initialSave.metadata.difficulty;
    } else {
      // New Game: Initialize full pre-built starter base compound
      this.buildingMgr.initStarterBase();
      // Position player in the sunny starter compound yard facing the cabin and facilities
      this.player.position.set(0, getTerrainHeight(0, 0, seed) + 0.12, 0);
      this.player.yaw = 0;

      this.playerStats = {
        health: 100,
        maxHealth: 100,
        stamina: 100,
        maxStamina: 100,
        hunger: 90,
        thirst: 95,
        temperature: 24,
        infection: 0,
        level: 1,
        xp: 0,
        xpToNextLevel: 100,
        skillPoints: 0,
        skills: {
          strength: 1,
          endurance: 1,
          engineering: 1,
          survival: 1,
        },
      };
      this.quests = [];
    }

    // Spawn starter wandering zombies outside safe radius
    for (let i = 0; i < 5; i++) {
      const angle = (i / 5) * Math.PI * 2;
      const x = Math.cos(angle) * 45;
      const z = Math.sin(angle) * 45;
      this.zombieMgr.spawnZombie('walker', [x, 0, z]);
    }

    // Attach resize listener
    window.addEventListener('resize', this.onResize);

    // Start loop
    this.isRunning = true;
    this.startLoop();
  }

  public setPaused(paused: boolean) {
    this.isPaused = paused;
    if (!paused) {
      this.clock.getDelta(); // reset delta step
    }
  }

  public onResize = () => {
    if (!this.container) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  private startLoop() {
    const tick = () => {
      if (!this.isRunning) return;

      if (!this.isPaused) {
        const delta = Math.min(0.1, this.clock.getDelta());
        this.update(delta);
      }

      this.renderer.render(this.scene, this.camera);

      if (this.isSoftwareGl) {
        // Pace loop on software WebGL to avoid starving main thread
        this.frameId = window.setTimeout(tick, 80);
      } else {
        this.frameId = requestAnimationFrame(tick);
      }
    };

    if (this.isSoftwareGl) {
      this.frameId = window.setTimeout(tick, 80);
    } else {
      this.frameId = requestAnimationFrame(tick);
    }
  }

  // --- Core Game Update ---
  private update(delta: number) {
    // 1. Advance Game Time (1 real sec = 2 game mins)
    this.gameTimeMinutes += delta * 2.0;
    if (this.gameTimeMinutes >= 1440) {
      this.gameTimeMinutes -= 1440;
      this.dayCount += 1;
    }

    const hour = this.gameTimeMinutes / 60;
    this.isNight = hour >= 21.0 || hour < 5.0;
    this.isDusk = hour >= 18.0 && hour < 21.0;

    // Trigger audio ambience
    soundEngine.updateNightAmbience(this.isNight);

    // Dusk warning
    if (this.isDusk && !this.duskWarningFired) {
      this.duskWarningFired = true;
      soundEngine.playDuskWarningHorn();
      this.callbacks.onHordeEvent('dusk_warning');
    }

    // Night horde start
    if (this.isNight && this.duskWarningFired) {
      this.duskWarningFired = false;
      this.dawnVictoryFired = false;
      this.callbacks.onHordeEvent('night_horde_start');
    }

    // Dawn victory event
    if (!this.isNight && !this.isDusk && hour >= 6.0 && hour < 7.0 && !this.dawnVictoryFired) {
      this.dawnVictoryFired = true;
      this.nightHordesDefeated += 1;
      soundEngine.playDawnVictoryChime();
      this.callbacks.onHordeEvent('dawn_victory');
      this.addXP(150);
      this.updateQuestProgress('survive_night', 1);
      this.updateQuestProgress('survive_hordes', 1);
    }

    // Update Dynamic Infinite Chunk Streaming around player
    this.chunkMgr.updatePlayerPosition(this.player.position);
    this.wildlifeMgr.update(delta, this.player.position);

    // Update Celestial Lighting, Biome, and Atmosphere
    this.updateAtmosphere(hour, delta);

    // 2. Vehicle Driving or Foot Movement
    if (this.isDriving) {
      this.baseMgr.vehicle.update(delta, this.inputState, this.chunkMgr.worldSeed);
      const vPos = this.baseMgr.vehicle.vehicleState.position;
      this.player.position.set(vPos[0], vPos[1], vPos[2]);
      this.player.avatarGroup.position.set(vPos[0], vPos[1] + 0.3, vPos[2]);
      this.player.avatarGroup.rotation.y = this.baseMgr.vehicle.vehicleState.rotationY;
      this.callbacks.onVehicleStateChange?.(
        this.baseMgr.vehicle.vehicleState,
        true,
        this.baseMgr.vehicle.currentSpeed
      );
    } else {
      const { staminaDelta } = this.player.update(
        delta,
        this.inputState,
        this.playerStats.stamina,
        this.buildingMgr
      );
      this.playerStats.stamina = Math.max(
        0,
        Math.min(this.playerStats.maxStamina, this.playerStats.stamina + staminaDelta)
      );
    }

    // Distance to Safe Zone Center
    const distToSafe = Math.hypot(
      this.player.position.x - this.buildingMgr.safeZoneCenter.x,
      this.player.position.z - this.buildingMgr.safeZoneCenter.z
    );
    const inSafeZone = distToSafe < this.buildingMgr.safeZoneRadius;

    // Count nearby zombies for security radar
    let zombiesNearBase = 0;
    for (let i = 0; i < this.zombieMgr.zombies.length; i++) {
      const z = this.zombieMgr.zombies[i];
      if (Math.hypot(z.position[0] - this.buildingMgr.safeZoneCenter.x, z.position[2] - this.buildingMgr.safeZoneCenter.z) < 40) {
        zombiesNearBase++;
      }
    }

    // Update Base Subsystems (Power, Water, Food, Security, NPCs)
    this.baseMgr.update(delta, hour, this.isNight, zombiesNearBase);

    // Automated Sentry Turret Defense (engages zombies if powered)
    if (this.baseMgr.power.state.isPowered) {
      this.sentryCooldown -= delta;
      if (this.sentryCooldown <= 0) {
        const turret = this.buildingMgr.structures.find((s) => s.typeId === 'sentry_turret');
        if (turret) {
          let closestZ: { id: string; dist: number } | null = null;
          for (let i = 0; i < this.zombieMgr.zombies.length; i++) {
            const z = this.zombieMgr.zombies[i];
            const d = Math.hypot(z.position[0] - turret.position[0], z.position[2] - turret.position[2]);
            if (d < 24.0) {
              if (!closestZ || d < closestZ.dist) {
                closestZ = { id: z.id, dist: d };
              }
            }
          }
          if (closestZ) {
            this.sentryCooldown = 1.1; // 1 shot per 1.1s
            soundEngine.playCrossbowShot();
            const res = this.zombieMgr.damageZombie(closestZ.id, 40, 1.2);
            if (res && res.killed) {
              this.addXP(res.xp);
            }
          }
        }
      }
    }

    // Hunger & Thirst Drains (slower in safe zone)
    const drainMultiplier = inSafeZone ? 0.6 : 1.0;
    this.playerStats.hunger = Math.max(0, this.playerStats.hunger - delta * 0.12 * drainMultiplier);
    this.playerStats.thirst = Math.max(0, this.playerStats.thirst - delta * 0.18 * drainMultiplier);

    // Starvation / Dehydration Health Damage
    if (this.playerStats.hunger <= 0 || this.playerStats.thirst <= 0) {
      this.damagePlayer(delta * 2.5);
    }

    // Passive Health Regen if well-fed & hydrated
    if (this.playerStats.hunger > 60 && this.playerStats.thirst > 60 && this.playerStats.health < this.playerStats.maxHealth) {
      this.playerStats.health = Math.min(this.playerStats.maxHealth, this.playerStats.health + delta * 1.5);
    }

    this.callbacks.onStatsChange({ ...this.playerStats });
    this.callbacks.onTimeChange(this.gameTimeMinutes, this.dayCount, this.isNight, this.isDusk);

    // 4. Horde Director Waves at Night
    if (this.isNight) {
      this.hordeWaveTimer += delta;
      if (this.hordeWaveTimer >= 35.0) {
        this.hordeWaveTimer = 0;
        const waveCount = 3 + Math.min(6, this.dayCount * 2);
        this.zombieMgr.spawnHordeWave(this.player.position, waveCount);
      }
    }

    // 5. Update Zombies
    this.zombieMgr.update(delta, this.player.position, this.buildingMgr, (dmg) => {
      this.damagePlayer(dmg);
    });

    // 6. Raycast Interaction Prompt
    this.checkInteractionPrompt();

    // 7. Auto-save every 60s
    this.autoSaveTimer += delta;
    if (this.autoSaveTimer >= 60.0) {
      this.autoSaveTimer = 0;
      this.triggerAutoSave();
    }
  }

  private updateAtmosphere(hour: number, delta: number) {
    const biome = this.chunkMgr.getCurrentBiome(this.player.position.x, this.player.position.z);
    this.callbacks.onBiomeChange?.(biome.name, biome.temperature);

    let sunIntensity = 2.4;
    let sunColor = new THREE.Color(0xfff6dd);
    const isBloodMoon = this.isNight && (this.dayCount % 3 === 0 || this.nightHordesDefeated > 0);

    if (hour >= 5.0 && hour < 8.0) {
      // Dawn (soft rose & gold)
      const t = (hour - 5.0) / 3.0;
      sunColor.setRGB(1.0, 0.65 + t * 0.3, 0.4 + t * 0.5);
      sunIntensity = 0.9 + t * 1.5;
    } else if (hour >= 8.0 && hour < 17.0) {
      // Full bright daylight
      sunColor.setRGB(1.0, 0.98, 0.93);
      sunIntensity = 2.4;
    } else if (hour >= 17.0 && hour < 20.5) {
      // Sunset / Golden Hour (warm amber to deep crimson)
      const t = (hour - 17.0) / 3.5;
      sunColor.setRGB(1.0, 0.45 - t * 0.3, 0.15);
      sunIntensity = 2.0 - t * 1.5;
    } else {
      // Night / Midnight / Blood Moon
      if (isBloodMoon) {
        sunColor.setRGB(1.0, 0.18, 0.18); // Ominous Crimson Blood Moon
        sunIntensity = 0.65;
      } else {
        sunColor.setRGB(0.68, 0.82, 1.0); // Cool silvery moonlight
        sunIntensity = 0.45;
      }
    }

    this.dirLight.color = sunColor;
    this.dirLight.intensity = sunIntensity;

    // Orbit sun / moon along celestial sphere centered over the player
    const sunAngle = ((hour - 6.0) / 24.0) * Math.PI * 2;
    this.dirLight.target.position.set(this.player.position.x, this.player.position.y, this.player.position.z);
    this.dirLight.position.set(
      this.player.position.x + Math.cos(sunAngle) * 75,
      this.player.position.y + Math.max(16, Math.sin(sunAngle) * 95),
      this.player.position.z + Math.sin(sunAngle) * 60
    );

    // Update Atmospheric Sky Dome (Rayleigh-Mie scattering, sun/moon disc, star constellations)
    this.atmosphericSky.update(
      this.gameTimeMinutes,
      this.isNight,
      this.isDusk,
      isBloodMoon,
      delta,
      this.player.position
    );

    // Dynamic Tone Mapping Exposure Adaptation (human eye iris simulation)
    const targetExposure = this.isNight ? (isBloodMoon ? 1.4 : 1.3) : this.isDusk ? 1.25 : 1.15;
    this.renderer.toneMappingExposure = THREE.MathUtils.lerp(
      this.renderer.toneMappingExposure,
      targetExposure,
      delta * 1.8
    );

    // Distance Fog naturally matches the atmospheric horizon color
    const horizonColor = this.atmosphericSky.getHorizonColor();
    const biomeFogColor = new THREE.Color(biome.fogColor);
    horizonColor.lerp(biomeFogColor, 0.18);

    this.scene.background = horizonColor;
    if (this.scene.fog instanceof THREE.FogExp2) {
      this.scene.fog.color = horizonColor;
      this.scene.fog.density = this.isNight ? 0.015 : 0.0085;
    }

    // Animate fluid ripples on water surfaces
    getWaterRippleNormalMap(performance.now() * 0.001);
  }

  // --- Interaction & Action Handling ---

  public handlePrimaryAction(inventory: { hasCrossbowBolts: boolean; consumeBolt: () => boolean }): boolean {
    this.player.triggerActionSwing();

    // 1. If currently in Building Mode -> place active structure
    if (this.buildingMgr.activeDef) {
      const snapTarget = this.getPlacementAimPoint();
      if (snapTarget) {
        const placed = this.buildingMgr.placeActiveStructure(snapTarget);
        if (placed) {
          soundEngine.playBuildSnap();
          this.updateQuestProgress('build_foundation', placed.typeId === 'wooden_foundation' ? 1 : 0);
          this.updateQuestProgress('build_wall', placed.typeId === 'wooden_wall' ? 1 : 0);
          this.updateQuestProgress('build_gate', placed.typeId === 'wooden_gate' ? 1 : 0);
          this.updateQuestProgress('build_spikes', placed.typeId === 'defense_spikes' ? 1 : 0);
          this.updateQuestProgress('build_watchtower', placed.typeId === 'watchtower' ? 1 : 0);
          this.updateQuestProgress('build_lights', (placed.typeId === 'perimeter_torch' || placed.typeId === 'solar_spotlight') ? 1 : 0);
          this.updateQuestProgress('build_workbench', placed.typeId === 'workbench' ? 1 : 0);
          return true;
        }
      }
      return false;
    }

    // 2. Ranged Crossbow Attack
    if (this.activeSlotItem?.id === 'pulse_crossbow') {
      if (inventory.hasCrossbowBolts && inventory.consumeBolt()) {
        soundEngine.playCrossbowShot();
        this.performRangedShot();
        return true;
      }
      return false;
    }

    // 3. Stun Baton Shock Discharge
    if (this.activeSlotItem?.id === 'stun_baton') {
      soundEngine.playShockDischarge();
    }

    // 4. Melee Raycast against Zombies or Harvestables
    this.performMeleeRaycast();
    return true;
  }

  private performMeleeRaycast() {
    this.raycaster.setFromCamera(this.screenCenter, this.camera);
    const range = 3.2;

    // Check zombies first
    let hitZombie: { id: string; dist: number } | null = null;
    for (const z of this.zombieMgr.zombies) {
      const dx = z.position[0] - this.player.position.x;
      const dz = z.position[2] - this.player.position.z;
      const d = Math.hypot(dx, dz);
      if (d < range) {
        if (!hitZombie || d < hitZombie.dist) {
          hitZombie = { id: z.id, dist: d };
        }
      }
    }

    if (hitZombie) {
      let dmg = 20;
      let knockback = 1.5;
      if (this.activeSlotItem) {
        dmg = this.activeSlotItem.damage || 20;
        if (this.activeSlotItem.id === 'stun_baton') knockback = 4.0;
      }
      const res = this.zombieMgr.damageZombie(hitZombie.id, dmg, knockback);
      if (res) {
        soundEngine.playHurt();
        if (res.killed) {
          this.addXP(res.xp);
          // Drop loot (cloth / metal)
          this.callbacks.onItemCollected('cloth_fabric', 2);
          if (Math.random() > 0.5) this.callbacks.onItemCollected('nails_bolts', 2);
        }
      }
      return;
    }

    // Check harvestable resources across active streaming chunks
    let nearestRes: HarvestableResource | null = null;
    let minResDist = 3.5;

    const activeResources = this.chunkMgr.getAllActiveResources();
    for (const r of activeResources) {
      const dx = r.position[0] - this.player.position.x;
      const dz = r.position[2] - this.player.position.z;
      const d = Math.hypot(dx, dz);
      if (d < minResDist) {
        nearestRes = r;
        minResDist = d;
      }
    }

    if (nearestRes) {
      const toolType = this.activeSlotItem?.toolType || 'none';
      let dmg = 25;
      if (nearestRes.type === 'tree') {
        soundEngine.playChopWood();
        dmg = toolType === 'axe' ? 50 : 20;
      } else if (nearestRes.type === 'rock' || nearestRes.type === 'metal_scrap') {
        soundEngine.playMineRock();
        dmg = toolType === 'pickaxe' ? 55 : 18;
      } else {
        soundEngine.playChopWood();
        dmg = 40;
      }

      const damaged = this.chunkMgr.damageResource(nearestRes.id, dmg);
      if (damaged && damaged.health <= 0) {
        // Collect yield
        const itemDef = ITEMS[damaged.yieldItem];
        if (itemDef) {
          this.callbacks.onResourceHarvested(nearestRes, itemDef, damaged.yieldAmount);
          this.callbacks.onItemCollected(itemDef.id, damaged.yieldAmount);
          this.addXP(15);
          if (damaged.yieldItem === 'wood') {
            this.updateQuestProgress('gather_wood', damaged.yieldAmount);
          } else if (damaged.yieldItem === 'stone') {
            this.updateQuestProgress('gather_stone', damaged.yieldAmount);
          }
        }
      }
      return;
    }

    // Check for structure repair with hammer
    if (this.activeSlotItem?.toolType === 'hammer') {
      for (const s of this.buildingMgr.structures) {
        const dx = s.position[0] - this.player.position.x;
        const dz = s.position[2] - this.player.position.z;
        if (Math.hypot(dx, dz) < 3.2) {
          if (this.buildingMgr.repairStructure(s.uid, 250)) {
            soundEngine.playBuildSnap();
          }
          break;
        }
      }
    }
  }

  private performRangedShot() {
    this.raycaster.setFromCamera(this.screenCenter, this.camera);
    const range = 50.0;

    // Check hit on closest zombie
    let nearestZombie: { id: string; dist: number } | null = null;
    for (const z of this.zombieMgr.zombies) {
      const dx = z.position[0] - this.player.position.x;
      const dz = z.position[2] - this.player.position.z;
      const d = Math.hypot(dx, dz);
      if (d < range) {
        if (!nearestZombie || d < nearestZombie.dist) {
          nearestZombie = { id: z.id, dist: d };
        }
      }
    }

    if (nearestZombie) {
      const res = this.zombieMgr.damageZombie(nearestZombie.id, 65, 3.0);
      if (res) {
        soundEngine.playHurt();
        if (res.killed) {
          this.addXP(res.xp);
          this.callbacks.onItemCollected('cloth_fabric', 2);
        }
      }
    }
  }

  public handleInteractKey() {
    // 1. Vehicle Driving Toggle
    const vPos = this.baseMgr.vehicle.vehicleState.position;
    const distToVehicle = Math.hypot(vPos[0] - this.player.position.x, vPos[2] - this.player.position.z);
    if (distToVehicle < 3.8) {
      this.toggleVehicleDriving();
      return;
    }

    // 2. Placed structures interaction
    const range = 3.5;
    for (const struct of this.buildingMgr.structures) {
      const dx = struct.position[0] - this.player.position.x;
      const dz = struct.position[2] - this.player.position.z;
      if (Math.hypot(dx, dz) < range) {
        if (struct.typeId === 'command_terminal') {
          soundEngine.playUIClick();
          this.callbacks.onOpenBaseDashboard?.();
          return;
        } else if (struct.typeId === 'medical_bed') {
          soundEngine.playUIClick();
          this.playerStats.health = this.playerStats.maxHealth;
          this.playerStats.stamina = this.playerStats.maxStamina;
          this.playerStats.infection = 0;
          this.callbacks.onStatsChange({ ...this.playerStats });
          this.callbacks.onInteractionPrompt('Medical Recovery Complete (+100 HP)');
          return;
        } else if (struct.typeId === 'wooden_gate' || struct.typeId === 'sliding_glass_door' || struct.typeId === 'starter_cabin') {
          const isOpen = this.buildingMgr.toggleDoor(struct.uid);
          soundEngine.playGateToggle(isOpen);
          return;
        } else if (struct.typeId === 'survivor_bed' || struct.typeId === 'modern_king_bed') {
          this.updateQuestProgress('rest_in_bed', 1);
          this.sleepUntilDawn();
          return;
        } else if (struct.typeId === 'notice_board') {
          soundEngine.playUIClick();
          this.updateQuestProgress('read_notice_board', 1);
          this.callbacks.onOpenNoticeBoard();
          return;
        } else if (struct.typeId === 'farm_plot') {
          const result = this.buildingMgr.tendFarmPlot(struct.uid, true);
          this.updateQuestProgress('tend_farm', 1);
          if (result.action === 'harvested') {
            soundEngine.playBuildSnap();
            this.callbacks.onItemCollected('wild_berries', result.yieldAmount || 4);
            this.addXP(25);
          } else if (result.action === 'planted') {
            soundEngine.playBuildSnap();
          }
          return;
        } else if (struct.typeId === 'water_collector') {
          soundEngine.playUIClick();
          this.callbacks.onItemCollected('clean_water', 1);
          return;
        } else if (struct.typeId === 'storage_chest' || struct.typeId === 'modern_fridge') {
          soundEngine.playUIClick();
          this.updateQuestProgress('open_storage_stash', 1);
          this.callbacks.onOpenStorage(struct);
          return;
        } else if (struct.typeId === 'workbench') {
          soundEngine.playUIClick();
          this.callbacks.onOpenCrafting('workbench');
          return;
        } else if (struct.typeId === 'campfire' || struct.typeId === 'modern_kitchen_island') {
          soundEngine.playUIClick();
          this.callbacks.onOpenCrafting('campfire');
          return;
        }
      }
    }
  }

  public toggleVehicleDriving() {
    this.isDriving = !this.isDriving;
    this.baseMgr.vehicle.setOccupied(this.isDriving);
    soundEngine.playBuildSnap();
    if (this.isDriving) {
      this.player.cameraView = 'third';
      this.player.thirdPersonDistance = 6.5;
    } else {
      this.player.thirdPersonDistance = 4.2;
      const vPos = this.baseMgr.vehicle.vehicleState.position;
      this.player.position.set(vPos[0] - 2.0, vPos[1], vPos[2]);
    }
    this.callbacks.onVehicleStateChange?.(
      this.baseMgr.vehicle.vehicleState,
      this.isDriving,
      this.baseMgr.vehicle.currentSpeed
    );
  }

  public setGraphicsQuality(quality: GraphicsQuality) {
    this.graphicsQuality = quality;
    this.chunkMgr.quality = quality;
    this.dirLight.castShadow = quality !== 'low' && !this.isSoftwareGl;
  }

  public sleepUntilDawn() {
    soundEngine.playDawnVictoryChime();
    this.gameTimeMinutes = 360; // 06:00 AM Dawn
    this.dayCount += 1;
    this.playerStats.health = this.playerStats.maxHealth;
    this.playerStats.stamina = this.playerStats.maxStamina;
    this.playerStats.temperature = 24;
    this.buildingMgr.advanceFarmCrops();
    this.callbacks.onStatsChange({ ...this.playerStats });
    this.callbacks.onTimeChange(this.gameTimeMinutes, this.dayCount, false, false);
    this.callbacks.onHordeEvent('dawn_victory');
    this.updateQuestProgress('survive_night', 1);
    this.triggerAutoSave();
  }

  private checkInteractionPrompt() {
    if (this.buildingMgr.activeDef) {
      this.callbacks.onInteractionPrompt('[Left-Click] Place Structure | [R] Rotate | [B / Esc] Cancel');
      const aim = this.getPlacementAimPoint();
      if (aim) {
        this.buildingMgr.updatePreview(aim, true);
      }
      return;
    }

    // Vehicle drive prompt
    const vPos = this.baseMgr.vehicle.vehicleState.position;
    if (Math.hypot(vPos[0] - this.player.position.x, vPos[2] - this.player.position.z) < 3.8) {
      this.callbacks.onInteractionPrompt(this.isDriving ? '[F] Exit Nomad EV Buggy' : '[F] Drive Nomad EV Recon Buggy');
      return;
    }

    const range = 3.5;
    for (const struct of this.buildingMgr.structures) {
      const dx = struct.position[0] - this.player.position.x;
      const dz = struct.position[2] - this.player.position.z;
      if (Math.hypot(dx, dz) < range) {
        if (this.activeSlotItem?.toolType === 'hammer' && struct.currentHealth < struct.maxHealth) {
          const name = struct.typeId === 'wooden_wall' ? 'Fortified Palisade Wall' : struct.typeId === 'wooden_gate' ? 'Perimeter Gate' : 'Structure';
          this.callbacks.onInteractionPrompt(`[Left-Click] Repair ${name} (${Math.round(struct.currentHealth)}/${struct.maxHealth} HP)`);
          return;
        }
        if (struct.typeId === 'command_terminal') {
          this.callbacks.onInteractionPrompt('[E] Access Central Base Command Terminal');
          return;
        } else if (struct.typeId === 'medical_bed') {
          this.callbacks.onInteractionPrompt('[E] Rest in ICU Recovery Bed (Heal Wounds & Infection)');
          return;
        } else if (struct.typeId === 'wooden_gate' || struct.typeId === 'sliding_glass_door' || struct.typeId === 'starter_cabin') {
          this.callbacks.onInteractionPrompt(`[E] ${struct.isOpen ? 'Close Gate / Door' : 'Open Gate / Door'}`);
          return;
        } else if (struct.typeId === 'survivor_bed' || struct.typeId === 'modern_king_bed') {
          this.callbacks.onInteractionPrompt('[E] Sleep in Bed until Morning (Heals & Recovers Stamina)');
          return;
        } else if (struct.typeId === 'notice_board') {
          this.callbacks.onInteractionPrompt('[E] Read Sanctuary Notice Board & Directives');
          return;
        } else if (struct.typeId === 'farm_plot') {
          const stage = struct.farmStage || 0;
          if (stage === 0) {
            this.callbacks.onInteractionPrompt('[E] Plant Seed Packet in Soil');
          } else if (stage === 1) {
            this.callbacks.onInteractionPrompt('[E] Tend Farm Plot (Crops are Growing)');
          } else {
            this.callbacks.onInteractionPrompt('[E] Harvest Ripe Berries (+4 Crops)');
          }
          return;
        } else if (struct.typeId === 'water_collector') {
          this.callbacks.onInteractionPrompt('[E] Draw Clean Water from Cistern');
          return;
        } else if (struct.typeId === 'storage_chest' || struct.typeId === 'modern_fridge') {
          this.callbacks.onInteractionPrompt('[E] Open Storage Stash / Refrigerator');
          return;
        } else if (struct.typeId === 'workbench') {
          this.callbacks.onInteractionPrompt('[E] Use Artisan Workbench');
          return;
        } else if (struct.typeId === 'campfire' || struct.typeId === 'modern_kitchen_island') {
          this.callbacks.onInteractionPrompt('[E] Cook Rations / Prepare Meal');
          return;
        }
      }
    }

    // Check resource prompt in active chunks
    for (const res of this.chunkMgr.getAllActiveResources()) {
      const dx = res.position[0] - this.player.position.x;
      const dz = res.position[2] - this.player.position.z;
      if (Math.hypot(dx, dz) < 3.2) {
        if (res.type === 'tree') {
          this.callbacks.onInteractionPrompt('[Left-Click] Fell Timber Pine (Equip Axe)');
          return;
        } else if (res.type === 'rock') {
          this.callbacks.onInteractionPrompt('[Left-Click] Quarry Granite Boulder (Equip Pickaxe)');
          return;
        } else if (res.type === 'metal_scrap') {
          this.callbacks.onInteractionPrompt('[Left-Click] Salvage Vehicle Scrap (Equip Pickaxe)');
          return;
        } else if (res.type === 'berry_bush') {
          this.callbacks.onInteractionPrompt('[Left-Click] Forage Wild Berries');
          return;
        }
      }
    }

    this.callbacks.onInteractionPrompt(null);
  }

  private getPlacementAimPoint(): THREE.Vector3 | null {
    // Project ray forward 6 meters onto terrain
    const forwardX = Math.sin(this.player.yaw) * 4.5;
    const forwardZ = Math.cos(this.player.yaw) * 4.5;
    return new THREE.Vector3(
      this.player.position.x + forwardX,
      0,
      this.player.position.z + forwardZ
    );
  }

  public damagePlayer(amount: number) {
    if (this.gameMode === 'creative') return;
    this.playerStats.health = Math.max(0, this.playerStats.health - amount);
    soundEngine.playHurt();

    if (this.playerStats.health <= 0) {
      this.callbacks.onGameOver();
    }
  }

  public addXP(amount: number) {
    this.playerStats.xp += amount;
    while (this.playerStats.xp >= this.playerStats.xpToNextLevel) {
      this.playerStats.xp -= this.playerStats.xpToNextLevel;
      this.playerStats.level += 1;
      this.playerStats.skillPoints += 1;
      this.playerStats.xpToNextLevel = Math.floor(this.playerStats.xpToNextLevel * 1.5);
    }
  }

  public updateQuestProgress(objectiveId: string, amount: number) {
    let changed = false;
    this.quests.forEach((q) => {
      if (q.completed) return;
      q.objectives.forEach((obj) => {
        if (obj.id === objectiveId && !obj.completed) {
          obj.current = Math.min(obj.target, obj.current + amount);
          if (obj.current >= obj.target) {
            obj.completed = true;
          }
          changed = true;
        }
      });
      // Check if entire quest completed
      const allDone = q.objectives.every((o) => o.completed);
      if (allDone && !q.completed) {
        q.completed = true;
        this.addXP(q.rewards.xp);
        if (q.rewards.items) {
          q.rewards.items.forEach((rew) => {
            this.callbacks.onItemCollected(rew.itemId, rew.count);
          });
        }
      }
    });

    if (changed) {
      this.callbacks.onQuestsUpdate([...this.quests]);
    }
  }

  public triggerAutoSave() {
    const meta: SaveSlotMetadata = {
      id: 'autosave',
      name: 'Autosave Slot',
      characterName: 'Survivor',
      dayCount: this.dayCount,
      timeString: `${Math.floor(this.gameTimeMinutes / 60).toString().padStart(2, '0')}:${Math.floor(this.gameTimeMinutes % 60).toString().padStart(2, '0')}`,
      timestamp: Date.now(),
      difficulty: this.difficulty,
      gameMode: this.gameMode,
    };

    const saveData: FullGameSave = {
      metadata: meta,
      worldSeed: this.chunkMgr.worldSeed,
      playerPosition: [this.player.position.x, this.player.position.y, this.player.position.z],
      playerRotation: this.player.yaw,
      playerStats: { ...this.playerStats },
      inventory: [],
      hotbar: [],
      selectedHotbarIndex: 0,
      structures: [...this.buildingMgr.structures],
      quests: [...this.quests],
      gameTimeMinutes: this.gameTimeMinutes,
      dayCount: this.dayCount,
      nightHordeCountDefeated: this.nightHordesDefeated,
      discoveredChunks: Array.from(this.persistence.discoveredChunks),
      waypoints: [...this.persistence.waypoints],
      chunkModifications: this.persistence.exportSaveData().chunkModifications,
      baseState: this.baseMgr.getBaseState(),
    };

    saveGameToSlot(saveData);
  }

  public dispose() {
    this.isRunning = false;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    window.removeEventListener('resize', this.onResize);
    this.chunkMgr.dispose();
    this.baseMgr.dispose();
    this.terrain.dispose();
    this.buildingMgr.dispose();
    this.zombieMgr.dispose();
    this.wildlifeMgr.dispose();
    this.atmosphericSky.dispose();
    this.pmremGenerator.dispose();
    this.renderer.dispose();

    if (this.container && this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
