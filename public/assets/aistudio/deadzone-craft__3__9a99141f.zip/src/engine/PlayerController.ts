import * as THREE from 'three';
import { CameraView, ItemDefinition } from '../types/game';
import { getTerrainHeight } from './Terrain';
import { BuildingManager } from './BuildingManager';
import { soundEngine } from '../utils/audio';
import { STRUCTURES } from '../data/structures';

export class PlayerController {
  public camera: THREE.PerspectiveCamera;
  public scene: THREE.Scene;
  private worldSeed: number;
  private readonly groundClearance = 0.12;
  public position: THREE.Vector3 = new THREE.Vector3(0, 0, 0);
  public velocity: THREE.Vector3 = new THREE.Vector3(0, 0, 0);

  // Rotation angles (radians)
  /** Character facing direction; independent from the orbit camera. */
  public yaw: number = 0;
  /** Third-person camera orbit angles. */
  public cameraYaw: number = 0;
  public pitch: number = 0;

  // Camera settings
  public cameraView: CameraView = 'third';
  public observerDistance: number = 5.2;
  public thirdPersonDistance: number = 4.2;
  public currentCamDistance: number = 4.2;
  public eyeHeight: number = 1.7;
  public shakeIntensity: number = 0;
  public enableCameraShake: boolean = true;

  // Movement parameters
  public walkSpeed: number = 4.5;
  public runSpeed: number = 7.5;
  public isGrounded: boolean = true;
  public isSprinting: boolean = false;
  public isCrouching: boolean = false;
  private footstepTimer: number = 0;

  // Visual avatar (Composite 7-part model)
  public avatarGroup: THREE.Group;
  public heldToolGroup: THREE.Group;
  public flashlight: THREE.SpotLight;
  public isFlashlightOn: boolean = false;

  // Swing animation
  private swingProgress: number = 1.0;
  private swingDuration: number = 0.25;

  constructor(scene: THREE.Scene, camera: THREE.PerspectiveCamera, worldSeed: number = 42) {
    this.scene = scene;
    this.camera = camera;
    this.worldSeed = worldSeed;

    // Build procedural survivor avatar
    this.avatarGroup = this.createPlayerAvatar();
    this.scene.add(this.avatarGroup);

    // Held item group (attached to right arm)
    this.heldToolGroup = new THREE.Group();
    const rightArm = this.avatarGroup.getObjectByName('rightArm');
    if (rightArm) {
      rightArm.add(this.heldToolGroup);
      this.heldToolGroup.position.set(0, -0.4, 0.2);
    }

    // Flashlight
    this.flashlight = new THREE.SpotLight(0xfffaea, 3.5, 30, Math.PI / 5, 0.35, 1.2);
    this.flashlight.position.set(0, 1.5, 0);
    this.flashlight.visible = false;
    this.avatarGroup.add(this.flashlight);
    this.avatarGroup.add(this.flashlight.target);
    this.flashlight.target.position.set(0, 1.2, 10);
  }

  public setView(view: CameraView) {
    this.cameraView = view;
    this.avatarGroup.visible = this.cameraView !== 'first';
  }

  public toggleView() {
    const next: CameraView = this.cameraView === 'first'
      ? 'third'
      : this.cameraView === 'third'
        ? 'second'
        : 'first';
    this.setView(next);
  }

  public toggleFlashlight(): boolean {
    this.isFlashlightOn = !this.isFlashlightOn;
    this.flashlight.visible = this.isFlashlightOn;
    return this.isFlashlightOn;
  }

  public triggerActionSwing() {
    if (this.swingProgress >= 1.0) {
      this.swingProgress = 0.0;
    }
  }

  public adjustCameraDistance(deltaZoom: number) {
    this.thirdPersonDistance = THREE.MathUtils.clamp(this.thirdPersonDistance + deltaZoom, 1.6, 12);
  }

  /** Rotate the camera around the avatar without turning the avatar itself. */
  public rotateCamera(deltaX: number, deltaY: number, sensitivity: number = 0.005) {
    this.cameraYaw -= deltaX * sensitivity;
    this.pitch = THREE.MathUtils.clamp(
      this.pitch - deltaY * sensitivity,
      -Math.PI / 2.15,
      Math.PI / 2.15
    );
  }

  public triggerCameraShake(intensity: number = 0.3) {
    if (this.enableCameraShake) {
      this.shakeIntensity = Math.min(0.8, this.shakeIntensity + intensity);
    }
  }

  public setHeldItem(item: ItemDefinition | null) {
    // Clear existing held tool meshes
    while (this.heldToolGroup.children.length > 0) {
      this.heldToolGroup.remove(this.heldToolGroup.children[0]);
    }

    if (!item) return;

    // Create mini representation of held item
    const toolMat = new THREE.MeshStandardMaterial({ color: 0x556677, metalness: 0.7, roughness: 0.3 });
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x8b5a2b, roughness: 0.8 });

    if (item.toolType === 'axe') {
      const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.7, 6), woodMat);
      handle.rotation.x = Math.PI / 2;
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.25, 0.2), toolMat);
      blade.position.set(0, 0, 0.3);
      this.heldToolGroup.add(handle, blade);
    } else if (item.toolType === 'pickaxe') {
      const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.75, 6), woodMat);
      handle.rotation.x = Math.PI / 2;
      const pick = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.4, 4), toolMat);
      pick.rotation.z = Math.PI / 2;
      pick.position.set(0, 0, 0.32);
      this.heldToolGroup.add(handle, pick);
    } else if (item.toolType === 'hammer') {
      const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.65, 6), woodMat);
      handle.rotation.x = Math.PI / 2;
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 0.22), toolMat);
      head.position.set(0, 0, 0.3);
      this.heldToolGroup.add(handle, head);
    } else if (item.id === 'stun_baton') {
      const baton = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.8, 8), toolMat);
      baton.rotation.x = Math.PI / 2;
      const glow = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.3, 8), new THREE.MeshBasicMaterial({ color: 0x00ffff }));
      glow.rotation.x = Math.PI / 2;
      glow.position.set(0, 0, 0.25);
      this.heldToolGroup.add(baton, glow);
    } else if (item.id === 'pulse_crossbow') {
      const stock = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.1, 0.7), woodMat);
      const bow = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.05, 0.05), toolMat);
      bow.position.set(0, 0.05, 0.3);
      this.heldToolGroup.add(stock, bow);
    }
  }

  /** Check collision against structures at candidate (x, z) coordinates. */
  private checkStructureCollision(x: number, z: number, buildingMgr: BuildingManager): boolean {
    const playerRadius = 0.32;
    for (let i = 0; i < buildingMgr.structures.length; i++) {
      const struct = buildingMgr.structures[i];
      if (struct.isOpen) continue; // open gates and doors are passable
      const def = STRUCTURES[struct.typeId];
      if (!def) continue;
      if (def.category === 'structure' && def.height < 0.5) continue; // floor foundations are walkable

      // Small poles and lamps have slim radial collision
      if (struct.typeId === 'perimeter_torch' || struct.typeId === 'modern_lamp') {
        const tdx = struct.position[0] - x;
        const tdz = struct.position[2] - z;
        if (tdx * tdx + tdz * tdz < 0.12) {
          return true;
        }
        continue;
      }

      // Oriented bounding box check
      const cosR = Math.cos(-struct.rotationY);
      const sinR = Math.sin(-struct.rotationY);
      const worldDx = x - struct.position[0];
      const worldDz = z - struct.position[2];
      const localX = worldDx * cosR - worldDz * sinR;
      const localZ = worldDx * sinR + worldDz * cosR;

      const halfW = (def.width * 0.5) + playerRadius;
      const halfD = (def.depth * 0.5) + playerRadius;

      if (Math.abs(localX) < halfW && Math.abs(localZ) < halfD) {
        return true;
      }
    }
    return false;
  }

  public update(
    delta: number,
    input: {
      forward: boolean;
      backward: boolean;
      left: boolean;
      right: boolean;
      jump: boolean;
      sprint: boolean;
      analogX?: number;
      analogZ?: number;
      isAnalog?: boolean;
    },
    stamina: number,
    buildingMgr: BuildingManager
  ): { staminaDelta: number; isMoving: boolean } {
    let staminaDelta = 0;
    const clampedDelta = Math.min(Math.max(delta, 0.001), 0.05);

    // Movement direction in local space
    let moveX = 0;
    let moveZ = 0;
    let inputMagnitude = 0;

    if (input.isAnalog && input.analogX !== undefined && input.analogZ !== undefined) {
      moveX = input.analogX;
      moveZ = -input.analogZ; // invert Y so pushing stick forward (+screen up) moves forward
      inputMagnitude = Math.hypot(moveX, moveZ);
      if (inputMagnitude > 1.0) {
        moveX /= inputMagnitude;
        moveZ /= inputMagnitude;
        inputMagnitude = 1.0;
      }
    } else {
      if (input.forward) moveZ += 1;
      if (input.backward) moveZ -= 1;
      if (input.left) moveX -= 1;
      if (input.right) moveX += 1;
      if (moveX !== 0 || moveZ !== 0) {
        const len = Math.hypot(moveX, moveZ);
        moveX /= len;
        moveZ /= len;
        inputMagnitude = 1.0;
      }
    }

    const isMoving = inputMagnitude > 0.08;

    // Sprint check
    this.isSprinting = input.sprint && isMoving && stamina > 5;
    const speedMultiplier = input.isAnalog ? Math.max(0.4, inputMagnitude) : 1.0;
    const targetSpeed = (this.isSprinting ? this.runSpeed : this.walkSpeed) * speedMultiplier;

    if (this.isSprinting) {
      staminaDelta = -18 * clampedDelta;
    } else if (!isMoving) {
      staminaDelta = +14 * clampedDelta;
    } else {
      staminaDelta = +4 * clampedDelta;
    }

    // World direction relative to camera yaw
    let targetVelX = 0;
    let targetVelZ = 0;

    if (isMoving) {
      const sin = Math.sin(this.cameraYaw);
      const cos = Math.cos(this.cameraYaw);

      targetVelX = (moveX * cos + moveZ * sin) * targetSpeed;
      targetVelZ = (-moveX * sin + moveZ * cos) * targetSpeed;

      // Smooth turning towards travel direction (shortest angular distance)
      const targetYaw = Math.atan2(-targetVelX, -targetVelZ);
      let diff = targetYaw - this.yaw;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      this.yaw += diff * Math.min(1.0, clampedDelta * 14.0);
    }

    // Acceleration & deceleration smoothing
    const accelRate = this.isGrounded ? (isMoving ? 18.0 : 14.0) : 5.0;
    this.velocity.x = THREE.MathUtils.damp(this.velocity.x, targetVelX, accelRate, clampedDelta);
    this.velocity.z = THREE.MathUtils.damp(this.velocity.z, targetVelZ, accelRate, clampedDelta);

    const stepX = this.velocity.x * clampedDelta;
    const stepZ = this.velocity.z * clampedDelta;

    if (Math.abs(stepX) > 0.0001 || Math.abs(stepZ) > 0.0001) {
      const testPosX = this.position.x + stepX;
      const testPosZ = this.position.z + stepZ;

      // Component-wise collision resolution (wall sliding)
      // 1. Try X step
      if (!this.checkStructureCollision(testPosX, this.position.z, buildingMgr)) {
        this.position.x = testPosX;
      } else {
        this.velocity.x = 0;
      }

      // 2. Try Z step
      if (!this.checkStructureCollision(this.position.x, testPosZ, buildingMgr)) {
        this.position.z = testPosZ;
      } else {
        this.velocity.z = 0;
      }

      // Footstep sound proportional to speed
      const currentSpeed = Math.hypot(this.velocity.x, this.velocity.z);
      if (currentSpeed > 0.5) {
        this.footstepTimer += clampedDelta * (this.isSprinting ? 1.6 : 1.0);
        if (this.footstepTimer > 0.38) {
          this.footstepTimer = 0;
          soundEngine.playFootstep();
        }
      }
    }

    // Jump & gravity
    if (input.jump && this.isGrounded && stamina > 12) {
      this.velocity.y = 6.2;
      this.isGrounded = false;
      staminaDelta -= 12;
    }

    // Apply gravity and resolve against the exact same seeded height field used by streamed chunks.
    // A small clearance compensates for the terrain mesh's triangle interpolation between vertices.
    const physicsDelta = Math.min(Math.max(delta, 0), 1 / 30);
    this.velocity.y -= 19.8 * physicsDelta;
    this.position.y += this.velocity.y * physicsDelta;

    const terrainY = getTerrainHeight(this.position.x, this.position.z, this.worldSeed) + this.groundClearance;
    if (this.position.y <= terrainY) {
      this.position.y = terrainY;
      this.velocity.y = 0;
      this.isGrounded = true;
    } else {
      this.isGrounded = false;
    }

    // Avatar position & rotation
    this.avatarGroup.position.copy(this.position);
    this.avatarGroup.rotation.y = this.yaw;

    // Leg running swing animation
    const leftLeg = this.avatarGroup.getObjectByName('leftLeg');
    const rightLeg = this.avatarGroup.getObjectByName('rightLeg');
    if (leftLeg && rightLeg) {
      if (isMoving) {
        const cycle = Math.sin(Date.now() * 0.012 * (currentSpeed / 4));
        leftLeg.rotation.x = cycle * 0.55;
        rightLeg.rotation.x = -cycle * 0.55;
      } else {
        leftLeg.rotation.x = 0;
        rightLeg.rotation.x = 0;
      }
    }

    // Action tool swing
    const rightArm = this.avatarGroup.getObjectByName('rightArm');
    if (rightArm) {
      if (this.swingProgress < 1.0) {
        this.swingProgress += delta / this.swingDuration;
        const swingFactor = Math.sin(this.swingProgress * Math.PI);
        rightArm.rotation.x = -Math.PI / 4 - swingFactor * 1.2;
      } else {
        rightArm.rotation.x = -Math.PI / 4;
      }
    }

    // Camera Positioning
    if (this.cameraView === 'first') {
      let targetX = this.position.x;
      let targetY = this.position.y + this.eyeHeight;
      let targetZ = this.position.z;

      // First-person subtle camera shake
      if (this.shakeIntensity > 0 && this.enableCameraShake) {
        targetX += (Math.random() - 0.5) * this.shakeIntensity * 0.4;
        targetY += (Math.random() - 0.5) * this.shakeIntensity * 0.4;
        this.shakeIntensity = Math.max(0, this.shakeIntensity - delta * 4.0);
      }

      this.camera.position.set(targetX, targetY, targetZ);
      this.camera.rotation.order = 'YXZ';
      this.camera.rotation.y = this.cameraYaw;
      this.camera.rotation.x = this.pitch;
    } else if (this.cameraView === 'second') {
      // Second-person-style observer view: a front-facing camera observes the player avatar.
      // This is an optional cinematic viewpoint, not a literal NPC eye camera.
      const forwardX = -Math.sin(this.cameraYaw);
      const forwardZ = -Math.cos(this.cameraYaw);
      const targetX = this.position.x;
      const targetY = this.position.y + 1.15;
      const targetZ = this.position.z;
      const camX = this.position.x - forwardX * this.observerDistance;
      const camY = this.position.y + 2.15 + Math.max(-0.5, Math.min(1.2, this.pitch * 0.35));
      const camZ = this.position.z - forwardZ * this.observerDistance;
      this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, camX, 12, delta);
      this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, camY, 12, delta);
      this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, camZ, 12, delta);
      this.camera.lookAt(targetX, targetY, targetZ);
      this.shakeIntensity = Math.max(0, this.shakeIntensity - delta * 3.5);
    } else {
      // Third-person follow camera with physical obstacle collision avoidance
      const cosP = Math.cos(this.pitch);
      const sinP = Math.sin(this.pitch);
      const sinY = Math.sin(this.cameraYaw);
      const cosY = Math.cos(this.cameraYaw);

      const headX = this.position.x;
      const headY = this.position.y + this.eyeHeight;
      const headZ = this.position.z;

      const dirX = -sinY * cosP;
      const dirY = sinP + 0.12;
      const dirZ = -cosY * cosP;

      let safeDistance = this.thirdPersonDistance;

      // Sample along line of sight to detect wall/roof/ground clipping
      const stepCount = 8;
      for (let i = 1; i <= stepCount; i++) {
        const testDist = (i / stepCount) * this.thirdPersonDistance;
        const testX = headX + dirX * testDist;
        const testY = headY + dirY * testDist;
        const testZ = headZ + dirZ * testDist;

        // Ground terrain check
        const groundHeight = getTerrainHeight(testX, testZ, this.worldSeed) + this.groundClearance + 0.4;
        if (testY <= groundHeight) {
          safeDistance = Math.max(1.2, testDist - 0.3);
          break;
        }

        // Placed structure collision check
        let hitStructure = false;
        for (const s of buildingMgr.structures) {
          const sdx = Math.abs(s.position[0] - testX);
          const sdz = Math.abs(s.position[2] - testZ);
          const sdy = testY - s.position[1];
          // Check collision bounds of walls, cabin, watchtower
          const halfWidth = s.typeId === 'starter_cabin' ? 3.4 : 1.8;
          const halfDepth = s.typeId === 'starter_cabin' ? 3.0 : 1.8;
          const height = s.typeId === 'starter_cabin' ? 4.0 : 3.0;

          if (sdx < halfWidth && sdz < halfDepth && sdy > 0 && sdy < height) {
            hitStructure = true;
            break;
          }
        }

        if (hitStructure) {
          safeDistance = Math.max(0.9, testDist - 0.35);
          break;
        }
      }

      // Smooth camera distance pull-in
      this.currentCamDistance = THREE.MathUtils.damp(this.currentCamDistance, safeDistance, 18, delta);

      let targetX = headX + dirX * this.currentCamDistance;
      let targetY = headY + dirY * this.currentCamDistance;
      let targetZ = headZ + dirZ * this.currentCamDistance;

      // Camera Shake decay and offset
      if (this.shakeIntensity > 0) {
        if (this.enableCameraShake) {
          targetX += (Math.random() - 0.5) * this.shakeIntensity;
          targetY += (Math.random() - 0.5) * this.shakeIntensity;
          targetZ += (Math.random() - 0.5) * this.shakeIntensity;
        }
        this.shakeIntensity = Math.max(0, this.shakeIntensity - delta * 3.5);
      }

      // Smooth camera movement interpolation
      this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, targetX, 22, delta);
      this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, targetY, 22, delta);
      this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, targetZ, 22, delta);

      this.camera.lookAt(headX, headY - 0.1, headZ);
    }

    return { staminaDelta, isMoving };
  }

  // --- Procedural Survivor Character (Composite 8-parts) ---
  private createPlayerAvatar(): THREE.Group {
    const group = new THREE.Group();

    // Materials
    const skinMat = new THREE.MeshStandardMaterial({ color: 0xdeb887, roughness: 0.7 });
    const jacketMat = new THREE.MeshStandardMaterial({ color: 0x3b443b, roughness: 0.85 }); // Military olive jacket
    const pantsMat = new THREE.MeshStandardMaterial({ color: 0x232b38, roughness: 0.9 }); // Dark denim
    const bootsMat = new THREE.MeshStandardMaterial({ color: 0x1b1b1b, roughness: 0.6 });
    const bandanaMat = new THREE.MeshStandardMaterial({ color: 0xa83232, roughness: 0.8 }); // Red survivor bandana

    // 1. Torso & Tactical Vest
    const torso = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.75, 0.32), jacketMat);
    torso.position.y = 1.15;
    torso.castShadow = true;
    torso.receiveShadow = true;
    group.add(torso);

    // 2. Head
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.35, 0.35), skinMat);
    head.position.y = 1.7;
    head.castShadow = true;
    group.add(head);

    // Bandana
    const bandana = new THREE.Mesh(new THREE.BoxGeometry(0.37, 0.1, 0.37), bandanaMat);
    bandana.position.y = 1.8;
    group.add(bandana);

    // 3. Left Arm
    const armGeo = new THREE.BoxGeometry(0.15, 0.65, 0.15);
    armGeo.translate(0, -0.28, 0);

    const leftArm = new THREE.Mesh(armGeo, jacketMat);
    leftArm.name = 'leftArm';
    leftArm.position.set(-0.35, 1.45, 0);
    leftArm.castShadow = true;
    group.add(leftArm);

    // 4. Right Arm (wielding arm)
    const rightArm = new THREE.Mesh(armGeo, jacketMat);
    rightArm.name = 'rightArm';
    rightArm.position.set(0.35, 1.45, 0);
    rightArm.rotation.x = -Math.PI / 4;
    rightArm.castShadow = true;
    group.add(rightArm);

    // 5. Left Leg
    const legGeo = new THREE.BoxGeometry(0.18, 0.75, 0.18);
    legGeo.translate(0, -0.37, 0);

    const leftLeg = new THREE.Mesh(legGeo, pantsMat);
    leftLeg.name = 'leftLeg';
    leftLeg.position.set(-0.15, 0.75, 0);
    leftLeg.castShadow = true;
    group.add(leftLeg);

    // Left Boot
    const bootL = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.18, 0.26), bootsMat);
    bootL.position.set(0, -0.68, 0.04);
    leftLeg.add(bootL);

    // 6. Right Leg
    const rightLeg = new THREE.Mesh(legGeo, pantsMat);
    rightLeg.name = 'rightLeg';
    rightLeg.position.set(0.15, 0.75, 0);
    rightLeg.castShadow = true;
    group.add(rightLeg);

    // Right Boot
    const bootR = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.18, 0.26), bootsMat);
    bootR.position.set(0, -0.68, 0.04);
    rightLeg.add(bootR);

    return group;
  }
}
