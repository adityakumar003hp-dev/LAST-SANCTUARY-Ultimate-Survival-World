/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';

/**
 * High-fidelity PBR procedural texture generator.
 * Creates seamless albedo, tangent-space normal maps, and roughness maps
 * using HTML5 Canvas with Sobel filters and Perlin/Simplex noise approximations.
 */

const pbrCache: Map<string, THREE.Texture> = new Map();

/**
 * Generate a tangent-space normal map from a grayscale heightmap canvas.
 */
function generateNormalMapFromCanvas(
  heightCanvas: HTMLCanvasElement,
  strength: number = 2.5
): THREE.CanvasTexture {
  const w = heightCanvas.width;
  const h = heightCanvas.height;
  const hCtx = heightCanvas.getContext('2d', { willReadFrequently: true })!;
  const srcData = hCtx.getImageData(0, 0, w, h).data;

  const normalCanvas = document.createElement('canvas');
  normalCanvas.width = w;
  normalCanvas.height = h;
  const nCtx = normalCanvas.getContext('2d')!;
  const nImg = nCtx.createImageData(w, h);
  const dst = nImg.data;

  // Sample height at (x, y) with wrapping
  const getH = (x: number, y: number) => {
    const wx = (x + w) % w;
    const wy = (y + h) % h;
    const idx = (wy * w + wx) * 4;
    return (srcData[idx] * 0.299 + srcData[idx + 1] * 0.587 + srcData[idx + 2] * 0.114) / 255.0;
  };

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      // Sobel kernel for dX and dY
      const tl = getH(x - 1, y - 1);
      const t  = getH(x,     y - 1);
      const tr = getH(x + 1, y - 1);
      const l  = getH(x - 1, y);
      const r  = getH(x + 1, y);
      const bl = getH(x - 1, y + 1);
      const b  = getH(x,     y + 1);
      const br = getH(x + 1, y + 1);

      const dx = (tr + 2 * r + br) - (tl + 2 * l + bl);
      const dy = (bl + 2 * b + br) - (tl + 2 * t + tr);
      const dz = 1.0 / strength;

      // Normalize vector
      const len = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1.0;
      const nx = -dx / len;
      const ny = -dy / len;
      const nz = dz / len;

      const idx = (y * w + x) * 4;
      dst[idx + 0] = Math.round((nx * 0.5 + 0.5) * 255);
      dst[idx + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      dst[idx + 2] = Math.round((nz * 0.5 + 0.5) * 255);
      dst[idx + 3] = 255;
    }
  }

  nCtx.putImageData(nImg, 0, 0);
  const texture = new THREE.CanvasTexture(normalCanvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.colorSpace = THREE.NoColorSpace; // Normal maps MUST be linear!
  return texture;
}

export interface PBRTextureSet {
  albedo: THREE.CanvasTexture;
  normal: THREE.CanvasTexture;
  roughness: THREE.CanvasTexture;
}

/**
 * 1. Realistic Grass PBR (fine blades, mossy base, normal bump, varied roughness)
 */
export function getGrassPBR(tintInput: string | number = '#466d2a'): PBRTextureSet {
  const tintHex = typeof tintInput === 'number' ? '#' + tintInput.toString(16).padStart(6, '0') : tintInput;
  const cacheKey = `grass_${tintHex}`;
  if (pbrCache.has(`${cacheKey}_albedo`)) {
    return {
      albedo: pbrCache.get(`${cacheKey}_albedo`) as THREE.CanvasTexture,
      normal: pbrCache.get(`${cacheKey}_normal`) as THREE.CanvasTexture,
      roughness: pbrCache.get(`${cacheKey}_roughness`) as THREE.CanvasTexture,
    };
  }

  const size = 512;
  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;

  // Base earthy underlay
  aCtx.fillStyle = '#2d381e';
  aCtx.fillRect(0, 0, size, size);

  hCtx.fillStyle = '#333333';
  hCtx.fillRect(0, 0, size, size);

  rCtx.fillStyle = '#cccccc'; // mostly rough
  rCtx.fillRect(0, 0, size, size);

  // Micro-clumps & blade strokes
  const colors = [tintHex, '#3d6124', '#537d32', '#2f451b', '#608f3a', '#4a4128'];
  for (let i = 0; i < 9000; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    const len = 3 + Math.random() * 9;
    const angle = -Math.PI / 2 + (Math.random() - 0.5) * 1.2;
    const col = colors[Math.floor(Math.random() * colors.length)];

    aCtx.strokeStyle = col;
    aCtx.lineWidth = 1 + Math.random() * 1.5;
    aCtx.beginPath();
    aCtx.moveTo(x, y);
    aCtx.lineTo(x + Math.cos(angle) * len, y + Math.sin(angle) * len);
    aCtx.stroke();

    // Heightmap
    const hVal = Math.floor(100 + Math.random() * 140);
    hCtx.strokeStyle = `rgb(${hVal},${hVal},${hVal})`;
    hCtx.lineWidth = 1.2;
    hCtx.beginPath();
    hCtx.moveTo(x, y);
    hCtx.lineTo(x + Math.cos(angle) * len, y + Math.sin(angle) * len);
    hCtx.stroke();

    // Occasional dewy glossy spot
    if (Math.random() > 0.96) {
      rCtx.fillStyle = '#444444'; // shiny dew
      rCtx.fillRect(x, y, 2, 2);
    }
  }

  const albedo = new THREE.CanvasTexture(albedoCanvas);
  albedo.wrapS = THREE.RepeatWrapping;
  albedo.wrapT = THREE.RepeatWrapping;
  albedo.colorSpace = THREE.SRGBColorSpace;

  const normal = generateNormalMapFromCanvas(heightCanvas, 3.2);

  const roughness = new THREE.CanvasTexture(roughCanvas);
  roughness.wrapS = THREE.RepeatWrapping;
  roughness.wrapT = THREE.RepeatWrapping;

  pbrCache.set(`${cacheKey}_albedo`, albedo);
  pbrCache.set(`${cacheKey}_normal`, normal);
  pbrCache.set(`${cacheKey}_roughness`, roughness);

  return { albedo, normal, roughness };
}

/**
 * 2. Realistic Cliff Rock PBR (layered strata, fracture cracks, crystalline specular roughness)
 */
export function getRockPBR(): PBRTextureSet {
  const cacheKey = 'rock_granite';
  if (pbrCache.has(`${cacheKey}_albedo`)) {
    return {
      albedo: pbrCache.get(`${cacheKey}_albedo`) as THREE.CanvasTexture,
      normal: pbrCache.get(`${cacheKey}_normal`) as THREE.CanvasTexture,
      roughness: pbrCache.get(`${cacheKey}_roughness`) as THREE.CanvasTexture,
    };
  }

  const size = 512;
  const aCanvas = document.createElement('canvas');
  aCanvas.width = size;
  aCanvas.height = size;
  const aCtx = aCanvas.getContext('2d')!;

  const hCanvas = document.createElement('canvas');
  hCanvas.width = size;
  hCanvas.height = size;
  const hCtx = hCanvas.getContext('2d')!;

  const rCanvas = document.createElement('canvas');
  rCanvas.width = size;
  rCanvas.height = size;
  const rCtx = rCanvas.getContext('2d')!;

  // Base stone tone
  aCtx.fillStyle = '#55585c';
  aCtx.fillRect(0, 0, size, size);
  hCtx.fillStyle = '#777777';
  hCtx.fillRect(0, 0, size, size);
  rCtx.fillStyle = '#b0b0b0';
  rCtx.fillRect(0, 0, size, size);

  // Mineral specks and stratification bands
  for (let y = 0; y < size; y += 4) {
    const wave = Math.sin(y * 0.05) * 15;
    const bandTone = Math.sin(y * 0.02 + wave * 0.1) * 25;
    const r = Math.max(0, Math.min(255, 85 + bandTone));
    const g = Math.max(0, Math.min(255, 88 + bandTone));
    const b = Math.max(0, Math.min(255, 92 + bandTone));
    aCtx.fillStyle = `rgb(${r},${g},${b})`;
    aCtx.fillRect(0, y, size, 4);

    const hVal = Math.max(0, Math.min(255, 128 + bandTone * 1.5));
    hCtx.fillStyle = `rgb(${hVal},${hVal},${hVal})`;
    hCtx.fillRect(0, y, size, 4);
  }

  // Fracture lines & crevices
  for (let f = 0; f < 35; f++) {
    let px = Math.random() * size;
    let py = Math.random() * size;
    aCtx.strokeStyle = '#222326';
    aCtx.lineWidth = 1.5 + Math.random() * 2;
    hCtx.strokeStyle = '#111111';
    hCtx.lineWidth = aCtx.lineWidth;

    aCtx.beginPath();
    hCtx.beginPath();
    aCtx.moveTo(px, py);
    hCtx.moveTo(px, py);

    for (let step = 0; step < 6; step++) {
      px += (Math.random() - 0.5) * 60;
      py += (Math.random() - 0.4) * 50;
      aCtx.lineTo(px, py);
      hCtx.lineTo(px, py);
    }
    aCtx.stroke();
    hCtx.stroke();
  }

  // Quartz/mineral sparkles
  for (let i = 0; i < 3000; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    if (Math.random() > 0.8) {
      aCtx.fillStyle = '#cccccc';
      aCtx.fillRect(x, y, 2, 2);
      rCtx.fillStyle = '#222222'; // sharp specular shine
      rCtx.fillRect(x, y, 2, 2);
    } else {
      aCtx.fillStyle = '#3a3a3a';
      aCtx.fillRect(x, y, 2, 2);
    }
  }

  const albedo = new THREE.CanvasTexture(aCanvas);
  albedo.wrapS = THREE.RepeatWrapping;
  albedo.wrapT = THREE.RepeatWrapping;
  albedo.colorSpace = THREE.SRGBColorSpace;

  const normal = generateNormalMapFromCanvas(hCanvas, 4.0);
  const roughness = new THREE.CanvasTexture(rCanvas);
  roughness.wrapS = THREE.RepeatWrapping;
  roughness.wrapT = THREE.RepeatWrapping;

  pbrCache.set(`${cacheKey}_albedo`, albedo);
  pbrCache.set(`${cacheKey}_normal`, normal);
  pbrCache.set(`${cacheKey}_roughness`, roughness);

  return { albedo, normal, roughness };
}

/**
 * 3. Realistic Tree Bark PBR (vertical corrugated furrow grooves, weathered brown/moss tone)
 */
export function getBarkPBR(): PBRTextureSet {
  const cacheKey = 'tree_bark';
  if (pbrCache.has(`${cacheKey}_albedo`)) {
    return {
      albedo: pbrCache.get(`${cacheKey}_albedo`) as THREE.CanvasTexture,
      normal: pbrCache.get(`${cacheKey}_normal`) as THREE.CanvasTexture,
      roughness: pbrCache.get(`${cacheKey}_roughness`) as THREE.CanvasTexture,
    };
  }

  const size = 512;
  const aCanvas = document.createElement('canvas');
  aCanvas.width = size;
  aCanvas.height = size;
  const aCtx = aCanvas.getContext('2d')!;

  const hCanvas = document.createElement('canvas');
  hCanvas.width = size;
  hCanvas.height = size;
  const hCtx = hCanvas.getContext('2d')!;

  const rCanvas = document.createElement('canvas');
  rCanvas.width = size;
  rCanvas.height = size;
  const rCtx = rCanvas.getContext('2d')!;

  aCtx.fillStyle = '#3b281a';
  aCtx.fillRect(0, 0, size, size);
  hCtx.fillStyle = '#808080';
  hCtx.fillRect(0, 0, size, size);
  rCtx.fillStyle = '#dddddd';
  rCtx.fillRect(0, 0, size, size);

  // Vertical ridges
  for (let x = 0; x < size; x += 6) {
    const depth = Math.sin(x * 0.12) * 40;
    const r = Math.max(0, Math.min(255, 65 + depth * 0.8));
    const g = Math.max(0, Math.min(255, 45 + depth * 0.5));
    const b = Math.max(0, Math.min(255, 30 + depth * 0.3));

    aCtx.fillStyle = `rgb(${r},${g},${b})`;
    aCtx.fillRect(x, 0, 6, size);

    const hVal = Math.max(0, Math.min(255, 128 + depth * 2.2));
    hCtx.fillStyle = `rgb(${hVal},${hVal},${hVal})`;
    hCtx.fillRect(x, 0, 6, size);
  }

  // Furrows & knots
  for (let i = 0; i < 400; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    const h = 25 + Math.random() * 60;
    aCtx.strokeStyle = '#1b120c';
    aCtx.lineWidth = 2 + Math.random() * 2;
    hCtx.strokeStyle = '#111111';
    hCtx.lineWidth = aCtx.lineWidth;

    aCtx.beginPath();
    hCtx.beginPath();
    aCtx.moveTo(x, y);
    hCtx.moveTo(x, y);
    aCtx.lineTo(x + (Math.random() - 0.5) * 4, y + h);
    hCtx.lineTo(x + (Math.random() - 0.5) * 4, y + h);
    aCtx.stroke();
    hCtx.stroke();

    // Occasional green moss patch
    if (Math.random() > 0.88) {
      aCtx.fillStyle = '#3d4d23';
      aCtx.fillRect(x, y, 6, 12);
      rCtx.fillStyle = '#888888';
      rCtx.fillRect(x, y, 6, 12);
    }
  }

  const albedo = new THREE.CanvasTexture(aCanvas);
  albedo.wrapS = THREE.RepeatWrapping;
  albedo.wrapT = THREE.RepeatWrapping;
  albedo.colorSpace = THREE.SRGBColorSpace;

  const normal = generateNormalMapFromCanvas(hCanvas, 4.5);
  const roughness = new THREE.CanvasTexture(rCanvas);
  roughness.wrapS = THREE.RepeatWrapping;
  roughness.wrapT = THREE.RepeatWrapping;

  pbrCache.set(`${cacheKey}_albedo`, albedo);
  pbrCache.set(`${cacheKey}_normal`, normal);
  pbrCache.set(`${cacheKey}_roughness`, roughness);

  return { albedo, normal, roughness };
}

/**
 * 4. Realistic Asphalt Road PBR (coarse tar aggregate, oil stains, yellow centerline)
 */
export function getRoadPBR(hasCenterline: boolean = true): PBRTextureSet {
  const cacheKey = `road_asphalt_${hasCenterline}`;
  if (pbrCache.has(`${cacheKey}_albedo`)) {
    return {
      albedo: pbrCache.get(`${cacheKey}_albedo`) as THREE.CanvasTexture,
      normal: pbrCache.get(`${cacheKey}_normal`) as THREE.CanvasTexture,
      roughness: pbrCache.get(`${cacheKey}_roughness`) as THREE.CanvasTexture,
    };
  }

  const size = 512;
  const aCanvas = document.createElement('canvas');
  aCanvas.width = size;
  aCanvas.height = size;
  const aCtx = aCanvas.getContext('2d')!;

  const hCanvas = document.createElement('canvas');
  hCanvas.width = size;
  hCanvas.height = size;
  const hCtx = hCanvas.getContext('2d')!;

  const rCanvas = document.createElement('canvas');
  rCanvas.width = size;
  rCanvas.height = size;
  const rCtx = rCanvas.getContext('2d')!;

  // Dark charcoal bitumen
  aCtx.fillStyle = '#222426';
  aCtx.fillRect(0, 0, size, size);
  hCtx.fillStyle = '#808080';
  hCtx.fillRect(0, 0, size, size);
  rCtx.fillStyle = '#999999';
  rCtx.fillRect(0, 0, size, size);

  // Gravel specs & aggregate texture
  for (let i = 0; i < 15000; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    const v = Math.random();
    const shade = Math.floor(40 + v * 80);
    aCtx.fillStyle = `rgb(${shade},${shade},${shade})`;
    aCtx.fillRect(x, y, 1.5, 1.5);

    const hVal = Math.floor(90 + v * 70);
    hCtx.fillStyle = `rgb(${hVal},${hVal},${hVal})`;
    hCtx.fillRect(x, y, 1.5, 1.5);
  }

  // Cracks in the asphalt
  for (let c = 0; c < 12; c++) {
    let cx = Math.random() * size;
    let cy = Math.random() * size;
    aCtx.strokeStyle = '#111213';
    aCtx.lineWidth = 1.2;
    hCtx.strokeStyle = '#000000';
    hCtx.lineWidth = 1.5;

    aCtx.beginPath();
    hCtx.beginPath();
    aCtx.moveTo(cx, cy);
    hCtx.moveTo(cx, cy);
    for (let s = 0; s < 5; s++) {
      cx += (Math.random() - 0.5) * 40;
      cy += (Math.random() - 0.5) * 40;
      aCtx.lineTo(cx, cy);
      hCtx.lineTo(cx, cy);
    }
    aCtx.stroke();
    hCtx.stroke();
  }

  // Worn weathered yellow center dashes
  if (hasCenterline) {
    const dashLength = 70;
    const gapLength = 50;
    const total = dashLength + gapLength;
    aCtx.fillStyle = '#d49b28';
    hCtx.fillStyle = '#aaaaaa';
    rCtx.fillStyle = '#aaaaaa';

    for (let y = 10; y < size; y += total) {
      aCtx.fillRect(size / 2 - 8, y, 16, dashLength);
      hCtx.fillRect(size / 2 - 8, y, 16, dashLength);
      // Rough weathered wear on the paint
      for (let w = 0; w < 40; w++) {
        const wx = size / 2 - 8 + Math.random() * 16;
        const wy = y + Math.random() * dashLength;
        aCtx.fillStyle = '#222426';
        aCtx.fillRect(wx, wy, 2, 2);
      }
    }
  }

  const albedo = new THREE.CanvasTexture(aCanvas);
  albedo.wrapS = THREE.RepeatWrapping;
  albedo.wrapT = THREE.RepeatWrapping;
  albedo.colorSpace = THREE.SRGBColorSpace;

  const normal = generateNormalMapFromCanvas(hCanvas, 2.8);
  const roughness = new THREE.CanvasTexture(rCanvas);
  roughness.wrapS = THREE.RepeatWrapping;
  roughness.wrapT = THREE.RepeatWrapping;

  pbrCache.set(`${cacheKey}_albedo`, albedo);
  pbrCache.set(`${cacheKey}_normal`, normal);
  pbrCache.set(`${cacheKey}_roughness`, roughness);

  return { albedo, normal, roughness };
}

/**
 * 5. Modern Architectural Polished Concrete & Marble PBR (Luxury Sanctuary Villa)
 */
export function getModernConcretePBR(): PBRTextureSet {
  const cacheKey = 'modern_concrete';
  if (pbrCache.has(`${cacheKey}_albedo`)) {
    return {
      albedo: pbrCache.get(`${cacheKey}_albedo`) as THREE.CanvasTexture,
      normal: pbrCache.get(`${cacheKey}_normal`) as THREE.CanvasTexture,
      roughness: pbrCache.get(`${cacheKey}_roughness`) as THREE.CanvasTexture,
    };
  }

  const size = 512;
  const aCanvas = document.createElement('canvas');
  aCanvas.width = size;
  aCanvas.height = size;
  const aCtx = aCanvas.getContext('2d')!;

  const hCanvas = document.createElement('canvas');
  hCanvas.width = size;
  hCanvas.height = size;
  const hCtx = hCanvas.getContext('2d')!;

  const rCanvas = document.createElement('canvas');
  rCanvas.width = size;
  rCanvas.height = size;
  const rCtx = rCanvas.getContext('2d')!;

  // Smooth architectural cool gray
  aCtx.fillStyle = '#a6adb3';
  aCtx.fillRect(0, 0, size, size);
  hCtx.fillStyle = '#808080';
  hCtx.fillRect(0, 0, size, size);
  rCtx.fillStyle = '#484848'; // silky semi-gloss smooth finish
  rCtx.fillRect(0, 0, size, size);

  // Formwork panels seam lines (modern form-tie holes and subtle panel joints)
  aCtx.strokeStyle = '#858b90';
  aCtx.lineWidth = 2;
  hCtx.strokeStyle = '#444444';
  hCtx.lineWidth = 2;

  aCtx.strokeRect(0, 0, size, size);
  hCtx.strokeRect(0, 0, size, size);

  // Formwork tie holes in the four corners
  const holes = [[40, 40], [size - 40, 40], [40, size - 40], [size - 40, size - 40]];
  for (const [hx, hy] of holes) {
    aCtx.fillStyle = '#5c6166';
    aCtx.beginPath();
    aCtx.arc(hx, hy, 6, 0, Math.PI * 2);
    aCtx.fill();

    hCtx.fillStyle = '#222222';
    hCtx.beginPath();
    hCtx.arc(hx, hy, 6, 0, Math.PI * 2);
    hCtx.fill();
  }

  // Very fine subtle aggregate speckles
  for (let i = 0; i < 4000; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    const v = (Math.random() - 0.5) * 16;
    const tone = Math.floor(168 + v);
    aCtx.fillStyle = `rgb(${tone},${tone},${tone})`;
    aCtx.fillRect(x, y, 1, 1);
  }

  const albedo = new THREE.CanvasTexture(aCanvas);
  albedo.wrapS = THREE.RepeatWrapping;
  albedo.wrapT = THREE.RepeatWrapping;
  albedo.colorSpace = THREE.SRGBColorSpace;

  const normal = generateNormalMapFromCanvas(hCanvas, 1.8);
  const roughness = new THREE.CanvasTexture(rCanvas);
  roughness.wrapS = THREE.RepeatWrapping;
  roughness.wrapT = THREE.RepeatWrapping;

  pbrCache.set(`${cacheKey}_albedo`, albedo);
  pbrCache.set(`${cacheKey}_normal`, normal);
  pbrCache.set(`${cacheKey}_roughness`, roughness);

  return { albedo, normal, roughness };
}

/**
 * 6. Luxury Modern Pool Tiles PBR (Submerged turquoise ceramic mosaic + normal ripples)
 */
export function getPoolTilesPBR(): PBRTextureSet {
  const cacheKey = 'pool_mosaic';
  if (pbrCache.has(`${cacheKey}_albedo`)) {
    return {
      albedo: pbrCache.get(`${cacheKey}_albedo`) as THREE.CanvasTexture,
      normal: pbrCache.get(`${cacheKey}_normal`) as THREE.CanvasTexture,
      roughness: pbrCache.get(`${cacheKey}_roughness`) as THREE.CanvasTexture,
    };
  }

  const size = 512;
  const aCanvas = document.createElement('canvas');
  aCanvas.width = size;
  aCanvas.height = size;
  const aCtx = aCanvas.getContext('2d')!;

  const hCanvas = document.createElement('canvas');
  hCanvas.width = size;
  hCanvas.height = size;
  const hCtx = hCanvas.getContext('2d')!;

  const rCanvas = document.createElement('canvas');
  rCanvas.width = size;
  rCanvas.height = size;
  const rCtx = rCanvas.getContext('2d')!;

  // White grout base
  aCtx.fillStyle = '#e8f4f8';
  aCtx.fillRect(0, 0, size, size);
  hCtx.fillStyle = '#222222';
  hCtx.fillRect(0, 0, size, size);
  rCtx.fillStyle = '#777777';
  rCtx.fillRect(0, 0, size, size);

  // Tiny 16x16 mosaic glass tiles
  const tileSize = 28;
  const gap = 3;
  for (let y = gap; y < size - gap; y += tileSize + gap) {
    for (let x = gap; x < size - gap; x += tileSize + gap) {
      // Mediterranean azure/cyan variations
      const blue = 190 + Math.floor(Math.random() * 55);
      const green = 130 + Math.floor(Math.random() * 60);
      aCtx.fillStyle = `rgb(10, ${green}, ${blue})`;
      aCtx.fillRect(x, y, tileSize, tileSize);

      hCtx.fillStyle = '#dddddd'; // raised tile
      hCtx.fillRect(x, y, tileSize, tileSize);

      rCtx.fillStyle = '#111111'; // mirror-gloss glass reflection
      rCtx.fillRect(x, y, tileSize, tileSize);
    }
  }

  const albedo = new THREE.CanvasTexture(aCanvas);
  albedo.wrapS = THREE.RepeatWrapping;
  albedo.wrapT = THREE.RepeatWrapping;
  albedo.colorSpace = THREE.SRGBColorSpace;

  const normal = generateNormalMapFromCanvas(hCanvas, 3.5);
  const roughness = new THREE.CanvasTexture(rCanvas);
  roughness.wrapS = THREE.RepeatWrapping;
  roughness.wrapT = THREE.RepeatWrapping;

  pbrCache.set(`${cacheKey}_albedo`, albedo);
  pbrCache.set(`${cacheKey}_normal`, normal);
  pbrCache.set(`${cacheKey}_roughness`, roughness);

  return { albedo, normal, roughness };
}

/**
 * 7. Animated Fluid Water Wave Normal Map Generator
 */
export function getWaterRippleNormalMap(timeSec: number = 0): THREE.CanvasTexture {
  const cacheKey = 'water_ripple_norm';
  let canvas = pbrCache.get(cacheKey) as unknown as HTMLCanvasElement;
  let texture: THREE.CanvasTexture;

  if (!canvas) {
    canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.colorSpace = THREE.NoColorSpace;
    pbrCache.set(cacheKey, canvas as unknown as THREE.Texture);
    pbrCache.set(`${cacheKey}_tex`, texture);
  } else {
    texture = pbrCache.get(`${cacheKey}_tex`) as THREE.CanvasTexture;
  }

  const ctx = canvas.getContext('2d')!;
  const img = ctx.createImageData(256, 256);
  const data = img.data;
  const w = 256;
  const h = 256;

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      // Dual intersecting wave equations
      const wave1 = Math.sin((x * 0.08) + (timeSec * 2.2)) * Math.cos((y * 0.08) + (timeSec * 1.8));
      const wave2 = Math.sin((x * 0.14 - y * 0.12) - (timeSec * 2.8));
      const wave3 = Math.cos((x * 0.04 + y * 0.05) + (timeSec * 1.1));

      const dx = wave1 * 0.5 + wave2 * 0.4 + wave3 * 0.2;
      const dy = wave1 * 0.4 - wave2 * 0.5 + wave3 * 0.3;
      const dz = 1.0;

      const len = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1.0;
      const nx = -dx / len;
      const ny = -dy / len;
      const nz = dz / len;

      const idx = (y * w + x) * 4;
      data[idx + 0] = Math.round((nx * 0.5 + 0.5) * 255);
      data[idx + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      data[idx + 2] = Math.round((nz * 0.5 + 0.5) * 255);
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(img, 0, 0);
  texture.needsUpdate = true;
  return texture;
}

/**
 * 8. Decayed Zombie Flesh PBR (Rotting pale flesh, exposed veins, blood spatters)
 */
export function getZombieFleshPBR(isBrute: boolean = false): PBRTextureSet {
  const cacheKey = `zombie_flesh_${isBrute}`;
  if (pbrCache.has(`${cacheKey}_albedo`)) {
    return {
      albedo: pbrCache.get(`${cacheKey}_albedo`) as THREE.CanvasTexture,
      normal: pbrCache.get(`${cacheKey}_normal`) as THREE.CanvasTexture,
      roughness: pbrCache.get(`${cacheKey}_roughness`) as THREE.CanvasTexture,
    };
  }

  const size = 256;
  const aCanvas = document.createElement('canvas');
  aCanvas.width = size;
  aCanvas.height = size;
  const aCtx = aCanvas.getContext('2d')!;

  const hCanvas = document.createElement('canvas');
  hCanvas.width = size;
  hCanvas.height = size;
  const hCtx = hCanvas.getContext('2d')!;

  const rCanvas = document.createElement('canvas');
  rCanvas.width = size;
  rCanvas.height = size;
  const rCtx = rCanvas.getContext('2d')!;

  // Decayed sickly pallor
  aCtx.fillStyle = isBrute ? '#3a4436' : '#52664b';
  aCtx.fillRect(0, 0, size, size);
  hCtx.fillStyle = '#808080';
  hCtx.fillRect(0, 0, size, size);
  rCtx.fillStyle = '#aaaaaa';
  rCtx.fillRect(0, 0, size, size);

  // Blackened necrotic veins
  for (let v = 0; v < 18; v++) {
    let vx = Math.random() * size;
    let vy = Math.random() * size;
    aCtx.strokeStyle = '#1b2618';
    aCtx.lineWidth = 1.2;
    hCtx.strokeStyle = '#444444';
    hCtx.lineWidth = 1.2;

    aCtx.beginPath();
    hCtx.beginPath();
    aCtx.moveTo(vx, vy);
    hCtx.moveTo(vx, vy);
    for (let s = 0; s < 4; s++) {
      vx += (Math.random() - 0.5) * 35;
      vy += (Math.random() - 0.5) * 35;
      aCtx.lineTo(vx, vy);
      hCtx.lineTo(vx, vy);
    }
    aCtx.stroke();
    hCtx.stroke();
  }

  // Dried coagulated blood stains & glistening wet gore patches
  for (let b = 0; b < 25; b++) {
    const bx = Math.random() * size;
    const by = Math.random() * size;
    const br = 4 + Math.random() * 14;

    const grad = aCtx.createRadialGradient(bx, by, 1, bx, by, br);
    grad.addColorStop(0, '#590d16');
    grad.addColorStop(0.7, '#38060c');
    grad.addColorStop(1, 'rgba(56, 6, 12, 0)');
    aCtx.fillStyle = grad;
    aCtx.beginPath();
    aCtx.arc(bx, by, br, 0, Math.PI * 2);
    aCtx.fill();

    // High specular wet sheen on fresh blood
    rCtx.fillStyle = '#111111';
    rCtx.beginPath();
    rCtx.arc(bx, by, br * 0.6, 0, Math.PI * 2);
    rCtx.fill();
  }

  const albedo = new THREE.CanvasTexture(aCanvas);
  albedo.wrapS = THREE.RepeatWrapping;
  albedo.wrapT = THREE.RepeatWrapping;
  albedo.colorSpace = THREE.SRGBColorSpace;

  const normal = generateNormalMapFromCanvas(hCanvas, 2.5);
  const roughness = new THREE.CanvasTexture(rCanvas);
  roughness.wrapS = THREE.RepeatWrapping;
  roughness.wrapT = THREE.RepeatWrapping;

  pbrCache.set(`${cacheKey}_albedo`, albedo);
  pbrCache.set(`${cacheKey}_normal`, normal);
  pbrCache.set(`${cacheKey}_roughness`, roughness);

  return { albedo, normal, roughness };
}
