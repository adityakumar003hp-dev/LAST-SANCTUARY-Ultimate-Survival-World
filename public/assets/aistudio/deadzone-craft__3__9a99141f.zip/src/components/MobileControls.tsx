import React, { useEffect, useRef, useState } from 'react';
import { Hand, ArrowUp, Zap, Camera, ZoomIn, ZoomOut } from 'lucide-react';

interface MobileControlsProps {
  onMoveChange: (move: { forward: boolean; backward: boolean; left: boolean; right: boolean }) => void;
  onLookDelta: (dx: number, dy: number) => void;
  onJump: () => void;
  onSprintToggle: (sprint: boolean) => void;
  onPrimaryAction: () => void;
  onInteract: () => void;
  onOpenBuild: () => void;
  onToggleCamera: () => void;
  onZoom: (delta: number) => void;
}

export const MobileControls: React.FC<MobileControlsProps> = ({
  onMoveChange, onLookDelta, onJump, onSprintToggle, onPrimaryAction,
  onInteract, onOpenBuild, onToggleCamera, onZoom,
}) => {
  const [isMobile, setIsMobile] = useState(false);
  const [isSprinting, setIsSprinting] = useState(false);
  const [joystickPos, setJoystickPos] = useState({ x: 0, y: 0 });
  const joystickRef = useRef<HTMLDivElement>(null);
  const joystickPointer = useRef<number | null>(null);
  const lookPointers = useRef(new Map<number, { x: number; y: number }>());
  const pinchDistance = useRef<number | null>(null);

  useEffect(() => {
    const check = () => setIsMobile(('ontouchstart' in window) || navigator.maxTouchPoints > 0);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);


  if (!isMobile) return null;

  const updateJoystick = (clientX: number, clientY: number) => {
    const el = joystickRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    let dx = clientX - (rect.left + rect.width / 2);
    let dy = clientY - (rect.top + rect.height / 2);
    const radius = Math.min(rect.width, rect.height) * 0.34;
    const distance = Math.hypot(dx, dy);
    if (distance > radius) { dx = dx / distance * radius; dy = dy / distance * radius; }
    setJoystickPos({ x: dx, y: dy });
    const nx = dx / radius, ny = dy / radius;
    const deadZone = 0.16;
    onMoveChange({
      forward: ny < -deadZone,
      backward: ny > deadZone,
      left: nx < -deadZone,
      right: nx > deadZone,
    });
  };

  const releaseJoystick = (e: React.PointerEvent<HTMLDivElement>) => {
    if (joystickPointer.current !== e.pointerId) return;
    joystickPointer.current = null;
    try { e.currentTarget.releasePointerCapture(e.pointerId); } catch { /* capture may already be released */ }
    setJoystickPos({ x: 0, y: 0 });
    onMoveChange({ forward: false, backward: false, left: false, right: false });
  };

  const handleLookDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === 'mouse' || (e.target as HTMLElement).closest('button')) return;
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    lookPointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (lookPointers.current.size === 2) {
      const pts = [...lookPointers.current.values()];
      pinchDistance.current = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
    }
  };

  const handleLookMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!lookPointers.current.has(e.pointerId)) return;
    e.preventDefault();
    const previous = lookPointers.current.get(e.pointerId)!;
    lookPointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (lookPointers.current.size >= 2) {
      const pts = [...lookPointers.current.values()];
      const distance = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
      if (pinchDistance.current !== null) {
        const change = distance - pinchDistance.current;
        if (Math.abs(change) > 0.5) onZoom(change * -0.025);
      }
      pinchDistance.current = distance;
    } else {
      onLookDelta(e.clientX - previous.x, e.clientY - previous.y);
    }
  };

  const handleLookUp = (e: React.PointerEvent<HTMLDivElement>) => {
    lookPointers.current.delete(e.pointerId);
    if (lookPointers.current.size < 2) pinchDistance.current = null;
    try { e.currentTarget.releasePointerCapture(e.pointerId); } catch { /* already released */ }
  };

  return (
    <div className="pointer-events-none absolute inset-0 z-30 select-none overflow-hidden" style={{ touchAction: 'none' }}>
      {/* Drag anywhere on the right side to orbit the camera; two fingers pinch to zoom. */}
      <div
        className="pointer-events-auto absolute left-[42%] right-0 top-0 bottom-32 z-0"
        style={{ touchAction: 'none' }}
        onPointerDown={handleLookDown}
        onPointerMove={handleLookMove}
        onPointerUp={handleLookUp}
        onPointerCancel={handleLookUp}
      />

      <div className="pointer-events-auto absolute right-4 top-24 z-20 flex flex-col gap-2">
        <button type="button" onClick={onToggleCamera} className="flex h-11 min-w-11 items-center justify-center gap-1 rounded-xl border border-neutral-700 bg-neutral-950/85 px-3 text-xs font-bold text-white shadow-lg active:scale-95" aria-label="Change camera view">
          <Camera className="h-4 w-4" /> VIEW
        </button>
        <div className="flex gap-2">
          <button type="button" onClick={() => onZoom(-0.7)} className="flex h-11 w-11 items-center justify-center rounded-xl border border-neutral-700 bg-neutral-950/85 text-white shadow-lg active:scale-95" aria-label="Zoom in"><ZoomIn className="h-5 w-5" /></button>
          <button type="button" onClick={() => onZoom(0.7)} className="flex h-11 w-11 items-center justify-center rounded-xl border border-neutral-700 bg-neutral-950/85 text-white shadow-lg active:scale-95" aria-label="Zoom out"><ZoomOut className="h-5 w-5" /></button>
        </div>
      </div>

      <div className="pointer-events-auto absolute bottom-8 left-8 z-20" onContextMenu={(e) => e.preventDefault()}>
        <div
          ref={joystickRef}
          onPointerDown={(e) => {
            e.preventDefault(); e.stopPropagation();
            if (joystickPointer.current !== null) return;
            joystickPointer.current = e.pointerId;
            e.currentTarget.setPointerCapture(e.pointerId);
            updateJoystick(e.clientX, e.clientY);
          }}
          onPointerMove={(e) => {
            if (joystickPointer.current !== e.pointerId) return;
            e.preventDefault(); updateJoystick(e.clientX, e.clientY);
          }}
          onPointerUp={releaseJoystick}
          onPointerCancel={releaseJoystick}
          className="relative flex h-32 w-32 items-center justify-center rounded-full border border-neutral-600/80 bg-neutral-900/65 shadow-xl backdrop-blur-sm"
          style={{ touchAction: 'none' }}
          aria-label="Movement joystick"
        >
          <div className="pointer-events-none h-14 w-14 rounded-full border border-amber-300 bg-amber-500/85 shadow-md" style={{ transform: `translate(${joystickPos.x}px, ${joystickPos.y}px)` }} />
        </div>
      </div>

      <div className="pointer-events-auto absolute bottom-8 right-8 z-20 flex flex-col items-end gap-3">
        <div className="flex items-center gap-3">
          <button type="button" onClick={() => { const next = !isSprinting; setIsSprinting(next); onSprintToggle(next); }} className={`flex h-12 w-12 items-center justify-center rounded-full border shadow-lg ${isSprinting ? 'border-amber-300 bg-amber-500 text-neutral-950' : 'border-neutral-700 bg-neutral-900/80 text-neutral-300'}`} aria-label="Toggle sprint"><Zap className="h-5 w-5" /></button>
          <button type="button" onClick={onJump} className="flex h-12 w-12 items-center justify-center rounded-full border border-neutral-700 bg-neutral-900/80 text-neutral-200 shadow-lg" aria-label="Jump"><ArrowUp className="h-5 w-5" /></button>
          <button type="button" onClick={onInteract} className="flex h-12 w-12 items-center justify-center rounded-full border border-emerald-400 bg-emerald-600/90 text-xs font-bold text-white shadow-lg">USE</button>
        </div>
        <button type="button" onClick={onPrimaryAction} className="flex h-16 w-16 items-center justify-center rounded-full border-2 border-amber-200 bg-gradient-to-tr from-amber-600 to-amber-400 text-neutral-950 shadow-2xl active:scale-95" aria-label="Primary action"><Hand className="h-7 w-7" /></button>
      </div>
    </div>
  );
};
