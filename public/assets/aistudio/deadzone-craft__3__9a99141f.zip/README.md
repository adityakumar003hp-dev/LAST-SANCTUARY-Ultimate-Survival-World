<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/ad41dc98-8556-4bb8-83f9-3ab24afceb7c

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## Modern base update

The starter compound now includes a procedural solar array, refrigerator storage, lounge sofa, operations desk, recreation pool, light modular barricades, and solar perimeter lamps. Camera cycling supports first-person, third-person, and a front-facing second-person-style observer camera using `V`.
