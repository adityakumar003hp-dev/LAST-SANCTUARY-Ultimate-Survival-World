# AI Train Physical Presence and Station Dwell Update

## Implemented in source

- Added `src/engine/world/AITrainManager.ts` and wired it into `GameEngine`.
- Four non-drivable AI trains are instantiated as solid Three.js mesh assemblies on F2, F3, B2 and B3.
- Each train includes a carriage body, roof, windows, bogies, individual wheel meshes, headlights and animated physical door panels.
- Rail beds, steel rails, sleepers and station platforms/canopies are generated as real 3D geometry around the player and trains. Geometry is streamed in bounded chunks while the route coordinates continue in both positive and negative X directions.
- Each AI train stops at every generated station coordinate and holds for 120 seconds of active game simulation. Doors open during the dwell and close during the final two seconds before departure.
- AI trains are marked `playerDrivable: false`; this update does not grant driving control on F2/F3/B2/B3.
- Train collision bounding boxes are exposed through `getTrainCollisionBoxes()` for later integration with a dedicated train/player collision response.

## Important limitations

- This update establishes a straight, coordinate-driven AI rail corridor for the four AI-only lines. It does not yet connect the tracks to the procedural POI/city/station graph, nor does it implement the separate F1/B1 player-driving system.
- Train meshes and station/track geometry are physically modeled Three.js objects, not ghost sprites. The current player controller does not consume the exposed train collision boxes, so train-to-player blocking/impact response is not yet integrated.
- The 120-second dwell counts active simulation seconds; pausing the game pauses the dwell timer.

## Validation performed for this update

- TypeScript syntax transpilation: passed for `AITrainManager.ts` and the modified `GameEngine.ts` (zero syntax diagnostics).
- Dependency installation: timed out in this environment.
- Full TypeScript semantic check: not run.
- Vite production build: not run.
- Runtime/in-game verification: not run.
