# LAST SANCTUARY: REBIRTH — FINAL MASTER IMPLEMENTATION SPECIFICATION

This document is the authoritative combined target for the existing React + TypeScript + Three.js project in this archive. Implement additively in the existing architecture; do not create a separate demo or remove existing gameplay.

## A. Preserve the existing game

Preserve the current apartment/prologue and Day 1/Day 2 storyline, all three friends/companions, Starter Base, environments, biomes, terrain/chunk streaming, player movement and camera, collision/physics, wildlife, NPCs, zombies, inventory, crafting, vehicles, missions, controls, UI, and existing save compatibility. Keep fixed authored locations fixed; do not randomly duplicate the apartment or Starter Base.

## B. Luxury mansion / apartment

Upgrade the existing apartment/building into a complete four-storey modern contemporary luxury mansion while retaining its world location and story interactions. Use white/grey stone, glass, timber accents, balconies, exterior lighting, landscaped grounds, driveway, boundary wall and gate. Complete front, rear and side elevations. Floor 1: foyer, living room, interactive TV, kitchen, refrigerator, dining area, bedroom, bathroom, storage, lights, fan, AC and phone interactions. Floor 2: grey-themed family lounge, bedrooms, wardrobes, bathroom and balcony. Floor 3: fictional equipment/armory display room linked to the existing inventory (no duplicate inventory). Floor 4: rooftop pool, safe deck, railings, steps, loungers, shade, plants and night lighting. One continuous accessible staircase connects all floors. Fix interior visibility, wall/door openings, camera clipping, material culling, lighting and collision. Never hide whole floors to reveal an interior.

## C. Apartment spawn and traversal

Every new game starts at the intended bedroom/opening-story spawn point inside the existing apartment, safely above the floor and outside furniture/walls. Initialize Day 1 exactly once. Never spawn outside and teleport indoors. Existing saves restore their saved position; only invalid saved positions use a safe apartment fallback. Doors must physically open; the player can walk out and re-enter without teleportation or an entrance loading screen. Fix thresholds, colliders, camera, lighting and indoor/outdoor chunk visibility.

## D. Infinite deterministic discoverable world

Generate settlements and facilities deterministically from world seed plus signed chunk coordinates. Include large/small cities, districts, towns, villages, rural/abandoned settlements, hospitals, clinics, medical research centres, emergency treatment facilities, fire stations, police stations, emergency response centres, laboratories, science campuses, restricted research compounds, shopping centres, markets, supermarkets, hotels, restaurants, service stations, factories, warehouses, industrial complexes, freight facilities, power stations, water-treatment facilities, schools, colleges, universities, farms, barns, airports, helipads, transport depots, ranger stations, watchtowers, campsites, ruins and roadside shelters. Avoid water, steep terrain, overlaps and impossible placements. Create coherent street layouts, roads and access paths. Stream distant landmarks, detailed exteriors and interiors progressively; do not load the whole world at once.

Discovery states are undiscovered, seen, discovered and visited. On discovery, show name/category, notify the player, save stable ID/coordinates and add a map entry. Mark visited on entry. Provide map filters for settlements, medical, emergency, research, industrial, transport, railway, safe locations and unknown landmarks. Persist discovery across save/load.

## E. Six-track infinite railway — exact configuration

There are exactly six main railway tracks, continuously connected through the generated world:

| Track | Direction | Player access |
|---|---|---|
| F1 | Forward | Player-drivable and explorable |
| F2 | Forward | AI-controlled, explorable, never player-drivable |
| F3 | Forward | AI-controlled, explorable, never player-drivable |
| B1 | Backward | Player-drivable and explorable |
| B2 | Backward | AI-controlled, explorable, never player-drivable |
| B3 | Backward | AI-controlled, explorable, never player-drivable |

The network continues deterministically into positive and negative world coordinates. Adjacent chunks must join with no gaps, misalignment or accidental dead ends. Generate upcoming chunks before trains reach them and unload distant render geometry while retaining route metadata for active trains. All six tracks are physically present and explorable. Only F1 and B1 can ever expose player driving controls.

## F. Railway access to major structures

Connect every major city, town, significant village, research facility, laboratory, hospital, major medical centre, fire station, police station, industrial complex, factory, warehouse, airport, major transport depot, power station, water-treatment plant, large agricultural facility and freight terminal by a valid station, terminal, freight siding or branch route. Small individual houses can use roads/paths to the nearest station. Include rural stops, village stations, town stations, city terminals, research/hospital/emergency stops, industrial freight terminals and maintenance depots. Every station has stable ID/name, platform, track connections, direction, discovery state, map icon and valid route. Cities may have multiple stations.

Include junctions, switches, crossovers, station loops, freight and maintenance sidings, yards, bridges, tunnels, embankments, cuttings, level crossings, signals, platforms and depots. Use a persistent route graph; switches must connect only valid routes. Preserve track direction and player/AI permissions.

## G. Player trains on F1 and B1

Implement boarding, driver cabin, train camera, acceleration/coasting/braking, speed display, station stopping, route selection, valid junction traversal and safe disembarking only while stopped. Train movement follows the railway graph, stays aligned to rails, handles curves and chunk boundaries, and stops at station markers. Support desktop and mobile controls.

## H. Four physical AI trains on F2/F3/B2/B3

Each AI-only line has physical 3D train assemblies with carriage body, roof, windows, bogies, wheels, doors, headlights and solid collision geometry. These must not be ghost sprites, transparent impostors or decorative non-interactive visuals. AI trains follow assigned valid routes, obey signals and block occupancy, avoid collisions, stop at their stations and resume. At **every station**, each AI train stops for **exactly 120 seconds of active game time**. Doors open while stopped and close before departure. Pausing the game pauses the dwell timer. This dwell rule applies repeatedly at every station, not just the first stop. AI trains never become player-drivable. Player collision response with physical trains must be implemented and tested.

## I. Save/load

Persist world seed, generated stable structure IDs, discovery/visit state, station/route IDs, discovered lines, junction state where needed, train availability and safe train route progress, apartment story progress, player position, inventory, companions, missions and Starter Base progress. Do not serialize transient meshes/particles; rebuild from stable data. Keep older saves compatible.

## J. Performance and mobile

Use chunk streaming, LOD, instancing, compressed textures, bounded active AI simulation, simplified distant collision, detailed nearby collision, interior-on-demand loading, spatial queries and quality-scaled shadows/reflections. Avoid full-world scans per frame, geometry recreation per frame, duplicate listeners, unbounded mesh retention and loading freezes. Maintain mobile and desktop controls and performance.

## K. Required verification before claiming completion

Run TypeScript semantic checks, lint, production build and automated tests. In-game test all four mansion floors and interactions; new-game apartment spawn and seamless entry/exit; existing save restoration; deterministic structure generation and discovery persistence; all six connected railway tracks; F1/B1 driving; AI-only permissions for F2/F3/B2/B3; AI train physical collision; 120-second stop at every station; station/branch connectivity to major structures; chunk-boundary continuity; desktop and mobile controls/performance. Never report a test as passed unless it was actually run successfully.

## L. Final Google AI Studio instruction

Inspect the entire existing source project first. Implement every section above directly into this project using its current React/Three.js/TypeScript architecture. Preserve all existing systems and saves. Resolve architectural conflicts rather than adding duplicate parallel systems. Integrate the railway into one coherent route graph shared by chunk generation, stations, POIs, AI trains and player trains. Deliver the complete updated source project ZIP and a truthful report listing completed features, remaining work, and tests actually run.
