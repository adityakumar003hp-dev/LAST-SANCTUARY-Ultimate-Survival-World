import * as THREE from 'three';
import { getTerrainHeight } from '../Terrain';
import { UnifiedPhysicsManager } from '../physics/UnifiedPhysicsManager';
import { soundEngine } from '../../utils/audio';

/**
 * Six-Track Railway and Train Simulation System.
 * 
 * Tracks:
 * - F1: Forward (+X), AI-operated passenger service
 * - F2: Forward (+X), AI Express, 120s station dwell, animated doors
 * - F3: Forward (+X), AI Commuter, 120s station dwell, animated doors
 * - B3: Backward (-X), AI Metro, 120s station dwell, animated doors
 * - B2: Backward (-X), AI Intercity, 120s station dwell, animated doors
 * - B1: Backward (-X), AI-operated passenger service
 */
export type RailwayTrackLine = 'F1' | 'F2' | 'F3' | 'B1' | 'B2' | 'B3';

export interface AITrain {
  id: string;
  line: RailwayTrackLine;
  direction: 1 | -1;
  group: THREE.Group;
  x: number;
  z: number;
  speed: number;
  dwellRemaining: number;
  currentStationIndex: number | null;
  doors: THREE.Mesh[];
  stationStatus: 'running' | 'doors_open' | 'doors_closing';
  isOccupied: boolean;
  lastAnnouncedStationIndex: number | null;
}

export interface DrivableTrain {
  id: string;
  line: 'F1' | 'B1';
  direction: 1 | -1;
  group: THREE.Group;
  x: number;
  z: number;
  speed: number;
  targetSpeed: number;
  throttle: number; // -1.0 (full brake/reverse) to +1.0 (full throttle)
  doors: THREE.Mesh[];
  doorsOpen: boolean;
  headlightsOn: boolean;
  spotlightL: THREE.SpotLight;
  spotlightR: THREE.SpotLight;
  cabinLight: THREE.PointLight;
  cabCameraActive: boolean;
  isOccupied: boolean;
  lastAnnouncedStationIndex: number | null;
}

const CHUNK_LENGTH = 128;
const TRACK_SEGMENT_LENGTH = 16;
const STATION_SPACING = 1200;
const DWELL_SECONDS = 120;
const AI_TRAIN_SPEED = 14;

const ALL_TRACKS: Array<{ id: RailwayTrackLine; z: number; direction: 1 | -1; isPlayerDrivable: false; startX: number }> = [
  { id: 'F1', z: 150, direction: 1, isPlayerDrivable: false, startX: 12 },
  { id: 'F2', z: 162, direction: 1, isPlayerDrivable: false, startX: -260 },
  { id: 'F3', z: 174, direction: 1, isPlayerDrivable: false, startX: -760 },
  { id: 'B3', z: 186, direction: -1, isPlayerDrivable: false, startX: 260 },
  { id: 'B2', z: 198, direction: -1, isPlayerDrivable: false, startX: 760 },
  { id: 'B1', z: 210, direction: -1, isPlayerDrivable: false, startX: -12 },
];

export class AITrainManager {
  private scene: THREE.Scene;
  private worldSeed: number;

  public trains: AITrain[] = [];
  public drivableTrains: DrivableTrain[] = [];
  public activeDrivableTrain: DrivableTrain | null = null;
  public activePassengerTrain: AITrain | null = null;
  public passengerSeatLocalPosition: THREE.Vector3 | null = null;
  private campaignRelayGroup!: THREE.Group;
  private finalJourneyGroup!: THREE.Group;

  private railChunks = new Map<string, THREE.Group>();
  private stationGroups = new Map<string, THREE.Group>();

  // Shared Procedural Railway Materials
  private readonly railMaterial = new THREE.MeshStandardMaterial({ color: 0x717b84, metalness: 0.85, roughness: 0.28 });
  private readonly sleeperMaterial = new THREE.MeshStandardMaterial({ color: 0x3d352b, roughness: 0.94 });
  private readonly platformMaterial = new THREE.MeshStandardMaterial({ color: 0x82868a, roughness: 0.88 });
  private readonly ballastMaterial = new THREE.MeshStandardMaterial({ color: 0x4f4d49, roughness: 1.0 });
  private readonly aiTrainBodyMaterial = new THREE.MeshStandardMaterial({ color: 0x244259, metalness: 0.65, roughness: 0.32 });
  private readonly playerTrainBodyMaterial = new THREE.MeshStandardMaterial({ color: 0x8b251e, metalness: 0.72, roughness: 0.28 }); // Distinct red/gold locomotive
  private readonly windowMaterial = new THREE.MeshPhysicalMaterial({ color: 0x9be0f0, metalness: 0.2, roughness: 0.1, transparent: true, opacity: 0.75, depthWrite: false });
  private readonly wheelMaterial = new THREE.MeshStandardMaterial({ color: 0x16181b, metalness: 0.8, roughness: 0.45 });
  private readonly doorMaterial = new THREE.MeshStandardMaterial({ color: 0xabb8bf, metalness: 0.6, roughness: 0.35 });

  // Wheel clatter audio timer
  private wheelAudioTimer = 0;
  private readonly collisionCenter = new THREE.Vector3();

  constructor(scene: THREE.Scene, worldSeed = 42) {
    this.scene = scene;
    this.worldSeed = worldSeed;

    // All six passenger services are autonomous; no locomotive accepts player control.
    const aiConfigs = ALL_TRACKS;
    for (const line of aiConfigs) {
      const group = this.createTrainMesh(line.id, false);
      this.scene.add(group);
      this.trains.push({
        id: `ai_train_${line.id.toLowerCase()}`,
        line: line.id,
        direction: line.direction,
        group,
        x: line.startX,
        z: line.z,
        speed: 0,
        dwellRemaining: 0,
        currentStationIndex: null,
        doors: group.userData.doors as THREE.Mesh[],
        stationStatus: 'running',
        isOccupied: false,
        lastAnnouncedStationIndex: null,
      });
    }

    // AI-only invariant: no player-drivable locomotive is ever instantiated.
    this.drivableTrains = [];
    this.activeDrivableTrain = null;
    this.campaignRelayGroup = this.createCampaignBeacon('forgotten_network_relay', 2425, 165, 0x22c9d9);
    this.finalJourneyGroup = this.createCampaignBeacon('final_journey_beacon', 4825, 165, 0xffbd59);
    this.campaignRelayGroup.visible = false;
    this.finalJourneyGroup.visible = false;
  }

  private createCampaignBeacon(name: string, x: number, z: number, color: number): THREE.Group {
    const group = new THREE.Group(); group.name = name;
    const groundY = getTerrainHeight(x,z,this.worldSeed); group.position.set(x,groundY,z);
    const steel = new THREE.MeshStandardMaterial({color:0x3a4a55,metalness:0.75,roughness:0.35});
    const beaconMat = new THREE.MeshStandardMaterial({color,emissive:color,emissiveIntensity:1.6,metalness:0.25,roughness:0.3});
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.12,0.2,4.0,10),steel); mast.position.set(0,2.0,0); mast.castShadow=true; group.add(mast);
    const dish = new THREE.Mesh(new THREE.SphereGeometry(0.72,14,10,0,Math.PI*2,0,Math.PI*0.55),steel); dish.position.set(0,3.35,0.15); dish.rotation.x=-Math.PI/2.6; group.add(dish);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.62,0.055,8,24),beaconMat); ring.position.set(0,3.25,0.2); ring.rotation.x=Math.PI/2; group.add(ring);
    const console = new THREE.Mesh(new THREE.BoxGeometry(1.25,1.05,0.8),steel); console.position.set(2.0,0.62,1.1); console.castShadow=true; group.add(console);
    const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.7,0.42),beaconMat); screen.position.set(2.0,0.82,0.68); screen.rotation.x=-0.16; group.add(screen);
    const light = new THREE.PointLight(color,2.0,18,1.5); light.position.set(0,3.6,0); group.add(light);
    group.userData.interactionPosition = new THREE.Vector3(x+2.0,groundY+0.85,z+1.1);
    this.scene.add(group);
    return group;
  }

  public getCampaignRelayPosition(): THREE.Vector3 { return (this.campaignRelayGroup.userData.interactionPosition as THREE.Vector3).clone(); }
  public getFinalJourneyPosition(): THREE.Vector3 { return (this.finalJourneyGroup.userData.interactionPosition as THREE.Vector3).clone(); }
  public setCampaignBeaconsVisible(relayVisible: boolean, finalVisible: boolean): void {
    const physics = UnifiedPhysicsManager.getInstance();
    if (this.campaignRelayGroup.visible !== relayVisible) {
      this.campaignRelayGroup.visible = relayVisible;
      if (relayVisible) physics?.registerBoxCollider('campaign_relay_console','prop',[2427,this.campaignRelayGroup.position.y+0.62,166.1],1.25,1.05,0.8);
      else physics?.unregisterCollider('campaign_relay_console');
    }
    if (this.finalJourneyGroup.visible !== finalVisible) {
      this.finalJourneyGroup.visible = finalVisible;
      if (finalVisible) physics?.registerBoxCollider('campaign_final_console','prop',[4827,this.finalJourneyGroup.position.y+0.62,166.1],1.25,1.05,0.8);
      else physics?.unregisterCollider('campaign_final_console');
    }
  }

  /** Height of the rail-running surface, sampled on the same 16m world grid as the rails. */
  private trackSurfaceY(x: number, z: number): number {
    const segmentCenter = Math.floor(x / TRACK_SEGMENT_LENGTH) * TRACK_SEGMENT_LENGTH + TRACK_SEGMENT_LENGTH * 0.5;
    // Rail top is 0.43m above the sampled terrain; wheel bottoms sit 0.06m below the train origin.
    return getTerrainHeight(segmentCenter, z, this.worldSeed) + 0.37;
  }

  private terrainY(x: number, z: number): number {
    return this.trackSurfaceY(x, z);
  }

  // --- Physical 3D Train Mesh Construction ---
  private createTrainMesh(line: RailwayTrackLine, isPlayerDrivable: false): THREE.Group {
    const root = new THREE.Group();
    root.name = isPlayerDrivable ? `DRIVABLE_TRAIN_${line}` : `PHYSICAL_AI_TRAIN_${line}`;
    root.userData = {
      lineId: line,
      physicalMesh: true,
      playerDrivable: isPlayerDrivable,
      collisionProxy: new THREE.Box3(),
    };

    const bodyMat = isPlayerDrivable ? this.playerTrainBodyMaterial : this.aiTrainBodyMaterial;

    // 1. Locomotive underframe and open passenger shell.
    // Do NOT use a single solid body box here: it visually seals the interior.
    // The floor, side-wall bands, end bulkheads and roof form a walkable enclosed carriage.
    const underframe = new THREE.Mesh(new THREE.BoxGeometry(25.6, 0.72, 3.55), bodyMat);
    underframe.position.set(0, 0.78, 0);
    underframe.castShadow = true;
    underframe.receiveShadow = true;
    root.add(underframe);

    const interiorWallMat = new THREE.MeshStandardMaterial({
      color: isPlayerDrivable ? 0x632d26 : 0x203b4b,
      metalness: 0.38,
      roughness: 0.72,
    });
    // Solid lower and upper side-wall bands leave the glazed window strip visible.
    for (const side of [-1, 1]) {
      // Split the lower wall into sections around the two sliding-door apertures.
      for (const [segmentStart, segmentEnd] of [[-12.5, -6.8], [-5.2, 4.7], [6.3, 12.5]]) {
        const lowerWall = new THREE.Mesh(
          new THREE.BoxGeometry(segmentEnd - segmentStart, 0.72, 0.16),
          interiorWallMat
        );
        lowerWall.position.set((segmentStart + segmentEnd) * 0.5, 2.05, side * 1.82);
        lowerWall.castShadow = true;
        root.add(lowerWall);
      }
      const upperWall = new THREE.Mesh(new THREE.BoxGeometry(25.0, 0.48, 0.16), interiorWallMat);
      upperWall.position.set(-0.1, 4.78, side * 1.82);
      upperWall.castShadow = true;
      root.add(upperWall);
      // Structural mullions make the side walls continuous around the window openings.
      for (let wx = -11.8; wx <= 11.8; wx += 3.1) {
        if (Math.abs(wx + 6.0) < 1.0 || Math.abs(wx - 5.5) < 1.0) continue;
        const post = new THREE.Mesh(new THREE.BoxGeometry(0.16, 2.15, 0.2), interiorWallMat);
        post.position.set(wx, 3.55, side * 1.82);
        root.add(post);
      }
    }
    // End bulkheads are split around the central gangway so passengers can walk between cars.
    for (const endX of [-12.45, 12.45]) for (const sideZ of [-1.25, 1.25]) {
      const panel = new THREE.Mesh(new THREE.BoxGeometry(0.18, 3.0, 1.05), interiorWallMat);
      panel.position.set(endX, 3.0, sideZ); root.add(panel);
    }

    // Visible passenger interior: floor, aisle, seats and grab rails. The roof remains
    // solid for exterior realism; boarding uses a dedicated interior camera position.
    const interiorFloor = new THREE.Mesh(new THREE.BoxGeometry(23.5, 0.12, 3.15), new THREE.MeshStandardMaterial({ color: 0x343b42, roughness: 0.82 }));
    interiorFloor.position.set(-0.2, 1.45, 0);
    root.add(interiorFloor);
    const seatMat = new THREE.MeshStandardMaterial({ color: isPlayerDrivable ? 0x7b3428 : 0x31566a, roughness: 0.9 });
    for (const sx of [-8, -3, 3, 8]) {
      for (const side of [-1, 1]) {
        const seat = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.9, 0.82), seatMat);
        seat.position.set(sx, 2.05, side * 1.0);
        seat.userData.isPassengerSeat = true;
        root.add(seat);
        const back = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.95, 0.16), seatMat);
        back.position.set(sx - 0.55, 2.5, side * 1.0);
        root.add(back);
      }
    }
    const aisleMat = new THREE.MeshStandardMaterial({ color: 0x9aa3aa, metalness: 0.65, roughness: 0.35 });
    for (const ax of [-9, -3, 3, 9]) {
      const rail = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 1.1, 8), aisleMat);
      rail.position.set(ax, 3.25, 0);
      root.add(rail);
    }

    // 2. Streamlined Aerodynamic Cab Roof
    const roof = new THREE.Mesh(
      new THREE.BoxGeometry(25.2, 0.45, 3.65),
      new THREE.MeshStandardMaterial({ color: 0x141a21, metalness: 0.6, roughness: 0.4 })
    );
    roof.position.set(0, 5.4, 0);
    roof.castShadow = true;
    root.add(roof);

    // 3. Driver's Cabin Front Nose & Heavy Cowcatcher / Pilot Grill
    const noseGeo = new THREE.BoxGeometry(2.4, 3.2, 3.6);
    const nose = new THREE.Mesh(noseGeo, bodyMat);
    nose.position.set(13.2, 2.65, 0);
    nose.castShadow = true;
    root.add(nose);

    // V-shaped heavy steel cowcatcher grill
    const cowcatcherMat = new THREE.MeshStandardMaterial({ color: 0x22262a, metalness: 0.85, roughness: 0.3 });
    const cowcatcher = new THREE.Mesh(new THREE.ConeGeometry(2.1, 1.8, 4), cowcatcherMat);
    cowcatcher.rotation.z = -Math.PI / 2;
    cowcatcher.rotation.y = Math.PI / 4;
    cowcatcher.position.set(14.8, 1.1, 0);
    cowcatcher.castShadow = true;
    root.add(cowcatcher);

    // 4. Driver's Windshield & Side Windows
    const windshield = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.45, 3.2), this.windowMaterial);
    windshield.position.set(14.35, 3.75, 0);
    root.add(windshield);

    // Passenger / Cabin Side Windows
    for (let i = 0; i < 7; i++) {
      const x = -9.8 + i * 3.1;
      for (const side of [-1, 1]) {
        const window = new THREE.Mesh(new THREE.BoxGeometry(1.9, 1.25, 0.08), this.windowMaterial);
        window.position.set(x, 3.85, side * 1.92);
        root.add(window);
      }
    }

    // 5. Sliding Passenger & Crew Doors
    const doors: THREE.Mesh[] = [];
    for (const x of [-6.0, 5.5]) {
      for (const side of [-1, 1]) {
        const door = new THREE.Mesh(new THREE.BoxGeometry(1.15, 2.45, 0.12), this.doorMaterial);
        door.position.set(x, 2.65, side * 1.93);
        door.userData.closedX = x;
        door.userData.side = side;
        door.castShadow = true;
        root.add(door);
        doors.push(door);
      }
    }
    root.userData.doors = doors;

    // 6. Realistic Bogies, Axles, Suspension & Dual Flanged Steel Wheels
    for (const bx of [-8.5, 8.5]) {
      const bogieFrame = new THREE.Mesh(new THREE.BoxGeometry(4.6, 0.65, 2.8), this.wheelMaterial);
      bogieFrame.position.set(bx, 1.05, 0);
      root.add(bogieFrame);

      for (const wx of [-1.45, 1.45]) {
        for (const side of [-1, 1]) {
          const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.62, 0.32, 18), this.wheelMaterial);
          wheel.rotation.x = Math.PI / 2;
          wheel.userData.isTrainWheel = true;
          wheel.position.set(bx + wx, 0.68, side * 1.42);
          wheel.castShadow = true;
          root.add(wheel);

          // Wheel hubcap bolt detail
          const hubcap = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.36, 10), this.railMaterial);
          hubcap.rotation.x = Math.PI / 2;
          hubcap.position.set(bx + wx, 0.68, side * 1.43);
          root.add(hubcap);
        }
      }
    }

    // 7. Dual Heavy Halogen Forward Headlights + Spotlights
    const lampMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0xffdf88,
      emissiveIntensity: 2.5,
    });

    const lampL = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 10), lampMat);
    lampL.position.set(14.3, 2.4, -0.95);
    const lampR = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 10), lampMat);
    lampR.position.set(14.3, 2.4, 0.95);
    root.add(lampL, lampR);

    // Forward long-range projection spotlights
    const spotL = new THREE.SpotLight(0xffeedd, 6.0, 120, Math.PI / 6, 0.45, 1.2);
    spotL.position.set(14.5, 2.4, -0.95);
    spotL.target.position.set(60, 1.5, -0.95);
    root.add(spotL);
    root.add(spotL.target);

    const spotR = new THREE.SpotLight(0xffeedd, 6.0, 120, Math.PI / 6, 0.45, 1.2);
    spotR.position.set(14.5, 2.4, 0.95);
    spotR.target.position.set(60, 1.5, 0.95);
    root.add(spotR);
    root.add(spotR.target);

    root.userData.spotlightL = spotL;
    root.userData.spotlightR = spotR;

    // 8. Driver's Cabin Interior & Ambient Glow
    const cabinLight = new THREE.PointLight(0xffc266, 1.8, 10);
    cabinLight.position.set(12.0, 4.2, 0);
    root.add(cabinLight);
    root.userData.cabinLight = cabinLight;

    // Driver control console inside cab
    const consoleMesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.85, 0.9, 2.2),
      new THREE.MeshStandardMaterial({ color: 0x1f2429, roughness: 0.8 })
    );
    consoleMesh.position.set(13.2, 3.1, 0);
    root.add(consoleMesh);

    // Illuminated dashboard dials
    const dialMat = new THREE.MeshBasicMaterial({ color: 0x38ef7d });
    const dial = new THREE.Mesh(new THREE.PlaneGeometry(0.35, 0.18), dialMat);
    dial.position.set(13.1, 3.65, 0);
    dial.rotation.y = -Math.PI / 2;
    root.add(dial);

    // 9. Line Identifier Plaque
    const linePlate = new THREE.Mesh(
      new THREE.BoxGeometry(2.4, 0.65, 0.08),
      new THREE.MeshStandardMaterial({
        color: isPlayerDrivable ? 0xf59e0b : 0xe5e7eb,
        emissive: isPlayerDrivable ? 0x92400e : 0x17202a,
        emissiveIntensity: 0.8,
      })
    );
    linePlate.position.set(0, 4.95, 1.93);
    root.add(linePlate);

    // 10. Two additional fully modelled passenger carriages (3 vehicles total:
    // one powered lead car plus two coaches). Every coach has a solid floor,
    // side walls, end walls, roof, windows, seats and bogies.
    const coachFloorMat = new THREE.MeshStandardMaterial({ color: 0x303941, roughness: 0.84 });
    const coachWallMat = new THREE.MeshStandardMaterial({ color: isPlayerDrivable ? 0x632d26 : 0x203b4b, metalness: 0.32, roughness: 0.72 });
    const coachRoofMat = new THREE.MeshStandardMaterial({ color: 0x141a21, metalness: 0.58, roughness: 0.42 });
    const coachSeatMat = new THREE.MeshStandardMaterial({ color: isPlayerDrivable ? 0x7b3428 : 0x31566a, roughness: 0.9 });
    for (let coachIndex = 1; coachIndex <= 2; coachIndex++) {
      const coach = new THREE.Group();
      coach.name = `PASSENGER_COACH_${coachIndex}`;
      coach.userData.physicalMesh = true;
      coach.userData.carriageIndex = coachIndex + 1;
      coach.position.x = -27.0 - (coachIndex - 1) * 27.0;
      const coachLength = 25.2;
      const floor = new THREE.Mesh(new THREE.BoxGeometry(coachLength, 0.18, 3.55), coachFloorMat);
      floor.position.y = 1.48; floor.receiveShadow = true; coach.add(floor);
      const under = new THREE.Mesh(new THREE.BoxGeometry(coachLength, 0.62, 3.6), bodyMat);
      under.position.y = 0.92; coach.add(under);
      for (const side of [-1, 1]) {
        for (const [a, b] of [[-12.5, -7.0], [-5.0, 4.8], [6.5, 12.5]]) {
          const wall = new THREE.Mesh(new THREE.BoxGeometry(b - a, 1.0, 0.16), coachWallMat);
          wall.position.set((a + b) / 2, 2.05, side * 1.82); coach.add(wall);
        }
        const upper = new THREE.Mesh(new THREE.BoxGeometry(coachLength, 0.48, 0.16), coachWallMat);
        upper.position.set(0, 4.78, side * 1.82); coach.add(upper);
        for (let wx = -10.5; wx <= 10.5; wx += 3.5) {
          const window = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.2, 0.07), this.windowMaterial);
          window.position.set(wx, 3.65, side * 1.91); coach.add(window);
        }
        for (const dx of [-6.0, 5.5]) {
          const door = new THREE.Mesh(new THREE.BoxGeometry(1.15, 2.45, 0.12), this.doorMaterial);
          door.position.set(dx, 2.65, side * 1.93);
          door.userData.side = side; door.userData.closedX = dx;
          coach.add(door); doors.push(door);
        }
      }
      for (const endX of [-12.5, 12.5]) for (const sideZ of [-1.25, 1.25]) {
        const endWall = new THREE.Mesh(new THREE.BoxGeometry(0.18, 3.0, 1.05), coachWallMat);
        endWall.position.set(endX, 3.0, sideZ); coach.add(endWall);
      }
      const roofMesh = new THREE.Mesh(new THREE.BoxGeometry(coachLength, 0.45, 3.65), coachRoofMat);
      roofMesh.position.y = 5.4; coach.add(roofMesh);
      for (const sx of [-8, -3, 3, 8]) for (const side of [-1, 1]) {
        const seat = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.9, 0.82), coachSeatMat);
        seat.position.set(sx, 2.05, side * 1.0); seat.userData.isPassengerSeat = true; coach.add(seat);
      }
      for (const bx of [-8.5, 8.5]) {
        const bogie = new THREE.Mesh(new THREE.BoxGeometry(4.6, 0.65, 2.8), this.wheelMaterial);
        bogie.position.set(bx, 1.05, 0); coach.add(bogie);
        for (const wx of [-1.45, 1.45]) for (const side of [-1, 1]) {
          const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.62, 0.32, 18), this.wheelMaterial);
          wheel.rotation.x = Math.PI / 2; wheel.userData.isTrainWheel = true; wheel.position.set(bx + wx, 0.68, side * 1.42); coach.add(wheel);
        }
      }
      root.add(coach);
    }
    // Short flexible gangway bridges keep the walking surface continuous between all cars.
    const gangwayMat = new THREE.MeshStandardMaterial({ color: 0x252b31, metalness: 0.25, roughness: 0.9 });
    for (const gx of [-13.5, -40.5]) {
      const bridge = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.16, 2.35), gangwayMat);
      bridge.position.set(gx, 1.48, 0); bridge.receiveShadow = true; root.add(bridge);
    }
    root.userData.carriageCount = 3;
    root.userData.boundingSize = new THREE.Vector3(81.0, 6.2, 4.8);
    return root;
  }

  // --- Continuous Ballast & Rail Segment Generator ---
  private buildRailChunk(lineId: RailwayTrackLine, z: number, chunkX: number): void {
    const key = `${lineId}:${chunkX}`;
    if (this.railChunks.has(key)) return;

    const group = new THREE.Group();
    group.name = `PHYSICAL_RAIL_${key}`;
    const start = chunkX * CHUNK_LENGTH;

    // Ballast and rails are built in short world-aligned grade segments. The train
    // samples this exact grid, preventing it from floating above or cutting through rails.
    for (let x = 0; x < CHUNK_LENGTH; x += TRACK_SEGMENT_LENGTH) {
      const segmentX = start + x + TRACK_SEGMENT_LENGTH * 0.5;
      const ground = getTerrainHeight(segmentX, z, this.worldSeed);
      const ballast = new THREE.Mesh(
        new THREE.BoxGeometry(TRACK_SEGMENT_LENGTH + 0.04, 0.38, 5.6),
        this.ballastMaterial
      );
      ballast.position.set(segmentX, ground + 0.02, z);
      ballast.receiveShadow = true;
      group.add(ballast);

      for (const side of [-1, 1]) {
        const rail = new THREE.Mesh(
          new THREE.BoxGeometry(TRACK_SEGMENT_LENGTH + 0.04, 0.26, 0.24),
          this.railMaterial
        );
        rail.position.set(segmentX, ground + 0.30, z + side * 0.88);
        rail.castShadow = true;
        rail.receiveShadow = true;
        group.add(rail);
      }
    }

    // Heavy treated timber/concrete sleepers, following the same sampled rail grade.
    const sleeperSpacing = 2.4;
    for (let x = 0; x < CHUNK_LENGTH; x += sleeperSpacing) {
      const sleeperX = start + x + sleeperSpacing * 0.5;
      const ground = getTerrainHeight(sleeperX, z, this.worldSeed);
      const sleeper = new THREE.Mesh(
        new THREE.BoxGeometry(1.2, 0.2, 3.6),
        this.sleeperMaterial
      );
      sleeper.position.set(sleeperX, ground + 0.12, z);
      sleeper.castShadow = true;
      sleeper.receiveShadow = true;
      group.add(sleeper);
    }

    // Overhead catenary electrification masts (every 32m)
    for (let x = 0; x < CHUNK_LENGTH; x += 32) {
      const mastX = start + x;
      const mastY = getTerrainHeight(mastX, z, this.worldSeed);
      const mastMat = new THREE.MeshStandardMaterial({ color: 0x3d434a, metalness: 0.7, roughness: 0.4 });
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.16, 7.5, 8), mastMat);
      pole.position.set(mastX, mastY + 3.75, z + 3.4);
      const arm = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 3.8), mastMat);
      arm.position.set(mastX, mastY + 7.2, z + 1.6);
      group.add(pole, arm);
    }

    group.userData = { lineId, chunkX, physicalTrack: true };
    this.scene.add(group);
    this.railChunks.set(key, group);
  }

  // --- Railway Station Generator (1200m interval) ---
  private buildStation(lineId: RailwayTrackLine, z: number, stationIndex: number): void {
    const key = `${lineId}:station:${stationIndex}`;
    if (this.stationGroups.has(key)) return;

    const x = stationIndex * STATION_SPACING;
    const y = getTerrainHeight(x, z, this.worldSeed);
    const group = new THREE.Group();
    group.name = `PHYSICAL_STATION_${key}`;
    group.userData = { stationId: key, lineId, stationIndex, dwellSeconds: DWELL_SECONDS };

    const stationNames = [
      'Sanctuary Central Terminal',
      'Pine Valley Junction',
      'Highland Ridge Station',
      'Riverbend Depot',
      'Redwood Foothills Station',
      'Canyon Pass Freight Depot',
      'Sunset Coastway Station',
      'Northern Apex Research Stop',
    ];
    const stationName = stationNames[Math.abs(stationIndex) % stationNames.length];

    // 1. Raised Concrete Passenger Platform with Yellow Tactile Warning Edge
    const platform = new THREE.Mesh(new THREE.BoxGeometry(84, 0.75, 7.8), this.platformMaterial);
    // Platform top is level with the sampled ground plane so the existing player
    // ground solver can walk across it without floating or sinking.
    platform.position.set(x, y - 0.375, z + 7.0);
    platform.receiveShadow = true;
    platform.castShadow = true;
    group.add(platform);

    const safetyEdgeMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
    const safetyStripe = new THREE.Mesh(new THREE.BoxGeometry(84, 0.05, 0.35), safetyEdgeMat);
    safetyStripe.position.set(x, y + 0.54, z + 3.25);
    group.add(safetyStripe);

    // 2. Weatherproof Steel Truss Canopy
    const canopyMat = new THREE.MeshStandardMaterial({ color: 0x27343f, metalness: 0.5, roughness: 0.5 });
    const canopy = new THREE.Mesh(new THREE.BoxGeometry(48, 0.4, 7.2), canopyMat);
    canopy.position.set(x, y + 4.8, z + 7.0);
    group.add(canopy);

    for (const dx of [-20, -10, 0, 10, 20]) {
      const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.3, 4.6, 0.3), this.railMaterial);
      pillar.position.set(x + dx, y + 2.4, z + 7.0);
      group.add(pillar);

      // Warm platform hanging lights
      const light = new THREE.PointLight(0xffe299, 1.8, 14, 1.5);
      light.position.set(x + dx, y + 4.3, z + 7.0);
      group.add(light);
    }


    // Solid station concourse behind the platform: walkable floor, roof and physical walls.
    const hallCenterZ = z + 18.0;
    const hallWidth = 30;
    const hallDepth = 12;
    const hallWallMat = new THREE.MeshStandardMaterial({ color: 0x35434c, metalness: 0.25, roughness: 0.78 });
    const hallFloor = new THREE.Mesh(new THREE.BoxGeometry(hallWidth, 0.24, hallDepth), this.platformMaterial);
    hallFloor.position.set(x, y - 0.12, hallCenterZ);
    hallFloor.receiveShadow = true;
    group.add(hallFloor);
    const hallRoof = new THREE.Mesh(new THREE.BoxGeometry(hallWidth + 1.2, 0.35, hallDepth + 1.2), canopyMat);
    hallRoof.position.set(x, y + 4.35, hallCenterZ);
    hallRoof.castShadow = true;
    group.add(hallRoof);
    const hallWalls: Array<{ cx: number; cy: number; cz: number; sx: number; sy: number; sz: number }> = [];
    const addHallWall = (cx: number, cy: number, cz: number, sx: number, sy: number, sz: number) => {
      const wall = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), hallWallMat);
      wall.position.set(cx, cy, cz);
      wall.castShadow = true;
      wall.receiveShadow = true;
      group.add(wall);
      hallWalls.push({ cx, cy, cz, sx, sy, sz });
    };
    addHallWall(x - hallWidth / 2, y + 2.1, hallCenterZ, 0.35, 4.2, hallDepth);
    addHallWall(x + hallWidth / 2, y + 2.1, hallCenterZ, 0.35, 4.2, hallDepth);
    addHallWall(x, y + 2.1, hallCenterZ + hallDepth / 2, hallWidth, 4.2, 0.35);
    // Front wall is split into two wings, leaving a broad central entrance.
    addHallWall(x - 11.0, y + 2.1, hallCenterZ - hallDepth / 2, 8.0, 4.2, 0.35);
    addHallWall(x + 11.0, y + 2.1, hallCenterZ - hallDepth / 2, 8.0, 4.2, 0.35);
    const hallDoorHeader = new THREE.Mesh(new THREE.BoxGeometry(14, 0.6, 0.35), hallWallMat);
    hallDoorHeader.position.set(x, y + 3.9, hallCenterZ - hallDepth / 2);
    group.add(hallDoorHeader);
    hallWalls.push({ cx: x, cy: y + 3.9, cz: hallCenterZ - hallDepth / 2, sx: 14, sy: 0.6, sz: 0.35 });

    // Store exact static wall bounds for player collision in every streamed station.
    group.userData.stationColliders = hallWalls.map(w => new THREE.Box3(
      new THREE.Vector3(w.cx - w.sx / 2, w.cy - w.sy / 2, w.cz - w.sz / 2),
      new THREE.Vector3(w.cx + w.sx / 2, w.cy + w.sy / 2, w.cz + w.sz / 2)
    ));

    // 3. Passenger Waiting Benches
    const woodBenchMat = new THREE.MeshStandardMaterial({ color: 0x6e4726, roughness: 0.8 });
    for (const dx of [-14, 14]) {
      const bench = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.55, 0.75), woodBenchMat);
      bench.position.set(x + dx, y + 0.8, z + 7.5);
      group.add(bench);
    }

    // 4. Large Station Signboard & Clock
    const signMat = new THREE.MeshStandardMaterial({ color: 0x0f2938, emissive: 0x071923 });
    const sign = new THREE.Mesh(new THREE.BoxGeometry(10, 1.35, 0.25), signMat);
    sign.position.set(x, y + 3.4, z + 3.0);
    group.add(sign);

    // 5. Dual Aspect Railway Signals (Green when clear, Red when train is in station)
    const signalMast = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.14, 6.2, 8), this.railMaterial);
    signalMast.position.set(x + 36, y + 3.1, z - 2.8);
    const signalHead = new THREE.Mesh(new THREE.BoxGeometry(0.65, 1.4, 0.4), new THREE.MeshStandardMaterial({ color: 0x111111 }));
    signalHead.position.set(x + 36, y + 5.2, z - 2.8);

    const greenSignal = new THREE.PointLight(0x22c55e, 2.5, 18);
    greenSignal.position.set(x + 36, y + 5.4, z - 2.5);
    group.add(signalMast, signalHead, greenSignal);

    const stationColliders = group.userData.stationColliders as THREE.Box3[];
    const addStaticCollider = (cx: number, cy: number, cz: number, sx: number, sy: number, sz: number) => {
      stationColliders.push(new THREE.Box3(
        new THREE.Vector3(cx - sx / 2, cy - sy / 2, cz - sz / 2),
        new THREE.Vector3(cx + sx / 2, cy + sy / 2, cz + sz / 2)
      ));
    };
    for (const dx of [-20, -10, 0, 10, 20]) addStaticCollider(x + dx, y + 2.4, z + 7.0, 0.45, 4.6, 0.45);
    for (const dx of [-14, 14]) addStaticCollider(x + dx, y + 0.8, z + 7.5, 3.2, 1.1, 0.75);
    addStaticCollider(x, y + 3.4, z + 3.0, 10, 1.35, 0.25);
    addStaticCollider(x + 36, y + 3.1, z - 2.8, 0.3, 6.2, 0.3);

    group.userData.stationName = stationName;
    this.scene.add(group);
    this.stationGroups.set(key, group);
  }

  private ensureWorldGeometry(x: number, z: number, lineId: RailwayTrackLine): void {
    const centerChunk = Math.floor(x / CHUNK_LENGTH);
    for (let c = centerChunk - 2; c <= centerChunk + 2; c++) {
      this.buildRailChunk(lineId, z, c);
    }
    const stationIndex = Math.round(x / STATION_SPACING);
    for (let s = stationIndex - 1; s <= stationIndex + 1; s++) {
      this.buildStation(lineId, z, s);
    }
  }

  // --- Main Update Loop ---
  update(deltaSeconds: number, playerPosition: THREE.Vector3): void {
    const clampedDelta = Number.isFinite(deltaSeconds) ? THREE.MathUtils.clamp(deltaSeconds, 0, 0.1) : 0;

    // 1. Update all six AI passenger services with scheduled stops and announcements
    for (const train of this.trains) {
      this.ensureWorldGeometry(playerPosition.x, train.z, train.line);
      this.ensureWorldGeometry(train.x, train.z, train.line);

      const nextStationIndex = train.currentStationIndex === null
        ? (train.direction === 1 ? Math.ceil(train.x / STATION_SPACING) : Math.floor(train.x / STATION_SPACING))
        : train.currentStationIndex + train.direction;
      const stationX = nextStationIndex * STATION_SPACING;
      const distanceAhead = Math.max(0, (stationX - train.x) * train.direction);

      if (train.lastAnnouncedStationIndex !== nextStationIndex && distanceAhead <= 300 && distanceAhead > 0.5) {
        train.lastAnnouncedStationIndex = nextStationIndex;
        if (Math.abs(playerPosition.x - train.x) < 180 && Math.abs(playerPosition.z - train.z) < 6.5) {
          this.announce(`Attention passengers on line ${train.line}. ${this.stationName(nextStationIndex)} is approaching. Please prepare to alight.`);
        }
      }

      if (train.dwellRemaining > 0) {
        train.speed = 0;
        train.dwellRemaining = Math.max(0, train.dwellRemaining - clampedDelta);
        train.stationStatus = train.dwellRemaining > 0 ? 'doors_open' : 'doors_closing';

        // Slide doors outward during dwell and close during the final two seconds.
        const opening = train.dwellRemaining > 2 ? 0.65 : (train.dwellRemaining / 2) * 0.65;
        for (const door of train.doors) {
          const side = Number(door.userData.side);
          door.position.z = side * (1.93 + opening);
        }

        if (train.dwellRemaining === 0) {
          train.stationStatus = 'running';
          if (Math.abs(playerPosition.x - train.x) < 220 && Math.abs(playerPosition.z - train.z) < 6.5) {
            this.announce(`This train is departing. Please stand clear of the doors.`);
          }
          soundEngine.playTrainBrakes();
        }
      } else {
        // AI traction smoothly accelerates out of stations and brakes into the next stop.
        const brakingTargetSpeed = Math.min(AI_TRAIN_SPEED, Math.sqrt(2 * 3.2 * distanceAhead));
        train.speed = THREE.MathUtils.damp(train.speed, brakingTargetSpeed, 3.2, clampedDelta);
        if (distanceAhead <= train.speed * clampedDelta + 0.35) {
          // Arrive exactly at the platform marker without overshooting or teleporting through it.
          train.x = stationX;
          train.speed = 0;
          train.dwellRemaining = DWELL_SECONDS;
          train.currentStationIndex = nextStationIndex;
          train.stationStatus = 'doors_open';
          train.lastAnnouncedStationIndex = nextStationIndex;
          if (Math.abs(playerPosition.x - train.x) < 220 && Math.abs(playerPosition.z - train.z) < 6.5) {
            this.announce(`Now arriving at ${this.stationName(nextStationIndex)}. Please mind the gap. Doors are opening.`);
          }
          soundEngine.playStationChime();
          soundEngine.playTrainBrakes();
          for (const door of train.doors) {
            door.position.z = Number(door.userData.side) * 2.58;
          }
        } else {
          train.x += train.direction * train.speed * clampedDelta;
        }
      }

      const groundY = this.terrainY(train.x, train.z);
      train.group.position.set(train.x, groundY, train.z);
      train.group.rotation.y = train.direction === 1 ? 0 : Math.PI;
      // Wheels rotate only while the train is physically travelling. During a station
      // dwell the train is stationary even though its timetable cruise speed is retained.
      // Apply the line direction so backward services rotate in the opposite direction.
      const wheelTravelDistance = train.dwellRemaining > 0
        ? 0
        : train.speed * train.direction * clampedDelta;
      if (wheelTravelDistance !== 0) {
        const wheelAngularStep = wheelTravelDistance / 0.62;
        train.group.traverse((object) => {
          if (object instanceof THREE.Mesh && object.userData.isTrainWheel) {
            object.rotation.z += wheelAngularStep;
          }
        });
      }
      train.group.updateMatrixWorld(true);

      const size = train.group.userData.boundingSize as THREE.Vector3;
      const box = train.group.userData.collisionProxy as THREE.Box3;
      this.collisionCenter.set(train.x - train.direction * 25.8, train.group.position.y + 3.1, train.z);
      box.setFromCenterAndSize(this.collisionCenter, size);
      train.group.userData.stationStatus = train.stationStatus;
      train.group.userData.dwellRemainingSeconds = train.dwellRemaining;
      train.group.userData.collisionProxy = box;
    }

    // 3. Audio: Play wheel clatter on tracks when moving
    const movingTrain = this.trains.find(t => Math.hypot(t.x - playerPosition.x, t.z - playerPosition.z) < 60);
    if (movingTrain && Math.abs(movingTrain.speed) > 1.0) {
      this.wheelAudioTimer += clampedDelta;
      if (this.wheelAudioTimer > 0.65) {
        this.wheelAudioTimer = 0;
        // Periodic rail joint thud
        soundEngine.playFootstep();
      }
    }

    // 4. Memory Management: Unload distant rail chunks and stations beyond active window
    const keep = new Set<string>();
    const allTrackMonitors = this.trains;

    for (const t of allTrackMonitors) {
      const c = Math.floor(t.x / CHUNK_LENGTH);
      for (let i = c - 3; i <= c + 3; i++) keep.add(`${t.line}:${i}`);
      const pc = Math.floor(playerPosition.x / CHUNK_LENGTH);
      for (let i = pc - 2; i <= pc + 2; i++) keep.add(`${t.line}:${i}`);
    }

    for (const [key, group] of this.railChunks) {
      if (!keep.has(key)) {
        this.scene.remove(group);
        group.traverse((obj) => {
          if (obj instanceof THREE.Mesh) obj.geometry.dispose();
        });
        this.railChunks.delete(key);
      }
    }

    for (const [key, group] of this.stationGroups) {
      const stationX = Number(group.userData.stationIndex) * STATION_SPACING;
      const nearPlayer = Math.abs(stationX - playerPosition.x) <= 600;
      const nearTrain = allTrackMonitors.some((t) => Math.abs(stationX - t.x) <= 600);
      if (!nearPlayer && !nearTrain) {
        this.scene.remove(group);
        group.traverse((obj) => {
          if (obj instanceof THREE.Mesh) obj.geometry.dispose();
        });
        this.stationGroups.delete(key);
      }
    }
  }

  private stationName(index: number): string {
    return [
      'Sanctuary Central Terminal', 'Pine Valley Junction', 'Highland Ridge Station',
      'Riverbend Depot', 'Redwood Foothills Station', 'Canyon Pass Freight Depot',
      'Sunset Coastway Station', 'Northern Apex Research Stop',
    ][Math.abs(index) % 8];
  }

  private announce(message: string): void {
    // Use the browser's built-in speech engine where available; game audio remains the fallback.
    if (typeof window === 'undefined' || !('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') return;
    try {
      window.speechSynthesis.cancel();
      const line = new SpeechSynthesisUtterance(message);
      line.rate = 0.92; line.pitch = 0.92; line.volume = 0.85;
      window.speechSynthesis.speak(line);
    } catch { /* Speech is optional; train operation must never depend on it. */ }
  }

  public getNearbyPassengerSeat(playerPos: THREE.Vector3, radius = 2.4): { train: AITrain; localPosition: THREE.Vector3 } | null {
    for (const train of this.trains) {
      train.group.updateMatrixWorld(true);
      const seats: THREE.Mesh[] = [];
      train.group.traverse((object) => {
        if (object instanceof THREE.Mesh && object.userData.isPassengerSeat === true) seats.push(object);
      });
      let nearestPosition: THREE.Vector3 | null = null;
      let nearestDistance = radius;
      for (const seat of seats) {
        const world = seat.getWorldPosition(new THREE.Vector3());
        const distance = world.distanceTo(playerPos);
        if (distance <= nearestDistance) {
          nearestDistance = distance;
          nearestPosition = train.group.worldToLocal(world.clone());
        }
      }
      if (nearestPosition) return { train, localPosition: nearestPosition };
    }
    return null;
  }

  public sitOnNearbyPassengerSeat(playerPos: THREE.Vector3): boolean {
    if (!this.activePassengerTrain || this.passengerSeatLocalPosition) return false;
    const seat = this.getNearbyPassengerSeat(playerPos, 2.8);
    if (!seat || seat.train !== this.activePassengerTrain) return false;
    this.passengerSeatLocalPosition = seat.localPosition.clone().add(new THREE.Vector3(0, 0.35, 0));
    return true;
  }

  public standFromPassengerSeat(): boolean {
    if (!this.passengerSeatLocalPosition) return false;
    this.passengerSeatLocalPosition = null;
    return true;
  }

  public getPassengerSeatWorldPosition(): THREE.Vector3 | null {
    if (!this.activePassengerTrain || !this.passengerSeatLocalPosition) return null;
    this.activePassengerTrain.group.updateMatrixWorld(true);
    return this.activePassengerTrain.group.localToWorld(this.passengerSeatLocalPosition.clone());
  }

  public getNearbyBoardableAITrain(playerPos: THREE.Vector3, maxDist = 7.0): AITrain | null {
    let nearest: AITrain | null = null;
    let minDist = maxDist;
    for (const train of this.trains) {
      const d = Math.hypot(train.x - playerPos.x, train.z - playerPos.z);
      if (d < minDist && train.dwellRemaining > 0) {
        minDist = d;
        nearest = train;
      }
    }
    return nearest;
  }

  public boardAITrain(train: AITrain): void {
    this.activePassengerTrain = train;
    train.isOccupied = true;
  }

  public exitAITrain(_playerPosOut?: THREE.Vector3): void {
    if (this.activePassengerTrain) {
      this.activePassengerTrain.isOccupied = false;
      this.activePassengerTrain = null;
      this.passengerSeatLocalPosition = null;
    }
  }

  // --- Legacy train-driving API compatibility ---
  // These methods remain public for older callers, but all trains are AI-operated.
  public getNearbyDrivableTrain(_playerPos: THREE.Vector3, _maxDist = 7.0): DrivableTrain | null {
    return null;
  }

  public boardPlayerTrain(_train: DrivableTrain): void {
    // Intentionally disabled: passengers may only board AI services.
  }

  public exitPlayerTrain(_playerPosOut: THREE.Vector3): void {
    // Intentionally disabled: no player-drivable train exists.
  }

  public updateTrainControls(_input: { forward: boolean; backward: boolean; sprint?: boolean; brake?: boolean }): void {
    // Intentionally disabled: train traction is exclusively AI-controlled.
  }

  public toggleHeadlights(): boolean { return false; }
  public toggleDoors(): boolean { return false; }
  public toggleCameraView(): boolean { return false; }
  public honkHorn(): void { /* Passenger services use AI announcements only. */ }

  public getTrainHUDData() {
    if (this.activePassengerTrain) {
      const passengerTrain = this.activePassengerTrain;
      const stationIndex = passengerTrain.direction === 1
        ? Math.ceil(passengerTrain.x / STATION_SPACING)
        : Math.floor(passengerTrain.x / STATION_SPACING);
      const stationName = [
        'Sanctuary Central Terminal',
        'Pine Valley Junction',
        'Highland Ridge Station',
        'Riverbend Depot',
        'Redwood Foothills Station',
        'Canyon Pass Freight Depot',
        'Sunset Coastway Station',
        'Northern Apex Research Stop',
      ][Math.abs(stationIndex) % 8];
      const distance = Math.abs(stationIndex * STATION_SPACING - passengerTrain.x);
      return {
        line: passengerTrain.line,
        direction: passengerTrain.direction === 1 ? 'FORWARD (+X)' : 'BACKWARD (-X)',
        speedKmh: Math.round(Math.abs(passengerTrain.speed) * 3.6),
        speedMph: Math.round(Math.abs(passengerTrain.speed) * 2.23694),
        throttle: 0,
        headlightsOn: false,
        doorsOpen: passengerTrain.stationStatus === 'doors_open',
        cabCameraActive: false,
        stationDistance: Math.round(distance),
        nextStation: stationName,
        announcement: passengerTrain.stationStatus === 'doors_open'
          ? `Now arriving at ${stationName}. Doors are opening.`
          : (passengerTrain.stationStatus === 'doors_closing'
            ? 'Doors are closing. This train is departing. Please stand clear.'
            : (distance <= 300
              ? `Attention passengers: ${stationName} is approaching.`
              : 'The train is in motion. Please remain clear of the doors.')),
      };
    }
    return null;
  }

  public getStationCollisionBoxes(): Array<{ id: string; box: THREE.Box3 }> {
    const boxes: Array<{ id: string; box: THREE.Box3 }> = [];
    for (const [id, group] of this.stationGroups) {
      const colliders = group.userData.stationColliders as THREE.Box3[] | undefined;
      if (!colliders) continue;
      for (let i = 0; i < colliders.length; i++) boxes.push({ id: `${id}:wall:${i}`, box: colliders[i] });
    }
    return boxes;
  }

  public getTrainCollisionBoxes(): Array<{ id: string; line: RailwayTrackLine; box: THREE.Box3 }> {
    const list: Array<{ id: string; line: RailwayTrackLine; box: THREE.Box3 }> = [];
    for (const train of this.trains) {
      list.push({ id: train.id, line: train.line, box: (train.group.userData.collisionProxy as THREE.Box3).clone() });
    }
    return list;
  }

  dispose(): void {
    const physics = UnifiedPhysicsManager.getInstance();
    physics?.unregisterCollider('campaign_relay_console');
    physics?.unregisterCollider('campaign_final_console');
    for (const beacon of [this.campaignRelayGroup, this.finalJourneyGroup]) {
      if (!beacon) continue;
      this.scene.remove(beacon);
      beacon.traverse((object) => {
        if (object instanceof THREE.Mesh) {
          object.geometry.dispose();
          const materials = Array.isArray(object.material) ? object.material : [object.material];
          materials.forEach((material) => material.dispose());
        }
      });
    }
    for (const train of this.trains) this.scene.remove(train.group);
    for (const group of this.railChunks.values()) {
      this.scene.remove(group);
      group.traverse((obj) => { if (obj instanceof THREE.Mesh) obj.geometry.dispose(); });
    }
    for (const group of this.stationGroups.values()) {
      this.scene.remove(group);
      group.traverse((obj) => { if (obj instanceof THREE.Mesh) obj.geometry.dispose(); });
    }
    this.railMaterial.dispose();
    this.sleeperMaterial.dispose();
    this.platformMaterial.dispose();
    this.ballastMaterial.dispose();
    this.aiTrainBodyMaterial.dispose();
    this.playerTrainBodyMaterial.dispose();
    this.windowMaterial.dispose();
    this.wheelMaterial.dispose();
    this.doorMaterial.dispose();
    this.trains = [];
    this.drivableTrains = [];
    this.activeDrivableTrain = null;
    this.activePassengerTrain = null;
    this.railChunks.clear();
    this.stationGroups.clear();
  }
}
