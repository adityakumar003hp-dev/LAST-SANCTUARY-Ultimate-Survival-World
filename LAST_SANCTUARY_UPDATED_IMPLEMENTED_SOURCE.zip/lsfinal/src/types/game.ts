export type GameMode = 'survival' | 'creative' | 'story';
export type Difficulty = 'explorer' | 'standard' | 'survivor';
export type CameraView = 'first' | 'third' | 'second';

export type ItemCategory = 
  | 'resource' 
  | 'tool' 
  | 'weapon' 
  | 'building' 
  | 'consumable' 
  | 'medical' 
  | 'component';

export interface ItemDefinition {
  id: string;
  name: string;
  description: string;
  category: ItemCategory;
  icon: string; // Lucide icon identifier or visual key
  stackable: boolean;
  maxStack: number;
  weight: number;
  durability?: number;
  maxDurability?: number;
  // Consumable stats
  hungerRestore?: number;
  thirstRestore?: number;
  healthRestore?: number;
  staminaRestore?: number;
  // Tool stats
  toolType?: 'axe' | 'pickaxe' | 'hammer' | 'weapon' | 'ranged';
  damage?: number;
  harvestEfficiency?: {
    wood?: number;
    stone?: number;
    metal?: number;
  };
}

export interface InventorySlot {
  item: ItemDefinition;
  count: number;
  durability?: number;
}

export interface CraftingRecipe {
  id: string;
  resultItemId: string;
  resultCount: number;
  category: 'survival' | 'tools' | 'defense' | 'construction' | 'medical';
  ingredients: { itemId: string; count: number }[];
  requiredStation?: string; // e.g., 'workbench', 'campfire'
  craftTimeSeconds: number;
  description: string;
}

export type StructureCategory = 'defense' | 'structure' | 'utility' | 'furniture';

export interface StructureDefinition {
  id: string;
  name: string;
  category: StructureCategory;
  description: string;
  icon: string;
  width: number;
  height: number;
  depth: number;
  maxHealth: number;
  cost: { itemId: string; count: number }[];
  isDoor?: boolean;
  isLightSource?: boolean;
  isStorage?: boolean;
  isCraftingStation?: string; // 'workbench', 'campfire', 'water_collector'
  isBed?: boolean;
  isFarmPlot?: boolean;
  isNoticeBoard?: boolean;
  safeZoneContribution?: number; // meters radius of safe zone
  spikeDamage?: number; // damages attacking zombies
}

export interface PlacedStructure {
  uid: string;
  typeId: string;
  position: [number, number, number];
  rotationY: number;
  currentHealth: number;
  maxHealth: number;
  isOpen?: boolean; // for doors/gates
  storageItems?: (InventorySlot | null)[];
  farmStage?: number; // 0 = empty, 1 = growing, 2 = mature
  farmCrop?: string;
}

export type ZombieType = 'walker' | 'runner' | 'brute' | 'screamer' | 'crawler';

export interface ZombieEntity {
  id: string;
  type: ZombieType;
  position: [number, number, number];
  rotationY: number;
  health: number;
  maxHealth: number;
  speed: number;
  damage: number;
  state: 'idle' | 'patrol' | 'chase' | 'attack_structure' | 'attack_player' | 'stagger' | 'dead';
  targetStructureUid?: string;
  attackCooldown: number;
  detectionRadius: number;
  deathTimer?: number;
}

export interface HarvestableResource {
  id: string;
  type: 'tree' | 'rock' | 'metal_scrap' | 'berry_bush' | 'water_well' | 'supply_crate';
  position: [number, number, number];
  health: number;
  maxHealth: number;
  yieldItem: string;
  yieldAmount: number;
  requiredTool?: 'axe' | 'pickaxe' | 'none';
  respawnTime?: number;
}

export interface PlayerStats {
  health: number;
  maxHealth: number;
  stamina: number;
  maxStamina: number;
  hunger: number; // 0-100
  thirst: number; // 0-100
  temperature: number; // Celsius (e.g. 20-37)
  infection: number; // 0-100
  oxygen: number; // 0-100 for swimming & diving
  maxOxygen: number;
  isSwimming?: boolean;
  isSubmerged?: boolean;
  level: number;
  xp: number;
  xpToNextLevel: number;
  skillPoints: number;
  skills: {
    strength: number;      // Melee damage, carry weight
    endurance: number;     // Stamina regen, max health
    engineering: number;   // Structure HP bonus, crafting speed
    survival: number;      // Hunger/thirst drain reduction
  };
}

export interface CompanionState {
  speciesId: string;
  name: string;
  kind: 'mammal' | 'dinosaur' | 'bird';
  health: number;
  maxHealth: number;
  state: 'follow' | 'stay' | 'defend';
  isMounted?: boolean;
}

export interface EcosystemDossier {
  agentId: string;
  speciesName: string;
  scientificName: string;
  kind: string;
  diet: 'carnivore' | 'herbivore' | 'omnivore' | 'piscivore';
  state: string;
  intentDescription: string;
  health: number;
  maxHealth: number;
  hunger: number;
  thirst: number;
  generation: number;
  adaptationTrait: string;
  distance: number;
  isJuvenile: boolean;
  offspringCount: number;
  killsCount: number;
}

export interface EcosystemMetrics {
  totalOrganisms: number;
  predatorCount: number;
  herbivoreCount: number;
  totalBirths: number;
  totalPredations: number;
  highestGeneration: number;
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  chapter: number;
  completed: boolean;
  rewards: { xp: number; items?: { itemId: string; count: number }[] };
  objectives: {
    id: string;
    description: string;
    current: number;
    target: number;
    completed: boolean;
    migrationStatus?: 'unverified-legacy';
  }[];
  migrationStatus?: 'legacy-completed';
  completionSource?: 'objective-events' | 'legacy-migration';
}

export type GraphicsQuality = 'low' | 'medium' | 'high' | 'ultra';

export interface GameSettings {
  masterVolume: number;
  sfxVolume: number;
  musicVolume: number;
  mouseSensitivity: number;
  fieldOfView: number;
  showCoordinates: boolean;
  graphicsQuality: GraphicsQuality;
  firstPersonCamera: boolean;
  viewDistanceChunks?: number;
}

export type BiomeType =
  | 'dense_forest'
  | 'green_plains'
  | 'abandoned_city'
  | 'small_village'
  | 'farmland'
  | 'industrial_zone'
  | 'mountain_range'
  | 'valley'
  | 'river_basin'
  | 'lake_district'
  | 'coastline'
  | 'island'
  | 'desert'
  | 'snow_peaks'
  | 'wetlands'
  | 'cave_system'
  | 'subway_tunnels'
  | 'research_facility'
  | 'tropical_jungle'
  | 'savannah'
  | 'taiga'
  | 'tundra'
  | 'volcanic_wastes'
  | 'mangrove_delta'
  | 'coral_coast'
  | 'badlands'
  | 'ancient_forest'
  | 'alpine_meadow'
  | 'bamboo_forest'
  | 'crystal_cavern'
  | 'sand_dunes'
  | 'rocky_canyon'
  | 'glacier_field'
  | 'ashlands'
  | 'waterfall_valley'
  | 'dinosaur_valley'
  | 'deep_swamp';

export interface BiomeDefinition {
  id: BiomeType;
  name: string;
  description: string;
  groundColor: number;
  fogColor: number;
  foliageColor: number;
  temperature: number; // Celsius
  elevationMultiplier: number;
  roughness: number;
  treeDensity: number;
  rockDensity: number;
  scrapDensity: number;
  zombieThreatLevel: number; // 1-5
  waterColor?: number;
}

export interface ChunkCoord {
  cx: number;
  cz: number;
}

export interface POIStructure {
  id: string;
  type: 'cabin' | 'ruined_house' | 'gas_station' | 'warehouse' | 'watchtower' | 'radio_bunker' | 'research_lab' | 'village' | 'town' | 'city_district' | 'hospital' | 'clinic' | 'fire_station' | 'police_station' | 'factory' | 'industrial_complex' | 'airport' | 'power_station' | 'water_treatment' | 'university' | 'shopping_centre' | 'freight_terminal';
  name: string;
  position: [number, number, number];
  rotationY: number;
  hasLoot: boolean;
  isLooted: boolean;
}

export interface ChunkData {
  coord: ChunkCoord;
  key: string;
  seed: number;
  biome: BiomeType;
  resources: HarvestableResource[];
  pois: POIStructure[];
  isLoaded: boolean;
  lodLevel: number;
  minElevation: number;
  maxElevation: number;
}

export interface ChunkModificationData {
  destroyedResourceIds: string[];
  openedPoiIds: string[];
  placedStructures: PlacedStructure[];
}

export interface MapWaypoint {
  id: string;
  name: string;
  position: [number, number, number];
  icon: string;
  color: string;
  isCustom?: boolean;
}

// --- Base Systems & Modern Sanctuary ---
export type BaseLevel = 1 | 2 | 3 | 4;

export interface PowerState {
  solarProductionKw: number;
  generatorProductionKw: number;
  totalProductionKw: number;
  consumptionKw: number;
  batteryCurrentKwh: number;
  batteryCapacityKwh: number;
  isGeneratorRunning: boolean;
  generatorFuel: number; // 0-100%
  isPowered: boolean;
}

export interface WaterState {
  storageLiters: number;
  maxCapacityLiters: number;
  rainCatchmentRate: number; // L/h
  purificationRate: number; // L/h
  cleanWaterLiters: number;
}

export interface FoodState {
  refrigeratorRations: number;
  pantryRations: number;
  isRefrigerated: boolean;
  daysOfFoodRemaining: number;
}

export interface SecurityState {
  isAlarmArmed: boolean;
  isAlarmTriggered: boolean;
  activeGateLocked: boolean;
  nearbyZombiesDetected: number;
  cctvChannels: {
    id: number;
    name: string;
    cameraPosition: [number, number, number];
    lookAt: [number, number, number];
    status: 'online' | 'offline' | 'alert';
  }[];
}

export type NPCRole = 'scout' | 'engineer' | 'botanist' | 'medic' | 'idle';

export interface NPCSurvivor {
  id: string;
  name: string;
  role: NPCRole;
  assignedRoom: string;
  currentTask: string;
  health: number;
  maxHealth: number;
  morale: number; // 0-100
  position: [number, number, number];
  avatarColor: string;
}

export interface ResearchTech {
  id: string;
  name: string;
  description: string;
  costComponents: number;
  costMetal: number;
  unlocked: boolean;
  icon: string;
  category: 'power' | 'defense' | 'farming' | 'medical' | 'vehicle';
}

export interface VehicleState {
  id: string;
  name: string;
  position: [number, number, number];
  rotationY: number;
  batteryPercent: number; // 0-100%
  headlightsOn: boolean;
  isOccupied: boolean;
  trunkInventory: (InventorySlot | null)[];
}

export interface BaseState {
  level: BaseLevel;
  power: PowerState;
  water: WaterState;
  food: FoodState;
  security: SecurityState;
  npcs: NPCSurvivor[];
  research: ResearchTech[];
  vehicle: VehicleState;
  /** Complete garage fleet state; optional for compatibility with older saves. */
  vehicles?: VehicleState[];
  overallHealth: number;
}

export interface SaveSlotMetadata {
  id: string;
  name: string;
  characterName: string;
  dayCount: number;
  timeString: string;
  timestamp: number;
  difficulty: Difficulty;
  gameMode: GameMode;
}

export interface FullGameSave {
  metadata: SaveSlotMetadata;
  worldSeed: number;
  playerPosition: [number, number, number];
  playerRotation: number;
  playerStats: PlayerStats;
  inventory: (InventorySlot | null)[];
  hotbar: (InventorySlot | null)[];
  selectedHotbarIndex: number;
  structures: PlacedStructure[];
  quests: Quest[];
  gameTimeMinutes: number;
  dayCount: number;
  lastSleptDay?: number;
  nightHordeCountDefeated: number;
  // World Streaming & Base Additions
  discoveredChunks?: string[];
  waypoints?: MapWaypoint[];
  chunkModifications?: Record<string, ChunkModificationData>;
  baseState?: BaseState;
  rescuedSurvivorIds?: string[];
  tamedCompanion?: CompanionState | null;
  prologueState?: import('./prologue').PrologueSaveData;
  ecosystemMetrics?: EcosystemMetrics;
  eightDayCampaignComplete?: boolean;
}
