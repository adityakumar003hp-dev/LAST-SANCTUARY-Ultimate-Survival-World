# LAST SANCTUARY: REBIRTH — Master Requirements

## World and mansion
- Preserve existing environments, world/chunk streaming, physics, player, camera, wildlife, NPCs, inventory, missions, all three story friends, apartment, Starter Base, storyline and save compatibility.
- Retain the existing four-floor apartment implementation and its continuous staircase, armory floor and rooftop pool; complete the requested contemporary luxury mansion exterior/interior redesign without replacing existing story geometry.
- Keep apartment and Starter Base fixed. New games start inside the apartment; existing saves restore their saved positions.
- Generate deterministic, distance-streamed cities, towns, villages, hospitals, clinics, research facilities, fire/police stations, factories, industrial facilities, airports, utilities, universities, markets and other landmarks.
- Discover destinations progressively and persist them to the world map.

## Six-track railway
- Exactly six main tracks: F1/F2/F3 forward and B1/B2/B3 backward.
- F1: player-drivable and explorable.
- B1: player-drivable and explorable.
- F2/F3/B2/B3: AI-controlled and explorable, never player-drivable.
- All six tracks must form an effectively infinite, deterministic, interconnected network across streamed chunks.
- Connect major structures through stations, terminals, branch routes or freight sidings. Small houses may use nearby stations and roads/paths.
- Add junctions, crossovers, stations, platforms, signals, bridges, tunnels, yards, AI trains, map discovery and persistent route/station identity.
- Train movement must follow a route graph, cross chunk boundaries safely and respect signals and block occupancy.

## Performance and validation
- Stream chunks and interiors; do not load the whole world at once.
- Use LOD, instancing and reduced distant simulation for mobile.
- Preserve old saves and serialize stable world IDs rather than transient meshes.
- Run type checks, lint, production build, automated tests and desktop/mobile in-game verification. Report only tests actually run.
