# LAST SANCTUARY: REBIRTH — IMPLEMENTATION TRACEABILITY MASTER MATRIX

**Project Title:** LAST SANCTUARY: REBIRTH (Maximum Realism Survival & Railway Simulation)  
**Verification Date:** November 2026  
**Status:** FULLY INTEGRATED & VERIFIED  

---

## 1. Traceability Summary

This master matrix maps every requirement from the user directives and specification attachments directly to runtime code files, architectural subsystems, unit verification criteria, and test gate outcomes.

| Requirement ID | Domain | Specification Requirement | Source File(s) | Verification / Test Reference | Status |
|---|---|---|---|---|---|
| **REQ-DISP-01** | Railway Control | Relocate Railway Operations Control Centre to apartment basement ($Y = -3.12\text{m}$). | `src/engine/prologue/ApartmentBuilding.ts` | GATE-01: Console Geometry & Interaction | **IMPLEMENTED** |
| **REQ-DISP-02** | Railway Control | 5-Display console architecture: 1 Panoramic Wide Screen, 2 Left Displays, 2 Right Displays. | `src/engine/prologue/ApartmentBuilding.ts`, `src/components/TrainControlCenter.tsx` | GATE-01: Monitor Layout & Texture Mapping | **IMPLEMENTED** |
| **REQ-DISP-03** | Railway Control | Interactive keyboard ([1]-[6], [H], [A], [←/→], [ESC]) and mobile touch controls. | `src/components/TrainControlCenter.tsx` | GATE-01: Control Dispatch Input | **IMPLEMENTED** |
| **REQ-DISP-04** | Railway Control | Live telemetry and timetable for 6 services (F1, F2, F3, B1, B2, B3) with real-time train positions. | `src/engine/world/AITrainManager.ts`, `src/components/TrainControlCenter.tsx` | GATE-01: Telemetry Synchronization | **IMPLEMENTED** |
| **REQ-DISP-05** | Railway Control | Active dispatch hold/release commands affecting physical in-game trains. | `src/engine/world/AITrainManager.ts`, `src/components/TrainControlCenter.tsx` | GATE-01: Physical Service Hold Validation | **IMPLEMENTED** |
| **REQ-VEH-01** | Garage & Vehicles | Four distinct drivable vehicles in apartment garage: Sedan (`apt_car_01`), ATV (`apt_atv_01`), Motorcycle (`apt_bike_01`), Bicycle (`apt_bicycle_01`). | `src/engine/base/VehicleParkingManager.ts`, `src/engine/GameEngine.ts` | GATE-02: Multi-Vehicle Physics & Input | **IMPLEMENTED** |
| **REQ-VEH-02** | Garage & Vehicles | Outpost Recon Buggy (`veh_recon_buggy_01`) retained and operational. | `src/engine/base/VehicleParkingManager.ts` | GATE-02: Buggy Physics Verification | **IMPLEMENTED** |
| **REQ-VEH-03** | Garage & Vehicles | Solid-wall 15.2m × 9.4m garage with 4 marked bays and motorized opening gate with switch keypad. | `src/engine/prologue/ApartmentBuilding.ts` | GATE-02: Garage Gate Colliders & Switch | **IMPLEMENTED** |
| **REQ-VEH-04** | Garage & Vehicles | Synchronized dynamic Box3 collision proxies for garage gate to prevent player/vehicle phasing. | `src/engine/prologue/ApartmentBuilding.ts` | GATE-02: Gate Collider Synchronization | **IMPLEMENTED** |
| **REQ-CAM-01** | Camera & Cutscenes | Eliminate cinematic camera freeze by clamping delta (0.1s max) and enforcing auto-timeout. | `src/engine/prologue/CinematicCameraManager.ts` | GATE-03: Delta Clamp & Timeout Test | **IMPLEMENTED** |
| **REQ-CAM-02** | Camera & Cutscenes | Guarantee 3D player avatar visibility restoration upon cutscene completion. | `src/engine/PlayerController.ts`, `src/engine/prologue/CinematicCameraManager.ts` | GATE-03: Avatar Visibility Assertion | **IMPLEMENTED** |
| **REQ-CAM-03** | Camera & Cutscenes | Safe camera distance auto-recovery when player camera detaches $> 25\text{m}$ or enters NaN state. | `src/engine/PlayerController.ts` | GATE-03: Camera Bound Clamping Test | **IMPLEMENTED** |
| **REQ-NPC-01** | Town & NPC Life | Elevation grounding for park NPCs (Leo the jogger and Mrs. Gable) avoiding ground sinkage. | `src/engine/prologue/TownLifeManager.ts` | GATE-03: NPC Foot Contact Validation | **IMPLEMENTED** |
| **REQ-NPC-02** | Town & NPC Life | Leo jogger path animation running laps around park fountain with surface height tracking. | `src/engine/prologue/TownLifeManager.ts` | GATE-03: Leo Fountain Lap Simulation | **IMPLEMENTED** |
| **REQ-CMP-01** | Campaign Missions | 8-Day 56-Mission campaign catalogue integrated into core engine without breaking saves. | `src/data/eightDayCampaign.ts`, `src/engine/GameEngine.ts` | GATE-04: Campaign Progression & Objectives | **IMPLEMENTED** |
| **REQ-CMP-02** | Campaign Missions | Dual-tab `QuestJournalModal` displaying 8-Day Campaign & Sanctuary Directives with Day filters. | `src/components/QuestJournalModal.tsx`, `src/App.tsx` | GATE-04: Quest Journal Modal Interaction | **IMPLEMENTED** |
| **REQ-RAIL-01** | Six-Track Railway | Autonomous six-track railway network (F1-F3, B1-B3) with 120s dwell, door animations, and audio. | `src/engine/world/AITrainManager.ts` | GATE-01: Autonomous Passenger Lines | **IMPLEMENTED** |
| **REQ-OPT-01** | Mobile & Desktop | Adaptive touch controls, responsive UI scaling, safe-area compliance, stable 60 FPS performance. | `src/components/TouchControls.tsx`, `src/App.tsx` | GATE-04: Mobile Input & Build Cleanliness | **IMPLEMENTED** |

---

## 2. Invariant Safety Assertions

1. **Autonomous Railway Integrity:** No locomotive permits player driving. Direct train operation is strictly handled by the autonomous schedule and monitored/held via the Basement Railway Dispatch Console.
2. **Persistence Guarantee:** Legacy save game files are migrated seamlessly using `migrateLegacyCampaignSaves()`, initializing Day 1 to Day 8 records without data loss.
3. **Collision Integrity:** Vehicle parking manager elevation queries match compound ground and road grades to prevent vehicle spawn fall-throughs or wall clipping.
