/** Deterministic, chunk-streamed six-track railway network. */
import * as THREE from 'three';
import { POIStructure } from '../../types/game';
import { CHUNK_SIZE } from './WorldCoordinates';
import { TerrainGenerator } from './TerrainGenerator';

export type RailwayTrackId = 'F1' | 'F2' | 'F3' | 'B1' | 'B2' | 'B3';
export const RAILWAY_TRACKS: ReadonlyArray<{ id: RailwayTrackId; direction: 'forward' | 'backward'; playerDrivable: boolean; xOffset: number }> = [
  { id: 'F1', direction: 'forward', playerDrivable: true, xOffset: -7.5 },
  { id: 'F2', direction: 'forward', playerDrivable: false, xOffset: -4.5 },
  { id: 'F3', direction: 'forward', playerDrivable: false, xOffset: -1.5 },
  { id: 'B1', direction: 'backward', playerDrivable: true, xOffset: 1.5 },
  { id: 'B2', direction: 'backward', playerDrivable: false, xOffset: 4.5 },
  { id: 'B3', direction: 'backward', playerDrivable: false, xOffset: 7.5 },
];

const railMat = new THREE.MeshStandardMaterial({ color: 0x68727a, metalness: 0.82, roughness: 0.32 });
const sleeperMat = new THREE.MeshStandardMaterial({ color: 0x493b2d, roughness: 0.92 });
const ballastMat = new THREE.MeshStandardMaterial({ color: 0x55534f, roughness: 1 });
const platformMat = new THREE.MeshStandardMaterial({ color: 0x85898b, roughness: 0.9 });
const stationAccentMat = new THREE.MeshStandardMaterial({ color: 0x243b4a, roughness: 0.65 });

function hash01(x: number, z: number, seed: number, salt: number): number {
  const n = Math.sin(x * 127.1 + z * 311.7 + seed * 0.017 + salt * 74.7) * 43758.5453123;
  return n - Math.floor(n);
}

function addRailSegment(group: THREE.Group, a: THREE.Vector3, b: THREE.Vector3, material: THREE.Material, radius = 0.075) {
  const delta = new THREE.Vector3().subVectors(b, a);
  const length = delta.length();
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, length, 6), material);
  mesh.position.copy(a).add(b).multiplyScalar(0.5);
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), delta.normalize());
  mesh.castShadow = false;
  mesh.receiveShadow = true;
  group.add(mesh);
}

export class RailwayNetworkGenerator {
  /** Every chunk uses the same world-aligned six-track corridor, so boundaries join exactly. */
  public static createChunk(cx: number, cz: number, seed: number, pois: POIStructure[]): THREE.Group {
    const group = new THREE.Group();
    group.name = `railway_chunk_${cx}_${cz}`;
    group.userData.trackCount = 6;
    group.userData.trackIds = RAILWAY_TRACKS.map(t => t.id);
    group.userData.playerDrivableTracks = ['F1', 'B1'];
    const minX = cx * CHUNK_SIZE;
    const minZ = cz * CHUNK_SIZE;
    const centerX = minX + CHUNK_SIZE * 0.5;

    for (const track of RAILWAY_TRACKS) {
      const x = centerX + track.xOffset;
      const y = TerrainGenerator.getHeight(x, minZ + CHUNK_SIZE * 0.5, seed) + 0.24;
      const ballast = new THREE.Mesh(new THREE.BoxGeometry(2.65, 0.18, CHUNK_SIZE), ballastMat);
      ballast.position.set(x, y - 0.12, minZ + CHUNK_SIZE * 0.5);
      group.add(ballast);
      addRailSegment(group, new THREE.Vector3(x - 0.72, y + 0.12, minZ), new THREE.Vector3(x - 0.72, y + 0.12, minZ + CHUNK_SIZE), railMat, 0.065);
      addRailSegment(group, new THREE.Vector3(x + 0.72, y + 0.12, minZ), new THREE.Vector3(x + 0.72, y + 0.12, minZ + CHUNK_SIZE), railMat, 0.065);

      const sleeperCount = Math.floor(CHUNK_SIZE / 3.2);
      const sleeperGeo = new THREE.BoxGeometry(2.25, 0.16, 0.34);
      const sleepers = new THREE.InstancedMesh(sleeperGeo, sleeperMat, sleeperCount);
      const matrix = new THREE.Matrix4();
      const q = new THREE.Quaternion();
      const s = new THREE.Vector3(1, 1, 1);
      for (let i = 0; i < sleeperCount; i++) {
        const z = minZ + i * 3.2 + 1.6;
        const sy = TerrainGenerator.getHeight(x, z, seed) + 0.12;
        matrix.compose(new THREE.Vector3(x, sy, z), q, s);
        sleepers.setMatrixAt(i, matrix);
      }
      sleepers.instanceMatrix.needsUpdate = true;
      group.add(sleepers);
      group.userData[track.id] = { direction: track.direction, playerDrivable: track.playerDrivable };
    }

    // Deterministic station branches tie major POIs to the closest main line.
    for (const poi of pois) {
      const stationEligible = !(['cabin', 'ruined_house', 'watchtower'] as string[]).includes(poi.type);
      if (!stationEligible) continue;
      const px = poi.position[0];
      const pz = poi.position[2];
      const nearest = RAILWAY_TRACKS.reduce((best, t) => Math.abs(centerX + t.xOffset - px) < Math.abs(centerX + best.xOffset - px) ? t : best, RAILWAY_TRACKS[0]);
      const trackX = centerX + nearest.xOffset;
      const trackY = TerrainGenerator.getHeight(trackX, pz, seed) + 0.38;
      const poiY = TerrainGenerator.getHeight(px, pz, seed) + 0.38;
      const start = new THREE.Vector3(trackX, trackY, pz);
      const end = new THREE.Vector3(px, poiY, pz);
      const mid = new THREE.Vector3((trackX + px) * 0.5, Math.max(trackY, poiY) + 0.12, pz);
      const curve = new THREE.QuadraticBezierCurve3(start, mid, end);
      const branch = new THREE.Mesh(new THREE.TubeGeometry(curve, 16, 0.045, 5, false), railMat);
      group.add(branch);
      const platform = new THREE.Mesh(new THREE.BoxGeometry(8, 0.32, 15), platformMat);
      platform.position.set(px, poiY + 0.03, pz + 10);
      group.add(platform);
      const canopy = new THREE.Mesh(new THREE.BoxGeometry(6, 0.18, 5), stationAccentMat);
      canopy.position.set(px, poiY + 3.2, pz + 10);
      group.add(canopy);
      for (const dx of [-2.5, 2.5]) {
        const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.18, 3, 0.18), stationAccentMat);
        pillar.position.set(px + dx, poiY + 1.65, pz + 10);
        group.add(pillar);
      }
      const stationId = `station_${poi.id}`;
      group.userData[stationId] = { name: `${poi.name} Station`, poiId: poi.id, trackId: nearest.id, direction: nearest.direction, playerDrivable: nearest.playerDrivable, x: px, z: pz + 10 };
    }

    // Cross-chunk interchanges connect adjacent north/south corridors into one world-spanning graph.
    // These transverse links meet the next chunk's aligned corridor at the same stable lane offsets.
    const linkZ = minZ + CHUNK_SIZE * 0.5;
    for (const track of RAILWAY_TRACKS) {
      const y = TerrainGenerator.getHeight(centerX, linkZ, seed) + 0.38;
      addRailSegment(group, new THREE.Vector3(centerX + track.xOffset, y, linkZ - 0.72), new THREE.Vector3(centerX + CHUNK_SIZE + track.xOffset, y, linkZ - 0.72), railMat, 0.045);
      addRailSegment(group, new THREE.Vector3(centerX + track.xOffset, y, linkZ + 0.72), new THREE.Vector3(centerX + CHUNK_SIZE + track.xOffset, y, linkZ + 0.72), railMat, 0.045);
    }

    // A deterministic interchange marker every fourth chunk; rails remain continuous through it.
    if (hash01(cx, cz, seed, 11) > 0.72) {
      const x = centerX;
      const z = minZ + CHUNK_SIZE * (0.25 + hash01(cx, cz, seed, 12) * 0.5);
      const y = TerrainGenerator.getHeight(x, z, seed) + 0.5;
      const signal = new THREE.Group();
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.12, 5, 8), stationAccentMat);
      pole.position.set(x + 11, y + 2.5, z);
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.5, 1.25, 0.45), new THREE.MeshStandardMaterial({ color: 0x1b252a, roughness: 0.55 }));
      head.position.set(x + 11, y + 4.4, z);
      signal.add(pole, head);
      group.add(signal);
    }
    return group;
  }
}
