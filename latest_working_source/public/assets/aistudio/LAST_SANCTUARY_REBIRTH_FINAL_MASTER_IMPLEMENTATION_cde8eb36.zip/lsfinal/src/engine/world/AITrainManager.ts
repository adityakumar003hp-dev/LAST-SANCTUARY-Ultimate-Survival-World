import * as THREE from 'three';
import { getTerrainHeight } from '../Terrain';

/**
 * Physical AI rail traffic for the four non-drivable lines.
 * Trains are ordinary Three.js meshes (not sprites or impostors), and are
 * simulated only while the game is running. Each station dwell is 120 seconds.
 */
type AILineId = 'F2' | 'F3' | 'B2' | 'B3';
interface AITrain {
  id: string;
  line: AILineId;
  direction: 1 | -1;
  group: THREE.Group;
  x: number;
  z: number;
  speed: number;
  dwellRemaining: number;
  currentStationIndex: number | null;
  doors: THREE.Mesh[];
  stationStatus: 'running' | 'doors_open' | 'doors_closing';
}

const CHUNK_LENGTH = 128;
const STATION_SPACING = 1200;
const DWELL_SECONDS = 120;
const TRAIN_SPEED = 13;
const TRACKS: Array<{ id: AILineId; z: number; direction: 1 | -1; startX: number }> = [
  { id: 'F2', z: -18, direction: 1, startX: -260 },
  { id: 'F3', z: -6, direction: 1, startX: -760 },
  { id: 'B2', z: 6, direction: -1, startX: 760 },
  { id: 'B3', z: 18, direction: -1, startX: 260 },
];

export class AITrainManager {
  private scene: THREE.Scene;
  private worldSeed: number;
  private trains: AITrain[] = [];
  private railChunks = new Map<string, THREE.Group>();
  private stationGroups = new Map<string, THREE.Group>();
  private readonly railMaterial = new THREE.MeshStandardMaterial({ color: 0x626b73, metalness: 0.82, roughness: 0.34 });
  private readonly sleeperMaterial = new THREE.MeshStandardMaterial({ color: 0x39332b, roughness: 0.92 });
  private readonly platformMaterial = new THREE.MeshStandardMaterial({ color: 0x777b7d, roughness: 0.86 });
  private readonly trainBodyMaterial = new THREE.MeshStandardMaterial({ color: 0x253e52, metalness: 0.58, roughness: 0.38 });
  private readonly windowMaterial = new THREE.MeshPhysicalMaterial({ color: 0x8fc8d8, metalness: 0.25, roughness: 0.12, transparent: true, opacity: 0.78 });
  private readonly wheelMaterial = new THREE.MeshStandardMaterial({ color: 0x17191c, metalness: 0.75, roughness: 0.5 });
  private readonly doorMaterial = new THREE.MeshStandardMaterial({ color: 0x9aa8b0, metalness: 0.55, roughness: 0.42 });

  constructor(scene: THREE.Scene, worldSeed = 42) {
    this.scene = scene;
    this.worldSeed = worldSeed;
    for (const line of TRACKS) {
      const group = this.createTrainMesh(line.id);
      this.scene.add(group);
      this.trains.push({
        id: `ai_train_${line.id.toLowerCase()}`,
        line: line.id,
        direction: line.direction,
        group,
        x: line.startX,
        z: line.z,
        speed: TRAIN_SPEED,
        dwellRemaining: 0,
        currentStationIndex: null,
        doors: group.userData.doors as THREE.Mesh[],
        stationStatus: 'running',
      });
    }
  }

  private terrainY(x: number, z: number): number {
    return getTerrainHeight(x, z, this.worldSeed) + 0.22;
  }

  private createTrainMesh(line: AILineId): THREE.Group {
    const root = new THREE.Group();
    root.name = `PHYSICAL_AI_TRAIN_${line}`;
    root.userData = { lineId: line, physicalMesh: true, playerDrivable: false, collisionProxy: new THREE.Box3() };

    const body = new THREE.Mesh(new THREE.BoxGeometry(25, 4.1, 3.7), this.trainBodyMaterial);
    body.position.y = 3.1;
    body.castShadow = true;
    body.receiveShadow = true;
    root.add(body);

    const roof = new THREE.Mesh(new THREE.BoxGeometry(23.8, 0.35, 3.55), new THREE.MeshStandardMaterial({ color: 0x18232d, metalness: 0.45, roughness: 0.55 }));
    roof.position.set(0, 5.32, 0);
    roof.castShadow = true;
    root.add(roof);

    // Repeated solid window panels give the carriage readable scale and depth.
    for (let i = 0; i < 8; i++) {
      const x = -10.2 + i * 2.9;
      for (const side of [-1, 1]) {
        const window = new THREE.Mesh(new THREE.BoxGeometry(1.8, 1.15, 0.08), this.windowMaterial);
        window.position.set(x, 3.75, side * 1.88);
        root.add(window);
      }
    }

    const doors: THREE.Mesh[] = [];
    for (const x of [-5.8, 5.8]) {
      for (const side of [-1, 1]) {
        const door = new THREE.Mesh(new THREE.BoxGeometry(1.05, 2.35, 0.12), this.doorMaterial);
        door.position.set(x, 2.55, side * 1.91);
        door.userData.closedX = x;
        door.userData.side = side;
        door.castShadow = true;
        root.add(door);
        doors.push(door);
      }
    }
    root.userData.doors = doors;

    // Two bogies and eight visible wheels: solid cylinder meshes, not flat decals.
    for (const x of [-8.2, 8.2]) {
      const bogie = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.55, 2.7), this.wheelMaterial);
      bogie.position.set(x, 0.95, 0);
      root.add(bogie);
      for (const wx of [-1.35, 1.35]) {
        for (const side of [-1, 1]) {
          const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.58, 0.58, 0.28, 16), this.wheelMaterial);
          wheel.rotation.x = Math.PI / 2;
          wheel.position.set(x + wx, 0.65, side * 1.38);
          wheel.castShadow = true;
          root.add(wheel);
        }
      }
    }

    const headlightMaterial = new THREE.MeshStandardMaterial({ color: 0xfff1bf, emissive: 0xffd36b, emissiveIntensity: 1.4 });
    for (const side of [-1, 1]) {
      const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.22, 10, 8), headlightMaterial);
      lamp.position.set(12.58, 2.55, side * 0.95);
      root.add(lamp);
    }

    const linePlate = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.55, 0.08), new THREE.MeshStandardMaterial({ color: 0xe5e7eb, emissive: 0x17202a }));
    linePlate.position.set(0, 4.85, 1.91);
    root.add(linePlate);
    root.userData.boundingSize = new THREE.Vector3(25.5, 5.8, 4.2);
    return root;
  }

  private buildRailChunk(lineId: AILineId, z: number, chunkX: number): void {
    const key = `${lineId}:${chunkX}`;
    if (this.railChunks.has(key)) return;
    const group = new THREE.Group();
    group.name = `PHYSICAL_RAIL_${key}`;
    const start = chunkX * CHUNK_LENGTH;
    const y = this.terrainY(start + CHUNK_LENGTH / 2, z);

    // Ballast bed and two continuous steel rails.
    const ballast = new THREE.Mesh(new THREE.BoxGeometry(CHUNK_LENGTH, 0.34, 5.2), new THREE.MeshStandardMaterial({ color: 0x56534d, roughness: 1 }));
    ballast.position.set(start + CHUNK_LENGTH / 2, y - 0.25, z);
    ballast.receiveShadow = true;
    group.add(ballast);
    for (const side of [-1, 1]) {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(CHUNK_LENGTH, 0.24, 0.22), this.railMaterial);
      rail.position.set(start + CHUNK_LENGTH / 2, y + 0.08, z + side * 0.85);
      rail.castShadow = true;
      rail.receiveShadow = true;
      group.add(rail);
    }
    for (let x = 0; x < CHUNK_LENGTH; x += 2.6) {
      const sleeper = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.18, 3.5), this.sleeperMaterial);
      sleeper.position.set(start + x + 1.3, y - 0.02, z);
      sleeper.castShadow = true;
      group.add(sleeper);
    }
    group.userData = { lineId, chunkX, physicalTrack: true };
    this.scene.add(group);
    this.railChunks.set(key, group);
  }

  private buildStation(lineId: AILineId, z: number, stationIndex: number): void {
    const key = `${lineId}:station:${stationIndex}`;
    if (this.stationGroups.has(key)) return;
    const x = stationIndex * STATION_SPACING;
    const y = this.terrainY(x, z);
    const group = new THREE.Group();
    group.name = `PHYSICAL_STATION_${key}`;
    group.userData = { stationId: key, lineId, stationIndex, dwellSeconds: DWELL_SECONDS };

    const platform = new THREE.Mesh(new THREE.BoxGeometry(72, 0.65, 7), this.platformMaterial);
    platform.position.set(x, y + 0.05, z + 6.5);
    platform.receiveShadow = true;
    platform.castShadow = true;
    group.add(platform);

    const canopy = new THREE.Mesh(new THREE.BoxGeometry(34, 0.35, 6.5), new THREE.MeshStandardMaterial({ color: 0x34434d, metalness: 0.4, roughness: 0.62 }));
    canopy.position.set(x, y + 4.2, z + 6.5);
    group.add(canopy);
    for (const dx of [-15, -5, 5, 15]) {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.25, 4.1, 0.25), this.railMaterial);
      post.position.set(x + dx, y + 2.1, z + 6.5);
      group.add(post);
    }
    const sign = new THREE.Mesh(new THREE.BoxGeometry(8, 1.15, 0.2), new THREE.MeshStandardMaterial({ color: 0x15394b, emissive: 0x071923 }));
    sign.position.set(x, y + 3.05, z + 2.5);
    group.add(sign);
    this.scene.add(group);
    this.stationGroups.set(key, group);
  }

  private ensureWorldGeometry(x: number, z: number, lineId: AILineId): void {
    const config = TRACKS.find((t) => t.id === lineId)!;
    const centerChunk = Math.floor(x / CHUNK_LENGTH);
    for (let c = centerChunk - 2; c <= centerChunk + 2; c++) this.buildRailChunk(lineId, z, c);
    const stationIndex = Math.round(x / STATION_SPACING);
    for (let s = stationIndex - 1; s <= stationIndex + 1; s++) this.buildStation(lineId, z, s);
    void config;
  }

  update(deltaSeconds: number, playerPosition: THREE.Vector3): void {
    for (const train of this.trains) {
      this.ensureWorldGeometry(playerPosition.x, train.z, train.line);
      this.ensureWorldGeometry(train.x, train.z, train.line);
      const nearestStation = Math.round(train.x / STATION_SPACING);
      const stationX = nearestStation * STATION_SPACING;

      if (train.dwellRemaining > 0) {
        train.dwellRemaining = Math.max(0, train.dwellRemaining - deltaSeconds);
        train.stationStatus = train.dwellRemaining > 0 ? 'doors_open' : 'doors_closing';
        // Doors slide outward while stopped, then close during the final 2 seconds.
        const opening = train.dwellRemaining > 2 ? 0.62 : train.dwellRemaining / 2 * 0.62;
        for (const door of train.doors) {
          const side = Number(door.userData.side);
          door.position.z = side * (1.91 + opening);
        }
        if (train.dwellRemaining === 0) {
          // Retain the last station index until the train reaches the next one;
          // this prevents immediately re-triggering the same stop on departure.
          train.stationStatus = 'running';
        }
      } else if (Math.abs(train.x - stationX) <= train.speed * deltaSeconds + 0.35 && train.currentStationIndex !== nearestStation) {
        train.x = stationX;
        train.dwellRemaining = DWELL_SECONDS;
        train.currentStationIndex = nearestStation;
        train.stationStatus = 'doors_open';
        for (const door of train.doors) door.position.z = Number(door.userData.side) * 2.53;
      } else {
        train.x += train.direction * train.speed * deltaSeconds;
      }

      const groundY = this.terrainY(train.x, train.z);
      train.group.position.set(train.x, groundY, train.z);
      train.group.rotation.y = train.direction === 1 ? 0 : Math.PI;
      train.group.updateMatrixWorld(true);
      const size = train.group.userData.boundingSize as THREE.Vector3;
      const box = train.group.userData.collisionProxy as THREE.Box3;
      box.setFromCenterAndSize(train.group.position.clone().add(new THREE.Vector3(0, 2.9, 0)), size);
      train.group.userData.stationStatus = train.stationStatus;
      train.group.userData.dwellRemainingSeconds = train.dwellRemaining;
      train.group.userData.collisionProxy = box;
    }

    // Keep a bounded working set around the player and trains; the route itself
    // is coordinate-driven and can continue indefinitely in either X direction.
    const keep = new Set<string>();
    for (const train of this.trains) {
      const c = Math.floor(train.x / CHUNK_LENGTH);
      for (let i = c - 3; i <= c + 3; i++) keep.add(`${train.line}:${i}`);
      const pc = Math.floor(playerPosition.x / CHUNK_LENGTH);
      for (let i = pc - 2; i <= pc + 2; i++) keep.add(`${train.line}:${i}`);
    }
    for (const [key, group] of this.railChunks) {
      if (!keep.has(key)) {
        this.scene.remove(group);
        group.traverse((obj) => {
          if (obj instanceof THREE.Mesh) {
            obj.geometry.dispose();
            // Shared materials are disposed by manager.dispose().
          }
        });
        this.railChunks.delete(key);
      }
    }
    for (const [key, group] of this.stationGroups) {
      const stationX = Number(group.userData.stationIndex) * STATION_SPACING;
      const nearPlayer = Math.abs(stationX - playerPosition.x) <= 520;
      const nearTrain = this.trains.some((train) => Math.abs(stationX - train.x) <= 520);
      if (!nearPlayer && !nearTrain) {
        this.scene.remove(group);
        group.traverse((obj) => { if (obj instanceof THREE.Mesh) obj.geometry.dispose(); });
        this.stationGroups.delete(key);
      }
    }
  }

  getTrainCollisionBoxes(): Array<{ id: string; line: AILineId; box: THREE.Box3 }> {
    return this.trains.map((train) => ({ id: train.id, line: train.line, box: (train.group.userData.collisionProxy as THREE.Box3).clone() }));
  }

  dispose(): void {
    for (const train of this.trains) this.scene.remove(train.group);
    for (const group of this.railChunks.values()) {
      this.scene.remove(group);
      group.traverse((obj) => { if (obj instanceof THREE.Mesh) obj.geometry.dispose(); });
    }
    for (const group of this.stationGroups.values()) {
      this.scene.remove(group);
      group.traverse((obj) => { if (obj instanceof THREE.Mesh) obj.geometry.dispose(); });
    }
    for (const train of this.trains) {
      train.group.traverse((obj) => { if (obj instanceof THREE.Mesh) obj.geometry.dispose(); });
    }
    this.railMaterial.dispose();
    this.sleeperMaterial.dispose();
    this.platformMaterial.dispose();
    this.trainBodyMaterial.dispose();
    this.windowMaterial.dispose();
    this.wheelMaterial.dispose();
    this.doorMaterial.dispose();
    this.trains = [];
    this.railChunks.clear();
    this.stationGroups.clear();
  }
}
