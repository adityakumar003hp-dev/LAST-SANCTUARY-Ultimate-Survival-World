import * as THREE from 'three';
import { getTerrainHeight } from './Terrain';
import { CompanionState } from '../types/game';

export type WildlifeKind = 'mammal' | 'bird' | 'dinosaur' | 'aquatic' | 'reptile' | 'amphibian' | 'insect' | 'rare';

export interface WildlifeSpecies {
  id: string;
  name: string;
  kind: WildlifeKind;
  biomes: string[];
  color: number;
  scale: number;
  speed: number;
  temperament: 'shy' | 'neutral' | 'territorial';
  isTamable?: boolean;
}

export interface WildlifeAgent {
  id: string;
  species: WildlifeSpecies;
  group: THREE.Group;
  velocity: THREE.Vector3;
  target: THREE.Vector3;
  state: 'roam' | 'rest' | 'flee' | 'chase' | 'companion_follow' | 'companion_stay';
  stateTimer: number;
  health: number;
  maxHealth: number;
  isTamed?: boolean;
}

// 40+ species ecosystem across all 35 biomes
export const WILDLIFE_SPECIES: WildlifeSpecies[] = [
  // Dinosaurs & Prehistoric (Dinosaur Valley, Basins, Ashlands, Crags)
  { id: 'trex', name: 'Tyrannosaurus Rex', kind: 'dinosaur', biomes: ['dinosaur_valley', 'volcanic_wastes', 'ashlands'], color: 0x7a3e2b, scale: 2.3, speed: 5.6, temperament: 'territorial' },
  { id: 'triceratops', name: 'Triceratops', kind: 'dinosaur', biomes: ['dinosaur_valley', 'green_plains', 'valley', 'savannah', 'alpine_meadow'], color: 0x69734b, scale: 1.7, speed: 2.6, temperament: 'neutral' },
  { id: 'raptor', name: 'Velociraptor', kind: 'dinosaur', biomes: ['dinosaur_valley', 'dense_forest', 'valley', 'tropical_jungle', 'savannah', 'ancient_forest', 'bamboo_forest'], color: 0x55704a, scale: 1.05, speed: 6.2, temperament: 'territorial', isTamable: true },
  { id: 'stegosaurus', name: 'Stegosaurus', kind: 'dinosaur', biomes: ['dinosaur_valley', 'dense_forest', 'green_plains', 'tropical_jungle', 'ancient_forest'], color: 0x6c7650, scale: 1.55, speed: 2.4, temperament: 'neutral' },
  { id: 'longneck', name: 'Brachiosaurus', kind: 'dinosaur', biomes: ['dinosaur_valley', 'green_plains', 'valley', 'savannah', 'waterfall_valley'], color: 0x8c9871, scale: 2.4, speed: 1.9, temperament: 'neutral' },
  { id: 'pteranodon', name: 'Pteranodon', kind: 'bird', biomes: ['dinosaur_valley', 'rocky_canyon', 'mountain_range', 'snow_peaks'], color: 0x9c5c3d, scale: 1.5, speed: 9.0, temperament: 'neutral' },

  // Land Mammals
  { id: 'wolf', name: 'Grey Wolf', kind: 'mammal', biomes: ['dense_forest', 'mountain_range', 'snow_peaks', 'taiga', 'tundra', 'ancient_forest'], color: 0x777b80, scale: 0.85, speed: 5.4, temperament: 'territorial', isTamable: true },
  { id: 'bear', name: 'Grizzly Bear', kind: 'mammal', biomes: ['dense_forest', 'mountain_range', 'taiga', 'ancient_forest'], color: 0x493326, scale: 1.4, speed: 3.5, temperament: 'territorial' },
  { id: 'deer', name: 'Red Deer', kind: 'mammal', biomes: ['dense_forest', 'green_plains', 'valley', 'tropical_jungle', 'ancient_forest', 'bamboo_forest', 'savannah', 'waterfall_valley'], color: 0x8a5735, scale: 1.0, speed: 4.4, temperament: 'shy' },
  { id: 'fox', name: 'Red Fox', kind: 'mammal', biomes: ['dense_forest', 'green_plains', 'valley', 'ancient_forest', 'bamboo_forest'], color: 0xb65d25, scale: 0.6, speed: 4.8, temperament: 'shy', isTamable: true },
  { id: 'horse', name: 'Wild Mustang', kind: 'mammal', biomes: ['green_plains', 'savannah', 'alpine_meadow', 'waterfall_valley'], color: 0x79533b, scale: 1.1, speed: 6.2, temperament: 'shy', isTamable: true },
  { id: 'boar', name: 'Wild Boar', kind: 'mammal', biomes: ['dense_forest', 'wetlands', 'tropical_jungle', 'mangrove_delta', 'deep_swamp'], color: 0x514039, scale: 0.8, speed: 3.9, temperament: 'territorial' },
  { id: 'lion', name: 'African Lion', kind: 'mammal', biomes: ['savannah', 'green_plains'], color: 0xb58a4c, scale: 1.3, speed: 5.0, temperament: 'territorial' },
  { id: 'tiger', name: 'Bengal Tiger', kind: 'mammal', biomes: ['tropical_jungle', 'dense_forest', 'bamboo_forest'], color: 0xc66a22, scale: 1.25, speed: 5.6, temperament: 'territorial' },
  { id: 'panther', name: 'Black Panther', kind: 'mammal', biomes: ['tropical_jungle', 'deep_swamp', 'ancient_forest'], color: 0x1d1c1c, scale: 1.15, speed: 6.0, temperament: 'territorial' },
  { id: 'elephant', name: 'Asian Elephant', kind: 'mammal', biomes: ['green_plains', 'wetlands', 'tropical_jungle'], color: 0x77766f, scale: 1.95, speed: 2.8, temperament: 'neutral' },
  { id: 'giraffe', name: 'Savannah Giraffe', kind: 'mammal', biomes: ['savannah'], color: 0xb98b48, scale: 1.7, speed: 3.3, temperament: 'neutral' },
  { id: 'zebra', name: 'Plains Zebra', kind: 'mammal', biomes: ['savannah'], color: 0xd8d3c8, scale: 1.0, speed: 4.5, temperament: 'shy' },
  { id: 'monkey', name: 'Tree Macaque', kind: 'mammal', biomes: ['tropical_jungle', 'bamboo_forest', 'ancient_forest'], color: 0x8b654a, scale: 0.55, speed: 4.5, temperament: 'shy' },
  { id: 'buffalo', name: 'Wild Water Buffalo', kind: 'mammal', biomes: ['savannah', 'wetlands', 'mangrove_delta', 'deep_swamp'], color: 0x403b35, scale: 1.35, speed: 3.0, temperament: 'territorial' },

  // Birds (Flying AI)
  { id: 'eagle', name: 'Golden Eagle', kind: 'bird', biomes: ['mountain_range', 'snow_peaks', 'valley', 'alpine_meadow', 'tundra', 'rocky_canyon'], color: 0x8b6844, scale: 0.75, speed: 8.8, temperament: 'shy' },
  { id: 'parrot', name: 'Scarlet Macaw', kind: 'bird', biomes: ['dense_forest', 'wetlands', 'tropical_jungle', 'mangrove_delta'], color: 0xd52c24, scale: 0.45, speed: 7.4, temperament: 'shy', isTamable: true },
  { id: 'seagull', name: 'Coastal Seagull', kind: 'bird', biomes: ['coastline', 'sand_dunes', 'coral_coast', 'island'], color: 0xededed, scale: 0.45, speed: 8.0, temperament: 'shy' },
  { id: 'owl', name: 'Great Horned Owl', kind: 'bird', biomes: ['dense_forest', 'valley', 'taiga', 'ancient_forest'], color: 0x8a7459, scale: 0.5, speed: 6.5, temperament: 'shy' },
  { id: 'duck', name: 'Wild Mallard', kind: 'bird', biomes: ['river_basin', 'lake_district', 'wetlands', 'mangrove_delta', 'coral_coast', 'waterfall_valley'], color: 0x55765a, scale: 0.4, speed: 4.4, temperament: 'shy' },
  { id: 'flamingo', name: 'Greater Flamingo', kind: 'bird', biomes: ['wetlands', 'mangrove_delta', 'coral_coast'], color: 0xe58b9e, scale: 0.75, speed: 5.6, temperament: 'shy' },
  { id: 'penguin', name: 'Emperor Penguin', kind: 'bird', biomes: ['snow_peaks', 'glacier_field', 'tundra'], color: 0x222b35, scale: 0.6, speed: 2.0, temperament: 'neutral' },
  { id: 'crow', name: 'Carrion Crow', kind: 'bird', biomes: ['abandoned_city', 'green_plains', 'dense_forest', 'ashlands'], color: 0x20232a, scale: 0.4, speed: 7.2, temperament: 'shy' },

  // Aquatic & Marine Species
  { id: 'shark', name: 'Reef Shark', kind: 'aquatic', biomes: ['coral_coast', 'coastline', 'island'], color: 0x596b78, scale: 1.2, speed: 4.8, temperament: 'territorial' },
  { id: 'dolphin', name: 'Bottlenose Dolphin', kind: 'aquatic', biomes: ['coral_coast', 'coastline', 'island'], color: 0x658a9b, scale: 1.0, speed: 5.4, temperament: 'neutral' },
  { id: 'whale', name: 'Humpback Whale', kind: 'aquatic', biomes: ['coral_coast', 'coastline', 'island'], color: 0x455969, scale: 2.6, speed: 2.8, temperament: 'neutral' },
  { id: 'turtle', name: 'Sea Turtle', kind: 'aquatic', biomes: ['river_basin', 'lake_district', 'wetlands', 'mangrove_delta', 'coral_coast', 'island'], color: 0x456b4b, scale: 0.55, speed: 1.4, temperament: 'shy' },
  { id: 'reef_fish', name: 'Coral Fish School', kind: 'aquatic', biomes: ['coral_coast', 'coastline', 'island', 'lake_district', 'waterfall_valley'], color: 0x35a9b4, scale: 0.3, speed: 3.4, temperament: 'shy' },

  // Reptiles, Amphibians, Insects & Rare
  { id: 'crocodile', name: 'Saltwater Crocodile', kind: 'reptile', biomes: ['wetlands', 'mangrove_delta', 'coral_coast', 'deep_swamp'], color: 0x52614b, scale: 1.25, speed: 2.2, temperament: 'territorial' },
  { id: 'frog', name: 'Tree Frog', kind: 'amphibian', biomes: ['wetlands', 'tropical_jungle', 'mangrove_delta', 'deep_swamp'], color: 0x54a85a, scale: 0.24, speed: 1.6, temperament: 'shy' },
  { id: 'glow_moth', name: 'Luminous Moth', kind: 'rare', biomes: ['cave_system', 'wetlands', 'dense_forest', 'crystal_cavern', 'mangrove_delta', 'deep_swamp'], color: 0x76e6d1, scale: 0.32, speed: 3.4, temperament: 'shy' },
  { id: 'butterfly', name: 'Monarch Butterfly', kind: 'insect', biomes: ['green_plains', 'tropical_jungle', 'ancient_forest', 'waterfall_valley'], color: 0xe68a28, scale: 0.2, speed: 3.0, temperament: 'shy' },
  { id: 'firefly', name: 'Firefly', kind: 'insect', biomes: ['wetlands', 'dense_forest', 'ancient_forest', 'deep_swamp'], color: 0xd7e77a, scale: 0.14, speed: 1.9, temperament: 'shy' },
];

export class WildlifeManager {
  private scene: THREE.Scene;
  private agents = new Map<string, WildlifeAgent>();
  private seed: number;
  private spawnClock = 0;
  private maxAgents = 12;

  // Tamed companion state
  public companionState: CompanionState | null = null;
  public companionAgentId: string | null = null;

  constructor(scene: THREE.Scene, seed: number) {
    this.scene = scene;
    this.seed = seed;
  }

  public update(
    delta: number,
    player: THREE.Vector3,
    biomeAt: (x: number, z: number) => string,
    isNight: boolean
  ) {
    this.spawnClock += delta;
    if (this.spawnClock > 5.0 && this.agents.size < this.maxAgents) {
      this.spawnClock = 0;
      this.spawnAround(player, biomeAt, isNight);
    }

    for (const [id, a] of this.agents) {
      // 1. If agent is the tamed companion
      if (a.isTamed) {
        this.updateCompanionAgent(a, delta, player);
        continue;
      }

      const dx = a.group.position.x - player.x;
      const dz = a.group.position.z - player.z;
      const distance = Math.hypot(dx, dz);

      // Despawn far agents to conserve memory & CPU
      if (distance > 90) {
        this.scene.remove(a.group);
        this.disposeGroup(a.group);
        this.agents.delete(id);
        continue;
      }

      a.stateTimer -= delta;

      // Behavior state machine
      if (distance < 15 && a.species.temperament === 'shy' && a.state !== 'flee') {
        a.state = 'flee';
        a.stateTimer = 4.0;
        const normX = dx / (distance || 1);
        const normZ = dz / (distance || 1);
        a.target.set(
          a.group.position.x + normX * 32,
          a.group.position.y,
          a.group.position.z + normZ * 32
        );
      } else if (distance < 14 && a.species.temperament === 'territorial' && a.state !== 'chase') {
        a.state = 'chase';
        a.stateTimer = 5.0;
        a.target.set(player.x, player.y, player.z);
      } else if (a.stateTimer <= 0) {
        a.state = Math.random() < 0.2 ? 'rest' : 'roam';
        a.stateTimer = 3 + Math.random() * 6;
        const angle = Math.random() * Math.PI * 2;
        const radius = 10 + Math.random() * 22;
        a.target.set(
          a.group.position.x + Math.cos(angle) * radius,
          a.group.position.y,
          a.group.position.z + Math.sin(angle) * radius
        );
      }

      // Movement locomotion
      if (a.state !== 'rest') {
        if (a.state === 'chase') {
          a.target.set(player.x, player.y, player.z);
        }
        const direction = new THREE.Vector3(
          a.target.x - a.group.position.x,
          0,
          a.target.z - a.group.position.z
        );
        const distToTarget = direction.length();

        if (distToTarget > 0.3) {
          direction.normalize();
          const mult = a.state === 'flee' ? 1.7 : a.state === 'chase' ? 1.3 : 1.0;
          a.group.position.addScaledVector(direction, a.species.speed * delta * mult);

          // Smooth turn toward movement direction
          const targetRot = Math.atan2(direction.x, direction.z);
          a.group.rotation.y = THREE.MathUtils.damp(a.group.rotation.y, targetRot, 8, delta);
        }
      }

      // Elevation alignment
      if (a.species.kind === 'bird') {
        // Flying kinematics
        const flightAltitude = 7 + Math.sin(performance.now() * 0.0015 + a.group.position.x * 0.1) * 3;
        const ground = getTerrainHeight(a.group.position.x, a.group.position.z, this.seed);
        a.group.position.y = Math.max(ground + 3, ground + flightAltitude);
        // Wing flapping bank roll
        a.group.rotation.z = Math.sin(performance.now() * 0.008) * 0.12;
      } else if (a.species.kind === 'aquatic') {
        // Swims in water surface or shelf
        const ground = getTerrainHeight(a.group.position.x, a.group.position.z, this.seed);
        a.group.position.y = Math.min(-0.3, ground + 0.4);
        a.group.rotation.z = Math.sin(performance.now() * 0.004 + a.group.position.z) * 0.08;
      } else if (a.species.kind === 'insect') {
        const ground = getTerrainHeight(a.group.position.x, a.group.position.z, this.seed);
        a.group.position.y = ground + 0.8 + Math.sin(performance.now() * 0.004 + a.group.position.x) * 0.35;
      } else {
        // Terrestrial (quadrupeds & bipedal theropods)
        const ground = getTerrainHeight(a.group.position.x, a.group.position.z, this.seed);
        a.group.position.y = ground;

        // Limb walk cycle
        const isMoving = a.state !== 'rest';
        this.animateLimbs(a.group, a.species, isMoving, delta);
      }
    }
  }

  private updateCompanionAgent(a: WildlifeAgent, delta: number, player: THREE.Vector3) {
    const dx = player.x - a.group.position.x;
    const dz = player.z - a.group.position.z;
    const distToPlayer = Math.hypot(dx, dz);

    if (this.companionState && this.companionState.state === 'stay') {
      a.state = 'companion_stay';
    } else {
      a.state = 'companion_follow';
    }

    if (a.state === 'companion_follow') {
      // Teleport if player traveled too far (e.g. driving buggy across map)
      if (distToPlayer > 85) {
        a.group.position.set(player.x - 3, player.y, player.z - 3);
      } else if (distToPlayer > 3.2) {
        const dir = new THREE.Vector3(dx, 0, dz).normalize();
        const speed = a.species.speed * (distToPlayer > 8 ? 1.8 : 1.15);
        a.group.position.addScaledVector(dir, speed * delta);
        a.group.rotation.y = THREE.MathUtils.damp(a.group.rotation.y, Math.atan2(dir.x, dir.z), 10, delta);
      }
    }

    const ground = getTerrainHeight(a.group.position.x, a.group.position.z, this.seed);
    a.group.position.y = ground;
    this.animateLimbs(a.group, a.species, distToPlayer > 3.2, delta);
  }

  private animateLimbs(group: THREE.Group, species: WildlifeSpecies, isMoving: boolean, _delta: number) {
    const legL = group.getObjectByName('leg_left');
    const legR = group.getObjectByName('leg_right');
    const tail = group.getObjectByName('tail');

    if (legL && legR) {
      if (isMoving) {
        const cycle = Math.sin(performance.now() * 0.012 * (species.speed / 4));
        legL.rotation.x = cycle * 0.6;
        legR.rotation.x = -cycle * 0.6;
      } else {
        legL.rotation.x = 0;
        legR.rotation.x = 0;
      }
    }

    if (tail) {
      tail.rotation.y = Math.sin(performance.now() * 0.005) * 0.15;
    }
  }

  public getNearestCreature(playerPos: THREE.Vector3, maxDist: number = 4.0): WildlifeAgent | null {
    let nearest: WildlifeAgent | null = null;
    let minDist = maxDist;

    for (const a of this.agents.values()) {
      const d = Math.hypot(
        a.group.position.x - playerPos.x,
        a.group.position.z - playerPos.z
      );
      if (d < minDist) {
        minDist = d;
        nearest = a;
      }
    }
    return nearest;
  }

  public tameCreature(agentId: string): CompanionState | null {
    const agent = this.agents.get(agentId);
    if (!agent) return null;

    agent.isTamed = true;
    agent.state = 'companion_follow';
    this.companionAgentId = agent.id;

    // Attach gold companion ring halo
    const ringGeo = new THREE.TorusGeometry(0.5 * agent.species.scale, 0.05, 8, 18);
    ringGeo.rotateX(Math.PI / 2);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0xffd700 });
    const halo = new THREE.Mesh(ringGeo, ringMat);
    halo.position.set(0, 1.8 * agent.species.scale, 0);
    agent.group.add(halo);

    const comp: CompanionState = {
      speciesId: agent.species.id,
      name: `Loyal ${agent.species.name}`,
      kind: agent.species.kind === 'dinosaur' ? 'dinosaur' : agent.species.kind === 'bird' ? 'bird' : 'mammal',
      health: agent.health,
      maxHealth: agent.maxHealth,
      state: 'follow',
      isMounted: false,
    };
    this.companionState = comp;
    return comp;
  }

  public setCompanionOrder(order: 'follow' | 'stay' | 'defend') {
    if (this.companionState) {
      this.companionState.state = order;
    }
  }

  private spawnAround(player: THREE.Vector3, biomeAt: (x: number, z: number) => string, isNight: boolean) {
    const angle = Math.random() * Math.PI * 2;
    const radius = 28 + Math.random() * 70;
    const x = player.x + Math.cos(angle) * radius;
    const z = player.z + Math.sin(angle) * radius;
    const biome = biomeAt(x, z);

    let pool = WILDLIFE_SPECIES.filter((s) => s.biomes.includes(biome));
    if (isNight) {
      pool = pool.filter((s) => !['parrot', 'duck', 'butterfly'].includes(s.id));
    }
    if (!pool.length) {
      pool = WILDLIFE_SPECIES.filter((s) => s.kind === 'mammal' || s.kind === 'dinosaur');
    }

    const species = pool[Math.floor(Math.random() * pool.length)];
    const id = `wild_${species.id}_${Math.floor(x)}_${Math.floor(z)}`;
    if (this.agents.has(id)) return;

    const group = this.createCreature(species);
    const altitude = species.kind === 'bird' ? 8 : species.kind === 'insect' ? 1.2 : 0;
    group.position.set(x, getTerrainHeight(x, z, this.seed) + altitude, z);
    this.scene.add(group);

    this.agents.set(id, {
      id,
      species,
      group,
      velocity: new THREE.Vector3(),
      target: new THREE.Vector3(x, group.position.y, z),
      state: 'roam',
      stateTimer: 2 + Math.random() * 5,
      health: species.kind === 'dinosaur' ? 300 : 100,
      maxHealth: species.kind === 'dinosaur' ? 300 : 100,
    });
  }

  // Realistic Procedural Composite Models
  private createCreature(s: WildlifeSpecies): THREE.Group {
    const g = new THREE.Group();
    g.name = `wildlife_${s.id}`;
    g.scale.setScalar(s.scale);

    const mainMat = new THREE.MeshStandardMaterial({
      color: s.color,
      roughness: s.kind === 'aquatic' ? 0.3 : 0.82,
      metalness: s.kind === 'aquatic' ? 0.2 : 0.05,
    });
    const darkMat = new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.8 });
    const hornMat = new THREE.MeshStandardMaterial({ color: 0xd4cfc1, roughness: 0.6 });
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0xffcc00 });

    if (s.id === 'trex') {
      // T-REX: Towering apex theropod
      const body = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.4, 2.4), mainMat);
      body.position.set(0, 1.9, 0);
      body.rotation.x = -0.15;
      body.castShadow = true;
      g.add(body);

      // Skull with massive toothy jaws
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.95, 1.6), mainMat);
      head.position.set(0, 2.7, 1.6);
      head.castShadow = true;
      const lowerJaw = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.35, 1.4), darkMat);
      lowerJaw.position.set(0, 2.2, 1.6);
      g.add(head, lowerJaw);

      // Teeth
      for (let i = -0.5; i <= 0.5; i += 0.25) {
        const tooth = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.14, 4), hornMat);
        tooth.rotation.x = Math.PI;
        tooth.position.set(i < 0 ? -0.36 : 0.36, 2.4, 1.3 + Math.abs(i) * 0.4);
        g.add(tooth);
      }

      // Hind legs (Bipedal)
      const legGeo = new THREE.BoxGeometry(0.38, 1.8, 0.5);
      const legL = new THREE.Mesh(legGeo, mainMat);
      legL.name = 'leg_left';
      legL.position.set(-0.65, 0.9, 0);
      legL.castShadow = true;
      const legR = new THREE.Mesh(legGeo, mainMat);
      legR.name = 'leg_right';
      legR.position.set(0.65, 0.9, 0);
      legR.castShadow = true;
      g.add(legL, legR);

      // Tiny Arms
      const armGeo = new THREE.BoxGeometry(0.12, 0.45, 0.12);
      const armL = new THREE.Mesh(armGeo, mainMat);
      armL.position.set(-0.55, 1.8, 1.1);
      const armR = new THREE.Mesh(armGeo, mainMat);
      armR.position.set(0.55, 1.8, 1.1);
      g.add(armL, armR);

      // Massive Counterbalance Tail
      const tail = new THREE.Mesh(new THREE.ConeGeometry(0.45, 2.8, 6), mainMat);
      tail.name = 'tail';
      tail.rotation.x = -Math.PI / 2 + 0.1;
      tail.position.set(0, 1.7, -2.4);
      g.add(tail);

    } else if (s.id === 'triceratops') {
      // TRICERATOPS: Bony neck frill & 3 horns
      const body = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.3, 2.5), mainMat);
      body.position.set(0, 1.1, 0);
      body.castShadow = true;
      g.add(body);

      // Neck Shield Frill
      const frill = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.1, 0.18, 12), mainMat);
      frill.rotation.x = Math.PI / 3;
      frill.position.set(0, 1.7, 1.2);
      g.add(frill);

      // Head with Beak
      const head = new THREE.Mesh(new THREE.ConeGeometry(0.55, 1.2, 6), mainMat);
      head.rotation.x = Math.PI / 2;
      head.position.set(0, 1.1, 1.8);
      g.add(head);

      // Three Horns
      const horn1 = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.8, 6), hornMat);
      horn1.rotation.x = Math.PI / 4;
      horn1.position.set(-0.35, 1.8, 1.7);
      const horn2 = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.8, 6), hornMat);
      horn2.rotation.x = Math.PI / 4;
      horn2.position.set(0.35, 1.8, 1.7);
      const nasalHorn = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.45, 5), hornMat);
      nasalHorn.rotation.x = Math.PI / 5;
      nasalHorn.position.set(0, 1.3, 2.3);
      g.add(horn1, horn2, nasalHorn);

      // 4 Heavy Legs
      const legGeo = new THREE.CylinderGeometry(0.24, 0.28, 0.9, 8);
      for (const [x, z] of [[-0.7, 0.8], [0.7, 0.8], [-0.7, -0.8], [0.7, -0.8]]) {
        const leg = new THREE.Mesh(legGeo, darkMat);
        leg.position.set(x, 0.45, z);
        leg.castShadow = true;
        g.add(leg);
      }

    } else if (s.id === 'raptor') {
      // VELOCIRAPTOR: Agile pack hunter with sickle toe claws
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.65, 1.4), mainMat);
      body.position.set(0, 1.1, 0);
      body.castShadow = true;
      g.add(body);

      const head = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.4, 0.8), mainMat);
      head.position.set(0, 1.45, 0.9);
      g.add(head);

      // Sickle claw legs
      const legGeo = new THREE.BoxGeometry(0.16, 0.95, 0.22);
      const legL = new THREE.Mesh(legGeo, darkMat);
      legL.name = 'leg_left';
      legL.position.set(-0.3, 0.5, 0);
      const legR = new THREE.Mesh(legGeo, darkMat);
      legR.name = 'leg_right';
      legR.position.set(0.3, 0.5, 0);
      g.add(legL, legR);

      // Stiff Balance Tail
      const tail = new THREE.Mesh(new THREE.ConeGeometry(0.18, 1.8, 5), mainMat);
      tail.name = 'tail';
      tail.rotation.x = -Math.PI / 2;
      tail.position.set(0, 1.1, -1.6);
      g.add(tail);

    } else if (s.id === 'stegosaurus') {
      // STEGOSAURUS: Dorsal plates and spiked thagomizer
      const body = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.2, 2.6), mainMat);
      body.position.set(0, 1.1, 0);
      g.add(body);

      // Spine Plates (Double staggered row)
      for (let i = -1.0; i <= 1.0; i += 0.4) {
        const plate = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.65, 0.45), hornMat);
        plate.position.set(i % 0.8 === 0 ? 0.2 : -0.2, 1.9, i);
        plate.rotation.y = 0.2;
        g.add(plate);
      }

      // Thagomizer Tail Spikes
      const tail = new THREE.Mesh(new THREE.ConeGeometry(0.35, 1.8, 6), mainMat);
      tail.name = 'tail';
      tail.rotation.x = -Math.PI / 2;
      tail.position.set(0, 1.0, -2.1);
      for (const [sx, sz] of [[-0.3, -2.8], [0.3, -2.8], [-0.3, -2.5], [0.3, -2.5]]) {
        const spike = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.55, 4), hornMat);
        spike.rotation.z = sx < 0 ? -Math.PI / 3 : Math.PI / 3;
        spike.position.set(sx, 1.0, sz);
        g.add(spike);
      }
      g.add(tail);

      // Legs
      const legGeo = new THREE.CylinderGeometry(0.2, 0.25, 0.8, 7);
      for (const [x, z] of [[-0.6, 0.7], [0.6, 0.7], [-0.6, -0.7], [0.6, -0.7]]) {
        const leg = new THREE.Mesh(legGeo, darkMat);
        leg.position.set(x, 0.4, z);
        g.add(leg);
      }

    } else if (s.id === 'longneck') {
      // BRACHIOSAURUS: Soaring neck and colossal pillar legs
      const body = new THREE.Mesh(new THREE.BoxGeometry(2.0, 1.8, 3.4), mainMat);
      body.position.set(0, 2.2, 0);
      g.add(body);

      // Soaring arching neck
      const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.65, 4.5, 8), mainMat);
      neck.rotation.x = 0.35;
      neck.position.set(0, 4.6, 2.0);
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.45, 8, 8), mainMat);
      head.position.set(0, 6.7, 2.9);
      g.add(neck, head);

      // 4 Pillar Legs
      const pillarGeo = new THREE.CylinderGeometry(0.35, 0.42, 1.8, 8);
      for (const [x, z] of [[-0.9, 1.1], [0.9, 1.1], [-0.9, -1.1], [0.9, -1.1]]) {
        const leg = new THREE.Mesh(pillarGeo, darkMat);
        leg.position.set(x, 0.9, z);
        g.add(leg);
      }

    } else if (s.kind === 'bird') {
      // BIRDS: Aerodynamic torso, wings, beak, tail
      const body = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.85, 7), mainMat);
      body.rotation.x = Math.PI / 2;
      body.position.set(0, 0.5, 0);
      g.add(body);

      const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 7), mainMat);
      head.position.set(0, 0.6, 0.45);
      const beak = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.35, 4), hornMat);
      beak.rotation.x = Math.PI / 2;
      beak.position.set(0, 0.58, 0.68);
      g.add(head, beak);

      // Wide Wings
      const wingGeo = new THREE.BoxGeometry(1.4, 0.04, 0.5);
      const wingL = new THREE.Mesh(wingGeo, mainMat);
      wingL.position.set(-0.8, 0.58, 0);
      wingL.rotation.z = -0.15;
      const wingR = new THREE.Mesh(wingGeo, mainMat);
      wingR.position.set(0.8, 0.58, 0);
      wingR.rotation.z = 0.15;
      g.add(wingL, wingR);

    } else if (s.kind === 'aquatic') {
      // AQUATIC: Sleek swimming body with dorsal fin
      const body = new THREE.Mesh(new THREE.SphereGeometry(0.6, 10, 8), mainMat);
      body.scale.set(0.65, 0.55, 1.8);
      body.position.set(0, 0.5, 0);
      g.add(body);

      // Distinctive Dorsal Fin (Cuts water surface)
      const fin = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.6, 4), mainMat);
      fin.position.set(0, 0.9, 0.1);
      fin.rotation.x = -0.25;
      g.add(fin);

      // Tail Fluke
      const fluke = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.04, 0.35), mainMat);
      fluke.position.set(0, 0.5, -1.6);
      g.add(fluke);

    } else {
      // Standard Quadrupeds (Wolf, Bear, Deer, Horse, Lion, etc.)
      const body = new THREE.Mesh(new THREE.SphereGeometry(0.65, 12, 8), mainMat);
      body.scale.set(0.85, 0.7, 1.4);
      body.position.y = 0.85;
      body.castShadow = true;
      g.add(body);

      const head = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.45, 0.6), mainMat);
      head.position.set(0, 1.25, 0.8);
      head.castShadow = true;
      g.add(head);

      // Snout
      const muzzle = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.25, 0.4), darkMat);
      muzzle.position.set(0, 1.15, 1.15);
      g.add(muzzle);

      // Antlers if deer
      if (s.id === 'deer') {
        for (const sx of [-0.22, 0.22]) {
          const antler = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 0.65, 5), hornMat);
          antler.position.set(sx, 1.7, 0.7);
          antler.rotation.z = sx < 0 ? -0.35 : 0.35;
          g.add(antler);
        }
      }

      // 4 Sturdy Legs
      const legGeo = new THREE.CylinderGeometry(0.1, 0.12, 0.75, 7);
      const legL = new THREE.Mesh(legGeo, darkMat);
      legL.name = 'leg_left';
      legL.position.set(-0.35, 0.38, 0.35);
      const legR = new THREE.Mesh(legGeo, darkMat);
      legR.name = 'leg_right';
      legR.position.set(0.35, 0.38, 0.35);
      const legBL = new THREE.Mesh(legGeo, darkMat);
      legBL.position.set(-0.35, 0.38, -0.45);
      const legBR = new THREE.Mesh(legGeo, darkMat);
      legBR.position.set(0.35, 0.38, -0.45);
      g.add(legL, legR, legBL, legBR);

      // Tail
      const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.08, 0.55, 6), mainMat);
      tail.name = 'tail';
      tail.rotation.x = -0.4;
      tail.position.set(0, 0.9, -0.9);
      g.add(tail);
    }

    return g;
  }

  private disposeGroup(g: THREE.Group) {
    g.traverse((o) => {
      if (o instanceof THREE.Mesh) {
        o.geometry.dispose();
        if (Array.isArray(o.material)) o.material.forEach((m) => m.dispose());
        else o.material.dispose();
      }
    });
  }

  public get count() {
    return this.agents.size;
  }

  public dispose() {
    for (const a of this.agents.values()) {
      this.scene.remove(a.group);
      this.disposeGroup(a.group);
    }
    this.agents.clear();
  }
}
