import * as THREE from 'three';
import { GameEngine } from '../GameEngine';
import { TownLifeManager } from './TownLifeManager';
import { StoryCompanionManager } from './StoryCompanionManager';
import { MeteoriteImpactManager } from './MeteoriteImpactManager';
import { InfectionOutbreakManager } from './InfectionOutbreakManager';
import { ShelterManager } from './ShelterManager';
import { CinematicCameraManager } from './CinematicCameraManager';
import { ProloguePhase, PrologueSubtitle, PrologueSaveData } from '../../types/prologue';
import { soundEngine } from '../../utils/audio';
import { getTerrainHeight } from '../Terrain';

export interface PrologueCallbacks {
  onSubtitleChange: (subtitle: PrologueSubtitle | null) => void;
  onPhaseChange: (phase: ProloguePhase) => void;
  onTitleBanner: (banner: { title: string; subtitle: string; day: string } | null) => void;
  onObjectiveUpdate: (objective: string | null) => void;
}

export class PrologueManager {
  public engine: GameEngine;
  public phase: ProloguePhase = 'intro_cinematic';
  public isCompleted: boolean = false;
  public callbacks: PrologueCallbacks;

  // Sub-managers
  public townMgr: TownLifeManager;
  public companionMgr: StoryCompanionManager;
  public meteorMgr: MeteoriteImpactManager;
  public outbreakMgr: InfectionOutbreakManager;
  public shelterMgr: ShelterManager;
  public cinematicCam: CinematicCameraManager;

  // Timers & State Flags
  private phaseTimer: number = 0;
  private dialogueStep: number = 0;
  private currentSubtitle: PrologueSubtitle | null = null;
  private currentSubtitleTimer: number = 0;

  // Story Tracking across 13 Chapters
  public chapter: number = 1;
  public day: number = 1;
  public friendsMet = { marcus: false, chloe: false, maya: false };
  public apartmentInspected = { phone: false, fridge: false, window: false };
  public cityTasks = { market: false, cafe: false, park: false };
  public baseTasks = {
    generator: false,
    medical: false,
    gate: false,
    storage: false,
    friendsTalked: 0,
  };

  // Base Compound Positions (Starter Base at 0, 0)
  public readonly baseCompoundCenter = new THREE.Vector3(0, 0, 0);
  public readonly baseGatePos = new THREE.Vector3(0, 0, 12);

  constructor(engine: GameEngine, callbacks: PrologueCallbacks, initialData?: PrologueSaveData) {
    this.engine = engine;
    this.callbacks = callbacks;

    // Instantiate sub-managers
    this.townMgr = new TownLifeManager(engine.scene);
    this.companionMgr = new StoryCompanionManager(engine.scene);
    this.meteorMgr = new MeteoriteImpactManager(engine.scene);
    this.outbreakMgr = new InfectionOutbreakManager(engine.zombieMgr, this.townMgr);
    this.shelterMgr = new ShelterManager(engine.scene);
    this.cinematicCam = new CinematicCameraManager(engine.camera);

    if (initialData && initialData.isCompleted) {
      this.restoreCompletedState(initialData);
    } else if (initialData && initialData.chapter) {
      this.restoreChapterState(initialData);
    } else {
      this.initNewPrologue();
    }
  }

  private initNewPrologue() {
    this.chapter = 1;
    this.phase = 'ch1_apartment_morning';
    this.isCompleted = false;
    this.day = 1;
    this.engine.gameTimeMinutes = 420; // 07:00 AM sunny morning
    this.engine.dayCount = 1;

    // Optimize chunk radius during urban chapter
    this.engine.chunkManager.setStreamingRadius(1);

    // Position player cleanly inside bedroom of modern apartment complex (-26, 0, 38)
    const aptGround = Math.max(0.1, getTerrainHeight(-30, 41, this.engine.player.worldSeed));
    this.engine.player.position.set(-30, aptGround + 0.1, 41);
    this.engine.player.avatarGroup.position.copy(this.engine.player.position);
    this.engine.player.yaw = 0;

    // Establishing camera sweep of the city
    this.cinematicCam.playTrack('town_establishing', 6.0);
    this.callbacks.onTitleBanner({
      title: 'THE BEGINNING OF THE END',
      subtitle: 'CHAPTER 1: A NORMAL MORNING',
      day: 'DAY 1 — 07:00 AM',
    });
    this.setSubtitle({
      speaker: 'Narrator',
      text: 'Oakridge Valley. Day 1, 07:00 AM. A normal summer morning in the city.',
      duration: 5.5,
    });
    this.callbacks.onPhaseChange(this.phase);
    this.callbacks.onObjectiveUpdate('Mission: WAKE UP — Explore your apartment, inspect your phone, and grab breakfast');
  }

  public update(delta: number) {
    // Subtitle decay timer
    if (this.currentSubtitle) {
      this.currentSubtitleTimer -= delta;
      if (this.currentSubtitleTimer <= 0) {
        this.currentSubtitle = null;
        this.callbacks.onSubtitleChange(null);
      }
    }

    if (this.isCompleted) {
      this.shelterMgr.update(delta);
      return;
    }

    this.phaseTimer += delta;

    // Update Sub-Managers
    const isNight = this.engine.isNight;
    const isPanic = this.chapter >= 8 && this.chapter <= 10;
    this.townMgr.update(delta, isNight, isPanic);
    this.companionMgr.update(delta, this.engine.player.position, this.chapter === 10);
    this.shelterMgr.update(delta);

    // Meteor bolide update
    const { impactJustOccurred, screenShake } = this.meteorMgr.update(delta);
    if (screenShake > 0) {
      this.engine.player.shakeCamera(screenShake);
    }
    if (impactJustOccurred) {
      this.onMeteorImpacted();
    }

    if (this.outbreakMgr.isOutbreakActive) {
      this.outbreakMgr.update(delta, this.engine.player.position);
    }

    // Camera track update
    this.cinematicCam.update(delta);

    // --- State Machine across the 13 Story Chapters ---
    switch (this.phase) {
      case 'intro_cinematic':
      case 'ch1_apartment_morning':
        if (this.phaseTimer > 5.5 && this.dialogueStep === 0) {
          this.dialogueStep = 1;
          this.cinematicCam.playTrack('apartment_approach', 3.5);
        } else if (this.phaseTimer > 9.0 && this.dialogueStep === 1) {
          this.dialogueStep = 2;
          this.cinematicCam.endCinematic();
          this.callbacks.onTitleBanner(null);
          this.setSubtitle({
            speaker: 'Player',
            text: '7:00 AM already. Better check my phone and grab a bite before meeting the group.',
            duration: 4.5,
          });
        }
        break;

      case 'ch2_outside_apartment':
        // Heading towards cafe/town center
        const distToCenter = Math.hypot(this.engine.player.position.x - (-10), this.engine.player.position.z - 18);
        if (distToCenter < 6.0) {
          this.startChapter3();
        }
        break;

      case 'ch3_meet_friends':
        // Sequential 4-character reunion dialogue
        if (this.dialogueStep === 0 && this.phaseTimer > 0.5) {
          this.dialogueStep = 1;
          this.setSubtitle({
            speaker: 'Marcus Cole',
            role: 'The Leader',
            text: 'Finally! I thought you were going to be late again.',
            duration: 4.0,
          });
        } else if (this.dialogueStep === 1 && this.phaseTimer > 4.5) {
          this.dialogueStep = 2;
          this.setSubtitle({
            speaker: 'Player',
            text: 'Traffic was terrible.',
            duration: 3.5,
          });
        } else if (this.dialogueStep === 2 && this.phaseTimer > 8.0) {
          this.dialogueStep = 3;
          this.setSubtitle({
            speaker: 'Chloe Miller',
            role: 'The Technician',
            text: 'So, what is the plan today?',
            duration: 3.5,
          });
        } else if (this.dialogueStep === 3 && this.phaseTimer > 11.5) {
          this.dialogueStep = 4;
          this.setSubtitle({
            speaker: 'Dr. Maya Lin',
            role: 'The Medic',
            text: 'Can we just enjoy one normal day?',
            duration: 3.5,
          });
        } else if (this.dialogueStep === 4 && this.phaseTimer > 15.0) {
          this.startChapter4();
        }
        break;

      case 'ch4_city_alive':
        // Tour progression: advance to evening when tasks or 25s elapsed
        if (this.phaseTimer > 25.0 || (this.cityTasks.market && this.cityTasks.cafe)) {
          this.startChapter5();
        }
        break;

      case 'ch5_return_home':
        // Evening return home to sleep
        const dHomeApt = Math.hypot(this.engine.player.position.x - (-26), this.engine.player.position.z - 38);
        if (dHomeApt < 4.0) {
          this.callbacks.onObjectiveUpdate('Mission: GET SOME REST — Interact with your bed [E] to sleep for Day 2');
        }
        break;

      case 'ch6_something_is_coming':
        if (this.phaseTimer > 2.0 && this.dialogueStep === 0) {
          this.dialogueStep = 1;
          soundEngine.playRadioStatic(2.0);
          this.setSubtitle({
            speaker: 'Phone Notification',
            text: 'Marcus: "Are you watching the news? Strange atmospheric readings detected outside the city."',
            duration: 4.5,
          });
        } else if (this.phaseTimer > 7.0 && this.dialogueStep === 1) {
          this.dialogueStep = 2;
          this.setSubtitle({
            speaker: 'Chloe Miller',
            role: 'The Technician',
            text: 'Something strange is happening outside the city. My shortwave radio is going crazy.',
            duration: 4.5,
          });
          this.callbacks.onObjectiveUpdate('Mission: A NEW MORNING — Step outside your apartment to investigate');
        }
        break;

      case 'ch7_the_meteorite':
        if (this.dialogueStep === 0 && this.phaseTimer > 1.5) {
          this.dialogueStep = 1;
          this.cinematicCam.playTrack('sky_observation', 5.0);
          this.meteorMgr.launchMeteorFlight();
          this.setSubtitle({
            speaker: 'Marcus Cole',
            role: 'The Leader',
            text: 'Look at the sky! Something is entering the atmosphere right above the valley!',
            duration: 4.5,
          });
        } else if (this.dialogueStep === 1 && this.phaseTimer > 4.5) {
          this.dialogueStep = 2;
          this.cinematicCam.playTrack('meteor_track', 4.5);
        }
        break;

      case 'ch8_first_infection':
        if (this.phaseTimer > 6.0) {
          this.startChapter9();
        }
        break;

      case 'ch9_find_friends':
        // Friends regrouping dialogue
        if (this.dialogueStep === 0 && this.phaseTimer > 0.5) {
          this.dialogueStep = 1;
          this.setSubtitle({
            speaker: 'Marcus Cole',
            role: 'The Leader',
            text: 'We can’t stay here.',
            duration: 3.5,
          });
        } else if (this.dialogueStep === 1 && this.phaseTimer > 4.0) {
          this.dialogueStep = 2;
          this.setSubtitle({
            speaker: 'Chloe Miller',
            role: 'The Technician',
            text: 'The main roads are blocked.',
            duration: 3.5,
          });
        } else if (this.dialogueStep === 2 && this.phaseTimer > 7.5) {
          this.dialogueStep = 3;
          this.setSubtitle({
            speaker: 'Dr. Maya Lin',
            role: 'The Medic',
            text: 'We need supplies. We need somewhere safe.',
            duration: 3.5,
          });
        } else if (this.dialogueStep === 3 && this.phaseTimer > 11.0) {
          this.dialogueStep = 4;
          this.setSubtitle({
            speaker: 'Player',
            text: 'Then we leave together.',
            duration: 3.5,
          });
        } else if (this.dialogueStep === 4 && this.phaseTimer > 14.5) {
          this.startChapter10();
        }
        break;

      case 'ch10_the_escape':
        // Physical escape route towards the Starter Base Compound at (0, 0)
        const dToBaseGate = Math.hypot(
          this.engine.player.position.x - this.baseGatePos.x,
          this.engine.player.position.z - this.baseGatePos.z
        );
        if (dToBaseGate < 8.0) {
          this.startChapter11();
        }
        break;

      case 'ch11_starter_base':
        // Arrived at the industrial compound Starter Base
        if (this.dialogueStep === 0 && this.phaseTimer > 1.0) {
          this.dialogueStep = 1;
          this.setSubtitle({
            speaker: 'Marcus Cole',
            role: 'The Leader',
            text: 'This place might actually work.',
            duration: 3.5,
          });
        } else if (this.dialogueStep === 1 && this.phaseTimer > 4.5) {
          this.dialogueStep = 2;
          this.setSubtitle({
            speaker: 'Chloe Miller',
            role: 'The Technician',
            text: 'The generator needs attention.',
            duration: 3.5,
          });
        } else if (this.dialogueStep === 2 && this.phaseTimer > 8.0) {
          this.dialogueStep = 3;
          this.setSubtitle({
            speaker: 'Dr. Maya Lin',
            role: 'The Medic',
            text: 'We need medical supplies and clean water.',
            duration: 3.5,
          });
        } else if (this.dialogueStep === 3 && this.phaseTimer > 11.5) {
          this.dialogueStep = 4;
          this.setSubtitle({
            speaker: 'Player',
            text: 'Then let’s make this our home.',
            duration: 3.5,
          });
        } else if (this.dialogueStep === 4 && this.phaseTimer > 15.0) {
          this.startChapter12();
        }
        break;

      case 'ch12_establish_base':
        // Checking base establishment tasks
        if (
          this.baseTasks.generator &&
          this.baseTasks.storage &&
          this.baseTasks.medical &&
          this.baseTasks.gate
        ) {
          this.startChapter13();
        }
        break;

      case 'ch13_the_world_awaits':
        if (this.dialogueStep === 0 && this.phaseTimer > 1.5) {
          this.dialogueStep = 1;
          this.cinematicCam.playTrack('open_world_reveal', 12.0);
          soundEngine.playDawnVictoryChime();
          this.callbacks.onTitleBanner({
            title: 'LAST SANCTUARY: REBIRTH',
            subtitle: 'THE WORLD ENDED. OUR STORY BEGINS.',
            day: 'OPEN WORLD UNLOCKED',
          });
          this.setSubtitle({
            speaker: 'Narrator',
            text: 'The world as we knew it ended. But right here, from this sanctuary, our survival story begins.',
            duration: 7.0,
          });
        } else if (this.dialogueStep === 1 && this.phaseTimer > 11.0) {
          this.dialogueStep = 2;
          this.callbacks.onTitleBanner(null);
          this.completeCampaign();
        }
        break;
    }
  }

  // --- Chapter Transition Methods ---

  public startChapter2() {
    this.chapter = 2;
    this.setPhase('ch2_outside_apartment');
    const outPos = new THREE.Vector3(-26, 0.1, 29);
    this.engine.player.position.copy(outPos);
    this.engine.player.avatarGroup.position.copy(outPos);
    this.engine.player.yaw = Math.PI;

    this.callbacks.onTitleBanner({
      title: 'CHAPTER 2: OUTSIDE THE APARTMENT',
      subtitle: 'A LIVELY MORNING',
      day: 'DAY 1 — 08:30 AM',
    });
    setTimeout(() => this.callbacks.onTitleBanner(null), 4000);

    this.setSubtitle({
      speaker: 'Player',
      text: 'Fresh air. The city is already buzzing. I should head down Main Avenue to meet the group.',
      duration: 4.5,
    });
    this.callbacks.onObjectiveUpdate('Mission: STEP OUTSIDE — Explore the neighbourhood and meet Marcus, Chloe, and Maya');
  }

  public startChapter3() {
    this.chapter = 3;
    this.setPhase('ch3_meet_friends');
    this.friendsMet.marcus = true;
    this.friendsMet.chloe = true;
    this.friendsMet.maya = true;
    this.companionMgr.setAllFollowing(true);

    this.callbacks.onTitleBanner({
      title: 'CHAPTER 3: THREE FRIENDS',
      subtitle: 'THE CREW REUNITED',
      day: 'DAY 1 — 09:30 AM',
    });
    setTimeout(() => this.callbacks.onTitleBanner(null), 3500);
  }

  public startChapter4() {
    this.chapter = 4;
    this.setPhase('ch4_city_alive');
    this.callbacks.onTitleBanner({
      title: 'CHAPTER 4: THE CITY IS ALIVE',
      subtitle: 'EXPLORE OAKRIDGE',
      day: 'DAY 1 — 10:30 AM',
    });
    setTimeout(() => this.callbacks.onTitleBanner(null), 3500);
    this.setSubtitle({
      speaker: 'Marcus Cole',
      role: 'The Leader',
      text: 'Let’s check in on Mr. Henderson at the market and grab fresh coffee from Sam at the cafe.',
      duration: 4.5,
    });
    this.callbacks.onObjectiveUpdate('Mission: EXPLORE THE CITY — Visit the market, cafe, and central park with your friends');
  }

  public startChapter5() {
    this.chapter = 5;
    this.setPhase('ch5_return_home');
    this.engine.gameTimeMinutes = 1170; // 07:30 PM sunset

    this.callbacks.onTitleBanner({
      title: 'CHAPTER 5: THE LAST NORMAL NIGHT',
      subtitle: 'GOLDEN HOUR RETREAT',
      day: 'DAY 1 — 07:30 PM',
    });
    setTimeout(() => this.callbacks.onTitleBanner(null), 3500);

    this.setSubtitle({
      speaker: 'Marcus Cole',
      role: 'The Leader',
      text: 'Good day today. Get some rest tonight, we have that ridge hike tomorrow.',
      duration: 4.5,
    });
    this.callbacks.onObjectiveUpdate('Mission: RETURN HOME — Head back to your apartment to rest before tomorrow');
  }

  public sleepToDay2() {
    this.chapter = 6;
    this.day = 2;
    this.engine.dayCount = 2;
    this.engine.gameTimeMinutes = 480; // 08:00 AM
    this.setPhase('ch6_something_is_coming');

    // Bed rest audio and banner
    soundEngine.playDawnVictoryChime();
    this.callbacks.onTitleBanner({
      title: 'DAY 1 COMPLETED',
      subtitle: 'THE LAST NORMAL NIGHT HAS ENDED',
      day: 'DAY 2 — 08:00 AM',
    });
    setTimeout(() => this.callbacks.onTitleBanner(null), 4000);

    // Reposition player in bedroom waking up
    const aptGround = Math.max(0.1, getTerrainHeight(-30, 41, this.engine.player.worldSeed));
    this.engine.player.position.set(-30, aptGround + 0.1, 41);
    this.engine.player.avatarGroup.position.copy(this.engine.player.position);
    this.engine.player.yaw = 0;
  }

  public onMeteorImpacted() {
    this.chapter = 8;
    this.setPhase('ch8_first_infection');
    this.cinematicCam.playTrack('impact_view', 5.0);

    this.callbacks.onTitleBanner({
      title: 'CHAPTER 8: FIRST SIGNS OF INFECTION',
      subtitle: 'OUTBREAK IN SECTOR 4',
      day: 'DAY 2 — 08:20 AM',
    });
    setTimeout(() => this.callbacks.onTitleBanner(null), 4000);

    soundEngine.playRadioStatic(2.5);
    this.setSubtitle({
      speaker: 'Emergency Broadcast',
      text: 'WARNING: High-energy atmospheric impact detected. Civilian evacuation advised.',
      duration: 5.0,
    });

    this.outbreakMgr.triggerOutbreak(this.meteorMgr.craterCenter);
    this.callbacks.onObjectiveUpdate('Mission: INVESTIGATE THE CHAOS — Panic is spreading. Regroup with your friends at the crossroads!');
  }

  public startChapter9() {
    this.chapter = 9;
    this.setPhase('ch9_find_friends');
    this.cinematicCam.endCinematic();

    // Position friends meeting player at crossroads
    const px = this.engine.player.position.x;
    const pz = this.engine.player.position.z;
    this.companionMgr.teleportTo('marcus', [px + 2.0, 0, pz + 2.0], Math.PI);
    this.companionMgr.teleportTo('chloe', [px - 2.0, 0, pz + 2.0], Math.PI);
    this.companionMgr.teleportTo('maya', [px, 0, pz + 3.2], Math.PI);
    this.companionMgr.setAllFollowing(true);

    this.callbacks.onTitleBanner({
      title: 'CHAPTER 9: REGROUP',
      subtitle: 'WE LEAVE TOGETHER',
      day: 'DAY 2 — 08:30 AM',
    });
    setTimeout(() => this.callbacks.onTitleBanner(null), 3500);
  }

  public startChapter10() {
    this.chapter = 10;
    this.setPhase('ch10_the_escape');
    this.callbacks.onTitleBanner({
      title: 'CHAPTER 10: THE ESCAPE',
      subtitle: 'ESCAPE THE CITY',
      day: 'DAY 2 — 08:45 AM',
    });
    setTimeout(() => this.callbacks.onTitleBanner(null), 3500);

    this.setSubtitle({
      speaker: 'Marcus Cole',
      role: 'The Leader',
      text: 'Stay close! Follow the valley road north toward the old industrial compound on the outskirts!',
      duration: 5.0,
    });
    this.callbacks.onObjectiveUpdate('Mission: GET OUT OF THE CITY — Follow the valley road to the industrial compound on the outskirts!');
  }

  public startChapter11() {
    this.chapter = 11;
    this.setPhase('ch11_starter_base');
    this.callbacks.onTitleBanner({
      title: 'CHAPTER 11: THE STARTER BASE',
      subtitle: 'DISCOVERING OUR HAVEN',
      day: 'DAY 2 — 09:15 AM',
    });
    setTimeout(() => this.callbacks.onTitleBanner(null), 3500);

    // Station friends inside the starter compound courtyard
    this.companionMgr.teleportTo('marcus', [1.5, 0, 4.0], Math.PI);
    this.companionMgr.teleportTo('chloe', [-2.0, 0, 0.5], 0);
    this.companionMgr.teleportTo('maya', [-2.4, 0, -2.6], 0);
    this.companionMgr.setAllFollowing(false);
  }

  public startChapter12() {
    this.chapter = 12;
    this.setPhase('ch12_establish_base');
    this.callbacks.onTitleBanner({
      title: 'CHAPTER 12: BUILD A NEW BEGINNING',
      subtitle: 'ESTABLISHING THE HAVEN',
      day: 'DAY 2 — 09:30 AM',
    });
    setTimeout(() => this.callbacks.onTitleBanner(null), 3500);

    this.setSubtitle({
      speaker: 'Player',
      text: 'Let’s check the generator, open the storage crates, inspect the medical post, and secure the perimeter.',
      duration: 5.0,
    });
    this.callbacks.onObjectiveUpdate('Mission: ESTABLISH YOUR BASE — Inspect the generator, storage crates, medical corner, and secure the gate');
  }

  public startChapter13() {
    this.chapter = 13;
    this.setPhase('ch13_the_world_awaits');
    this.setSubtitle({
      speaker: 'Marcus Cole',
      role: 'The Leader',
      text: 'Take a look outside. This is our sanctuary now... but the world out there has changed.',
      duration: 4.5,
    });
    this.callbacks.onObjectiveUpdate('Mission: SURVIVE — Walk through the main gate to reveal the open world');
  }

  public completeCampaign() {
    this.isCompleted = true;
    this.phase = 'completed';
    this.cinematicCam.endCinematic();
    this.callbacks.onPhaseChange('completed');
    this.callbacks.onSubtitleChange(null);
    this.callbacks.onTitleBanner(null);

    // Restore full chunk streaming for open-world exploration
    this.engine.chunkManager.setStreamingRadius(null);

    // Station companions permanently in the base
    this.companionMgr.teleportTo('marcus', [0, 0, 11], Math.PI); // Guarding main gate
    this.companionMgr.teleportTo('chloe', [-2.4, 0, -2.6], 0);   // At workbench / generator
    this.companionMgr.teleportTo('maya', [2.2, 0, -2.6], 0);     // At notice board / medical
    this.companionMgr.setAllFollowing(false);

    // Ensure crater is physically present in the world
    this.meteorMgr.spawnPhysicalCrater();

    // Starter survival reward kit
    this.engine.callbacks.onItemCollected('canned_beans', 4);
    this.engine.callbacks.onItemCollected('clean_water', 4);
    this.engine.callbacks.onItemCollected('bandage', 3);
    this.engine.callbacks.onItemCollected('builder_hammer', 1);

    // Activate Chapter 1 open world quest
    this.engine.quests = [
      {
        id: 'main_survival_story',
        chapter: 1,
        title: 'The Road Ahead: Rebirth',
        description: 'You and your three friends have survived the meteorite impact and founded your sanctuary. Fortify the compound, scavenge the valley for resources, and defend against the nightly zombie hordes.',
        completed: false,
        rewards: {
          xp: 500,
          items: [
            { itemId: 'builder_hammer', count: 1 },
            { itemId: 'nails_bolts', count: 24 },
          ],
        },
        objectives: [
          {
            id: 'talk_to_marcus',
            description: 'Talk to Marcus [E] at the main gate to coordinate defense',
            current: 0,
            target: 1,
            completed: false,
          },
          {
            id: 'harvest_resources',
            description: 'Harvest wood and stone with your tools',
            current: 0,
            target: 20,
            completed: false,
          },
          {
            id: 'survive_night_one',
            description: 'Defend the sanctuary compound against the blood moon horde at night',
            current: 0,
            target: 1,
            completed: false,
          },
        ],
      },
    ];
    this.engine.callbacks.onQuestsUpdate(this.engine.quests);
    this.callbacks.onObjectiveUpdate('Discover what happened. Find survivors. Build a future.');
    this.engine.triggerAutoSave();
  }

  public skipPrologue() {
    this.completeCampaign();
  }

  // --- Interaction Router called by GameEngine ---

  public getInteractionPrompt(pos: THREE.Vector3): string | null {
    if (this.isCompleted) return null;

    // 1. Apartment Interactions (Chapters 1, 5, 6)
    if (this.chapter === 1 || this.chapter === 5 || this.chapter === 6) {
      const apt = this.townMgr.getApartmentInteraction(pos);
      if (apt) return apt.prompt;
    }

    // 2. Base Establishment Interactions (Chapter 12)
    if (this.chapter === 12) {
      // Generator
      if (Math.hypot(pos.x - 0, pos.z - (-4)) < 2.5 && !this.baseTasks.generator) {
        return 'Press [E] to Inspect & Repair Generator with Chloe';
      }
      // Medical
      if (Math.hypot(pos.x - (-2.4), pos.z - (-2.6)) < 2.5 && !this.baseTasks.medical) {
        return 'Press [E] to Inspect Medical First Aid Post with Dr. Maya';
      }
      // Gate
      if (Math.hypot(pos.x - 0, pos.z - 12) < 3.0 && !this.baseTasks.gate) {
        return 'Press [E] to Inspect Fortified Gate Security with Marcus';
      }
      // Cabin Storage Chest
      if (Math.hypot(pos.x - 1.8, pos.z - (-7.5)) < 2.8 && !this.baseTasks.storage) {
        return 'Press [E] to Organize Compound Storage Chest';
      }
    }

    // 3. Companion Dialogue Prompt
    const friend = this.companionMgr.getNearestCompanion(pos, 3.5);
    if (friend) {
      return `Press [E] to Talk to ${friend.name} (${friend.role})`;
    }

    // 4. Citizen Conversation Prompt
    const citizen = this.townMgr.getNearestCitizen(pos, 3.5);
    if (citizen) {
      return `Press [E] to Talk to ${citizen.name} (${citizen.role})`;
    }

    return null;
  }

  public handleInteraction(pos: THREE.Vector3): boolean {
    if (this.isCompleted) return false;

    // 1. Apartment Interactions
    if (this.chapter === 1 || this.chapter === 5 || this.chapter === 6) {
      const apt = this.townMgr.getApartmentInteraction(pos);
      if (apt) {
        if (apt.id === 'phone') {
          soundEngine.playUIClick();
          this.apartmentInspected.phone = true;
          this.setSubtitle({
            speaker: 'Smartphone',
            text: 'Marcus: "Hey! Don’t sleep in. Chloe and Maya are meeting us at Corner Roast Cafe at 9."',
            duration: 4.5,
          });
          return true;
        } else if (apt.id === 'fridge') {
          soundEngine.playBuildSnap();
          this.apartmentInspected.fridge = true;
          this.engine.playerStats.hunger = Math.min(100, this.engine.playerStats.hunger + 30);
          this.engine.playerStats.thirst = Math.min(100, this.engine.playerStats.thirst + 30);
          this.engine.callbacks.onStatsChange({ ...this.engine.playerStats });
          this.setSubtitle({
            speaker: 'Player',
            text: 'Fresh orange juice and a breakfast sandwich. Best start to a Saturday.',
            duration: 4.0,
          });
          return true;
        } else if (apt.id === 'window') {
          soundEngine.playPeacefulChirp();
          this.apartmentInspected.window = true;
          this.setSubtitle({
            speaker: 'Player',
            text: 'Blue skies and morning cars. The neighbourhood is looking lively today.',
            duration: 4.0,
          });
          return true;
        } else if (apt.id === 'door') {
          soundEngine.playBuildSnap();
          if (this.chapter === 1) {
            this.startChapter2();
            return true;
          } else if (this.chapter === 6) {
            this.setPhase('ch7_the_meteorite');
            return true;
          }
        } else if (apt.id === 'bed') {
          if (this.chapter === 5) {
            this.sleepToDay2();
            return true;
          } else {
            this.setSubtitle({
              speaker: 'Player',
              text: 'I just woke up! No time for a nap right now.',
              duration: 3.0,
            });
            return true;
          }
        }
      }
    }

    // 2. Base Establishment Interactions (Chapter 12)
    if (this.chapter === 12) {
      if (Math.hypot(pos.x - 0, pos.z - (-4)) < 2.5 && !this.baseTasks.generator) {
        this.baseTasks.generator = true;
        soundEngine.playBuildSnap();
        this.setSubtitle({
          speaker: 'Chloe Miller',
          role: 'The Technician',
          text: 'Alternator connected and diesel primed! Main compound power is online!',
          duration: 4.5,
        });
        return true;
      }
      if (Math.hypot(pos.x - (-2.4), pos.z - (-2.6)) < 2.5 && !this.baseTasks.medical) {
        this.baseTasks.medical = true;
        soundEngine.playDawnVictoryChime();
        this.engine.playerStats.health = this.engine.playerStats.maxHealth;
        this.engine.callbacks.onStatsChange({ ...this.engine.playerStats });
        this.setSubtitle({
          speaker: 'Dr. Maya Lin',
          role: 'The Medic',
          text: 'Triage kit ready. Your vitals are stabilized and I have clean bandages stocked.',
          duration: 4.5,
        });
        return true;
      }
      if (Math.hypot(pos.x - 0, pos.z - 12) < 3.0 && !this.baseTasks.gate) {
        this.baseTasks.gate = true;
        soundEngine.playBuildSnap();
        this.setSubtitle({
          speaker: 'Marcus Cole',
          role: 'The Leader',
          text: 'Deadbolt and heavy crossbar engaged. This perimeter will hold.',
          duration: 4.5,
        });
        return true;
      }
      if (Math.hypot(pos.x - 1.8, pos.z - (-7.5)) < 2.8 && !this.baseTasks.storage) {
        this.baseTasks.storage = true;
        soundEngine.playBuildSnap();
        this.engine.callbacks.onItemCollected('stone_axe', 1);
        this.engine.callbacks.onItemCollected('stone_pickaxe', 1);
        this.engine.callbacks.onItemCollected('canned_beans', 2);
        this.setSubtitle({
          speaker: 'Player',
          text: 'Found axes, pickaxes, and non-perishable canned food in the crates.',
          duration: 4.0,
        });
        return true;
      }
    }

    // 3. Companion Dialogue Interaction
    const friend = this.companionMgr.getNearestCompanion(pos, 3.8);
    if (friend) {
      soundEngine.playUIClick();
      if (this.chapter === 4) {
        if (friend.id === 'marcus') {
          this.setSubtitle({
            speaker: 'Marcus Cole',
            role: 'The Leader',
            text: 'I love these quiet weekend strolls. Makes you appreciate how peaceful life is.',
            duration: 4.0,
          });
        } else if (friend.id === 'chloe') {
          this.setSubtitle({
            speaker: 'Chloe Miller',
            role: 'The Technician',
            text: 'Did you hear? The town council approved the new solar substation project!',
            duration: 4.0,
          });
        } else if (friend.id === 'maya') {
          this.setSubtitle({
            speaker: 'Dr. Maya Lin',
            role: 'The Medic',
            text: 'Clinic was peaceful this week. Hopefully it stays that way all summer.',
            duration: 4.0,
          });
        }
      } else {
        this.setSubtitle({
          speaker: friend.name,
          role: friend.role,
          text: `Standing by with you. Let’s stay focused on our group objectives.`,
          duration: 3.5,
        });
      }
      return true;
    }

    // 4. Citizen Conversation
    const citizen = this.townMgr.getNearestCitizen(pos, 3.5);
    if (citizen) {
      const line = citizen.dialogueLines[Math.floor(Math.random() * citizen.dialogueLines.length)];
      this.setSubtitle({
        speaker: citizen.name,
        role: citizen.role,
        text: line,
        duration: 4.5,
      });
      if (citizen.id === 'mr_henderson') this.cityTasks.market = true;
      if (citizen.id === 'barista_sam') this.cityTasks.cafe = true;
      if (citizen.id === 'officer_davis') this.cityTasks.park = true;
      return true;
    }

    return false;
  }

  private setPhase(newPhase: ProloguePhase) {
    this.phase = newPhase;
    this.phaseTimer = 0;
    this.dialogueStep = 0;
    this.callbacks.onPhaseChange(newPhase);
  }

  private setSubtitle(subtitle: PrologueSubtitle) {
    this.currentSubtitle = subtitle;
    this.currentSubtitleTimer = subtitle.duration || 4.0;
    this.callbacks.onSubtitleChange(subtitle);
    soundEngine.playDialogueBeep();
  }

  public restoreCompletedState(saveData: PrologueSaveData) {
    this.isCompleted = true;
    this.phase = 'completed';
    this.chapter = 13;
    this.day = saveData.day || 2;
    this.friendsMet = saveData.friendsMet || { marcus: true, chloe: true, maya: true };

    // Spawn crater
    this.meteorMgr.spawnPhysicalCrater();

    // Station companions permanently in the base compound
    this.companionMgr.teleportTo('marcus', [0, 0, 11], Math.PI);
    this.companionMgr.teleportTo('chloe', [-2.4, 0, -2.6], 0);
    this.companionMgr.teleportTo('maya', [2.2, 0, -2.6], 0);
  }

  public restoreChapterState(saveData: PrologueSaveData) {
    this.chapter = saveData.chapter || 1;
    this.phase = saveData.phase;
    this.day = saveData.day || 1;
    this.friendsMet = saveData.friendsMet || { marcus: false, chloe: false, maya: false };
    if (saveData.apartmentInspected) this.apartmentInspected = saveData.apartmentInspected;
    if (saveData.cityTasks) this.cityTasks = saveData.cityTasks;
    if (saveData.baseTasks) this.baseTasks = saveData.baseTasks;

    if (saveData.craterFormed) {
      this.meteorMgr.spawnPhysicalCrater();
    }
  }

  public exportSaveData(): PrologueSaveData {
    const companionsData: Record<string, { health: number; station: string; relationshipScore: number }> = {};
    this.companionMgr.companions.forEach((c, id) => {
      companionsData[id] = {
        health: c.health,
        station: c.station,
        relationshipScore: c.relationshipScore,
      };
    });

    return {
      phase: this.phase,
      isCompleted: this.isCompleted,
      chapter: this.chapter,
      day: this.day,
      craterFormed: this.meteorMgr.isImpacted,
      friendsMet: { ...this.friendsMet },
      shelterUnlocked: true,
      shelterDoorClosed: true,
      generatorOnline: this.baseTasks.generator,
      radioInspected: true,
      suppliesInspected: this.baseTasks.storage,
      apartmentInspected: { ...this.apartmentInspected },
      cityTasks: { ...this.cityTasks },
      baseTasks: { ...this.baseTasks },
      companions: companionsData,
    };
  }

  public dispose() {
    this.townMgr.dispose();
    this.companionMgr.dispose();
    this.meteorMgr.dispose();
    this.shelterMgr.dispose();
  }
}
