/** Lightweight procedural wildlife for the streamed survival world. */
import * as THREE from 'three';
import { BiomeType } from '../../types/game';
import { BiomeGenerator } from './BiomeGenerator';
import { UnifiedPhysicsManager } from '../physics/UnifiedPhysicsManager';

type WildlifeKind = 'deer' | 'rabbit' | 'fox' | 'wolf' | 'bear' | 'boar' | 'monkey' | 'parrot' | 'elephant' | 'zebra' | 'lion' | 'camel' | 'goat' | 'eagle' | 'crocodile' | 'turtle' | 'crab' | 'horse' | 'cow' | 'chicken' | 'panda' | 'dinosaur' | 'dolphin';
interface WildlifeAgent { group: THREE.Group; kind: WildlifeKind; direction: THREE.Vector3; speed: number; turnTimer: number; origin: THREE.Vector3; }

const SPECIES: Partial<Record<BiomeType, WildlifeKind[]>> = {
  dense_forest: ['deer', 'fox', 'rabbit', 'boar'], green_plains: ['deer', 'rabbit', 'fox'],
  abandoned_city: ['fox', 'rabbit'], small_village: ['chicken', 'cow', 'horse'], farmland: ['cow', 'horse', 'chicken'],
  industrial_zone: ['fox'], mountain_range: ['goat', 'eagle'], valley: ['deer', 'rabbit', 'fox'],
  river_basin: ['deer', 'turtle', 'crab'], lake_district: ['turtle'], coastline: ['crab', 'turtle'],
  island: ['crab', 'turtle', 'parrot'], desert: ['camel', 'fox'], snow_peaks: ['wolf', 'bear', 'goat'],
  wetlands: ['crocodile', 'turtle', 'crab'], cave_system: ['fox'], subway_tunnels: ['fox'],
  research_facility: ['fox'], tropical_jungle: ['monkey', 'parrot', 'boar'], savannah: ['elephant', 'zebra', 'lion'],
  taiga: ['wolf', 'bear', 'fox'], alpine_meadow: ['deer', 'fox', 'rabbit'], volcanic_wastes: ['goat'], tundra: ['wolf', 'bear', 'goat'],
  ancient_forest: ['deer', 'bear', 'boar'], bamboo_forest: ['panda', 'monkey'], dinosaur_valley: ['dinosaur'],
};

export class WildlifeManager {
  private readonly scene: THREE.Scene;
  private readonly seed: number;
  private readonly heightAt: (x: number, z: number) => number;
  private agents: WildlifeAgent[] = [];
  private spawnClock = 0;
  private randomState: number;
  private readonly maxAgents = 12;

  constructor(scene: THREE.Scene, seed: number, heightAt: (x: number, z: number) => number) {
    this.scene = scene; this.seed = seed; this.heightAt = heightAt; this.randomState = (seed ^ 0x5f3759df) >>> 0;
  }

  private disposeAgent(agent: WildlifeAgent) {
    this.scene.remove(agent.group);
    UnifiedPhysicsManager.getInstance()?.unregisterCollider(`wildlife_${agent.group.id}`);
    agent.group.traverse(o => { if (o instanceof THREE.Mesh) { o.geometry.dispose(); const m = o.material; if (Array.isArray(m)) m.forEach(x => x.dispose()); else m.dispose(); } });
  }

  private random() { this.randomState = (this.randomState * 1664525 + 1013904223) >>> 0; return this.randomState / 4294967296; }

  private makeAnimal(kind: WildlifeKind): THREE.Group {
    const root = new THREE.Group();
    const palette: Record<string, number> = { deer:0x95643b, rabbit:0xb9a58d, fox:0xc76b2b, wolf:0x777b80, bear:0x49372b, boar:0x665044, monkey:0x795337, parrot:0x24a66a, elephant:0x777a78, zebra:0xe4dfd2, lion:0xb58a42, camel:0xb99158, goat:0xd0c9b5, eagle:0x6d5540, crocodile:0x536b3d, turtle:0x47734b, crab:0xb94c36, horse:0x68442f, cow:0xe0ded5, chicken:0xc58b48, panda:0xe5e1d7, dinosaur:0x527044, dolphin:0x668eaa, bat:0x39333c };
    const color = palette[kind] ?? 0x8a806d;
    const material = new THREE.MeshStandardMaterial({ color, roughness: 0.88 });
    const dark = new THREE.MeshStandardMaterial({ color: kind === 'zebra' || kind === 'panda' ? 0x252525 : 0x302820, roughness: 0.9 });
    const bodyScale = kind === 'elephant' ? [1.05,0.78,1.45] : kind === 'dinosaur' ? [0.9,1.05,1.55] : kind === 'bear' || kind === 'lion' ? [0.75,0.72,1.05] : [0.52,0.48,0.85];
    const body = new THREE.Mesh(new THREE.SphereGeometry(1, 8, 6), material); body.scale.set(bodyScale[0], bodyScale[1], bodyScale[2]); body.position.y = bodyScale[1] + 0.42; body.castShadow = false; root.add(body);
    const head = new THREE.Mesh(new THREE.SphereGeometry(kind === 'elephant' ? 0.48 : 0.31, 8, 6), material); head.position.set(0, bodyScale[1] + 0.55, bodyScale[2] * 0.78); root.add(head);
    if (kind === 'elephant') { const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.09,0.13,0.72,6), material); trunk.position.set(0,0.55,1.65); trunk.rotation.x=-0.35; root.add(trunk); }
    if (kind === 'dinosaur') { const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.2,0.3,0.8,6), material); neck.position.set(0,1.25,0.95); neck.rotation.x=-0.55; root.add(neck); const tail = new THREE.Mesh(new THREE.ConeGeometry(0.28,1.15,6), material); tail.position.set(0,0.75,-1.45); tail.rotation.x=-Math.PI/2; root.add(tail); }
    if (kind === 'deer' || kind === 'goat') { for (const side of [-1,1]) { const horn = new THREE.Mesh(new THREE.ConeGeometry(0.055,0.62,5), dark); horn.position.set(side*0.2, bodyScale[1]+1.0, bodyScale[2]*0.8); horn.rotation.z=side*0.22; root.add(horn); } }
    if (kind === 'zebra') { for (let i=0;i<4;i++){ const stripe=new THREE.Mesh(new THREE.BoxGeometry(0.035,0.58,0.9),dark); stripe.position.set(-0.34+i*0.22,0.82,0); root.add(stripe); } }
    if (kind === 'panda') { for (const side of [-1,1]) { const patch=new THREE.Mesh(new THREE.SphereGeometry(0.11,6,5),dark); patch.position.set(side*0.19,bodyScale[1]+0.58,bodyScale[2]*0.98); root.add(patch); } }
    // Four simple legs keep the model inexpensive while giving it a recognizable silhouette.
    if (!['dolphin','crab','parrot','eagle','turtle'].includes(kind)) {
      for (const x of [-0.27,0.27]) for (const z of [-0.48,0.48]) { const leg=new THREE.Mesh(new THREE.CylinderGeometry(0.075,0.09,0.48,5),material); leg.position.set(x,0.28,z); root.add(leg); }
    }
    if (kind === 'parrot' || kind === 'eagle') {
      const wingGeo = new THREE.BoxGeometry(0.85,0.07,0.32);
      for (const side of [-1,1]) { const wing=new THREE.Mesh(wingGeo,material); wing.position.set(side*0.48,0.65,0); wing.rotation.z=side*0.25; root.add(wing); }
    }
    if (kind === 'dolphin') { const fin=new THREE.Mesh(new THREE.ConeGeometry(0.22,0.65,5),material); fin.position.y=0.65; root.add(fin); }
    root.scale.setScalar(kind === 'elephant' || kind === 'dinosaur' ? 1.45 : kind === 'bear' ? 1.2 : kind === 'rabbit' || kind === 'chicken' || kind === 'crab' ? 0.55 : 0.85);
    root.traverse(o => { if (o instanceof THREE.Mesh) o.frustumCulled = true; });
    return root;
  }

  private spawnAround(player: THREE.Vector3) {
    if (this.agents.length >= this.maxAgents) return;
    const angle = this.random() * Math.PI * 2;
    const radius = 28 + this.random() * 48;
    const x = player.x + Math.cos(angle) * radius;
    const z = player.z + Math.sin(angle) * radius;
    const biome = BiomeGenerator.getBiomeAt(x, z, this.seed);
    const species = SPECIES[biome.id] ?? ['deer', 'rabbit'];
    const kind = species[Math.floor(this.random() * species.length)];
    const group = this.makeAnimal(kind);
    group.position.set(x, this.heightAt(x,z), z);
    group.rotation.y = this.random() * Math.PI * 2;
    this.scene.add(group);
    const radiusCollider = kind === 'dinosaur' ? 1.8 : kind === 'elephant' ? 1.5 : kind === 'bear' ? 0.9 : 0.55;
    const heightCollider = kind === 'dinosaur' ? 3.0 : kind === 'elephant' ? 2.6 : 1.6;
    UnifiedPhysicsManager.getInstance()?.registerCylinderCollider(`wildlife_${group.id}`, kind === 'dinosaur' ? 'dinosaur' : 'wildlife', group.position, radiusCollider, heightCollider);

    const direction = new THREE.Vector3(Math.cos(group.rotation.y),0,Math.sin(group.rotation.y));
    this.agents.push({ group, kind, direction, speed: 0.7 + this.random()*1.1, turnTimer: 1 + this.random()*4, origin: group.position.clone() });
  }

  update(delta: number, player: THREE.Vector3) {
    this.spawnClock += delta;
    if (this.spawnClock >= 3.2) { this.spawnClock = 0; if (this.random() > 0.18) this.spawnAround(player); }
    for (let i=this.agents.length-1;i>=0;i--) {
      const a=this.agents[i];
      const distance=a.group.position.distanceTo(player);
      if (distance > 115) { this.disposeAgent(a); this.agents.splice(i,1); continue; }
      a.turnTimer -= delta;
      if (a.turnTimer <= 0 || a.group.position.distanceTo(a.origin) > 22) {
        const angle=this.random()*Math.PI*2; a.direction.set(Math.cos(angle),0,Math.sin(angle)); a.turnTimer=2+this.random()*5;
      }
      // Wildlife keeps a generous buffer around the player and wanders rather than attacking.
      const flee = distance < 9 && !['turtle','dolphin'].includes(a.kind);
      const move = flee ? new THREE.Vector3().subVectors(a.group.position,player).setY(0).normalize() : a.direction;
      a.group.position.addScaledVector(move, a.speed * (flee ? 2.4 : 1) * delta);
      a.group.position.y=this.heightAt(a.group.position.x,a.group.position.z);
      a.group.rotation.y=Math.atan2(move.x,move.z);
      const bob=Math.sin((this.spawnClock + i)*5)*0.025;
      a.group.position.y += bob;
      UnifiedPhysicsManager.getInstance()?.updateColliderPosition(`wildlife_${a.group.id}`, a.group.position, a.group.rotation.y);
    }
  }

  dispose() { for (const a of this.agents) this.disposeAgent(a); this.agents=[]; }
}
