export type ProloguePhase =
  // The Beginning of the End: 13 Chapters
  | 'intro_cinematic'          // Aerial establishing shot of peaceful city
  | 'ch1_apartment_morning'    // Chapter 1: Day 1 07:00 AM, Wake Up, inspect apartment
  | 'ch2_outside_apartment'    // Chapter 2: Step Outside, explore neighbourhood
  | 'ch3_meet_friends'         // Chapter 3: Meet Marcus, Chloe, Maya at cafe
  | 'ch4_city_alive'           // Chapter 4: Peaceful city exploration (market, cafe, park)
  | 'ch5_return_home'          // Chapter 5: Sunset, return to apartment, sleep in bed (Day 1 Complete)
  | 'ch6_something_is_coming'  // Chapter 6: Day 2 08:00 AM, emergency news, friend messages
  | 'ch7_the_meteorite'        // Chapter 7: Real-time meteorite entry & crater impact
  | 'ch8_first_infection'      // Chapter 8: Sirens, panic, first infected emergence
  | 'ch9_find_friends'         // Chapter 9: Regroup with 3 friends at crossroads
  | 'ch10_the_escape'          // Chapter 10: Playable escape along valley road
  | 'ch11_starter_base'        // Chapter 11: Discover abandoned industrial compound Starter Base
  | 'ch12_establish_base'      // Chapter 12: Generator, medical corner, gate security, storage
  | 'ch13_the_world_awaits'    // Chapter 13: Epic cinematic open-world reveal
  // Legacy phase aliases for save compatibility
  | 'day1_town_explore'
  | 'day1_friends_gathered'
  | 'night1_peaceful'
  | 'day2_morning'
  | 'day2_meteorite_cinematic'
  | 'day2_impact_aftermath'
  | 'day2_first_infection'
  | 'day2_escape_sequence'
  | 'day2_shelter_arrival'
  | 'day2_final_cinematic'
  | 'completed';                // Full survival sandbox unlocked

export interface StoryChapter {
  number: number;
  title: string;
  subtitle: string;
  objective: string;
}

export interface StoryCompanion {
  id: 'marcus' | 'chloe' | 'maya';
  name: string;
  title: string;
  role: 'Leader' | 'Technician' | 'Medic';
  color: number;
  jacketColor: number;
  pantColor: number;
  hairColor: number;
  position: [number, number, number];
  rotationY: number;
  health: number;
  maxHealth: number;
  dialogueState: number;
  isFollowing: boolean;
  station: 'follow' | 'town' | 'shelter_guard' | 'shelter_tech' | 'shelter_med';
  relationshipScore: number;
}

export interface TownCitizen {
  id: string;
  name: string;
  role: string;
  buildingType: string;
  position: [number, number, number];
  rotationY: number;
  shirtColor: number;
  pantColor: number;
  schedule: 'walk' | 'stand' | 'shop' | 'flee' | 'cower' | 'infected';
  patrolPoints?: [number, number][];
  dialogueLines: string[];
  isInfected?: boolean;
  infectionStage?: 'normal' | 'exposed' | 'symptoms' | 'zombie';
}

export interface PrologueSubtitle {
  speaker: string;
  text: string;
  role?: string;
  portraitColor?: string;
  duration?: number;
}

export interface PrologueSaveData {
  phase: ProloguePhase;
  isCompleted: boolean;
  day: number;
  chapter?: number;
  craterFormed: boolean;
  friendsMet: {
    marcus: boolean;
    chloe: boolean;
    maya: boolean;
  };
  shelterUnlocked: boolean;
  shelterDoorClosed: boolean;
  generatorOnline: boolean;
  radioInspected: boolean;
  suppliesInspected: boolean;
  apartmentInspected?: {
    phone: boolean;
    fridge: boolean;
    window: boolean;
  };
  cityTasks?: {
    market: boolean;
    cafe: boolean;
    park: boolean;
  };
  baseTasks?: {
    generator: boolean;
    medical: boolean;
    gate: boolean;
    storage: boolean;
    friendsTalked: number;
  };
  companions: Record<string, {
    health: number;
    station: string;
    relationshipScore: number;
  }>;
}
