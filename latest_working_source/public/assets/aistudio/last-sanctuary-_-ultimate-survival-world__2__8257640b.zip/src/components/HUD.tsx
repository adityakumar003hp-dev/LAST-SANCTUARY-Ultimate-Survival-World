import React from 'react';
import { 
  Heart, 
  Zap, 
  Apple, 
  Droplet, 
  Shield, 
  Sun, 
  Moon, 
  Compass, 
  Hammer, 
  Package, 
  User, 
  Map as MapIcon, 
  BookOpen, 
  Eye, 
  Flashlight,
  Terminal,
  Navigation
} from 'lucide-react';
import { PlayerStats, InventorySlot, Quest } from '../types/game';

interface HUDProps {
  stats: PlayerStats;
  timeMinutes: number;
  dayCount: number;
  isNight: boolean;
  isDusk: boolean;
  interactionPrompt: string | null;
  hotbar: (InventorySlot | null)[];
  selectedIndex: number;
  onSelectSlot: (index: number) => void;
  activeQuest: Quest | null;
  cameraView: 'first' | 'third' | 'second';
  isFlashlightOn: boolean;
  biomeName?: string;
  playerPos?: [number, number, number];
  onOpenBuild: () => void;
  onOpenInventory: () => void;
  onOpenCharacter: () => void;
  onOpenMap: () => void;
  onOpenJournal: () => void;
  onOpenBaseDashboard?: () => void;
  onToggleCamera: () => void;
  onZoomCamera?: (delta: number) => void;
  onToggleFlashlight: () => void;
  onOpenPause: () => void;
  companion?: import('../types/game').CompanionState | null;
  onToggleCompanionOrder?: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  stats,
  timeMinutes,
  dayCount,
  isNight,
  isDusk,
  interactionPrompt,
  hotbar,
  selectedIndex,
  onSelectSlot,
  activeQuest,
  cameraView,
  isFlashlightOn,
  biomeName = 'Sanctuary Valley',
  playerPos = [0, 0, 0],
  onOpenBuild,
  onOpenInventory,
  onOpenCharacter,
  onOpenMap,
  onOpenJournal,
  onOpenBaseDashboard,
  onToggleCamera,
  onZoomCamera,
  onToggleFlashlight,
  companion,
  onToggleCompanionOrder,
}) => {
  const hours = Math.floor(timeMinutes / 60);
  const mins = Math.floor(timeMinutes % 60);
  const timeStr = `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`;

  const firstIncompleteObj = activeQuest?.objectives.find((o) => !o.completed);

  return (
    <div className="pointer-events-none absolute inset-0 select-none overflow-hidden font-sans">
      {/* --- Top Left: Survivor Vital Status Bars (Responsive) --- */}
      <div className="absolute top-3 left-3 sm:top-4 sm:left-4 flex flex-col gap-1.5 sm:gap-2 rounded-xl bg-neutral-950/85 p-2.5 sm:p-3.5 shadow-2xl backdrop-blur-md border border-neutral-800/80 w-44 sm:w-60 z-20">
        {/* Health */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          <Heart className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-rose-500 fill-rose-500/30 shrink-0" />
          <div className="relative h-2.5 sm:h-3 w-full overflow-hidden rounded-full bg-neutral-900 border border-neutral-700/50">
            <div
              className="h-full rounded-full bg-gradient-to-r from-red-600 to-rose-500 transition-all duration-300"
              style={{ width: `${Math.max(0, Math.min(100, (stats.health / stats.maxHealth) * 100))}%` }}
            />
          </div>
          <span className="w-8 sm:w-10 text-right text-[10px] sm:text-xs font-mono font-bold text-rose-400">
            {Math.round(stats.health)}
          </span>
        </div>

        {/* Stamina */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          <Zap className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-amber-400 fill-amber-400/30 shrink-0" />
          <div className="relative h-2 sm:h-2.5 w-full overflow-hidden rounded-full bg-neutral-900 border border-neutral-700/50">
            <div
              className="h-full rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 transition-all duration-150"
              style={{ width: `${Math.max(0, Math.min(100, (stats.stamina / stats.maxStamina) * 100))}%` }}
            />
          </div>
          <span className="w-8 sm:w-10 text-right text-[10px] sm:text-xs font-mono font-bold text-amber-300">
            {Math.round(stats.stamina)}
          </span>
        </div>

        {/* Hunger & Thirst Split */}
        <div className="grid grid-cols-2 gap-1.5 sm:gap-2 pt-1 border-t border-neutral-800">
          <div className="flex items-center gap-1">
            <Apple className="h-3 w-3 sm:h-3.5 sm:w-3.5 text-orange-400 shrink-0" />
            <div className="h-1.5 sm:h-2 w-full overflow-hidden rounded-full bg-neutral-900 border border-neutral-700/40">
              <div
                className="h-full bg-orange-500 transition-all duration-300"
                style={{ width: `${Math.max(0, Math.min(100, stats.hunger))}%` }}
              />
            </div>
            <span className="text-[9px] sm:text-[10px] font-mono text-neutral-300">{Math.round(stats.hunger)}%</span>
          </div>

          <div className="flex items-center gap-1">
            <Droplet className="h-3 w-3 sm:h-3.5 sm:w-3.5 text-sky-400 shrink-0" />
            <div className="h-1.5 sm:h-2 w-full overflow-hidden rounded-full bg-neutral-900 border border-neutral-700/40">
              <div
                className="h-full bg-sky-500 transition-all duration-300"
                style={{ width: `${Math.max(0, Math.min(100, stats.thirst))}%` }}
              />
            </div>
            <span className="text-[9px] sm:text-[10px] font-mono text-neutral-300">{Math.round(stats.thirst)}%</span>
          </div>
        </div>

        {/* Oxygen Gauge (Visible when swimming/submerged or recovering) */}
        {(stats.isSwimming || (stats.oxygen !== undefined && stats.oxygen < 98)) && (
          <div className="flex items-center gap-1.5 pt-1 border-t border-neutral-800 animate-in fade-in">
            <Droplet className="h-3 w-3 text-cyan-400 fill-cyan-400/50 shrink-0" />
            <div className="h-1.5 sm:h-2 w-full overflow-hidden rounded-full bg-neutral-900 border border-cyan-800/60">
              <div
                className={`h-full transition-all duration-150 ${
                  (stats.oxygen || 0) < 25 ? 'bg-rose-500 animate-pulse' : 'bg-cyan-400'
                }`}
                style={{ width: `${Math.max(0, Math.min(100, stats.oxygen ?? 100))}%` }}
              />
            </div>
            <span className="text-[9px] sm:text-[10px] font-mono text-cyan-300 font-bold shrink-0">
              {Math.round(stats.oxygen ?? 100)}% O₂
            </span>
          </div>
        )}

        {/* Level & XP */}
        <div className="flex items-center justify-between pt-1 text-[10px] sm:text-[11px] text-neutral-400 border-t border-neutral-800">
          <span className="font-semibold text-emerald-400">LVL {stats.level}</span>
          <span className="font-mono text-neutral-400">XP {stats.xp}/{stats.xpToNextLevel}</span>
        </div>
      </div>

      {/* --- Tamed Companion Card (When player has a pet/mount) --- */}
      {companion && (
        <div className="absolute top-44 sm:top-50 left-3 sm:left-4 flex items-center justify-between gap-3 rounded-xl bg-neutral-950/85 px-3 py-2 shadow-xl backdrop-blur-md border border-amber-500/40 w-44 sm:w-60 z-20 pointer-events-auto">
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <Shield className="h-3.5 w-3.5 text-amber-400" />
              <span className="text-xs font-bold text-amber-300 truncate max-w-[95px] sm:max-w-[120px]">
                {companion.name}
              </span>
            </div>
            <span className="text-[9px] text-neutral-400 font-mono capitalize">
              Role: {companion.state} · HP: {Math.round(companion.health)}/{companion.maxHealth}
            </span>
          </div>
          <button
            onClick={onToggleCompanionOrder}
            className="px-2 py-1 bg-amber-500/20 hover:bg-amber-500/40 border border-amber-400/50 rounded-lg text-[9px] font-bold text-amber-300 uppercase tracking-wider cursor-pointer active:scale-95 transition-all"
          >
            {companion.state === 'follow' ? 'STAY' : 'FOLLOW'}
          </button>
        </div>
      )}

      {/* --- Top Right: Time, Day, & Cycle Clock (Responsive) --- */}
      <div className="absolute top-3 right-3 sm:top-4 sm:right-4 flex items-center gap-2 sm:gap-3 rounded-xl bg-neutral-950/85 p-2.5 sm:p-3 shadow-2xl backdrop-blur-md border border-neutral-800/80 z-20">
        <div className="flex items-center gap-1.5 sm:gap-2 pr-2 sm:pr-3 border-r border-neutral-800">
          {isNight ? (
            <Moon className="h-4 w-4 sm:h-5 sm:w-5 text-rose-500" />
          ) : isDusk ? (
            <Sun className="h-4 w-4 sm:h-5 sm:w-5 text-amber-500" />
          ) : (
            <Sun className="h-4 w-4 sm:h-5 sm:w-5 text-yellow-400" />
          )}
          <div className="flex flex-col">
            <span className="text-xs sm:text-sm font-bold tracking-wider text-neutral-100 font-mono">
              {timeStr}
            </span>
            <span className="text-[9px] sm:text-[10px] uppercase font-semibold text-neutral-400">
              DAY {dayCount} {isNight ? '• BLOOD MOON' : isDusk ? '• DUSK' : '• DAYLIGHT'}
            </span>
          </div>
        </div>

        {/* Biome & Coordinates */}
        <div className="flex flex-col items-end text-[10px] sm:text-xs">
          <span className="font-semibold text-amber-400 truncate max-w-[90px] sm:max-w-[120px]">{biomeName}</span>
          <span className="font-mono text-[9px] sm:text-[10px] text-neutral-400">
            {Math.round(playerPos[0])}, {Math.round(playerPos[2])}
          </span>
        </div>
      </div>

      {/* --- Top Center: Active Quest Tracker --- */}
      {activeQuest && firstIncompleteObj && (
        <div className="absolute top-16 sm:top-4 left-1/2 -translate-x-1/2 flex flex-col items-center rounded-xl bg-neutral-950/85 px-3 py-1.5 sm:px-4 sm:py-2 border border-neutral-800/80 shadow-xl backdrop-blur-md max-w-[280px] sm:max-w-md text-center z-10">
          <div className="flex items-center gap-1 text-[10px] sm:text-xs font-bold text-amber-400 uppercase tracking-wider">
            <Compass className="h-3 w-3 sm:h-3.5 sm:w-3.5" />
            <span className="truncate">{activeQuest.title}</span>
          </div>
          <div className="text-xs sm:text-sm text-neutral-200 font-medium mt-0.5 line-clamp-1">
            {firstIncompleteObj.description}
          </div>
          <div className="text-[10px] sm:text-xs font-mono text-amber-300/90 mt-0.5">
            Progress: {firstIncompleteObj.current} / {firstIncompleteObj.target}
          </div>
        </div>
      )}

      {/* --- Center: Reticle & Contextual Interaction Prompt --- */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="relative flex items-center justify-center">
          <div className="h-1.5 w-1.5 rounded-full bg-white/70" />
          <div className="absolute -top-3 h-2 w-[1px] bg-white/40" />
          <div className="absolute -bottom-3 h-2 w-[1px] bg-white/40" />
          <div className="absolute -left-3 w-2 h-[1px] bg-white/40" />
          <div className="absolute -right-3 w-2 h-[1px] bg-white/40" />
        </div>

        {interactionPrompt && (
          <div className="absolute mt-14 sm:mt-16 rounded-lg bg-neutral-950/90 px-3 py-1 text-xs font-semibold text-neutral-100 shadow-xl border border-neutral-700/80 tracking-wide backdrop-blur-sm max-w-[90vw] text-center">
            {interactionPrompt}
          </div>
        )}
      </div>

      {/* --- Bottom Center: Hotbar & Desktop Control Dock --- */}
      <div className="absolute bottom-3 sm:bottom-4 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 pointer-events-auto z-25 max-w-[95vw]">
        {/* Quick Desktop Action Buttons (Hidden on smaller screens since MobileControls has top shortcut bar) */}
        <div className="hidden lg:flex items-center gap-1.5 rounded-xl bg-neutral-950/80 px-3 py-1.5 border border-neutral-800/80 backdrop-blur-md shadow-lg text-neutral-300 text-xs">
          <button
            onClick={onOpenBuild}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer text-amber-400 font-medium"
            title="Open Building Catalog [B]"
          >
            <Hammer className="h-3.5 w-3.5" />
            <span>Build [B]</span>
          </button>
          <div className="h-3 w-[1px] bg-neutral-800" />

          <button
            onClick={onOpenInventory}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer text-neutral-200"
            title="Open Inventory [I]"
          >
            <Package className="h-3.5 w-3.5" />
            <span>Bag [I]</span>
          </button>
          <div className="h-3 w-[1px] bg-neutral-800" />

          <button
            onClick={onOpenCharacter}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer text-neutral-200"
            title="Character RPG Stats [C]"
          >
            <User className="h-3.5 w-3.5" />
            <span>Stats [C]</span>
          </button>
          <div className="h-3 w-[1px] bg-neutral-800" />

          <button
            onClick={onOpenMap}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer text-neutral-200"
            title="Map & Radar [M]"
          >
            <MapIcon className="h-3.5 w-3.5" />
            <span>Map [M]</span>
          </button>
          <div className="h-3 w-[1px] bg-neutral-800" />

          <button
            onClick={onOpenJournal}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer text-neutral-200"
            title="Quest Journal [J]"
          >
            <BookOpen className="h-3.5 w-3.5" />
            <span>Journal [J]</span>
          </button>
          <div className="h-3 w-[1px] bg-neutral-800" />

          <button
            onClick={onToggleCamera}
            className="flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer text-neutral-200"
            title="Cycle Camera View [V]"
          >
            <Eye className="h-3.5 w-3.5" />
            <span>{cameraView === 'first' ? '1st' : cameraView === 'third' ? '3rd' : '2nd'} [V]</span>
          </button>

          <button onClick={() => onZoomCamera?.(-0.6)} className="flex items-center justify-center rounded-lg px-1.5 py-1 hover:bg-neutral-800 text-neutral-300" title="Zoom in (+)">+</button>
          <button onClick={() => onZoomCamera?.(0.6)} className="flex items-center justify-center rounded-lg px-1.5 py-1 hover:bg-neutral-800 text-neutral-300" title="Zoom out (-)">−</button>

          <button
            onClick={onToggleFlashlight}
            className={`flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer ${
              isFlashlightOn ? 'text-yellow-400 bg-neutral-800/80' : 'text-neutral-400'
            }`}
            title="Flashlight [F]"
          >
            <Flashlight className="h-3.5 w-3.5" />
            <span>[F]</span>
          </button>

          {onOpenBaseDashboard && (
            <>
              <div className="h-3 w-[1px] bg-neutral-800" />
              <button
                onClick={onOpenBaseDashboard}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer text-cyan-400 font-medium"
                title="Sanctuary Base Dashboard [O]"
              >
                <Terminal className="h-3.5 w-3.5" />
                <span>Base [O]</span>
              </button>
            </>
          )}
        </div>

        {/* 8-Slot Hotbar (Scaled for all mobile screens) */}
        <div className="flex items-center gap-1 sm:gap-1.5 rounded-2xl bg-neutral-950/90 p-1.5 sm:p-2 border border-neutral-800/90 shadow-2xl backdrop-blur-md overflow-x-auto max-w-[94vw]">
          {hotbar.slice(0, 8).map((slot, idx) => {
            const isSelected = selectedIndex === idx;
            return (
              <button
                key={idx}
                onClick={() => onSelectSlot(idx)}
                className={`relative flex h-11 w-11 sm:h-14 sm:w-14 shrink-0 flex-col items-center justify-center rounded-xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'border-amber-400 bg-amber-500/25 shadow-lg shadow-amber-500/20 scale-105'
                    : 'border-neutral-800 bg-neutral-900/80 hover:border-neutral-700'
                }`}
              >
                {/* Number Key Indicator */}
                <span className="absolute top-0.5 left-1 text-[8px] sm:text-[9px] font-mono text-neutral-400 font-bold">
                  {idx + 1}
                </span>

                {slot ? (
                  <>
                    <span className="text-[10px] sm:text-xs font-semibold text-neutral-100 truncate px-0.5 text-center w-full">
                      {slot.item.name.split(' ')[0]}
                    </span>
                    {slot.count > 1 && (
                      <span className="absolute bottom-0.5 right-1 font-mono text-[9px] sm:text-[10px] font-bold text-amber-300">
                        x{slot.count}
                      </span>
                    )}
                  </>
                ) : (
                  <span className="text-neutral-700 text-xs font-mono">-</span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
