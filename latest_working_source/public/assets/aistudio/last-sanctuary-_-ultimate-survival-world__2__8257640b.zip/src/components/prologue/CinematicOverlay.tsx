import React from 'react';
import { FastForward, Radio, Shield, User, Heart, Sparkles, MapPin } from 'lucide-react';
import { PrologueSubtitle, ProloguePhase } from '../../types/prologue';

interface CinematicOverlayProps {
  phase: ProloguePhase;
  subtitle: PrologueSubtitle | null;
  titleBanner: { title: string; subtitle: string; day: string } | null;
  objective: string | null;
  onSkipScene: () => void;
  onSkipPrologue: () => void;
}

export const CinematicOverlay: React.FC<CinematicOverlayProps> = ({
  phase,
  subtitle,
  titleBanner,
  objective,
  onSkipScene,
  onSkipPrologue,
}) => {
  const isCinematicMode =
    phase === 'intro_cinematic' ||
    phase === 'ch7_the_meteorite' ||
    phase === 'ch13_the_world_awaits' ||
    phase === 'day2_meteorite_cinematic' ||
    phase === 'day2_impact_aftermath' ||
    phase === 'day2_final_cinematic';

  if (phase === 'completed' && !subtitle && !objective) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-40 flex flex-col justify-between overflow-hidden select-none font-sans">
      {/* Top Letterbox Bar */}
      <div
        className={`w-full bg-black transition-all duration-700 ease-in-out ${
          isCinematicMode ? 'h-14 md:h-20' : 'h-0'
        }`}
      />

      {/* Top Bar Controls & Objective Banner */}
      <div className="relative z-50 flex w-full items-start justify-between p-4 md:p-6">
        {/* Objective Toast */}
        {objective && phase !== 'completed' && (
          <div className="pointer-events-auto flex items-center gap-2.5 rounded-xl border border-amber-500/30 bg-neutral-950/85 px-4 py-2 text-xs md:text-sm text-neutral-100 shadow-xl backdrop-blur-sm animate-fade-in">
            <span className="flex h-2 w-2 rounded-full bg-amber-400" />
            <span className="font-semibold text-amber-400 uppercase tracking-wider text-[11px]">
              {phase.startsWith('day1') ? 'DAY 1 OBJECTIVE' : 'DAY 2 OBJECTIVE'}:
            </span>
            <span className="text-neutral-200 font-medium">{objective}</span>
          </div>
        )}

        {/* Skip Options Button Group */}
        {phase !== 'completed' && (
          <div className="pointer-events-auto ml-auto flex items-center gap-2">
            {isCinematicMode && (
              <button
                onClick={onSkipScene}
                className="flex items-center gap-1.5 rounded-lg border border-neutral-700 bg-neutral-900/80 px-3 py-1.5 text-xs font-semibold text-neutral-300 hover:bg-neutral-800 hover:text-white transition-all cursor-pointer shadow-lg"
              >
                <FastForward className="h-3.5 w-3.5" />
                <span>Skip Scene</span>
              </button>
            )}
            <button
              onClick={onSkipPrologue}
              className="flex items-center gap-1.5 rounded-lg border border-amber-600/40 bg-amber-950/60 hover:bg-amber-900/80 px-3 py-1.5 text-xs font-bold text-amber-300 transition-all cursor-pointer shadow-lg"
              title="Jump straight to underground shelter and open-world survival"
            >
              <Shield className="h-3.5 w-3.5" />
              <span>Skip Prologue</span>
            </button>
          </div>
        )}
      </div>

      {/* Center Grand Title Banner (Final Cinematic) */}
      {titleBanner && (
        <div className="flex flex-col items-center justify-center text-center px-4 py-8 animate-fade-in">
          <div className="rounded-full border border-amber-500/40 bg-amber-500/10 px-4 py-1 text-xs font-mono font-bold tracking-widest text-amber-400 uppercase mb-3">
            {titleBanner.day}
          </div>
          <h1 className="text-4xl md:text-6xl font-black tracking-widest text-neutral-100 drop-shadow-2xl">
            {titleBanner.title}
          </h1>
          <h2 className="text-lg md:text-2xl font-bold tracking-widest text-rose-500 uppercase mt-2">
            {titleBanner.subtitle}
          </h2>
        </div>
      )}

      {/* Bottom Subtitle / Dialogue Dialogue Card */}
      <div className="relative z-50 flex flex-col items-center justify-end p-4 md:p-8">
        {subtitle && (
          <div className="pointer-events-auto max-w-xl rounded-2xl border border-neutral-800 bg-neutral-950/90 p-4 md:p-5 shadow-2xl backdrop-blur-md transition-all">
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                {subtitle.speaker}
              </span>
              {subtitle.role && (
                <span className="rounded bg-neutral-800 px-2 py-0.5 text-[10px] font-semibold text-neutral-400">
                  {subtitle.role}
                </span>
              )}
            </div>
            <p className="text-sm md:text-base font-normal text-neutral-100 leading-relaxed">
              "{subtitle.text}"
            </p>
          </div>
        )}
      </div>

      {/* Bottom Letterbox Bar */}
      <div
        className={`w-full bg-black transition-all duration-700 ease-in-out ${
          isCinematicMode ? 'h-14 md:h-20' : 'h-0'
        }`}
      />
    </div>
  );
};
